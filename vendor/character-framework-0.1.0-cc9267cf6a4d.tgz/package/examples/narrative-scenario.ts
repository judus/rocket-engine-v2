import { createScenario } from './scenario.js';
import { QuestDraft } from '../src/index.js';
import type {
  Capability,
  CharacterDefinition,
  Condition,
  ContextInput,
  Json,
  NarrativeResult,
  ObjectiveTemplate,
} from '../src/index.js';

/** Fake game owns visits. The framework owns every quest and dialogue choice. */
export function createNarrativeScenario() {
  const visits = new Set<string>();
  let unavailable = false;
  const locations = (character: CharacterDefinition) =>
    character.id === 'director' ? ['grove-1', 'river-town'] : ['grove-1'];
  const locationArguments = (input: Json): input is { [key: string]: Json } =>
    input !== null &&
    typeof input === 'object' &&
    !Array.isArray(input) &&
    Object.keys(input).length === 2 &&
    input['playerRef'] === 'player-1' &&
    typeof input['locationRef'] === 'string';
  const capability: Capability = {
    name: 'game_inspect_location',
    kind: 'inspection',
    description: 'Inspect an authoritative player visit fact.',
    inputSchema: {
      type: 'object',
      properties: {
        playerRef: { type: 'string' },
        locationRef: { type: 'string' },
      },
      required: ['playerRef', 'locationRef'],
      additionalProperties: false,
    },
    validate: locationArguments,
    execute: (context, input) => {
      if (unavailable)
        return { status: 'running', operationId: 'location-data-pending' };
      if (
        !locationArguments(input) ||
        typeof input['locationRef'] !== 'string' ||
        !locations(context.character).includes(input['locationRef'])
      )
        return {
          status: 'rejected',
          code: 'entity_unavailable',
          message: 'Location is not accessible.',
        };
      return {
        status: 'completed',
        data: { visited: visits.has(input['locationRef']) },
      };
    },
  };
  const foundation = createScenario(10, [capability], {
    objectiveTemplates: () => [visitTemplate],
    capabilities: (character) =>
      character.capabilities.includes(capability.name) ? [capability] : [],
    recipientAvailable: (_, recipientRef) => recipientRef === 'player-1',
    referencesAvailable: (character, condition: Condition) =>
      locationArguments(condition.arguments) &&
      typeof condition.arguments['locationRef'] === 'string' &&
      locations(character).includes(condition.arguments['locationRef']),
    inspectContext: (
      character: CharacterDefinition,
      input: ContextInput,
    ): NarrativeResult => {
      const scope = character.id === 'director' ? 'world' : 'local';
      if (input.scope === 'world' && scope !== 'world')
        return {
          status: 'rejected',
          code: 'scope_denied',
          message: 'World inspection is not granted.',
          issues: [],
        };
      const entities = [
        ...locations(character).map((ref) => ({
          ref,
          kind: 'location',
          name: ref === 'grove-1' ? 'Old Grove' : 'River Town',
        })),
        { ref: 'player-1', kind: 'player', name: 'The player' },
      ];
      if (
        input.entityRefs?.some(
          (ref) => !entities.some((entity) => entity.ref === ref),
        )
      )
        return {
          status: 'rejected',
          code: 'entity_unavailable',
          message: 'Entity is unavailable.',
          issues: [],
        };
      return {
        status: 'completed',
        data: {
          characterRef: character.id,
          role: character.id === 'director' ? 'director' : 'actor',
          entityRef: character.entityId ?? null,
          scope: input.scope,
          revision: visits.size,
          facts: [
            { ref: 'winter-shortage', summary: 'Firewood stocks are low.' },
          ],
          entities: entities.filter(
            (entity) =>
              !input.entityRefs || input.entityRefs.includes(entity.ref),
          ),
          capabilities: [
            {
              name: capability.name,
              description: capability.description,
              kind: capability.kind,
              inputSchema: capability.inputSchema,
            },
          ],
          truncated: false,
        },
      };
    },
  });
  const narrative = foundation.runtime.narrative;
  if (!narrative) throw new Error('Narrative service expected');
  const foresterNarrative = narrative.bind(foundation.forester);
  const directorNarrative = narrative.bind(foundation.director);
  const visitTemplate: ObjectiveTemplate = {
    name: 'visit_location',
    description: 'Ask the player to visit an accessible location.',
    inputSchema: {
      type: 'object',
      properties: { id: { type: 'string' }, locationRef: { type: 'string' } },
      required: ['id', 'locationRef'],
      additionalProperties: false,
    },
    build: (recipientRef, input) => {
      if (
        input === null ||
        typeof input !== 'object' ||
        Array.isArray(input) ||
        Object.keys(input).length !== 2 ||
        typeof input['id'] !== 'string' ||
        typeof input['locationRef'] !== 'string'
      )
        throw new TypeError('Invalid visit template arguments');
      return {
        id: input['id'],
        description: `Visit ${input['locationRef']}.`,
        condition: {
          tool: capability.name,
          arguments: {
            playerRef: recipientRef,
            locationRef: input['locationRef'],
          },
          expect: { path: ['visited'], operator: 'equals', value: true },
        },
      };
    },
  };
  const draft = (title: string, location: string) =>
    new QuestDraft(
      {
        recipientRef: 'player-1',
        title,
        summary: 'Discover the winter story.',
      },
      [visitTemplate],
    ).addStep('visit_location', { id: 'visit', locationRef: location });
  const advance = (seconds: number) => {
    foundation.runtime.advance(seconds);
  };
  const dispose = () => {
    foundation.runtime.dispose();
  };
  return {
    ...foundation,
    narrative,
    foresterNarrative,
    directorNarrative,
    visitTemplate,
    draft,
    advance,
    dispose,
    visit: (location: string) => {
      if (!['grove-1', 'river-town'].includes(location))
        throw new TypeError('Unknown fake location');
      visits.add(location);
    },
    setUnavailable: (value: boolean) => {
      unavailable = value;
    },
    gameSave: () => [...visits],
    gameRestore: (saved: readonly string[]) => {
      visits.clear();
      for (const location of saved) visits.add(location);
    },
  };
}
