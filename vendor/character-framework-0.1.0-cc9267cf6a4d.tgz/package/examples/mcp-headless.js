import { randomUUID } from 'node:crypto';
import { createMcpScenario } from '../dist/examples/mcp-scenario.js';
import { FakeCaiClient } from './fake-cai-client.js';
import { record } from '../dist/src/narrative/validation.js';

const credential = randomUUID();
const scenario = createMcpScenario(credential);
const url = new URL('http://127.0.0.1:8094/mcp');
const localFetch = (target, init) =>
  scenario.gateway.handle(new Request(target, init));
const forester = new FakeCaiClient(
  url,
  scenario.foresterHeaders,
  credential,
  localFetch,
);
const director = new FakeCaiClient(
  url,
  scenario.directorHeaders,
  credential,
  localFetch,
);
const timer = setInterval(() => {
  scenario.advance();
}, 10);
try {
  await Promise.all([forester.connect(), director.connect()]);
  const discoveries = await Promise.all([
    forester.client.listTools(),
    director.client.listTools(),
  ]);
  console.log(
    'Scoped MCP tools:',
    discoveries.map((entry) => entry.tools.map((tool) => tool.name)),
  );
  for (const [client, location, title] of [
    [forester, 'grove-1', 'Survey the Old Grove'],
    [director, 'river-town', 'Winter across the valley'],
  ]) {
    const identity = {
      callId: `author-${location}`,
      turnId: 'initial-story',
      effectKey: `create-${location}`,
    };
    const created = await client.call(
      'create_quest',
      scenario.draft(title, location).toInput(),
      identity,
    );
    const replayed = await client.call(
      'create_quest',
      scenario.draft(title, location).toInput(),
      identity,
    );
    const data = created.structuredContent?.['data'];
    if (!record(data) || typeof data['questId'] !== 'string')
      throw new Error('Expected committed quest');
    console.log(
      'Committed create and replay:',
      created.structuredContent,
      replayed.structuredContent,
    );
    const offered = await client.call(
      'offer_quest',
      {
        questId: data['questId'],
        recipientRef: 'player-1',
        dialogue: 'Will you discover this winter story?',
      },
      {
        callId: `offer-${location}`,
        turnId: 'initial-story',
        effectKey: `offer-${location}`,
      },
    );
    const offerData = offered.structuredContent?.['data'];
    if (!record(offerData) || typeof offerData['offerId'] !== 'string')
      throw new Error('Expected committed offer');
    await scenario.narrative.choose(
      'player-1',
      `${offerData['offerId']}/accept`,
      `player-${location}`,
    );
    scenario.visit(location);
    // Host observations commit during subsequent advances; inspection cannot invent progress.
    await new Promise((resolve) => {
      setTimeout(resolve, 40);
    });
    console.log(
      'Confirmed quest:',
      (
        await client.call(
          'inspect_quest',
          { questId: data['questId'], recipientRef: 'player-1' },
          { callId: `inspect-${location}`, turnId: 'progress' },
        )
      ).structuredContent,
    );
  }
  console.log(
    'Framework facts and receipts:',
    scenario.narrative.stats,
    scenario.gateway.saveReceipts().receipts.length,
  );
} finally {
  clearInterval(timer);
  await Promise.all([forester.close(), director.close()]);
  await scenario.dispose();
}
