import { CaiHostDriver, CharacterHostPort } from '../src/host/index.js';
import { readFile, stat } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { setTimeout } from 'node:timers/promises';
import {
  CaiHttpBackend,
  CaiConversation,
  CaiBindingPublication,
  connectCaiConversation,
} from '../src/cai/index.js';
import type { CaiConversationSave, CaiBindingSave } from '../src/cai/index.js';
import { shape, record, integer, text } from '../src/narrative/validation.js';

const useHostDriver = process.env['CFW_ADAPTER_USE_HOST_DRIVER'] === '1';
let driver: CaiHostDriver | undefined;
let port: CharacterHostPort | undefined;
let stage = 'configuration';
let conversation: CaiConversation | undefined;
let seed: CaiConversation | undefined;
let publication: CaiBindingPublication | undefined;
try {
  const path = process.env['CFW_ADAPTER_CONFIG'];
  if (!path || (await stat(path)).mode % 512 !== 384)
    throw new Error('Private config required');
  const bytes = await readFile(path, 'utf8');
  if (Buffer.byteLength(bytes) > 16384) throw new Error('Config limit');
  const config: unknown = JSON.parse(bytes);
  if (
    !shape(config, [
      'caiOrigin',
      'caiToken',
      'characterId',
      'bindingKey',
      'cfwControlUrl',
      'cfwCredential',
    ]) ||
    !text(config['caiOrigin'], 1000) ||
    !text(config['caiToken'], 4096) ||
    !integer(config['characterId']) ||
    config['characterId'] < 1 ||
    !text(config['bindingKey']) ||
    !text(config['cfwControlUrl'], 1000) ||
    !text(config['cfwCredential'], 4096)
  )
    throw new Error('Invalid config');
  for (const origin of [config['caiOrigin'], config['cfwControlUrl']]) {
    const url = new URL(origin);
    if (
      url.protocol !== 'http:' ||
      url.hostname !== '127.0.0.1' ||
      url.username ||
      url.password
    )
      throw new Error('Isolated loopback API required');
  }
  const controlUrl = config['cfwControlUrl'];
  const controlCredential = config['cfwCredential'];
  const signal = AbortSignal.timeout(120000);
  const control = async (
    operation: string,
    input?: Record<string, unknown>,
  ): Promise<Record<string, unknown>> => {
    const response = await fetch(controlUrl + '/' + operation, {
      method: input ? 'POST' : 'GET',
      signal,
      redirect: 'error',
      headers: {
        Authorization: 'Bearer ' + controlCredential,
        'Content-Type': 'application/json',
      },
      ...(input ? { body: JSON.stringify(input) } : {}),
    });
    if (!response.ok) throw new Error('Control failed');
    const encoded = await response.text();
    if (Buffer.byteLength(encoded) > 524288)
      throw new Error('Control result limit');
    const value: unknown = JSON.parse(encoded);
    if (!record(value)) throw new Error('Invalid control result');
    return value;
  };
  const state = await control('state');
  if (!Array.isArray(state['quests']) || state['quests'].length !== 0)
    throw new Error('Fresh world required');
  const backend = new CaiHttpBackend({
    origin: config['caiOrigin'],
    token: config['caiToken'],
    enableGameDraft: true,
  });
  let checkpoint: CaiConversationSave | undefined;
  let bindingCheckpoint: CaiBindingSave | undefined;
  const persist = (save: CaiConversationSave) => {
    checkpoint = JSON.parse(JSON.stringify(save)) as CaiConversationSave;
  };
  stage = 'attach';
  seed = await CaiConversation.attach(
    backend,
    {
      characterId: String(config['characterId']),
      bindingKey: config['bindingKey'],
    },
    signal,
    () => undefined,
    persist,
  );
  persist(seed.save());
  const sessionId = Number(seed.save().session.id);
  if (!Number.isSafeInteger(sessionId) || sessionId < 1)
    throw new Error('Numeric session required');
  const bound = await control('bind', {
    sessionId,
    characterId: config['characterId'],
  });
  if (
    !record(bound['headers']) ||
    !text(bound['headers']['X-CF-Binding-Generation'])
  )
    throw new Error('Invalid host binding');
  const generation = bound['headers']['X-CF-Binding-Generation'];
  stage = 'publication';
  publication = new CaiBindingPublication(
    backend,
    {
      schemaVersion: 1,
      sessionId: String(sessionId),
      bindingKey: config['bindingKey'],
      acceptedGeneration: seed.save().session.bindingGeneration ?? null,
      pending: null,
    },
    (save) => {
      bindingCheckpoint = JSON.parse(JSON.stringify(save)) as CaiBindingSave;
    },
  );
  await publication.publish(generation);
  stage = 'confirmation';
  conversation = await connectCaiConversation({
    backend,
    publication,
    generation,
    saved: seed.save(),
    signal,
    current: () => undefined,
    persist,
  });
  seed.dispose();
  if (useHostDriver) {
    driver = new CaiHostDriver({
      backend,
      saved: {
        schemaVersion: 1,
        conversation: conversation.save(),
        operations: [],
      },
      current: () => {
        if (
          publication?.status.pending ||
          publication?.status.acceptedGeneration !== generation
        )
          throw new Error('Host publication changed');
      },
      persist: (saved) => {
        checkpoint = JSON.parse(
          JSON.stringify(saved.conversation),
        ) as CaiConversationSave;
      },
    });
    port = new CharacterHostPort(driver, () => undefined);
  }
  stage = 'quest-turn';
  const request =
    'Inspect the local situation, create one grove survey quest for player-1 and offer it.';
  if (port)
    await port.dispatch({
      kind: 'dialogue',
      requestId: randomUUID(),
      expectedRevision: port.read().revision,
      message: request,
    });
  else await conversation.requestNarrative(request);
  const offered = await control('state');
  const quests: unknown = offered['quests'];
  if (
    !Array.isArray(quests) ||
    quests.length !== 1 ||
    !record(quests[0]) ||
    quests[0]['status'] !== 'offered' ||
    !text(quests[0]['questId'])
  )
    throw new Error('One offered quest required');
  const questId = quests[0]['questId'];
  stage = 'host-completion';
  await control('accept', { effectKey: randomUUID() });
  await control('complete', {});
  let completion: Record<string, unknown> | undefined;
  for (let i = 0; i < 50; i++) {
    const world = await control('state');
    if (Array.isArray(world['events']))
      completion = world['events'].find(
        (event: unknown): event is Record<string, unknown> =>
          record(event) && event['type'] === 'quest_completed',
      );
    if (completion) break;
    await setTimeout(20);
  }
  if (!completion || !text(completion['id']))
    throw new Error('Completion event missing');
  stage = 'feedback-followup';
  const feedback = {
    sourceId: completion['id'],
    type: 'quest_completed',
    origin: 'game_outcome' as const,
    summary: 'The game confirms the grove survey quest is completed.',
    references: { quest_id: questId },
  };
  if (driver && port) {
    await driver.persistFeedback(feedback);
    await port.dispatch({
      kind: 'dialogue',
      requestId: randomUUID(),
      expectedRevision: port.read().revision,
      message: 'I completed the survey.',
    });
  } else {
    conversation.enqueueFeedback(feedback);
    persist(conversation.save());
    await conversation.dialogue('I completed the survey.');
  }
  if (
    !checkpoint ||
    checkpoint.pending ||
    !bindingCheckpoint ||
    bindingCheckpoint.pending
  )
    throw new Error('Unsettled proof checkpoint');
  console.log(
    JSON.stringify({
      proof: 'actual-CFW-HTTP-adapter',
      quests: 1,
      completed: true,
      confirmedGeneration: true,
      checkpointVersion: checkpoint.session.version,
      provider: 'CAI-owned-test-bootstrap',
      ...(useHostDriver
        ? { hostDriver: true, presentedMessages: port?.read().messages.length }
        : {}),
    }),
  );
} catch {
  console.error('CFW adapter proof failed at ' + stage);
  process.exitCode = 1;
} finally {
  port?.dispose();
  driver?.dispose();
  conversation?.dispose();
  seed?.dispose();
  publication?.dispose();
}
