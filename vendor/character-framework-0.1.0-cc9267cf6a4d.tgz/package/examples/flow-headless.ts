import { QuestDraft } from '../src/index.js';
import type { Json, NarrativeResult } from '../src/index.js';
import { createNarrativeScenario } from './narrative-scenario.js';

const scenario = createNarrativeScenario();
async function commit(request: Promise<NarrativeResult>) {
  scenario.advance(0);
  const result = await request;
  if (result.status !== 'completed') throw new Error(JSON.stringify(result));
  return result.data as Record<string, Json>;
}
async function poll() {
  for (let i = 0; i < 6; i++) {
    scenario.advance(0.1);
    await new Promise<void>((resolve) => setImmediate(resolve));
  }
}
try {
  const draft = new QuestDraft(
    {
      recipientRef: 'player-1',
      title: 'A winter route',
      summary: 'Choose who needs help.',
      flow: {
        start: 'survey',
        stages: [
          {
            id: 'survey',
            objectives: ['survey'],
            dialogue: 'Which place should we help?',
            choices: [
              { id: 'town', label: 'Help River Town', next: 'town' },
              { id: 'grove', label: 'Stay in the grove', next: 'grove' },
            ],
          },
          { id: 'town', objectives: ['town'] },
          { id: 'grove', objectives: ['grove'] },
        ],
      },
    },
    [scenario.visitTemplate],
  )
    .addStep('visit_location', { id: 'survey', locationRef: 'grove-1' })
    .addStep('visit_location', { id: 'town', locationRef: 'river-town' })
    .addStep('visit_location', { id: 'grove', locationRef: 'grove-1' });
  const created = await commit(
    scenario.directorNarrative.call('create_quest', draft.toInput(), 'create'),
  );
  const questId = created['questId'];
  if (typeof questId !== 'string') throw new Error('Quest ID expected');
  const offer = await commit(
    scenario.directorNarrative.call(
      'offer_quest',
      { questId, recipientRef: 'player-1', dialogue: 'Help with winter?' },
      'offer',
    ),
  );
  const offerId = offer['offerId'];
  if (typeof offerId !== 'string') throw new Error('Offer ID expected');
  await commit(
    scenario.narrative.choose('player-1', offerId + '/accept', 'accept'),
  );
  scenario.visit('grove-1');
  await poll();
  const waiting = await commit(
    scenario.directorNarrative.call('inspect_quest', {
      questId,
      recipientRef: 'player-1',
    }),
  );
  console.log('Waiting for the player:', waiting['flow'], waiting['choices']);
  const choices = waiting['choices'];
  const choice = Array.isArray(choices) ? choices[0] : undefined;
  if (
    !choice ||
    typeof choice !== 'object' ||
    Array.isArray(choice) ||
    typeof choice['id'] !== 'string'
  )
    throw new Error('Player choice expected');
  await commit(scenario.narrative.choose('player-1', choice['id'], 'route'));
  scenario.visit('river-town');
  await poll();
  const completed = await commit(
    scenario.directorNarrative.call('inspect_quest', {
      questId,
      recipientRef: 'player-1',
    }),
  );
  if (completed['status'] !== 'completed')
    throw new Error('Quest did not complete');
  scenario.narrative.restore(
    JSON.parse(JSON.stringify(scenario.narrative.save())) as unknown,
  );
  console.log(
    'Completed selected path:',
    completed['flow'],
    completed['objectives'],
  );
} finally {
  scenario.dispose();
}
