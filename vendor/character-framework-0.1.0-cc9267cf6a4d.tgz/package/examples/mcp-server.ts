import { writeFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { createMcpScenario } from './mcp-scenario.js';
import { createMcpHttpServer } from './mcp-http.js';

const authority = '127.0.0.1:8094';
const credential = process.env['CF_MCP_KEY'] ?? randomBytes(32).toString('hex');
const scenario = createMcpScenario(credential, authority);
const server = createMcpHttpServer(scenario.gateway, authority);
// Keep the private fixture under /tmp, never in browser-served assets or logs.
const configPath =
  process.env['CF_MCP_CONFIG_PATH'] ??
  `/tmp/character-framework-mcp-${randomBytes(6).toString('hex')}.json`;
await writeFile(
  configPath,
  JSON.stringify(
    {
      url: `http://${authority}/mcp`,
      credential,
      forester: scenario.foresterHeaders,
      director: scenario.directorHeaders,
    },
    null,
    2,
  ),
  { mode: 0o600, flag: 'wx' },
);
const timer = setInterval(() => {
  scenario.advance();
}, 20);
server.listen(8094, '127.0.0.1', () => {
  console.log(
    `MCP fake-game server: http://${authority}/mcp\nPrivate connection fixture: ${configPath}`,
  );
});
const stop = () => {
  clearInterval(timer);
  server.close();
  void scenario.dispose().catch(() => {
    process.exitCode = 1;
  });
};
process.once('SIGINT', stop);
process.once('SIGTERM', stop);
server.on('error', (error) => {
  console.error(`MCP server failed: ${error.message}`);
  process.exitCode = 1;
  stop();
});
