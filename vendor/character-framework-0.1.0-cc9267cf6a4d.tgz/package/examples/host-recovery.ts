import assert from 'node:assert/strict';
import { CharacterHostPort } from '../src/host/index.js';
import type { HostDriver } from '../src/host/index.js';
let lose = true;
const attempts: { id: string; effect: string }[] = [];
const driver: HostDriver = {
  current() {},
  choices: () => [],
  run: (id, effect) => {
    attempts.push({ id, effect });
    if (id === 'last' && lose) {
      lose = false;
      return Promise.reject(new Error('simulated lost reply'));
    }
    return Promise.resolve('Retained offline reply');
  },
};
const original = new CharacterHostPort(driver, () => {});
for (let i = 0; i < 127; i++)
  await original.dispatch({
    kind: 'dialogue',
    requestId: 'completed-' + String(i),
    expectedRevision: original.read().revision,
    message: 'Hello',
  });
await assert.rejects(
  original.dispatch({
    kind: 'dialogue',
    requestId: 'last',
    expectedRevision: original.read().revision,
    message: 'Hello',
  }),
  /lost reply/,
);
const restored = new CharacterHostPort(
  driver,
  () => {},
  JSON.parse(JSON.stringify(original.save())) as unknown,
);
assert.deepEqual(restored.read().commands, ['replay', 'stop_waiting']);
await restored.dispatch({ kind: 'replay', operationId: 'last' });
const recent = attempts.slice(-2);
assert.deepEqual(recent[0], recent[1]);
const calls = attempts.length;
await restored.dispatch({ kind: 'replay', operationId: 'last' });
assert.equal(attempts.length, calls);
assert.equal(restored.save().deliveries.length, 128);
assert.equal(
  restored.read().messages.filter((message) => message.id === 'last/player')
    .length,
  1,
);
console.log(
  JSON.stringify({
    offline: true,
    saturatedDeliveries: 128,
    restoredReplay: true,
    originalEffectRetained: true,
    completedReplayNoDispatch: true,
    historyPublishedOnce: true,
  }),
);
original.dispose();
restored.dispose();
