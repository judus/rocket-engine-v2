import { CharacterRuntime } from '../src/index.js';
import type { Capability, Json, NarrativeResult } from '../src/index.js';
import { record } from '../src/narrative/validation.js';

/** A second tiny host: station systems rather than woodland visits. No game engine imports. */
export function createStationScenario() {
  const systems = new Map([
    ['oxygen-loop', 20],
    ['reactor', 90],
  ]);
  const inspection: Capability = {
    name: 'station_inspect_system',
    kind: 'inspection',
    description: 'Read authoritative station system efficiency.',
    inputSchema: {
      type: 'object',
      properties: {
        systemRef: { type: 'string', enum: ['oxygen-loop', 'reactor'] },
      },
      required: ['systemRef'],
      additionalProperties: false,
    },
    validate: (input: Json) =>
      record(input) &&
      Object.keys(input).length === 1 &&
      typeof input['systemRef'] === 'string' &&
      systems.has(input['systemRef']),
    execute: (context, input) => {
      if (
        !record(input) ||
        typeof input['systemRef'] !== 'string' ||
        (context.character.id !== 'director' &&
          input['systemRef'] !== 'oxygen-loop')
      )
        return {
          status: 'rejected',
          code: 'system_unavailable',
          message: 'System is not accessible.',
        };
      return {
        status: 'completed',
        data: { efficiency: systems.get(input['systemRef']) ?? null },
      };
    },
  };
  const runtime = new CharacterRuntime({
    gameId: 'station-example',
    capabilities: [inspection],
    reasoning: { decide: () => ({ dialogue: 'The station needs air.' }) },
    narrativeGame: {
      capabilities: () => [inspection],
      recipientAvailable: (_, recipient) => recipient === 'crew-player',
      referencesAvailable: (character, condition) =>
        inspection.validate(condition.arguments) &&
        (character.id === 'director' ||
          condition.arguments['systemRef'] === 'oxygen-loop'),
      inspectContext: (character, input): NarrativeResult =>
        input.scope === 'world' && character.id !== 'director'
          ? {
              status: 'rejected',
              code: 'scope_denied',
              message: 'World scope is unavailable.',
              issues: [],
            }
          : {
              status: 'completed',
              data: {
                characterRef: character.id,
                role: character.id === 'director' ? 'director' : 'actor',
                entityRef: character.entityId ?? null,
                scope: input.scope,
                revision: 0,
                facts: [
                  {
                    ref: 'air-shortage',
                    summary: 'The oxygen loop is operating poorly.',
                  },
                ],
                entities: [
                  { ref: 'oxygen-loop', kind: 'machine', name: 'Oxygen loop' },
                  { ref: 'crew-player', kind: 'player', name: 'Crew operator' },
                ],
                capabilities: [
                  {
                    name: inspection.name,
                    description: inspection.description,
                    kind: inspection.kind,
                    inputSchema: inspection.inputSchema,
                  },
                ],
                truncated: false,
              },
            },
    },
  });
  const mechanic = runtime.register({
    id: 'mechanic',
    name: 'Ivo',
    entityId: 'maintenance-bot',
    capabilities: [inspection.name],
  });
  const director = runtime.register({
    id: 'director',
    name: 'Station lore director',
    capabilities: [inspection.name],
  });
  const narrative = runtime.narrative;
  if (!narrative) throw new Error('Narrative service required');
  return {
    runtime,
    narrative,
    mechanic: narrative.bind(mechanic),
    director: narrative.bind(director),
    repair: (systemRef: string) => {
      if (!systems.has(systemRef)) throw new Error('Unknown system');
      systems.set(systemRef, 100);
    },
    advance: () => {
      runtime.advance(0);
    },
    dispose: () => {
      runtime.dispose();
    },
  };
}
