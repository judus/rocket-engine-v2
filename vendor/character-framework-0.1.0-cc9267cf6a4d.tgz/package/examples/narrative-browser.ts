import { createNarrativeScenario } from './narrative-scenario.js';
import type { NarrativeResult, NarrativeSave } from '../src/index.js';

const scenario = createNarrativeScenario();
let paused = false,
  storySequence = 0,
  lastTime = performance.now();
let checkpoint: { narrative: NarrativeSave; visits: readonly string[] } | null =
  null;
const history: unknown[] = [];
let display = '[]';
function element(id: string): HTMLElement {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Missing demo element: ${id}`);
  return node;
}
function record(value: unknown): void {
  history.unshift(value);
  history.length = Math.min(history.length, 40);
}
function resultData(result: NarrativeResult) {
  if (
    result.status !== 'completed' ||
    result.data === null ||
    typeof result.data !== 'object' ||
    Array.isArray(result.data)
  )
    throw new Error(
      result.status === 'rejected' ? result.message : 'Expected tool data',
    );
  return result.data;
}
function show(): void {
  if (
    scenario.narrative.stats.pendingCommands === 0 &&
    !scenario.narrative.stats.disposed
  ) {
    const saved = scenario.narrative.save();
    display = JSON.stringify(
      saved.quests.map((quest) => ({
        character: quest.authorRef,
        title: quest.definition.title,
        status: quest.offer?.status ?? 'registered',
        dialogue: quest.offer?.dialogue ?? null,
        objectives: quest.definition.objectives.map((objective) => ({
          description: objective.description,
          status:
            quest.progress.find((entry) => entry.id === objective.id)?.status ??
            'pending',
        })),
      })),
      null,
      2,
    );
  }
  element('stories').textContent = display;
  element('history').textContent = JSON.stringify(history, null, 2);
  element('status').textContent =
    `${String(scenario.narrative.stats.quests)} quests · ${String(scenario.narrative.stats.pendingCommands)} queued commands · ${String(scenario.narrative.stats.pendingInspections)} inspections · ${paused ? 'host paused' : 'host running'}`;
  element('pause').textContent = paused ? 'Resume host' : 'Pause host';
}
async function publish(role: 'forester' | 'director'): Promise<void> {
  const key = role + '/story-' + String(++storySequence);
  const handle =
    role === 'forester'
      ? scenario.foresterNarrative
      : scenario.directorNarrative;
  const draft = scenario.draft(
    role === 'forester' ? 'Survey the Old Grove' : 'Winter across the valley',
    'grove-1',
  );
  if (role === 'director')
    draft.addStep('visit_location', { id: 'town', locationRef: 'river-town' });
  const created = await handle.call(
    'create_quest',
    draft.toInput(),
    key + '/create',
  );
  record(created);
  const questId = resultData(created)['questId'];
  if (typeof questId !== 'string') throw new Error('Missing quest reference');
  record(
    await handle.call(
      'offer_quest',
      {
        questId,
        recipientRef: 'player-1',
        dialogue:
          role === 'forester'
            ? 'Will you survey the Old Grove for me?'
            : 'Winter is coming. Discover the stories of the grove and River Town.',
      },
      key + '/offer',
    ),
  );
}
async function choose(
  role: 'forester' | 'director',
  action: 'accept' | 'decline',
): Promise<void> {
  if (scenario.narrative.stats.pendingCommands)
    throw new Error('Wait for queued commands to commit.');
  const quest = scenario.narrative
    .save()
    .quests.find(
      (entry) => entry.authorRef === role && entry.offer?.status === 'offered',
    );
  if (!quest?.offer)
    throw new Error('No outstanding offer for this character.');
  record(
    await scenario.narrative.choose(
      'player-1',
      quest.offer.id + '/' + action,
      quest.offer.id + '/player-choice',
    ),
  );
}
function button(id: string, action: () => unknown): void {
  element(id).addEventListener('click', () => {
    void Promise.resolve()
      .then(action)
      .then(
        (value: unknown) => {
          if (value !== undefined) record(value);
          show();
        },
        (error: unknown) => {
          record({
            error: error instanceof Error ? error.message : 'Unknown error',
          });
          show();
        },
      );
  });
}
button('forester-create', () => publish('forester'));
button('director-create', () => publish('director'));
button('forester-accept', () => choose('forester', 'accept'));
button('forester-decline', () => choose('forester', 'decline'));
button('director-accept', () => choose('director', 'accept'));
button('director-decline', () => choose('director', 'decline'));
button('grove', () => {
  scenario.visit('grove-1');
  return { gameFact: 'Player visited the Old Grove.' };
});
button('town', () => {
  scenario.visit('river-town');
  return { gameFact: 'Player visited River Town.' };
});
button('unknown', () => {
  scenario.setUnavailable(true);
  return { gameFacts: 'Location data temporarily unavailable.' };
});
button('ready', () => {
  scenario.setUnavailable(false);
  return { gameFacts: 'Location data available again.' };
});
button('save', () => {
  checkpoint = {
    narrative: scenario.narrative.save(),
    visits: scenario.gameSave(),
  };
  return {
    checkpoint:
      'Saved framework state, receipts and fake game visits in memory.',
  };
});
button('restore', () => {
  if (!checkpoint) throw new Error('Save a checkpoint first.');
  scenario.narrative.restore(checkpoint.narrative);
  scenario.gameRestore(checkpoint.visits);
  return {
    checkpoint:
      'Restored narrative and fake game state. No effects re-executed.',
  };
});
button('pause', () => {
  paused = !paused;
  return { paused };
});
button('step', () => {
  scenario.advance(0.1);
  return { hostStep: 0.1 };
});
function frame(now: number): void {
  const seconds = Math.min((now - lastTime) / 1000, 0.1);
  lastTime = now;
  if (!paused) scenario.advance(seconds);
  for (const event of scenario.narrative.drainEvents()) record(event);
  show();
  requestAnimationFrame(frame);
}
window.addEventListener(
  'pagehide',
  () => {
    scenario.dispose();
  },
  { once: true },
);
show();
requestAnimationFrame(frame);
