import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { CharacterRuntime } from '../src/index.js';
import type { Capability, CapabilityResult, Json } from '../src/index.js';
import { CaiConversation } from '../src/cai/CaiConversation.js';
import type {
  CaiBackend,
  CaiEventInput,
  CaiSessionState,
} from '../src/cai/types.js';

// Local execution boundary proof. Decisions and CAI are canned, not a new CAI
// intention envelope. A real game exposes its admitted action through MCP tools.
let location = 'yard';
let finish: ((result: CapabilityResult) => void) | undefined;
const movement: Capability = {
  name: 'game_depart',
  kind: 'action',
  description:
    'Request departure to an eligible location. Admission is not arrival.',
  inputSchema: {
    type: 'object',
    properties: { target: { type: 'string' } },
    required: ['target'],
    additionalProperties: false,
  },
  validate: (input: Json) =>
    input !== null &&
    typeof input === 'object' &&
    !Array.isArray(input) &&
    Object.keys(input).length === 1 &&
    typeof input['target'] === 'string',
  execute: (_, input) => {
    if (
      input === null ||
      typeof input !== 'object' ||
      Array.isArray(input) ||
      input['target'] !== 'gate'
    )
      return {
        status: 'rejected',
        code: 'target_unavailable',
        message: 'Host rejected destination.',
      };
    return new Promise<CapabilityResult>((resolve) => {
      finish = resolve;
    });
  },
};
const runtime = new CharacterRuntime({
  gameId: 'intention-proof',
  capabilities: [movement],
  reasoning: {
    decide: () => ({
      dialogue: 'That insult crossed a line. I am leaving.',
      intention: { kind: 'game_depart', args: { target: 'gate' } },
    }),
  },
});
const actor = runtime.register({
  id: 'mara',
  name: 'Mara',
  entityId: 'worker-17',
  capabilities: ['game_depart'],
});
let session: CaiSessionState = {
  id: 'canned-session',
  characterId: 'canned-profile',
  bindingKey: 'mara',
  version: 0,
  mode: 'game',
  continuityMode: 'session',
  bindingGeneration: actor.snapshot().binding.generation,
};
const outcomes: CaiEventInput[] = [];
const backend: CaiBackend = {
  attach: () => Promise.resolve(session),
  event: (_, input) => {
    assert.equal(input.version, session.version);
    outcomes.push(structuredClone(input));
    session = { ...session, version: session.version + 1 };
    return Promise.resolve({
      eventId: input.event_id,
      version: session.version,
    });
  },
  turn: (_, input) => {
    assert.equal(input.version, session.version);
    assert.equal(input.origin, 'framework_request');
    assert.equal(outcomes.at(-1)?.type, 'arrival_confirmed');
    session = { ...session, version: session.version + 1 };
    return Promise.resolve({
      requestId: input.request_id,
      message: 'I reached the gate. We can speak later.',
      session,
    });
  },
};
const conversation = await CaiConversation.attach(
  backend,
  {
    characterId: session.characterId,
    bindingKey: session.bindingKey,
    sessionId: session.id,
  },
  new AbortController().signal,
  () => {
    actor.snapshot();
  },
);
async function boundary() {
  runtime.advance(0);
  await setImmediate();
  runtime.advance(0);
  return runtime.drainEvents();
}
try {
  assert.equal(
    actor.requestDecision({ event: 'insult', facts: 'Mara is at the yard.' })
      .status,
    'accepted',
  );
  await boundary();
  const proposal = actor.snapshot().lastDecision?.intention;
  assert.equal(proposal?.kind, movement.name);
  assert.equal(location, 'yard');
  assert.equal(actor.dispatch('ungranted_action', {}).status, 'rejected');
  assert.equal(
    actor.dispatch(movement.name, { target: 'forbidden' }).status,
    'accepted',
  );
  const denied = await boundary();
  assert.equal(actor.snapshot().lastCapabilityResult?.status, 'rejected');
  assert.equal(location, 'yard');
  assert.equal(outcomes.length, 0);
  const rejection = denied.find((event) => event.kind === 'capability');
  assert.ok(rejection);
  conversation.enqueueFeedback({
    sourceId: 'host-rejection/' + rejection.requestId,
    origin: 'game_outcome',
    type: 'departure_rejected',
    summary: 'The host rejected the destination. Mara remains at the yard.',
    references: { operation_id: rejection.requestId, actor_ref: 'worker-17' },
  });
  await conversation.flushFeedback();
  assert.equal(outcomes.length, 1);
  assert.equal(outcomes[0]?.type, 'departure_rejected');
  const admitted = actor.dispatch(movement.name, proposal.args);
  assert.equal(admitted.status, 'accepted');
  await boundary();
  assert.equal(location, 'yard');
  assert.equal(outcomes.length, 1);
  assert.notEqual(actor.snapshot().pendingCapability, null);
  // Only this host commit establishes arrival. No view or model updates location.
  location = 'gate';
  assert.ok(finish);
  finish({ status: 'completed', data: { location, arrived: true } });
  const completed = await boundary();
  const arrival = completed.find((event) => event.kind === 'capability');
  assert.ok(arrival);
  assert.equal(actor.snapshot().lastCapabilityResult?.status, 'completed');
  const feedback = {
    sourceId: 'host-arrival/' + arrival.requestId,
    origin: 'game_outcome' as const,
    type: 'arrival_confirmed',
    summary: 'Mara reached the gate after host-confirmed movement.',
    references: {
      operation_id: arrival.requestId,
      actor_ref: 'worker-17',
      location_ref: 'gate',
    },
  };
  conversation.enqueueFeedback(feedback);
  conversation.enqueueFeedback(feedback);
  await conversation.requestNarrative('React to the confirmed departure.', {
    facts: 'The host confirmed arrival at the gate.',
    actor_ref: 'worker-17',
  });
  assert.equal(outcomes.length, 2);
  assert.equal(conversation.save().session.version, 3);
  // Removal invalidates a late capability result; it cannot produce another event.
  actor.dispatch(movement.name, { target: 'gate' });
  await boundary();
  actor.unregister();
  assert.ok(finish);
  finish({ status: 'completed', data: { arrived: true } });
  const late = await boundary();
  assert.equal(late.filter((event) => event.kind === 'capability').length, 0);
  assert.equal(outcomes.length, 2);
  console.log(
    JSON.stringify({
      offline: true,
      cannedReasoning: true,
      proposalOnlyBeforeAdmission: true,
      rejectedTarget: denied.some((event) => event.kind === 'capability'),
      arrivalCommitted: location === 'gate',
      outcomeEvents: outcomes.length,
      checkpointVersion: conversation.save().session.version,
      lateResultSuppressed: true,
    }),
  );
} finally {
  conversation.dispose();
  runtime.dispose();
}
