import { CaiHostDriver, CharacterHostPort } from '../src/host/index.js';
import type { CaiHostDriverSave, HostPortSave } from '../src/host/index.js';
import { FakeCaiBackend } from './fake-cai-backend.js';
import type { CaiBackend } from '../src/cai/index.js';

const session = {
  id: 'demo-session-1',
  characterId: 'demo-profile-1',
  bindingKey: 'forester',
  version: 0,
  mode: 'game' as const,
  continuityMode: 'session' as const,
  bindingGeneration: 'G1',
};
const fake = new FakeCaiBackend(() => Promise.resolve(), [session]);
let lose = true,
  sends = 0;
const backend: CaiBackend = {
  attach: (input, signal) => fake.attach(input, signal),
  event: (id, input, signal) => fake.event(id, input, signal),
  turn: async (id, input, signal) => {
    sends++;
    const reply = await fake.turn(id, input, signal);
    if (lose) {
      lose = false;
      throw new Error('Simulated lost committed CAI reply');
    }
    return reply;
  },
};
let driverSaved: CaiHostDriverSave = {
  schemaVersion: 1,
  conversation: {
    schemaVersion: 1,
    session,
    pending: null,
    feedback: [],
    reported: [],
  },
  operations: [],
};
let portSaved: HostPortSave | undefined;
const createDriver = () =>
  new CaiHostDriver({
    backend,
    saved: driverSaved,
    current: () => undefined,
    persist: (saved) => {
      driverSaved = JSON.parse(JSON.stringify(saved)) as CaiHostDriverSave;
    },
  });
let driver = createDriver();
const createPort = () =>
  new CharacterHostPort(
    driver,
    (saved) => {
      portSaved = JSON.parse(JSON.stringify(saved)) as HostPortSave;
    },
    portSaved,
  );
let port = createPort();
try {
  await port
    .dispatch({
      kind: 'dialogue',
      requestId: 'ui-one',
      expectedRevision: 0,
      message: 'Hello Mara',
    })
    .then(
      () => {
        throw new Error('Expected lost reply');
      },
      (error: unknown) => {
        if (
          !(error instanceof Error) ||
          error.message !== 'Simulated lost committed CAI reply'
        )
          throw error;
      },
    );
  const original = driverSaved.operations[0]?.input?.request_id;
  port.dispose();
  driver.dispose();
  driver = createDriver();
  port = createPort();
  await port.dispatch({
    kind: 'retry',
    requestId: 'ui-retry',
    failedRequestId: 'ui-one',
  });
  const settledDriver = JSON.parse(
    JSON.stringify(driverSaved),
  ) as CaiHostDriverSave;
  if (
    !settledDriver.operations[0] ||
    settledDriver.operations[0].receipt?.requestId !== original ||
    settledDriver.conversation.session.version !== 1
  )
    throw new Error('Retry regenerated a CAI turn');
  // The driver has acknowledged CAI, while the port may still be pending at a
  // crash boundary. Its original receipt must remain usable with no new send.
  const known = await driver.run(
    'ui-one',
    settledDriver.operations[0].effectKey,
    { kind: 'dialogue', message: 'Hello Mara' },
  );
  if (!known || sends !== 2 || port.read().messages.length !== 2)
    throw new Error('Known reply replay changed effects');
  console.log(
    JSON.stringify({
      proof: 'actual-CaiConversation-host-driver-offline',
      restoredOriginalRequest: true,
      committedVersion: 1,
      backendSends: sends,
      messages: 2,
    }),
  );
} finally {
  port.dispose();
  driver.dispose();
}
