import { setImmediate } from 'node:timers/promises';
import { createNarrativeScenario } from './narrative-scenario.js';
import { FakeCaiBackend } from './fake-cai-backend.js';
import { McpGateway } from '../src/mcp/index.js';
import {
  CaiConversation,
  CaiBindingPublication,
  connectCaiConversation,
} from '../src/cai/index.js';
import type {
  CaiBackend,
  CaiBindingBackend,
  CaiConversationSave,
} from '../src/cai/index.js';
import { record } from '../src/narrative/validation.js';

// Offline orchestration example. CAI is canned; the shared world, quest state and
// gateway binding are real. No listener, browser credential or provider is used.
const world = createNarrativeScenario();
const key = 'forester/workforce-17';
const signal = new AbortController().signal;
let generation: string | null = null;
let loseReply = true;
let saved: CaiConversationSave | undefined;
const current = () => {
  world.forester.snapshot();
};
const persist = (state: CaiConversationSave) => {
  saved = structuredClone(state);
};
const fake = new FakeCaiBackend(
  async (_, requestId) => {
    const created = await world.foresterNarrative.call(
      'create_quest',
      world.draft('Survey the Old Grove', 'grove-1').toInput(),
      requestId + '/create',
    );
    if (
      created.status !== 'completed' ||
      !record(created.data) ||
      typeof created.data['questId'] !== 'string'
    )
      throw new Error('Quest creation failed');
    const offered = await world.foresterNarrative.call(
      'offer_quest',
      {
        questId: created.data['questId'],
        recipientRef: 'player-1',
        dialogue: 'Visit the grove?',
      },
      requestId + '/offer',
    );
    if (offered.status !== 'completed') throw new Error('Quest offer failed');
  },
  [
    {
      id: 'demo-session-1',
      characterId: 'demo-profile-1',
      bindingKey: key,
      version: 0,
      mode: 'game',
      continuityMode: 'session',
    },
  ],
);
const backend: CaiBackend & CaiBindingBackend = {
  attach: async (input, abort) => ({
    ...(await fake.attach(input, abort)),
    bindingGeneration: generation,
  }),
  publishBinding: async (sessionId, input, abort) => {
    abort.throwIfAborted();
    if (
      generation !== input.binding_generation &&
      generation !== input.expected_binding_generation
    )
      throw new Error('Binding conflict');
    const session = await fake.attach(
      { sessionId, characterId: 'demo-profile-1', bindingKey: key },
      abort,
    );
    generation = input.binding_generation;
    return { sessionId, bindingKey: key, generation, version: session.version };
  },
  turn: async (sessionId, input, abort) => {
    const receipt = await fake.turn(sessionId, input, abort);
    if (loseReply) {
      loseReply = false;
      throw new Error('Simulated committed dialogue reply loss');
    }
    return {
      ...receipt,
      session: { ...receipt.session, bindingGeneration: generation },
    };
  },
  event: (sessionId, input, abort) => fake.event(sessionId, input, abort),
};
async function pump<T>(promise: Promise<T>): Promise<T> {
  const status: { settled: boolean; value?: T; failure?: Error } = {
    settled: false,
  };
  void promise.then(
    (value) => {
      status.value = value;
      status.settled = true;
    },
    (error: unknown) => {
      status.failure =
        error instanceof Error ? error : new Error('Host operation failed');
      status.settled = true;
    },
  );
  for (let i = 0; i < 200 && !status.settled; i++) {
    world.advance(0.01);
    gateway.advance(0.01);
    await setImmediate();
  }
  if (!status.settled) throw new Error('Host operation did not settle');
  if (status.failure) throw status.failure;
  return status.value as T;
}
const seed = await CaiConversation.attach(
  backend,
  {
    characterId: 'demo-profile-1',
    bindingKey: key,
    sessionId: 'demo-session-1',
  },
  signal,
  current,
  persist,
);
persist(seed.save());
const gateway = new McpGateway({
  runtime: world.runtime,
  credential: 'offline-only-unused-key',
  allowedHosts: ['127.0.0.1:8096'],
});
const selectors = gateway.bind(
  key,
  world.forester,
  world.capabilities.filter((cap) => cap.name === 'game_inspect_location'),
);
const publication = new CaiBindingPublication(
  backend,
  {
    schemaVersion: 1,
    sessionId: seed.save().session.id,
    bindingKey: key,
    acceptedGeneration: null,
    pending: null,
  },
  () => undefined,
  current,
); // Volatile demo storage; production host persists this journal too.
await publication.publish(selectors['X-CF-Binding-Generation'] ?? '');
let conversation = await connectCaiConversation({
  backend,
  publication,
  generation: selectors['X-CF-Binding-Generation'] ?? '',
  saved: seed.save(),
  signal,
  current,
  persist,
});
seed.dispose();
try {
  await pump(conversation.requestNarrative('Create one quest.')).then(
    () => {
      throw new Error('Expected simulated reply loss');
    },
    (error: unknown) => {
      if (
        !(error instanceof Error) ||
        error.message !== 'Simulated committed dialogue reply loss'
      )
        throw error;
    },
  );
  if (!saved?.pending) throw new Error('Lost reply was not retained');
  conversation.dispose();
  conversation = new CaiConversation(
    backend,
    JSON.parse(JSON.stringify(saved)) as CaiConversationSave,
    current,
    persist,
  );
  await pump(conversation.retry()); // Exact saved request; canned backend returns original committed reply.
  const quests = world.narrative.save().quests;
  if (quests.length !== 1 || !quests[0]?.offer)
    throw new Error('Expected exactly one offer');
  await pump(
    world.narrative.choose(
      'player-1',
      quests[0].offer.id + '/accept',
      'host-choice-1',
    ),
  );
  world.visit('grove-1');
  for (let i = 0; i < 20; i++) {
    world.advance(0.01);
    await setImmediate();
  }
  const event = world.narrative
    .save()
    .events.find((item) => item.type === 'quest_completed');
  if (!event) throw new Error('Authoritative completion missing');
  conversation.enqueueFeedback({
    sourceId: event.id,
    type: event.type,
    origin: 'game_outcome',
    summary: 'The grove survey is complete.',
    references: {},
  });
  persist(conversation.save());
  const reply = await pump(conversation.dialogue('I completed the survey.'));
  if (!reply.includes('You did visit the grove'))
    throw new Error('Feedback was not consumed');
  console.log(
    JSON.stringify({
      mode: 'offline-canned-CAI',
      quests: world.narrative.save().quests.length,
      completed: true,
      exactDialogueReplay: true,
      reply,
    }),
  );
} finally {
  conversation.dispose();
  publication.dispose();
  await gateway.dispose();
  world.dispose();
}
