import { createScenario } from './scenario.js';
import type { RuntimeEvent } from '../src/index.js';

const scenario = createScenario();
let forester = scenario.forester;
const { runtime, director } = scenario;
let auto = true;
let lastTime = performance.now();
const history: unknown[] = [];
function element(id: string): HTMLElement {
  const found = document.getElementById(id);
  if (!found) throw new Error(`Missing demo element: ${id}`);
  return found;
}
function record(value: unknown): void {
  history.unshift(value);
  history.length = Math.min(history.length, 60);
}
function show(): void {
  element('stats').textContent = JSON.stringify(runtime.stats, null, 2);
  element('characters').textContent = JSON.stringify(
    runtime.characters(),
    null,
    2,
  );
  element('history').textContent = JSON.stringify(history, null, 2);
  element('toggle-auto').textContent = auto
    ? 'Pause host updates'
    : 'Resume host updates';
}
function tick(seconds: number): void {
  runtime.advance(seconds);
  for (const event of runtime.drainEvents())
    record(event satisfies RuntimeEvent);
  show();
}
function button(id: string, action: () => unknown): void {
  element(id).addEventListener('click', () => {
    try {
      record(action());
    } catch (error) {
      record({
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }
    show();
  });
}
button('think', () => ({
  forester: forester.requestDecision({
    event: 'work_available',
    jobId: 'forestry',
  }),
  director: director.requestDecision({ event: 'winter_shortage' }),
}));
button('inspect', () => ({
  forester: forester.dispatch('inspect_nearby', {}),
  director: director.dispatch('inspect_world', {}),
}));
button('forbidden', () => forester.dispatch('inspect_world', {}));
button('invalid', () => forester.dispatch('request_work', { jobId: 123 }));
button('rejected-job', () =>
  forester.dispatch('request_work', { jobId: 'warrior' }),
);
button('assign', () =>
  forester.dispatch('request_work', { jobId: 'forestry' }),
);
button('remove', () => ({ removed: forester.unregister() }));
button('register', () => {
  forester = scenario.registerForester();
  return { registered: 'forester', freshState: true };
});
button('step', () => {
  tick(0.1);
  return { hostStep: 0.1 };
});
button('toggle-auto', () => {
  auto = !auto;
  return { auto };
});
button('dispose', () => {
  auto = false;
  runtime.dispose();
  return { disposed: true };
});
function frame(now: number): void {
  const seconds = Math.min((now - lastTime) / 1000, 0.1);
  lastTime = now;
  if (auto && !runtime.stats.disposed) tick(seconds);
  requestAnimationFrame(frame);
}
window.addEventListener(
  'pagehide',
  () => {
    auto = false;
    runtime.dispose();
  },
  { once: true },
);
show();
requestAnimationFrame(frame);
