import { createNarrativeScenario } from './narrative-scenario.js';
import { FakeCaiBackend } from './fake-cai-backend.js';
import { CaiConversation } from '../src/cai/index.js';
import { record } from '../src/narrative/validation.js';

export function createChatScenario() {
  const scenario = createNarrativeScenario();
  const backend = new FakeCaiBackend(
    async (role, requestId) => {
      const handle =
        role === 'forester'
          ? scenario.foresterNarrative
          : scenario.directorNarrative;
      const draft = scenario.draft(
        role === 'forester' ? 'Survey the Old Grove' : 'Winter at River Town',
        role === 'forester' ? 'grove-1' : 'river-town',
      );
      const created = await handle.call(
        'create_quest',
        draft.toInput(),
        requestId + '/create',
      );
      if (
        created.status !== 'completed' ||
        !record(created.data) ||
        typeof created.data['questId'] !== 'string'
      )
        throw new Error('Quest authoring failed');
      const offered = await handle.call(
        'offer_quest',
        {
          questId: created.data['questId'],
          recipientRef: 'player-1',
          dialogue:
            role === 'forester'
              ? 'Will you visit the Old Grove?'
              : 'Discover River Town’s winter story.',
        },
        requestId + '/offer',
      );
      if (offered.status !== 'completed')
        throw new Error('Quest offering failed');
    },
    [
      {
        id: 'demo-session-1',
        characterId: 'demo-profile-1',
        bindingKey: 'forester/workforce-17',
        version: 0,
        mode: 'game',
        continuityMode: 'session',
      },
      {
        id: 'demo-session-2',
        characterId: 'demo-profile-2',
        bindingKey: 'director/main-story',
        version: 0,
        mode: 'game',
        continuityMode: 'session',
      },
    ],
  );
  const attach = async () => {
    const signal = new AbortController().signal;
    const forester = await CaiConversation.attach(
      backend,
      {
        characterId: 'demo-profile-1',
        bindingKey: 'forester/workforce-17',
        sessionId: 'demo-session-1',
      },
      signal,
      () => {
        scenario.forester.snapshot();
      },
    );
    const director = await CaiConversation.attach(
      backend,
      {
        characterId: 'demo-profile-2',
        bindingKey: 'director/main-story',
        sessionId: 'demo-session-2',
      },
      signal,
      () => {
        scenario.director.snapshot();
      },
    );
    return { forester, director };
  };
  return { ...scenario, attach };
}
