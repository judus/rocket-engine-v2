import { createScenario } from './scenario.js';

const { runtime, forester, director } = createScenario(10);
try {
  console.log('One runtime, two registered characters:', runtime.characters());
  console.log(
    'Forester cannot inspect the whole world:',
    forester.dispatch('inspect_world', {}),
  );
  console.log('Forester inspection:', forester.dispatch('inspect_nearby', {}));
  console.log('Director inspection:', director.dispatch('inspect_world', {}));
  forester.requestDecision({ event: 'available_work', job: 'forestry' });
  director.requestDecision({ event: 'winter_shortage' });
  // This loop belongs to the demo host. The framework creates no simulation timer.
  for (let tick = 0; tick < 12; tick++) {
    runtime.advance(0.01);
    for (const event of runtime.drainEvents()) console.log(event);
    await new Promise<void>((resolve) => setTimeout(resolve, 10));
  }
  console.log(
    'Reasoning does not automatically execute proposals:',
    runtime.characters(),
  );
  console.log(
    'Host rejects an unsuitable job:',
    forester.dispatch('request_work', { jobId: 'warrior' }),
  );
  runtime.advance(0);
  await new Promise<void>((resolve) => setTimeout(resolve, 0));
  runtime.advance(0);
  console.log(runtime.drainEvents());
  forester.requestDecision({ event: 'removal_test' });
  runtime.advance(0);
  forester.unregister();
  await new Promise<void>((resolve) => setTimeout(resolve, 0));
  runtime.advance(0);
  console.log('Removed forester; director remains:', runtime.characters());
  console.log(runtime.drainEvents());
} finally {
  runtime.dispose();
}
