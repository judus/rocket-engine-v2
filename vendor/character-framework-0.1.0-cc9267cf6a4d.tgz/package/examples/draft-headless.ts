import { createNarrativeScenario } from './narrative-scenario.js';
import type { Json, NarrativeResult } from '../src/index.js';

const scenario = createNarrativeScenario();
function data(result: NarrativeResult): Record<string, Json> {
  if (
    result.status !== 'completed' ||
    result.data === null ||
    typeof result.data !== 'object' ||
    Array.isArray(result.data)
  )
    throw new Error(JSON.stringify(result));
  return result.data;
}
async function commit(request: Promise<NarrativeResult>) {
  scenario.advance(0);
  return data(await request);
}
let draft: Json = {
  recipientRef: 'player-1',
  title: 'Small winter tasks',
  summary: 'Discover the winter story.',
  objectives: [],
};
async function edit(change: Json) {
  const result = await commit(
    scenario.directorNarrative.call('compose_quest_draft', { draft, change }),
  );
  const next = result['draft'];
  if (!next) throw new Error('Draft expected');
  draft = next;
  console.log('Publishable:', result['valid'], 'Issues:', result['issues']);
  return result['valid'];
}
try {
  console.log(
    'Templates:',
    await commit(
      scenario.directorNarrative.call('inspect_quest_templates', {}),
    ),
  );
  await edit({ kind: 'validate' });
  await edit({
    kind: 'append_step',
    template: 'visit_location',
    arguments: { id: 'survey', locationRef: 'grove-1' },
  });
  await edit({
    kind: 'append_stage',
    stage: { id: 'survey', objectives: ['survey'], next: 'town' },
  });
  await edit({
    kind: 'append_step',
    template: 'visit_location',
    arguments: { id: 'town', locationRef: 'river-town' },
  });
  if (
    !(await edit({
      kind: 'append_stage',
      stage: { id: 'town', objectives: ['town'] },
    }))
  )
    throw new Error('Draft is incomplete');
  console.log('Before publication:', scenario.narrative.stats.quests);
  console.log(
    'Published:',
    await commit(
      scenario.directorNarrative.call(
        'create_quest',
        { quest: draft },
        'publish-once',
      ),
    ),
  );
  console.log('After publication:', scenario.narrative.stats.quests);
} finally {
  scenario.dispose();
}
