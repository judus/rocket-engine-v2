import { createNarrativeScenario } from './narrative-scenario.js';
import { McpGateway } from '../src/mcp/index.js';

/** Host-controlled fixtures and one combined endpoint for two different characters. */
export function createMcpScenario(
  credential: string,
  authority = '127.0.0.1:8094',
) {
  const scenario = createNarrativeScenario();
  const gateway = new McpGateway({
    runtime: scenario.runtime,
    credential,
    allowedHosts: [authority],
  });
  const capabilities = (names: readonly string[]) =>
    scenario.capabilities.filter((capability) =>
      names.includes(capability.name),
    );
  const foresterHeaders = gateway.bind(
    'forester/workforce-17',
    scenario.forester,
    capabilities(['game_inspect_location', 'inspect_nearby', 'request_work']),
  );
  const directorHeaders = gateway.bind(
    'director/main-story',
    scenario.director,
    capabilities(['game_inspect_location', 'inspect_world']),
  );
  const advance = (seconds = 0.02) => {
    scenario.advance(seconds);
    gateway.advance(seconds);
  };
  const dispose = async () => {
    await gateway.dispose();
    scenario.dispose();
  };
  return {
    ...scenario,
    gateway,
    foresterHeaders,
    directorHeaders,
    advance,
    dispose,
  };
}
