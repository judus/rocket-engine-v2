import { CharacterRuntime } from '../src/index.js';
import type {
  Capability,
  CharacterHandle,
  Decision,
  Json,
  NarrativeGame,
  RuntimeOptions,
} from '../src/index.js';

function delay(milliseconds: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) {
      reject(new Error('Aborted'));
      return;
    }
    const abort = () => {
      clearTimeout(timer);
      reject(new Error('Aborted'));
    };
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', abort);
      resolve();
    }, milliseconds);
    signal.addEventListener('abort', abort, { once: true });
  });
}

/** Fake host owns facts and assignments. No real quests, navigation or CAI calls. */
export function createScenario(
  delayMs = 500,
  additionalCapabilities: readonly Capability[] = [],
  narrativeGame?: NarrativeGame,
) {
  const assignments = new Map<string, string>();
  const workInput = (input: Json): input is { [key: string]: Json } =>
    input !== null &&
    typeof input === 'object' &&
    !Array.isArray(input) &&
    typeof input['jobId'] === 'string';
  const capabilities: Capability[] = [
    {
      name: 'inspect_nearby',
      kind: 'inspection',
      description: 'Read nearby work opportunities for an embodied actor.',
      inputSchema: { type: 'object', additionalProperties: false },
      validate: (input) =>
        input !== null &&
        typeof input === 'object' &&
        !Array.isArray(input) &&
        Object.keys(input).length === 0,
      execute: (context) =>
        context.character.entityId
          ? {
              status: 'completed',
              data: {
                location: 'Northern lumber yard',
                jobs: ['forestry'],
                assignment: assignments.get(context.character.id) ?? null,
              },
            }
          : {
              status: 'rejected',
              code: 'no_body',
              message: 'Nearby inspection requires an entity.',
            },
    },
    {
      name: 'inspect_world',
      kind: 'inspection',
      description: 'Read world context supplied to a story director.',
      inputSchema: { type: 'object', additionalProperties: false },
      validate: (input) =>
        input !== null &&
        typeof input === 'object' &&
        !Array.isArray(input) &&
        Object.keys(input).length === 0,
      execute: () => ({
        status: 'completed',
        data: {
          season: 'winter',
          settlements: ['Northern village', 'River town'],
          shortage: 'firewood',
        },
      }),
    },
    {
      name: 'request_work',
      kind: 'action',
      description:
        'Ask the host to assign a qualified worker to an available job.',
      inputSchema: {
        type: 'object',
        properties: { jobId: { type: 'string' } },
        required: ['jobId'],
        additionalProperties: false,
      },
      validate: (input) => workInput(input) && Object.keys(input).length === 1,
      execute: (context, input) => {
        if (input === null || typeof input !== 'object' || Array.isArray(input))
          throw new Error('Validated work input expected');
        if (
          context.character.entityId !== 'workforce-17' ||
          input['jobId'] !== 'forestry'
        )
          return {
            status: 'rejected',
            code: 'not_qualified',
            message: 'Host qualification/job checks rejected the assignment.',
          };
        assignments.set(context.character.id, 'forestry');
        return {
          status: 'completed',
          data: { assigned: true, jobId: 'forestry', attendance: false },
        };
      },
    },
  ];
  const options: RuntimeOptions = {
    gameId: 'grandquest-demo',
    maxConcurrent: 2,
    capabilities: [...capabilities, ...additionalCapabilities],
    ...(narrativeGame ? { narrativeGame } : {}),
    reasoning: {
      async decide(context, observation): Promise<Decision> {
        await delay(
          context.character.entityId ? delayMs * 3 : delayMs,
          context.signal,
        );
        return context.character.entityId
          ? {
              dialogue:
                'I will consider forestry work. Do not mistake an assignment for attendance.',
              intention: {
                kind: 'consider_work',
                args: { jobId: 'forestry', observation },
              },
            }
          : {
              dialogue:
                'Winter and the firewood shortage suggest a story about the old grove.',
              intention: {
                kind: 'propose_story',
                args: { theme: 'winter firewood', observation },
              },
            };
      },
    },
  };
  const runtime = new CharacterRuntime(options);
  const registerForester = (): CharacterHandle =>
    runtime.register({
      id: 'forester',
      name: 'Mara the forester',
      entityId: 'workforce-17',
      cai: { characterId: 'demo-profile-1', sessionId: 'demo-session-1' },
      capabilities: [
        'inspect_nearby',
        'request_work',
        ...additionalCapabilities.map((capability) => capability.name),
      ],
    });
  const forester = registerForester();
  const director = runtime.register({
    id: 'director',
    name: 'The unseen storyteller',
    cai: { characterId: 'demo-profile-2', sessionId: 'demo-session-2' },
    capabilities: [
      'inspect_world',
      ...additionalCapabilities.map((capability) => capability.name),
    ],
  });
  return {
    runtime,
    forester,
    director,
    registerForester,
    assignments,
    capabilities: [...capabilities, ...additionalCapabilities],
  };
}
