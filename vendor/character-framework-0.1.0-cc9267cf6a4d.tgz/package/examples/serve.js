import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, relative, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const mime = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.map': 'application/json',
};
const server = createServer(async (request, response) => {
  try {
    const url = new URL(request.url ?? '/', 'http://localhost');
    const pathname = decodeURIComponent(
      url.pathname === '/' ? '/demo/index.html' : url.pathname,
    );
    const path = resolve(root, '.' + pathname);
    const inside = relative(root, path);
    if (
      inside.startsWith('..') ||
      (!inside.startsWith('demo/') && !inside.startsWith('dist/'))
    ) {
      response.writeHead(404).end();
      return;
    }
    const content = await readFile(path);
    response.writeHead(200, {
      'Content-Type': mime[extname(path)] ?? 'application/octet-stream',
      'Cache-Control': 'no-store',
    });
    response.end(content);
  } catch {
    response.writeHead(404).end();
  }
});
server.listen(8093, '127.0.0.1', () =>
  console.log('Foundation demo: http://127.0.0.1:8093/'),
);
