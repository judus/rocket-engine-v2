import { canonical } from '../src/narrative/validation.js';
import type {
  CaiBackend,
  CaiSessionState,
  CaiTurnInput,
  CaiTurnReceipt,
  CaiEventInput,
  CaiEventReceipt,
} from '../src/cai/types.js';
import type { Json } from '../src/types.js';
import { isJson } from '../src/json.js';

/** Canned demo backend implementing the adapter port, not a claim about implemented CAI routes. */
export class FakeCaiBackend implements CaiBackend {
  readonly #sessions = new Map<string, CaiSessionState>();
  readonly #bindings = new Map<string, string>();
  readonly #receipts = new Map<
    string,
    { digest: string; result: CaiTurnReceipt | CaiEventReceipt }
  >();
  readonly #author: (role: string, requestId: string) => Promise<void>;
  readonly #completed = new Set<string>();
  #sequence = 0;
  constructor(
    author: (role: string, requestId: string) => Promise<void>,
    sessions: readonly CaiSessionState[] = [],
  ) {
    this.#author = author;
    for (const session of sessions) {
      this.#sessions.set(session.id, Object.freeze({ ...session }));
      this.#bindings.set(session.bindingKey, session.id);
    }
  }
  attach(
    input: { characterId: string; bindingKey: string; sessionId?: string },
    signal: AbortSignal,
  ): Promise<CaiSessionState> {
    if (signal.aborted) throw new Error('Aborted');
    const found = input.sessionId ?? this.#bindings.get(input.bindingKey);
    if (found) {
      const session = this.#sessions.get(found);
      if (
        !session ||
        session.characterId !== input.characterId ||
        session.bindingKey !== input.bindingKey
      )
        throw new Error('Session binding unavailable');
      return Promise.resolve(session);
    }
    const session: CaiSessionState = Object.freeze({
      id: `fake-session-${String(++this.#sequence)}`,
      characterId: input.characterId,
      bindingKey: input.bindingKey,
      version: 0,
      mode: 'game',
      continuityMode: 'session',
    });
    this.#sessions.set(session.id, session);
    this.#bindings.set(input.bindingKey, session.id);
    return Promise.resolve(session);
  }
  async turn(
    sessionId: string,
    input: CaiTurnInput,
    signal: AbortSignal,
  ): Promise<CaiTurnReceipt> {
    const digest = canonical(inputJson(input));
    const prior = this.#receipts.get(sessionId + '/turn/' + input.request_id);
    if (prior) {
      if (prior.digest !== digest || !('message' in prior.result))
        throw new Error('Request identity conflict');
      return prior.result;
    }
    const session = this.#read(sessionId, input.version, signal);
    const role =
      session.characterId === 'demo-profile-2' ? 'director' : 'forester';
    let message: string;
    if (
      input.origin === 'framework_request' &&
      input.message.startsWith('Introduce')
    )
      message =
        'Winter settles over the valley. Beyond the lumber yard, the Old Grove waits.';
    else if (input.origin === 'framework_request') {
      await this.#author(role, input.request_id);
      message =
        role === 'forester'
          ? 'Would you visit the Old Grove for me? Winter has been hard on those trees.'
          : 'The valley remembers its winters. There is a story waiting at River Town.';
    } else if (this.#completed.has(sessionId))
      message =
        'You did visit the grove. Thank you. I remember who keeps their word.';
    else
      message =
        'Trees are patient. I try to be. Ask about the grove if you want useful work.';
    const updated = Object.freeze({ ...session, version: session.version + 1 });
    this.#sessions.set(sessionId, updated);
    const receipt = { requestId: input.request_id, message, session: updated };
    this.#receipts.set(sessionId + '/turn/' + input.request_id, {
      digest,
      result: receipt,
    });
    return receipt;
  }
  event(
    sessionId: string,
    input: CaiEventInput,
    signal: AbortSignal,
  ): Promise<CaiEventReceipt> {
    const digest = canonical(inputJson(input));
    const key = sessionId + '/event/' + input.event_id;
    const prior = this.#receipts.get(key);
    if (prior) {
      if (prior.digest !== digest || !('eventId' in prior.result))
        throw new Error('Event identity conflict');
      return Promise.resolve(prior.result);
    }
    const session = this.#read(sessionId, input.version, signal);
    if (input.type === 'quest_completed') this.#completed.add(sessionId);
    const receipt = { eventId: input.event_id, version: session.version + 1 };
    this.#sessions.set(
      sessionId,
      Object.freeze({ ...session, version: receipt.version }),
    );
    this.#receipts.set(key, { digest, result: receipt });
    return Promise.resolve(receipt);
  }
  #read(id: string, version: number, signal: AbortSignal): CaiSessionState {
    const session = this.#sessions.get(id);
    if (signal.aborted || !session || session.version !== version)
      throw new Error('Aborted, missing or stale fake session');
    return session;
  }
}
function inputJson(value: unknown): Json {
  if (!isJson(value)) throw new TypeError('Invalid fake backend input');
  return value;
}
