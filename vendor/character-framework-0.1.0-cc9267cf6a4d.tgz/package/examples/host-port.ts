import { CharacterHostPort } from '../src/host/index.js';
import { FakeCaiBackend } from './fake-cai-backend.js';
import type { CaiTurnInput, CaiTurnReceipt } from '../src/cai/index.js';

// Offline port example: the trusted driver retains original backend inputs and
// receipts. A production host persists these with its conversation/port journal.
const backend = new FakeCaiBackend(
  () => Promise.resolve(),
  [
    {
      id: 'demo-session-1',
      characterId: 'demo-profile-1',
      bindingKey: 'forester',
      version: 0,
      mode: 'game',
      continuityMode: 'session',
    },
  ],
);
const retained = new Map<
  string,
  { input: CaiTurnInput; receipt?: CaiTurnReceipt }
>();
let version = 0;
let lose = true;
const port = new CharacterHostPort(
  {
    current: () => undefined,
    choices: () => [],
    run: async (id, effectKey, intent) => {
      if (intent.kind !== 'dialogue')
        throw new Error('No committed choice in this example');
      let call = retained.get(id);
      if (!call) {
        call = {
          input: {
            request_id: effectKey,
            version,
            origin: 'player_dialogue',
            message: intent.message,
          },
        };
        retained.set(id, call);
      }
      const receipt =
        call.receipt ??
        (await backend.turn(
          'demo-session-1',
          call.input,
          new AbortController().signal,
        ));
      call.receipt = receipt;
      version = receipt.session.version;
      if (lose) {
        lose = false;
        throw new Error('Simulated lost driver reply');
      }
      return receipt.message;
    },
  },
  () => undefined,
); // Volatile example, no claim of crash-safe storage.
let viewA = 0,
  viewB = 0;
const detachA = port.subscribe(() => {
  viewA++;
});
const detachB = port.subscribe(() => {
  viewB++;
});
try {
  await port
    .dispatch({
      kind: 'dialogue',
      requestId: 'ui-original',
      expectedRevision: 0,
      message: 'Hello Mara',
    })
    .then(
      () => {
        throw new Error('Expected lost reply');
      },
      (error: unknown) => {
        if (
          !(error instanceof Error) ||
          error.message !== 'Simulated lost driver reply'
        )
          throw error;
      },
    );
  detachA();
  await port.dispatch({
    kind: 'stop_waiting',
    requestId: 'ui-stop',
    pendingRequestId: 'ui-original',
  });
  if (port.read().state !== 'uncertain')
    throw new Error('Stop waiting cleared uncertainty');
  await port.dispatch({
    kind: 'retry',
    requestId: 'ui-new-delivery',
    failedRequestId: 'ui-original',
  });
  await port.dispatch({
    kind: 'dialogue',
    requestId: 'ui-original',
    expectedRevision: 0,
    message: 'Hello Mara',
  });
  if (retained.size !== 1 || port.read().messages.length !== 2)
    throw new Error('Replay duplicated a turn');
  console.log(
    JSON.stringify({
      mode: 'offline-host-port',
      state: port.read().state,
      retainedTurns: retained.size,
      messages: port.read().messages.length,
      viewA,
      viewB,
    }),
  );
} finally {
  detachA();
  detachB();
  port.dispose();
}
