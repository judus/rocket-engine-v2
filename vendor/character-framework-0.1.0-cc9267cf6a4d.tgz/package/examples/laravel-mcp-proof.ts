import { spawn } from 'node:child_process';
import { writeFile, unlink } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { once } from 'node:events';
import { createMcpScenario } from './mcp-scenario.js';
import { createMcpHttpServer } from './mcp-http.js';

const serverRoot = process.argv[2];
if (!serverRoot) throw new Error('Supply the read-only CAI apps/server path');
const credential = randomBytes(32).toString('hex');
const scenario = createMcpScenario(credential, '127.0.0.1:8095');
const server = createMcpHttpServer(scenario.gateway, '127.0.0.1:8095');
const path = `/tmp/cf-php-proof-${randomBytes(6).toString('hex')}.json`;
let timer: ReturnType<typeof setInterval> | undefined;
try {
  await writeFile(
    path,
    JSON.stringify({
      url: 'http://127.0.0.1:8095/mcp',
      credential,
      forester: scenario.foresterHeaders,
      director: scenario.directorHeaders,
    }),
    { flag: 'wx', mode: 0o600 },
  );
  server.listen(8095, '127.0.0.1');
  await once(server, 'listening');
  timer = setInterval(() => {
    scenario.advance();
  }, 10);
  const child = spawn(
    'php',
    ['tests/laravel-mcp-proof.php', serverRoot, path],
    { stdio: ['ignore', 'inherit', 'inherit'] },
  );
  const code = await new Promise<number | null>((resolve, reject) => {
    child.once('exit', resolve);
    child.once('error', reject);
  });
  if (code !== 0) throw new Error('Installed Laravel MCP proof failed');
  if (scenario.narrative.stats.quests !== 1)
    throw new Error('Lost-response replay duplicated a quest');
  console.log(
    'Disposable framework host: one committed quest; no CAI application/database/provider used.',
  );
} finally {
  if (timer) clearInterval(timer);
  server.close();
  await scenario.dispose();
  await unlink(path).catch(() => undefined);
}
