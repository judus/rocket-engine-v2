import { createNarrativeScenario } from './narrative-scenario.js';
import type { NarrativeResult } from '../src/index.js';

const scenario = createNarrativeScenario();
async function commit(
  request: Promise<NarrativeResult>,
): Promise<NarrativeResult> {
  scenario.advance(0);
  return request;
}
function data(result: NarrativeResult) {
  if (
    result.status !== 'completed' ||
    result.data === null ||
    typeof result.data !== 'object' ||
    Array.isArray(result.data)
  )
    throw new Error('Expected a completed tool result');
  return result.data;
}
try {
  console.log(
    await commit(
      scenario.foresterNarrative.call('inspect_context', { scope: 'local' }),
    ),
  );
  for (const [role, handle, location] of [
    ['forester', scenario.foresterNarrative, 'grove-1'],
    ['director', scenario.directorNarrative, 'river-town'],
  ] as const) {
    const input = scenario.draft(`${role}'s winter survey`, location).toInput();
    const created = await commit(
      handle.call('create_quest', input, role + '/create'),
    );
    console.log('Created:', created);
    const questId = data(created)['questId'];
    if (typeof questId !== 'string') throw new Error('Quest ID expected');
    const offer = await commit(
      handle.call(
        'offer_quest',
        {
          questId,
          recipientRef: 'player-1',
          dialogue: 'Will you investigate this place?',
        },
        role + '/offer',
      ),
    );
    console.log('Offer:', offer);
    const offerId = data(offer)['offerId'];
    if (typeof offerId !== 'string') throw new Error('Offer ID expected');
    console.log(
      'Player:',
      await commit(
        scenario.narrative.choose(
          'player-1',
          offerId + '/accept',
          role + '/accept',
        ),
      ),
    );
    scenario.visit(location);
    scenario.advance(0.05);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    scenario.advance(0.05);
    console.log(
      'Progress:',
      await commit(
        handle.call('inspect_quest', { questId, recipientRef: 'player-1' }),
      ),
    );
  }
  const save = JSON.parse(JSON.stringify(scenario.narrative.save())) as unknown;
  scenario.narrative.restore(save);
  console.log('Restored:', scenario.narrative.stats);
  console.log('Narrative feedback:', scenario.narrative.drainEvents());
} finally {
  scenario.dispose();
}
