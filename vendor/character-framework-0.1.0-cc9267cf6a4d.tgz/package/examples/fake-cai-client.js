import { AsyncLocalStorage } from 'node:async_hooks';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { Ajv2020 } from 'ajv/dist/2020.js';
import { AjvJsonSchemaValidator } from '@modelcontextprotocol/sdk/validation/ajv';

/** Test connector only: no model/provider calls or CAI route assumptions. */
export class FakeCaiClient {
  #calls = new AsyncLocalStorage();
  client = new Client(
    { name: 'fake-cai', version: '0.1.0' },
    {
      capabilities: {},
      jsonSchemaValidator: new AjvJsonSchemaValidator(
        new Ajv2020({ strict: true, allowUnionTypes: true }),
      ),
    },
  );
  transport;
  constructor(url, bindingHeaders, credential, fetch_ = fetch) {
    const bound = Object.freeze({
      ...bindingHeaders,
      Authorization: `Bearer ${credential}`,
    });
    this.transport = new StreamableHTTPClientTransport(url, {
      requestInit: { headers: bound },
      fetch: (target, init) => {
        const headers = new Headers(init?.headers);
        for (const [key, value] of Object.entries(this.#calls.getStore() ?? {}))
          headers.set(key, value);
        return fetch_(target, { ...init, headers });
      },
    });
  }
  async connect() {
    await this.client.connect(this.transport);
  }
  call(name, arguments_, identity) {
    const headers = Object.freeze({
      'X-CF-Call-Id': identity.callId,
      'X-CF-Turn-Request-Id': identity.turnId,
      ...(identity.effectKey ? { 'X-CF-Effect-Key': identity.effectKey } : {}),
    });
    return this.#calls.run(headers, () =>
      this.client.callTool({ name, arguments: arguments_ }),
    );
  }
  async close() {
    try {
      await this.transport.terminateSession();
    } catch (error) {
      if (![403, 404, 503].includes(error.code)) throw error;
    } finally {
      await this.client.close();
    }
  }
}
