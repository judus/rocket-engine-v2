import { createChatScenario } from './chat-scenario.js';
import type { CaiConversation } from '../src/cai/index.js';

const scenario = createChatScenario();
let conversations:
  { forester: CaiConversation; director: CaiConversation } | undefined;
let busy = false;
let lastTime = performance.now();
function element(id: string): HTMLElement {
  const node = document.getElementById(id);
  if (!node) throw new Error('Missing demo element');
  return node;
}
function control(id: string): HTMLButtonElement {
  const node = element(id);
  if (!(node instanceof HTMLButtonElement)) throw new Error('Expected button');
  return node;
}
function say(who: string, message: string): void {
  const line = document.createElement('p');
  line.textContent = `${who}: ${message}`;
  element('conversation').append(line);
}
async function run(action: () => Promise<void>): Promise<void> {
  if (busy) return;
  busy = true;
  try {
    await action();
    element('status').textContent = 'Ready.';
  } catch (error) {
    element('status').textContent =
      error instanceof Error ? error.message : 'Request failed';
  } finally {
    busy = false;
    control('retry').hidden = !conversations?.forester.status.pending;
  }
}
const form = element('chat-form');
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const input = element('message');
  if (
    !(input instanceof HTMLInputElement) ||
    !input.value.trim() ||
    !conversations ||
    busy
  )
    return;
  const message = input.value.trim();
  const conversation = conversations.forester;
  void run(async () => {
    say('You', message);
    say('Mara', await conversation.dialogue(message));
  });
});
control('ask').addEventListener('click', () => {
  void run(async () => {
    if (!conversations) return;
    say(
      'Mara',
      await conversations.forester.requestNarrative(
        'Offer the player one useful woodland errand.',
      ),
    );
  });
});
control('accept').addEventListener('click', () => {
  void run(async () => {
    const quest = scenario.narrative
      .save()
      .quests.find(
        (entry) =>
          entry.authorRef === 'forester' && entry.offer?.status === 'offered',
      );
    if (!quest?.offer) return;
    await scenario.narrative.choose(
      'player-1',
      quest.offer.id + '/accept',
      quest.offer.id + '/player-choice',
    );
    say('You', 'I will visit the grove.');
  });
});
control('visit').addEventListener('click', () => {
  scenario.visit('grove-1');
  say('Game', 'You visited the Old Grove.');
});
control('retry').addEventListener('click', () => {
  void run(async () => {
    const reply = await conversations?.forester.retry();
    if (reply) say('Mara', reply);
  });
});
function frame(now: number): void {
  scenario.advance(Math.min((now - lastTime) / 1000, 0.1));
  lastTime = now;
  for (const event of scenario.narrative.drainEvents()) {
    const conversation =
      event.characterRef === 'forester'
        ? conversations?.forester
        : conversations?.director;
    conversation?.enqueueFeedback({
      sourceId: event.id,
      origin: event.origin,
      type: event.type,
      summary: `${event.type}: ${event.questId}`,
      references: { quest_id: event.questId, framework_event_id: event.id },
    });
  }
  if (!scenario.narrative.stats.pendingCommands) {
    const quest = scenario.narrative
      .save()
      .quests.filter((entry) => entry.authorRef === 'forester')
      .at(-1);
    element('quest').textContent = quest
      ? `${quest.definition.title} — ${quest.offer?.status ?? 'registered'}`
      : 'No quest offered yet.';
    control('accept').disabled = busy || quest?.offer?.status !== 'offered';
    control('visit').disabled = busy || quest?.offer?.status !== 'active';
    control('ask').disabled = busy || !conversations || Boolean(quest);
    control('send').disabled = busy || !conversations;
  }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
void run(async () => {
  conversations = await scenario.attach();
  say('Mara', 'Good morning. Mind the saplings.');
  // The director uses the same session abstraction, but has no visible body or chat controls.
  say(
    'Narrator',
    await conversations.director.requestNarrative(
      'Introduce this woodland setting without creating a quest.',
    ),
  );
});
window.addEventListener(
  'pagehide',
  () => {
    conversations?.forester.dispose();
    conversations?.director.dispose();
    scenario.dispose();
  },
  { once: true },
);
