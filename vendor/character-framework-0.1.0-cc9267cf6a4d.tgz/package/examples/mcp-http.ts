import { createServer } from 'node:http';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import type { ReadableStream as NodeReadableStream } from 'node:stream/web';
import type { McpGateway } from '../src/mcp/index.js';

/** Small Node adapter; authentication and bounded body parsing belong to the gateway. */
export function createMcpHttpServer(
  gateway: Pick<McpGateway, 'handle'>,
  authority: string,
) {
  return createServer((incoming, outgoing) => {
    const run = async () => {
      const headers = new Headers();
      for (const [key, value] of Object.entries(incoming.headers)) {
        if (Array.isArray(value)) headers.set(key, value.join(', '));
        else if (value !== undefined) headers.set(key, value);
      }
      const method = incoming.method ?? 'GET';
      const init: RequestInit & { duplex: 'half' } = {
        method,
        headers,
        duplex: 'half',
        ...(method === 'POST'
          ? { body: Readable.toWeb(incoming) as ReadableStream<Uint8Array> }
          : {}),
      };
      const response = await gateway.handle(
        new Request(new URL(incoming.url ?? '/', `http://${authority}`), init),
      );
      outgoing.writeHead(response.status, Object.fromEntries(response.headers));
      if (response.body)
        await pipeline(
          Readable.fromWeb(response.body as NodeReadableStream<Uint8Array>),
          outgoing,
        );
      else outgoing.end();
    };
    void run().catch(() => {
      if (!outgoing.headersSent)
        outgoing.writeHead(500, { 'content-type': 'application/json' });
      if (!outgoing.writableEnded)
        outgoing.end(JSON.stringify({ error: 'http_adapter_failed' }));
    });
  });
}
