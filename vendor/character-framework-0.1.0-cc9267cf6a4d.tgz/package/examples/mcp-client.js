import { readFile } from 'node:fs/promises';
import { FakeCaiClient } from './fake-cai-client.js';

const path = process.argv[2];
if (!path)
  throw new Error(
    'Usage: node examples/mcp-client.js /tmp/character-framework-mcp-PRINTED-ID.json',
  );
const config = JSON.parse(await readFile(path, 'utf8'));
const forester = new FakeCaiClient(
  new URL(config.url),
  config.forester,
  config.credential,
);
const director = new FakeCaiClient(
  new URL(config.url),
  config.director,
  config.credential,
);
try {
  await Promise.all([forester.connect(), director.connect()]);
  for (const [client, scope] of [
    [forester, 'local'],
    [director, 'world'],
  ]) {
    console.log(
      'Discovered tools:',
      (await client.client.listTools()).tools.map((tool) => tool.name),
    );
    const context = await client.call(
      'inspect_context',
      { scope },
      { callId: `context-${scope}`, turnId: 'connection-proof' },
    );
    const data = context.structuredContent?.data;
    console.log(
      `${data?.characterRef}: ${data?.scope} context, ${data?.entities?.length ?? 0} visible entities`,
    );
  }
} finally {
  await Promise.all([forester.close(), director.close()]);
}
