# Character Framework Implementation Roadmap

Develop characters whose personality and experience influence conversation, behavior and a framework-owned universal quest/dialogue system. Support embodied NPCs and unseen story/lore directors. Begin with one shared runtime, registered characters and game capabilities, then connect CAI characters, persistent sessions, player chat and quests. Then develop behavioral reasoning and local execution together, preserving the game/Rocket ownership boundaries.

Status, 13 October 2026: the shared runtime, agreed contracts, persistent-session adapter, scoped MCP gateway and universal narrative core are implemented. The bounded CAI–CFW native HTTP proof passed with a fake provider (CAI message123; maintained harness reviewed read-only). It covers one quest, lost-response effect reconciliation, authoritative completion feedback and follow-up dialogue. See [joint proof](JOINT-PROOF.md) for evidence and limitations. Trusted host confirmation and the current conversation driver/port now pass a separate actual HTTP proof with provider-only fake (CAI174); CAI also delivered its own live-model proof (141). Rocket independently accepted the portable host package (171) and delivered its own ChatPort/Mara adapter (179), with scripted driver and volatile checkpoints. General dialogue graphs, production host storage/transport and later behavior/execution milestones remain open. Other projects remain read-only.

## Phase 0 Runtime registry and capability foundation

Delivered: strict TypeScript runtime/handles, character registry, scoped capability discovery/dispatch, bounded shared request scheduling, host-bound result commits and lifecycle cleanup. Headless and interactive fake-host demos cover an embodied forester and a bodyless director. Behavioral tests and type-aware analysis run through `npm run check`. No CAI calls, real MCP server or quest/dialogue engine are included. See [FOUNDATION.md](FOUNDATION.md) for exact limits and verification.

Build one Character Framework runtime per game instance. Register all characters in that runtime rather than constructing an independent intelligence service for each NPC. Each registration has a stable framework identity, independent execution/request state, optional physical entity reference and an optional CAI character/session binding. A lightweight character handle delegates operations to shared services.

The game owns runtime lifetime. The runtime owns registrations, shared reasoning coordination and framework narrative/execution state. The game retains physical entities and mechanics; CAI retains its profiles/sessions. Unregistering cancels pending local work and invalidates late replies without implicitly deleting a CAI session or game entity. View teardown is not character removal.

Define injected game inspection/action capabilities and a shared dispatcher that binds every call to the game association and character. Plan one combined MCP endpoint per association; the MCP server exposes runtime operations and game capabilities, but does not own the execution loop or character state. A forester can receive local capabilities and a director broader ones. A shared endpoint must not mix their sessions or authority.

Start with a headless fake game and fake reasoning provider. Establish host-driven advancement, independent per-character request state and bounded scheduling so one pending reasoning request does not block other characters. Reserve a shared quest/dialogue service boundary; implement its narrative semantics in Phase 3 rather than creating one quest engine per character.

Completion:

- One runtime registers an embodied forester and a bodyless director with separate state and optional bindings.
- Inspection/action dispatch uses the acting character's available capabilities and rejects unsupported calls.
- Pending work for one character does not stop another; removal makes its late results ineffective.
- The host advances execution once, independently of view count, with no private per-character simulation loop.
- Registration, removal and runtime disposal have explicit resource ownership and cleanup.
- Core does not require CAI, MCP transport, Rocket nodes or physics bodies to run the fake example. The real shared MCP transport is connected in Phase 3.

Owners: Character Framework and fake host. This milestone does not require the proposed CAI game APIs to exist.

## Phase 1 Agree the first session integration

Draft delivered: [MCP tool contracts](MCP-CONTRACTS.md), machine-readable discovery schemas and sixteen successful/rejected call examples for the forester/director. Request binding, mutation replay, narrative ownership and typed feedback are explicit. Schema validation is in `npm run contracts:check` and the aggregate test gate. Review is still required for connector binding, effect-key retention and CAI session/origin changes. The framework MCP server is now implemented; those proposed CAI additions remain pending. See [MCP-SERVER.md](MCP-SERVER.md).

Use the CompanionAI response and detailed API handoff to agree the intended flow: prose-based profile creation, existing-character reuse, one attached session per character instance, with optional game entity binding, session-only memories, exclusive game-session writes and a game quest mode. Ask what current routes already support and what small extensions make the flow work. Distinguish existing suggestion/creation/session routes from proposed game ownership, external tools and typed feedback. Provide successful and rejected examples for inspect_context, create_quest, offer_quest and inspect_quest, including per-call association/character/session binding.

Choose one game example and a small framework quest/dialogue representation. Define MCP inspection/action capabilities and how their facts/results drive framework objective progression. Include a simple director role without a body. Establish a simple game identity/key association with CAI. Questions about existing memory behavior and all session-mutating routes belong here.

Completion: a concrete interaction example and agreed integration surface explain profile creation, session reuse, chat, initial quest generation and feedback without relying on invented existing APIs.

## Phase 2 Character profiles and persistent sessions

The game creates one NPC or a small workforce, supplies world/profession/stats prose, and receives saved CAI character IDs or binds existing characters. Attach one game-owned session per framework character instance and persist both IDs. Also create a director character with no physical entity. Single profile requests precede optional batching.

Completion: reconnecting reuses the attached session; game memories remain in it; the same character can have ordinary sessions outside the game. Other clients cannot mutate the game session through chat or other session-write paths. No profile request silently spawns a game entity or grants qualifications. A director can reason without a body, position or movement capability.

Owners: game/framework adapter and CompanionAI, using existing facilities plus agreed extensions.

Framework-side adapter delivered: [CAI conversations](CAI-ADAPTER.md) retain sessions, versions, pending requests and typed feedback with a configurable HTTP backend. The simple fake-backend chat demo exercises a completed quest and subsequent reply. CAI game execution/connector and retained unknown-effect reconciliation are delivered and exercised in the shared proof. Confirmed-generation bootstrap and the integrated CaiHostDriver/CharacterHostPort are delivered and pass the isolated actual HTTP proof (174); example host checkpoints are volatile.

Current foundation integration: CAI has delivered locally tested association-owned attachment, binding metadata and event persistence. Framework HTTP publication/recovery and delivered feedback bounds are implemented against simulated HTTP; see [binding lifecycle](BINDING-LIFECYCLE.md). Operator provisioning and owner-only interrupted-turn reads are delivered in CAI; the framework now has bounded attempt/call readers. Game turns and the native connector/journal now run together in the bounded fake-provider joint proof; trusted host glue and the bounded CAI-owned live-model proof are delivered; production durability and broader real-model behavior remain open.

## Phase 3 Framework quests dialogue and MCP integration

Local slice delivered: the four in-process tool contracts, recipient-specific quest definitions, committed offers, player accept/decline, authoritative condition monitoring, receipt replay and checkpoint validation. One shared narrative service is advanced/disposed by the runtime. Whole definitions and incremental local draft templates use the same validator. The forester/director demos and semantic tests exercise it. See [NARRATIVE.md](NARRATIVE.md) and [Zemegagame assessment](ZEMEGAGAME-REFERENCE.md). MCP transport is now delivered with scoped discovery, raw structured results, generation checks and saved effect receipts. A second independent fake station adapter now validates numerical system-efficiency objectives against different world records/capabilities; it does not import woodland mechanics. CAI integration is delivered in bounded joint proofs. Full dialogue graphs are not delivered, so this phase is not complete.

Connect one combined MCP service to the shared runtime, with character-scoped discovery and dispatch of framework tools plus game capabilities. Build the reusable framework quest/dialogue runtime: definitions, instances, stages/objectives, conditions, choices and progression. Connect player chat through the attached session and CAI generation through an agreed format or framework authoring tools. The game supplies MCP inspection/action tools; the framework validates/registers narrative content, evaluates progress from game facts and invokes game operations for consequences.

Completion: the player talks to the NPC, receives a playable quest and completes it in the game. The framework retains executable quest/dialogue state, and the CAI session retains character history. Conversation choices can introduce tasks or branches; game actions validate physical effects. The same narrative runtime works against two small game adapters with different world records, without importing either game into core. A director can introduce a quest without being a visible NPC. Ordinary CAI chat behavior remains available outside game sessions.

This is the first product slice, not the full extent of the framework.

Current independent progress: [quest flows](QUEST-FLOWS.md) implement ordered stages, stage dialogue, player branches and checkpoint recovery. `npm run demo:flow` demonstrates a director-authored branch. Remote incremental authoring now has pure task/stage composition and scoped template discovery; see [authoring](QUEST-AUTHORING.md). General dialogue graphs remain open. Current driver/port real HTTP integration passes with provider-only fake; the separate CAI-owned live-model proof does not establish every authoring/behavior path. The existing browser demo stays simple.

First external consumer: Rocket now has a scripted Mara proof using its pinned built CFW core, host ChatPort, physical arrival facts and framework quest progression. Source/package/ownership docs verified read-only; Rocket reports browser verification and its own gates. See [Rocket’s integration notes](/home/maduser/workspace/rocket-engine-v2/docs/CHARACTER-DIALOGUE.md). This does not establish live CAI or durable saves.

## Phase 4 Personality driven intentions

Develop with CAI a response that can express dialogue, behavioral intentions and narrative changes together. Supply current opportunities, relevant facts and available game capabilities. Agree which parts are existing session behavior and which require a new mode or turn extension.

Aligned execution boundary177: existing CAI game turns can invoke dynamic MCP inspection/action/narrative tools and receive typed outcomes without a new reply envelope. See [intentions and outcomes](BEHAVIOR-INTENTIONS.md). The headless canned departure proof covers proposal/admission/host arrival, rejected destinations and late-result suppression; live personality evaluation and quest-access/redemption semantics remain open.

First example: an insult produces a character-appropriate comment plus proposed departure, refusal of quest access or a redemption quest. The framework admits supported proposals and changes its quest-offering/dialogue state; game capability outcomes return to the same session. Conversation effects and committed gameplay effects remain distinguishable.

Completion: structured examples and a small headless executor demonstrate the full reaction/feedback cycle. Missing capabilities and invalid targets are rejected. A failed action does not become a remembered success. Actual personality judgments need a live-provider demonstration when authorized; fakes establish transport and execution contracts.

## Phase 5 Real Rocket behavior

Jointly review navigation/journey contracts before either side implements them. Rocket owns navigation and movement; the framework owns intention/task coordination; the game owns permissions and consequences. Build one finite-map actor and the physical walk-away example.

Completion: the NPC physically leaves through Rocket, reports actual arrival or failure, while the framework changes narrative quest access. Physical eligibility and world effects still use game operations. Dialogue alone does not commit either effect. Two views do not advance the actor twice. Interruption, removal and late replies cannot resurrect obsolete behavior. If execution must outlive the last view, establish and verify the corresponding host/Rocket support.

This phase requires a separate Rocket implementation task. Headless behavioral work can continue with reviewed fake movement adapters while that facility develops.

## Phase 6 Autonomous work and local decisions

Expose game-needed professions, job requirements, actual qualifications and available work. Develop decisions reflecting laziness, ambition, loyalty and other traits. Support scripted/local policies alongside CAI for routine execution and immediate responses.

Completion: NPCs can accept, refuse or negotiate work within game rules. Assignment does not imply physical attendance. A courier plan collects and unloads only after authoritative commits; cargo never becomes a duplicate framework inventory. Reckless behavior can attempt a supported game action such as igniting an eligible object and receive a real outcome.

Player control and autonomous behavior share capability ownership. Remote decisions happen on meaningful events or a bounded schedule, not per frame. Tactical/combat behavior follows through the same boundaries as its game mechanics become available.

## Phase 7 Recovery and sustained character continuity

Persist task steps, stable operation IDs and NPC-to-CAI bindings with host state. Reconcile interrupted tasks and outcomes before resuming. Bound pending reasoning, feedback retention and retries using observed integration needs.

Completion: ordinary reload resumes the same session and reconciles actions without repeated cargo transfers, framework quest registration or game rewards. Duplicate feedback does not repeatedly apply the same supported session effect. Late replies from a previous task/runtime are rejected. Network failure leaves responsive local behavior or an explicit waiting state.

Critical correlation and duplicate-effect protection begin when commands first execute; this phase broadens recovery rather than deferring basic correctness. Save rewind versus later CAI memories needs a separate agreed policy before supporting that feature.

## Further development

Extend quest continuation and branching, social initiatives, richer local/tactical policies, workforce batching and richer game/framework MCP tools as working consumers need them. The initial MCP capability bridge can grow with new inspection/action tools while preserving game rules. Director behavior can coordinate longer story/lore arcs using the same framework narrative system.

Streamed residency, collision readiness, offscreen simulation, detailed vehicle dynamics and concurrent action scheduling are later Rocket/host/framework work. Sophisticated permissions, immutable profile snapshots, general event ledgers and world-history branching are not prerequisites for the first slice.

## Next step

The first bounded connection is delivered: actual CAI game turns, scoped MCP execution, confirmed-session bootstrap and current CFW driver/port all pass their retained joint proofs. Rocket delivered its own ChatPort/Mara integration against the exact accepted package (179); its retained proof remains scripted and volatile. Preserve these checks and fixed artifacts; address concrete consumer findings without cross-project edits.

General dialogue graphs remain the open Phase 3 feature. Assess their required authored state and consumer need before adding a second dialogue representation. Align Phase 4 personality-driven intentions with CAI's maintained tool/turn contract before implementing behavior; retain game authority for physical effects and report only committed outcomes. Production storage, browser transport, deployment and broader recovery remain separate. The simple browser demo stays unchanged. Direct CAI/Rocket coordination is authorized; other peers still need direct human authorization.
