# CAI adapter and simple chat demo

Framework-side slice, 13 October 2026. `character-framework/cai` supplies a conversation coordinator and a configurable HTTP backend. CAI has delivered locally tested game attachment, binding metadata and event persistence. Operator provisioning is also delivered locally; game turns and the MCP connector/journal remain pending; live mode stays disabled. No live provider or real CAI data was used here.

## Try the simple flow

Run `npm run demo:web` and open [Chat with Mara](http://127.0.0.1:8093/demo/chat.html). Ask for work, accept, visit the grove, then send a message. Mara's canned reply acknowledges completion only after the framework confirms it and forwards typed feedback. The invisible director supplies a brief introduction through the same session abstraction. There are no extra director or infrastructure controls.

The browser uses `FakeCaiBackend`, not CAI HTTP, MCP or an AI model. Fake authoring calls the real local narrative tools; existing MCP tests independently cover the wire path. Session/turn handling, player acceptance and quest monitoring are real framework code. Reloading resets the fake world/conversations. The display is intentionally small; the earlier technical demos remain available separately.

## Host connection

```ts
import { CaiConversation, CaiHttpBackend } from 'character-framework/cai';

const backend = new CaiHttpBackend({
  origin: caiOrigin,
  token: gameCredential,
  enableGameDraft: true,
});
const conversation = await CaiConversation.attach(
  backend,
  {
    characterId,
    bindingKey,
    ...(existingSessionId ? { sessionId: existingSessionId } : {}),
  },
  signal,
  assertCurrentCharacterRegistration,
  persistConversationCheckpoint,
);
const reply = await conversation.dialogue('Hello Mara!', {
  facts: 'The player is beside the northern lumber yard.',
  actor_ref: 'workforce-17',
});
```

Credentials remain in the host backend. Never put the real HTTP backend/token in a player browser. HTTP redirects are refused. Errors report status and operation without reflecting CAI response bodies, credentials or observations. JSON responses are bounded to 64 KiB and finite JSON depth.

Attachment either reads the stored session or requests get-or-create game attachment using the delivered foundation route. It checks character, binding key, session ID where supplied, `mode: game` and session-only continuity. It fails if CAI ignores the game fields and returns an ordinary session. This check is not independent proof of backend authorization; the joint bridge still needs a disposable authorization/integration proof.

For a newly created attachment, persist the returned character/session IDs before registering the character with those CAI IDs. Provision its MCP metadata through the existing gateway handoff. A loaded character reuses the same session; it does not create a fresh session for every conversation. The coordinator's guard should reject a retired handle both before dispatch and after a reply. It does not register game entities, generate profiles or provision credentials automatically.

## Dialogue, authoring and feedback

`dialogue()` sends `player_dialogue`; `requestNarrative()` sends `framework_request`. Both retain the existing versioned `data.turn`/`data.session` envelope and synchronous request semantics. CAI invokes MCP during reasoning; the framework does not parse assistant prose into quest commands. The host must continue advancing its runtime/gateway while awaiting CAI.

`enqueueFeedback()` accepts a stable framework/game source ID, typed origin, summary and references. `flushFeedback()` reports it without generating a reply or treating it as player speech. A turn flushes queued feedback first, so its request uses the updated session version. The simple demo forwards narrative outcomes at its host boundary and flushes them on the next player turn. A live host can flush at meaningful events without waiting for chat.

Player quest acceptance stays in `NarrativeSystem.choose()` and never becomes a CAI interaction-choice selection. Assistant dialogue and committed offers remain separate. Feedback does not itself advance a CAI quest runtime or grant inventory.

Each conversation has independent version/request state. There is one active remote request per conversation; uncertain pending work blocks new turns. `retry()` uses the exact original ID, version, origin and payload. It never changes the version after a 409 or automatically regenerates a turn with fresh tool effects. Invalid/mismatched receipts and retired registrations cannot advance local conversation state. The coordinator does not yet read CAI's incomplete-turn tool journal; that response remains a CAI integration seam.

## Saving and recovery

`save()` captures the session, pending turn/event, feedback queue and acknowledged source IDs. Restore with `new CaiConversation(backend, saved, guard, persist)`. Checkpoints reject malformed sessions, invalid versions, duplicate/overlapping feedback IDs and inconsistent pending input.

The injected persistence callback runs before remote dispatch and after acknowledgment. If storing the pending request fails, no dispatch occurs. A durable host must atomically save its exact input before sending; the default callback stores nothing. If a response is lost, the retained pending request can be replayed after JSON restore. A post-ack storage failure keeps both live and durable state pending at the original version. New turns remain blocked; retry replays the exact input, obtains CAI's original receipt and returns the dialogue only after acknowledgment storage succeeds. Feedback added while saving is included before the acknowledgment is published. This does not promise exactly-once provider execution or undo external MCP effects.

Feedback is bounded to 128 queued reports and 4096 queued/acknowledged source IDs per conversation. UUID event IDs are generated once on dispatch and retained for retry. The adapter automatically reserves `references.source_event_id` for the authoritative source ID, rejects a conflicting caller value, and retains it on replay. Callers have at most fifteen other reference fields. Queue insertion is separate from acknowledgment. Hosts must persist queued feedback before acknowledging/draining their authoritative event source, and coordinate game/narrative/MCP/conversation checkpoints. The browser demo is volatile and does not claim crash-safe event delivery.

## Delivered foundation and remaining integration

The HTTP backend follows the session/turn/event route families in [CAI's API handoff](/home/maduser/workspace/companion-ai/companion-ai-next/docs/character-framework-api.md). CAI delivered locally tested game attachment, ownership, binding CAS and event persistence in message 31. Game turns and actual MCP discovery/journal remain unavailable; server-admin provisioning is now delivered separately. `enableGameDraft` stays an explicit opt-in, and the browser live switch remains disabled.

The delivered event envelope is `{ data: { event_id, version } }`, mapped to `{ eventId, version }`. `decodeEvent` remains an optional override for a deliberately agreed alternative. The conversation checks the retained identity and version. Missing/queued/malformed responses never become acknowledgments merely because HTTP succeeded. Accepted event persistence does not yet prove consumption by the pending game executor.

Tests cover independent/reused sessions, exact unknown-outcome replay, feedback acknowledgment without dialogue, guarded late replies, corrupt checkpoints, host persistence ordering, HTTP route/envelope checks and the completed-quest chat flow. These prove our adapter against fakes, not CAI mood/memory behavior, actual game ownership or a live end-to-end provider connection.

## CAI alignment status

CAI accepted the recovery fixes, `source_event_id`, quest-flow discovery and bounded branch feedback. Foundation publication/session/event contracts are delivered; the framework implements and tests them against simulated HTTP. Game execution, actual connector/journal and incomplete-turn receipt reconciliation remain blockers for a live joint proof. The simple browser demo continues using its fake backend.

## Foundation publication and delivered bounds

`CaiHttpBackend.publishBinding` uses the trusted PUT route and validates its numeric session receipt, exact binding key/generation and informational version. `CaiBindingPublication` retains publication state separately from conversations; see [binding lifecycle](BINDING-LIFECYCLE.md) for initialization, host gating and restart recovery. Game HTTP reads require `binding_generation` as null or a bounded opaque string; older local/fake conversation checkpoints may omit it.

Typed feedback now matches CAI's delivered limits: type at most 80 characters, summary 2,000, at most 16 references, keys at most 80 and values 160. Type, source ID, reference keys/values and binding selectors must be nonblank and contain no Unicode control characters (Cc). Summary must contain non-whitespace text; multiline summary text remains allowed. Valid strings retain their exact spaces and spelling; validation never trims the stored or dispatched value. Reserve one reference slot for automatic `source_event_id`. Accepted reports are durable history in CAI; their consumption by its game executor is not delivered yet. The existing draft opt-in stays required because the complete game conversation/connector flow is unavailable. No credential or live provider was used in framework validation.

Interrupted-turn inspection is available through `CaiReceiptBackend`, implemented by `CaiHttpBackend.readAttempt` and `.readCall`. See [INTERRUPTED-TURNS.md](INTERRUPTED-TURNS.md) for bounds, paging and the separation from pending-state acknowledgment. Explicit durable failure acknowledgment is available through `CaiConversation.acknowledgeFailure`; game turn execution and automatic reconciliation remain pending.

Turn input is validated before flushing feedback or saving a pending request: message must contain nonblank prose (max8000), optional context has nonblank facts (max4000) and optional nonblank actor_ref (max160), with no unknown context keys. Surrounding spaces and multiline prose remain unchanged. Context is copied before asynchronous work so caller mutation cannot alter the exact saved/replayed input. Restore rejects whitespace-only pending input as an invalid checkpoint. actor_ref is descriptive context, never routing authority.

`CaiConversation.reconcileCompleted(receipts)` recovers a lost committed reply through GET and a durable local acknowledgment, preserving original request/input/generation correlation and the separate committed/current versions. It does not regenerate a provider turn. See [receipt recovery](INTERRUPTED-TURNS.md).

## Joint native API proof update, 13 October 2026

The earlier pending-executor statements above describe the foundation handoff. CAI now delivers the public game-turn API, native discovery/execution, atomic replies and typed session history. The shared actual HTTP proof passed with the provider alone faked: one quest, deliberately lost committed reply, original effect replay, host completion and follow-up. See [joint proof](JOINT-PROOF.md) for the maintained harness, reported34assertions and explicit limits. No paid-provider call was made by CFW. The browser remains the simple fake demo; a durable trusted host must still join attachment, binding publication, authenticated confirmed-generation read/checkpoint and conversation lifetime.
