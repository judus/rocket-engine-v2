# Trusted CAI binding publication

Status: CAI delivered the foundation publication route in message 31. Framework `CaiHttpBackend.publishBinding` and `CaiBindingPublication` implement its wire contract and host recovery journal, tested with simulated HTTP. CAI operator provisioning is delivered separately; actual MCP connector/journal and game turns remain pending; no live bridge proof exists. Existing demo uses fictional preconfigured session bindings.

## Lifecycle and identity

The operator configures an association's combined MCP endpoint and gateway credential in CAI, and provisions a separate CAI game bearer for the host. The host attaches/reuses a game-owned session, registers the character with that session, calls `gateway.bind()` and publishes the returned selectors through the trusted CAI route. Neither models nor browser chat inputs supply endpoint URLs or credentials.

`X-CF-Binding-Key` maps to `binding_key`; `X-CF-Binding-Generation` maps to `binding_generation`. Generation is the runtime's opaque string, currently a UUID, compared by equality. The session route supplies `X-CF-CAI-Session-Id`. Runtime restoration retains the durable binding identity when explicitly requested, but always generates a fresh generation. Gateway receipts are scoped to durable identity, not transport generation.

Delivered request:

```http
PUT /api/v1/companion/sessions/{session}/mcp-binding
```

```json
{
  "binding_key": "forester/workforce-17",
  "binding_generation": "current-framework-generation",
  "expected_binding_generation": null
}
```

On first publication the expected generation is explicitly null. Later it is the last accepted generation. The key is the attached session's immutable binding key. HTTP 200 response:

```json
{
  "data": {
    "session_id": 81,
    "binding_key": "forester/workforce-17",
    "binding_generation": "current-framework-generation",
    "version": 0
  }
}
```

Publishing the already-current generation is an idempotent success even if the request retains an older expectation. Changing generation requires an exact expectation match; otherwise CAI returns HTTP 409 `binding_conflict`. Generations have no numeric ordering. Wire `session_id` is a JSON integer; framework-local session IDs remain strings and the adapter normalizes at the boundary. `binding_key` and `binding_generation` are nonblank strings of at most 160 characters without Unicode control characters (Cc), preserving all valid surrounding spaces; `expected_binding_generation` is explicitly present and is null or the same bounded string type. Game session reads expose null before publication and the exact generation string afterward. Retired publications must not overwrite a newer generation.

Publication does not advance the conversation version. A response's current version is informational; it must not overwrite a pending conversation request's original version or acknowledge a turn/event. The pending connector must invalidate old discovery/transport and interrupt old dialogue attempts on changed generation while preserving durable call/effect records; this behavior is not yet delivered by CAI. Late raw results can still be journaled; committed game effects are not undone. Typed events keep their session version/lock semantics and are not cancelled as dialogue attempts. Interrupted-turn reconciliation still needs CAI's delivered receipt contract.

## Host recovery requirements

Before dispatch, persist the session/key, last accepted generation and exact pending publication body. Keep this journal separate from ephemeral MCP transport sessions. Retry the exact body on timeout, connection loss or acknowledgment-save failure. Persist the accepted response before replacing live accepted state or clearing the pending record, following the conversation adapter's existing persistence discipline.

Example: CAI knows G1; host sends G2 with expected G1; CAI commits G2 but the response is lost. Host restart creates a fresh runtime generation G3. First retry the retained G2/expected-G1 request. An identical-current-generation reply confirms G2 without another change. Then publish G3 with expected G2. Sending G3/expected-G1 directly would conflict because G2 may already have committed.

Do not dispatch new reasoning while publication is unresolved. A recovery replay may temporarily publish the retained retired generation, for which the restored gateway refuses tools; reconcile publication before starting any new work. If another trusted writer has advanced CAI beyond the pending generation, a conflict requires explicit host reconciliation. Do not silently read current state and retry with a new expectation to overwrite that writer.

Persist gateway/narrative/game receipts at the established safe host checkpoint. Publication recovery does not supply an atomic transaction with arbitrary physical game actions. A CAI rebind alone cannot prove an interrupted action failed, and cannot clear uncertain conversation work.

## Framework host API

```ts
import { CaiBindingPublication } from 'character-framework/cai';

const publication = new CaiBindingPublication(
  backend, // CaiHttpBackend or a test CaiBindingBackend
  savedPublication ?? {
    schemaVersion: 1,
    sessionId,
    bindingKey,
    acceptedGeneration: session.bindingGeneration,
    pending: null,
  },
  persistPublicationCheckpoint,
  assertCurrentHostRegistration,
);
if (publication.status.pending) await publication.retry();
await publication.publish(selectors['X-CF-Binding-Generation']);
```

Initialize from the attached session's delivered nullable generation only for a genuinely new journal. Prefer the saved journal on recovery; a new read must not replace an uncertain pending body. Local legacy/fake session checkpoints may lack generation metadata; the HTTP adapter requires it on new game reads. Persist `publication.save()` without credentials. Its `status` supplies pending/active/accepted generation; the host must block reasoning until publication has settled and the accepted generation matches the current gateway selectors. The coordinator does not automatically wire this guard into `CaiConversation`.

`publish()` constructs the exact compare-and-set request; `retry()` retains that input through loss, conflict and failed storage. A changed response identity/generation or malformed version never commits local acknowledgment. `dispose()` aborts transport and prevents late replies from changing local state, while retaining the uncertain checkpoint. This method cannot undo remote publication or tool effects. Publication response version is never applied to a conversation checkpoint.

## Delivery questions

CAI delivered the agreed bounds/types, nullable read metadata, CAS and event persistence contracts in message 31. Operator provisioning is delivered; connector/game turns and interrupted-turn receipt details remain pending. Joint tests should cover first publication, exact replay, lost response, restart through G1/G2/G3, competing stale publications, in-flight interruption and retained receipts. Fake-provider/disposable fixtures come before enabling live mode; no paid provider proof is implied.

## First-turn bootstrap checkpoint

A newly attached CAI session has `binding_generation:null`. Publish the runtime's generation through `CaiBindingPublication`, then read the same session through the authenticated attachment/read path. Verify its character, binding key and confirmed generation against the settled publication before saving the conversation checkpoint and permitting its first turn. Keep the existing session ID. The publication receipt's version is informational; do not copy it into the conversation as a turn/event acknowledgment. Use the verified session read for current metadata.

Persist the confirmed conversation checkpoint before dispatch. If publication/read/save is uncertain or mismatched, keep first-turn reasoning blocked and recover the original publication journal. Do not replace a conversation with pending work simply to refresh its metadata. A pending turn must retain its original generation for receipt correlation and explicit failure acknowledgment. This is a requirement for the forthcoming connection glue and disposable joint proof, accepted with CAI in message98; no live connection is enabled by this checklist.

## Connected host conversation

`connectCaiConversation` now implements the authenticated confirmation/checkpoint step after the host has registered the character and settled publication. Use the original settled conversation checkpoint; pending turns/events must retain their identity and go through their existing recovery path. The helper rejects changed session identity, generation or conversation version. It preserves queued feedback and reported IDs, stores the confirmed checkpoint, then returns a conversation guarded by the host registration, settled publication and supplied lifetime signal.

```ts
import { connectCaiConversation } from 'character-framework/cai';

// Host previously attached/reused and persisted the session, registered its
// character, bound the MCP gateway and settled this publication journal.
const conversation = await connectCaiConversation({
  backend,
  publication,
  generation: selectors['X-CF-Binding-Generation'],
  saved: savedConversation,
  signal: hostLifetime.signal,
  current: assertCurrentHostRegistration,
  persist: persistConversationCheckpoint,
});
const reply = await conversation.dialogue('Hello Mara!');
```

The helper never publishes or invents a new generation/session, copies publication receipt versions or clears pending work. A foreign writer advancing the version requires explicit host reconciliation, rather than silently refreshing the checkpoint. Hosts own the lifetime signal, publication/registration disposal and coordinated game/narrative/effect persistence. This tested connection step does not itself open a browser connection or invoke a provider; the next integration check must run the CFW conversation adapter against an isolated actual CAI API.
