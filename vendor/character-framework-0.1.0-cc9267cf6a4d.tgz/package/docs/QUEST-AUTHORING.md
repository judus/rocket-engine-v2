# Incremental quest authoring

Discovery contract 0.3 adds `inspect_quest_templates` and `compose_quest_draft` alongside the four existing tools. These tools compose and validate data. `create_quest` remains the publication operation; offering, acceptance and gameplay progression remain separate. CAI needs a generic connector, not an embedded quest schema or new quest endpoint.

Run `npm run demo:draft` for the small headless authoring example. The browser Mara demo and Rocket's pinned scripted proof stay unchanged.

## A small authoring request

Start by inspecting permitted world context and calling `inspect_quest_templates` with `{}`. The game may expose up to sixteen trusted objective templates with names, descriptions and input schemas. An empty list is valid; CAI can still provide explicit objectives referencing discovered inspection capabilities.

The fake woodland game offers `visit_location` with arguments `id` and `locationRef`. The template inserts the draft recipient and constructs its game inspection condition. CAI can request one task without writing that whole condition:

```json
{
  "draft": {
    "recipientRef": "player-1",
    "title": "Survey the Old Grove",
    "summary": "Learn what the village needs for winter.",
    "objectives": []
  },
  "change": {
    "kind": "append_step",
    "template": "visit_location",
    "arguments": { "id": "survey", "locationRef": "grove-1" }
  }
}
```

`compose_quest_draft` returns `{status:"completed", data:{draft, valid, issues}}`. Carry the returned `draft` into the next composition call. `completed` means composition completed; `valid:false` means the returned data still needs correction before publication. Drafts may have zero objectives or unresolved stage references during editing. Invalid edit shapes, unknown templates, template argument/build failures and duplicate append operations are rejected without returning an edited draft.

When `valid` is true, publish with `create_quest` arguments `{quest: draft}` and a stable effect key. Creation revalidates the current character, capabilities, recipient and references; draft validity is not a reservation or promise of later acceptance. The registered quest ID comes only from publication, not the draft.

## Edits and partial graphs

Supported changes:

| Kind                | Additional fields       | Meaning                                                                          |
| ------------------- | ----------------------- | -------------------------------------------------------------------------------- |
| `validate`          | none                    | Return current scoped issues without changing data.                              |
| `append_step`       | `template`, `arguments` | Construct one objective using a permitted trusted template.                      |
| `append_objective`  | `objective`             | Add one explicit complete objective definition.                                  |
| `replace_objective` | `objective`             | Replace the objective with the same ID; missing IDs are rejected.                |
| `remove_objective`  | `id`                    | Remove an existing objective; affected flow references become validation issues. |
| `append_stage`      | `stage`                 | Add one stage; the first becomes the flow start.                                 |
| `set_flow`          | `flow` or null          | Replace the flow for correction, or remove it for independent objectives.        |

An appended stage may refer to a later stage/objective that has not been added yet. The composer returns `invalid_flow` until every objective belongs to exactly one reachable stage and the graph has no cycles or missing destinations. See [quest flows](QUEST-FLOWS.md). Header fields can be supplied with each caller-carried draft; no server-owned authoring record exists to patch.

Scoped issues also identify `missing_objectives`, `duplicate_objective`, `recipient_unavailable` and `invalid_condition`. Invalid conditions identify an objective path so CAI can replace that objective using permitted capabilities/references. Template output uses the same checks as an explicit objective; a forester's template cannot grant access to a director-only location. Composition does not execute inspection conditions.

## State, retries and boundaries

Drafts are caller-carried data with no framework draft ID, ownership record or persistence. The host/CAI conversation may retain them as authoring context. Repeating the same composition input does not append another task to a shared draft, register a quest, consume an effect receipt, emit quest events, spawn entities or grant rewards. No effect key is needed for these two pure tools; authenticated binding and call/turn headers still apply over MCP, and calls are committed at host advancement boundaries. Discovery annotates composition as read-only and idempotent.

Inputs/outputs remain bounded to 64 KiB and the existing JSON depth limit. Drafts have at most eight objectives/stages; stage/choice limits match contract 0.2. Available templates and current reference authority may change, so validation must be repeated at publication. Duplicate whole-quest publication still uses the established effect-key receipt/checkpoint semantics.

Games optionally inject `NarrativeGame.objectiveTemplates(character)`. Templates are pure, synchronous, trusted code supplied by the game. Their `build(recipientRef, arguments)` must validate its own argument schema and return objective data; it must not perform game actions, query facts, call providers or mutate narrative state. The core validates the returned objective and scoped condition. Model input never supplies executable builders or validators. Template discovery schemas are descriptive data, not a grant of authority.

Tests cover individual task/stage composition, incomplete graphs, actor scope, corrections, invalid edits, publication replay and an official MCP compose/publish exchange. They use fake game templates and no model/provider. The live CAI connector remains pending; schema discovery and local tools are implemented.
