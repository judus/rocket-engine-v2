# Zemegagame Narrative Reuse Assessment

Zemegagame provides useful semantics and worked content. Its Godot project remains read-only. We can reuse the model and lessons without importing Godot or game-specific mechanics into core.

## Useful ideas

- Separate quest definitions from playthrough state.
- Shared conditions for quests and dialogue, with inventory/flags/reputation owned by game services.
- Dialogue entry routing by quest state: greet, offer, ask for progress or thank the player.
- Conditional choices and separate truth/report flags, supporting deception.
- Explicit consequences through registered operations.
- A worked investigation spanning George's offer, Lucas's confrontation and a return to George.

The local first slice reuses definition/state separation, shared inspection conditions and explicit player choices. Optional ordered stages and player branches now extend this slice; conversation entry routing and consequence operations remain extensions.

## Changes needed

The inspected dialogue service stores one current tree/node; independent conversations need instance state outside the shared evaluator. Quest progress is keyed by quest ID around a current-player model; our definitions, recipient offers and instances need explicit identities.

QuestObjectiveDto silently maps unknown types to interact. We reject invalid conditions/capabilities. The inspected quest/dialogue schema files are empty and cannot supply a generation contract.

Lucas content uses two consecutive quest_advance triggers to skip a consequence stage. Node-enter effects can run when a node is revisited. Explicit validated transitions and effect receipts should replace repeated advance calls and protect against duplicate consequences.

The quest service explicitly handles kill, collect and location telemetry; other content relies on dialogue triggers. Declaring talk/interact/dialogue-choice objectives does not prove automatic progress exists. Confirmed facts and player claims must remain distinct.

## Easier CAI generation

Support complete definitions and incremental drafts through the same final validator. A local QuestDraft already accepts complete objectives or small template requests, such as visit_location with a real location reference. The template fills capability arguments/expectations, allowing CAI to focus on narrative and discovered world facts.

Future MCP tools can begin a draft, add one objective/dialogue node, validate and publish. Precise issue paths and permitted references let CAI correct one part instead of regenerating a graph. Unfinished drafts must not become active content, and edits must not silently rewrite an accepted quest.

Ordered steps should become explicit stages with stable IDs, a declared entry stage and named transitions. Dialogue should similarly have explicit nodes and choice IDs, scoped effects and return-entry rules. Do not infer execution from insertion order, null nodes or repeated quest_advance calls.

The complete dialogue graph remains future work. Contract 0.2 adds bounded ordered quest stages and player-selected branches; see [quest flows](QUEST-FLOWS.md). Flat quests retain independent objectives, one offer and accept/decline choices. The local draft builder supports incremental objectives and an explicit flow; contract 0.3 now exposes pure [remote draft composition](QUEST-AUTHORING.md), with CAI review pending.

## Sources inspected

- [Dialogue and quest overview](</home/maduser/workspace/godot/zemegagame/docs/implemented/Dialogue and Quest Systems.md>)
- [Quest DTOs](/home/maduser/workspace/godot/zemegagame/systems/quests/QuestDtos.gd) and [quest service](/home/maduser/workspace/godot/zemegagame/systems/quests/QuestManagerService.gd)
- [Dialogue DTOs](/home/maduser/workspace/godot/zemegagame/systems/dialogues/DialogueDtos.gd) and [dialogue service](/home/maduser/workspace/godot/zemegagame/systems/dialogues/DialogueEngineService.gd)
- [Conditions](/home/maduser/workspace/godot/zemegagame/systems/conditions/ConditionEvaluatorService.gd) and [triggers](/home/maduser/workspace/godot/zemegagame/systems/triggers/TriggerProcessorService.gd)
- [Investigation quest](/home/maduser/workspace/godot/zemegagame/data/quests/traitor_among_us.json), [George dialogue](/home/maduser/workspace/godot/zemegagame/data/dialogues/george.json) and [Lucas dialogue](/home/maduser/workspace/godot/zemegagame/data/dialogues/lucas.json)
