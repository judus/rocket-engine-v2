# Ordered quests and player branches

Contract 0.2 adds optional `quest.flow` to `create_quest`. Existing flat quests retain their behavior: all objectives are independent requirements. A flow evaluates only the active stage and completes when the selected path reaches a satisfied terminal stage. The framework owns this state; game inspection capabilities supply the facts.

Run `npm run demo:flow` for a small bodyless-director example. It builds objectives individually from the trusted visit template, publishes once, waits for the player to choose a route and completes the selected path. The browser chat demo remains the simple one-objective forester example.

## Authoring

Supply the usual recipient, title, summary and objective definitions, plus this flow:

```json
{
  "start": "survey",
  "stages": [
    {
      "id": "survey",
      "objectives": ["survey"],
      "dialogue": "Which place should we help?",
      "choices": [
        { "id": "town", "label": "Help River Town", "next": "town" },
        { "id": "grove", "label": "Stay in the grove", "next": "grove" }
      ]
    },
    { "id": "town", "objectives": ["town"] },
    { "id": "grove", "objectives": ["grove"] }
  ]
}
```

Each listed objective ID must have a complete objective definition using an inspection capability granted to this character. The headless example contains the complete request. For a linear sequence, replace `choices` with `next`. A terminal stage has neither. Objectives within a stage are all required.

Bounds: one to eight objectives and stages; one to four choices per branching stage. Every objective belongs to exactly one stage; all stages must be reachable from `start`. Stage IDs and choice IDs within each stage are unique. Cycles, missing destinations, duplicate assignments and a stage containing both `next` and `choices` are rejected. JSON Schema checks shape; runtime validation checks the graph and capability/reference scope. Rejection commits no quest.

`QuestDraft` accepts `flow` in its header and can add objectives one at a time with `addObjective` or `addStep`. `toInput()` checks the complete graph before publication. Templates are trusted injected builders; contract 0.3 now exposes [incremental draft authoring](QUEST-AUTHORING.md) through pure scoped tools. Editing published quests remains future work. CAI can currently author the complete request through `create_quest` without any game-specific quest schema in its backend.

## Progress and dialogue

Acceptance activates the start stage. Only current-stage objectives are inspected. Confirmed satisfaction is latched; unknown or failed observations never advance progress. A satisfied stage with `next` advances automatically. A satisfied stage with `choices` stays active until the player chooses. A satisfied terminal stage completes the quest; objectives in unselected branches remain pending with no observations.

`inspect_quest` returns `flow.definition`, `flow.currentStage`, `flow.visited` and `flow.dialogue` alongside objective progress and currently available `choices`. Stage dialogue is authored text for the host to display, not a new CAI chat turn. Inspection without a recipient returns no instance stage/history/dialogue. The host should use the returned choice IDs as opaque values and submit the authenticated player's selection through `narrative.choose(recipientRef, choiceId, effectKey)`. CAI has no player-choice tool. Wrong recipients and unavailable/stale choices are rejected; an identical effect-key replay returns the original receipt.

Conditions describe current game facts. A visit that occurred before entering a later stage may already satisfy its condition once that stage becomes active. Games needing "visit after entry" must expose a suitable timestamp/cursor condition; stage order alone does not invent that distinction.

`inspect_quest` permits up to four returned choices and opaque IDs up to 3,200 characters, accommodating URI encoding of the bounded authored IDs.

Stage entry and branch selection emit committed framework facts for outcome feedback, not player dialogue or successful physical actions. Distinguish their stage references:

- A `quest_branch_selected` event is emitted **before** the transition. Its `stageId` identifies the source branching stage and its `choiceId` is the selected opaque ID.
- The completed `narrative.choose` receipt is returned **after** the transition. Its `stageId` identifies the destination; its `choiceId` is the same opaque ID. Do not look up the authored choice in this destination stage.
- The following `quest_stage_entered` event names the destination. `flow.visited` records the source and destination in order, but later transitions may advance it further; the branch event is the stable source reference.

CAI feedback uses `origin=framework_narrative` and the adapter-reserved stable `source_event_id`. Reference values remain bounded to 160 characters. Resolve the branch event's source stage in the immutable definition and match its opaque ID against that stage's authored choices. Forward the authored key as `choice_id`, the source as `choice_stage_id` and the destination as `stage_id`. Do not truncate the opaque ID or derive any of these references from dialogue.

```js
const source = definition.flow.stages.find(
  (stage) => stage.id === event.stageId,
);
const choice = source?.choices?.find(
  (choice) =>
    `${event.questId}/stage/${encodeURIComponent(source.id)}/${encodeURIComponent(choice.id)}` ===
    event.choiceId,
);
if (!choice) throw new Error('Branch event does not match its definition');
conversation.enqueueFeedback({
  sourceId: event.id,
  origin: 'framework_narrative',
  type: 'quest_branch_selected',
  summary: 'The player selected a quest route.',
  references: {
    quest_id: event.questId,
    choice_stage_id: source.id,
    choice_id: choice.id,
    stage_id: choice.next,
  },
});
```

This example consumes a `quest_branch_selected` event from the narrative event drain and its quest definition. The adapter supplies `source_event_id` automatically. The host owns collecting and durably forwarding these events; the simple demo currently forwards only its flat quest outcomes.

## Recovery and limits

Checkpoints retain the current stage, visited path, objective progress and receipts. Restore rejects impossible paths, progress in unvisited stages and inconsistent completion atomically. Old flat checkpoints remain readable. New flow checkpoints require this implementation; the earlier runtime does not understand them. The host still owns durable checkpoint storage.

This slice supplies quest sequencing and branch dialogue. General conversation graphs, loops, rewards, action triggers, generated follow-up quests and live CAI integration remain roadmap work. The tests and demo use fake game facts and no paid provider.
