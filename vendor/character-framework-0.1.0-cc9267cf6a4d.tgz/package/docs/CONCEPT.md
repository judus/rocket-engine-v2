# Character Framework Concept

The character framework gives characters a brain and owns a reusable quest and dialogue system for any game. Characters can be embodied NPCs, disembodied voices or unseen story and lore directors. Personality, memories, relationships, motives and judgment influence what a character says, wants and attempts. The framework connects those choices to real behavior and feeds actual outcomes back into the character's experience. Task execution supports this purpose; it is not the whole purpose.

Status: working concept, revised 12 October 2026. The ownership boundaries and session model below reflect the agreed direction. Concrete API shapes and execution policies remain proposals. See [the roadmap](ROADMAP.md) and [the CompanionAI discussion](COMPANIONAI-REQUESTS.md).

## Responsibilities

| Owner                         | Responsibility                                                                                                                                         |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Character Framework           | Character instances, quest definitions and progression, dialogue flow and choices, narrative access policy, intentions, execution and outcome feedback |
| CompanionAI Next              | Profiles, persistent sessions, personality, session memory, generated dialogue and quest content, contextual reasoning                                 |
| Game                          | World facts and mechanics, entities, qualifications, jobs, inventory, combat, fire and rewards; inspection/action capabilities exposed through MCP     |
| Rocket Engine v2              | Optional navigation, route estimates, route following and movement; physics integration and presentation                                               |
| Production Workshop when used | Authoritative production, reservations, inventory and delivery cargo                                                                                   |
| Zemegagame                    | Reference for quests, dialogue, service composition and character behavior; no Godot integration is required                                           |

Rocket has its own JavaScript engine and games. Neither character intelligence nor game economy becomes mandatory engine core. The character framework owns the universal quest/dialogue runtime. Games integrate through capabilities rather than implementing a competing narrative runtime. Universal means reusable narrative semantics with game-supplied facts and actions, not identical gameplay mechanics in every game.

## One character and one attached session

A framework character instance stores its CompanionAI character ID and attached session ID. An embodied character also references a game-owned entity; a director has no physical entity at all. Either can use an existing CAI character or request a generated profile. Creating a CAI character does not spawn an entity.

For each framework character instance, the game creates a session only when none is attached. It then keeps using that same session for player chat, narrative continuity, quests and future behavioral reasoning. Reconnecting or saving/loading normally reuses the binding rather than creating a session for every interaction.

The session's memories are scoped to that session. Memories from ordinary chats or other game sessions must not enter it, and its memories must not enter those sessions. The CAI character remains available outside the game for new ordinary chat sessions. We reuse CAI characters directly; a separate immutable profile snapshot or world-context model is not an initial requirement.

The requesting game instance has exclusive write access to its game session. Other clients see it as read-only wherever their existing access allows them to read it. That includes all routes capable of mutating the session, not just sending chat messages. A simple backend association with a game identity/key is the initial mechanism. Detailed delegation, tenant policies and world-history branches are deferred.

## First connection to CompanionAI

The first slice connects existing character, session, chat and quest capabilities to game NPCs:

1. The game creates workforce entities with professions, qualifications and other facts.
2. It asks CAI to create a fitting profile using prose, or selects an existing character.
3. It attaches one game-owned session with a selected mode.
4. The mode may generate that NPC's initial quest.
5. The player chats through the attached session, and the framework receives dialogue and quest content.
6. The framework tracks choices and quest progression, uses game facts/results to establish progress and reports that history to the session.

A profile prompt can describe GrandQuest, its fantasy world and quirks, then ask for a forester who fits the supplied stats and facts. The desired result is a saved CAI character ID. CAI already has prose-based profile suggestion; review whether suggestion followed by existing creation is sufficient before adding a specialized endpoint. Single requests are enough initially; batching workforce profiles is a useful follow-up.

This first slice is the entry point to the larger character framework. Movement, courier plans, autonomous goal selection and tactical decisions remain in scope and develop alongside CAI after the initial connection works.

## Personality becomes behavior

An NPC is not merely a chat window or a worker that executes assignments. A lazy forester, loyal warrior and reckless troublemaker can choose differently even when offered the same capabilities.

The game supplies facts and opportunities. CAI interprets them in the character's session, using personality and experience. The framework turns proposed intentions into supported game requests, maintains responsive local execution and reports actual outcomes.

The desired future response can combine dialogue, behavioral intentions and narrative proposals. These need not be three independent model calls. Exact response fields and how they fit existing CAI turns should be designed with CAI rather than prescribed in advance.

### Insult and redemption

The player insults an NPC. The session interprets the insult in context. The NPC might say “Find someone else to help you,” walk away, refuse to offer its quests, or propose a redemption quest.

The framework coordinates these related intentions. Rocket executes the departure. The framework changes narrative quest access and validates/registers a new quest against supported capabilities and current game facts. Any physical eligibility or world-changing effect still goes through the game. Feedback records whether the NPC actually left, whether access changed and whether the proposed quest was accepted. Dialogue alone cannot confirm those effects.

Conversation itself may change mood, relationship and memory through CAI's session behavior. Physical success and gameplay consequences require game confirmation. A rejected action does not erase the fact that the character wanted to attempt it.

### Work and qualifications

The game exposes needed professions, available jobs and the character's actual qualifications. Reasoning considers those facts alongside willingness, laziness, ambition, loyalty and resentment. The NPC might accept work, refuse, negotiate or seek another role.

A profile's descriptive occupation does not automatically grant a game skill or qualification. The game determines job eligibility and assignment. Physical attendance is established after actual arrival and revoked on departure or other game-defined invalidation; production remains owned by the game or Workshop.

### Reckless behavior

A chaotic character may attempt something foolish, such as setting a flammable object on fire, if that behavior is available in the game. CAI proposes the motive and intention. The game determines valid targets, ability requirements and actual fire consequences. The framework reports failure or success back to the session.

No text response creates a mechanic the game has not implemented. Game rules constrain execution without requiring every NPC to make sensible or obedient choices.

## Reasoning and local execution

CAI supplies contextual character reasoning and narrative continuity. Local policies and scripted providers keep movement, routine tasks and immediate reactions responsive. Scripted actors and machines can work without CAI. These providers use the same host capabilities and control boundaries.

The exact division between remote and local decisions is open. Start with meaningful choices such as refusing work or walking away, while local execution handles routine steps. Later tactical decisions, social behavior and opportunistic goals can use richer context without remote model calls per frame.

The host determines when to reconsider: dialogue, relevant world events, changed opportunities, action failure or a bounded interval. A movement request can continue while reasoning is pending. Remote replies are applied at a safe update boundary, not directly from a network callback.

Only one effective authority controls an actor's conflicting actions. Player takeover, interruption and actor removal invalidate old autonomous requests. Task/control/runtime generations allow the framework to reject stale replies. These are execution concerns; they do not require CAI to understand the framework's internal scheduler.

## Embodied characters and story directors

A character does not require a sprite, body, position, profession or public chat interface. An unseen story/lore director can inspect game-wide facts, maintain narrative continuity, introduce quests, connect story branches and request world events through available capabilities. Its persistent CAI session is its narrative memory just as an NPC session is that NPC's memory.

Physical characters normally receive local observations. A director can receive game-wide inspection capabilities, but broad presence does not imply unrestricted knowledge or world mutation. The game selects the tools available to each role. A director can request a spawn or event only if the game supplies such an action and accepts it. Physical movement remains optional per character.

## Game capabilities through MCP

Each game exposes inspection and action capabilities through MCP tools. Inspection tools provide facts such as entity details, resources, job availability and world events. Action tools request operations such as travel, pickup, spawning a game event or granting an eligible reward. The game validates targets, qualifications, resources and current rules when accepting an operation. Advertised capability does not guarantee success.

The framework's quest/dialogue runtime uses these capabilities to evaluate conditions and request consequences. Examples might be inspect_entity, inspect_inventory, request_move or grant_reward; names and payloads are proposals. Framework-owned narrative operations, such as offering a quest or advancing a dialogue node, remain framework operations and may be exposed to CAI as framework tools.

MCP is the game integration surface, not a second rules engine. Underlying typed capability contracts also allow local execution and fake adapters; this does not imply network tool calls or model reasoning per physics step. How CAI reaches game/framework tools, directly or through a framework tool bridge, is an integration question for CAI review.

## Execution state

| Concept           | Meaning                                                     |
| ----------------- | ----------------------------------------------------------- |
| Intention or goal | What the character wants to achieve                         |
| Task              | A tracked attempt to carry out an intention                 |
| Plan              | Local steps and branches used to carry out a task           |
| Action            | One accepted or rejected operation with observable progress |

Use narrow injected collaborators for actor bindings, context preparation, reasoning, execution and result feedback. Their public class structure is undecided. Start with a small state machine and explicit plans; a universal planner, mandatory behavior tree, ECS or editor is unnecessary.

Accepted operations report running, waiting and terminal outcomes. Arrival is different from acceptance. Cancellation does not roll back committed effects. Repeated commands use stable operation IDs where effects could otherwise repeat. Unknown outcomes are reconciled with the host before retrying.

A courier plan remains a useful mechanical proof: travel to pickup, obtain authoritative cargo, travel to destination and unload. Cargo stays with its owner, including after interruption. This verifies execution reliability; personality-driven examples verify the framework's actual purpose.

## Rocket boundary

Rocket owns navigation, route estimates, route following and movement. The game supplies traversal rules and actor capabilities. Physics owns dynamic body poses. The character framework chooses destinations and responds to outcomes without calculating routes or writing poses.

Before implementation, review journey request/status/cancellation and navigation estimate contracts together. Agree actor identity, coordinate spaces and units, fixed points versus entity/interaction targets, readiness, arrival criteria, failure and control-release semantics. These contracts must also work for Rocket consumers without this framework.

A finite-map proof can precede streamed worlds. Unloaded terrain is unknown, not automatically walkable. View teardown does not imply actor removal, but view-independent simulation requires an explicit host/Rocket arrangement. Actor residency and collision readiness remain later work.

## Framework owned quests and dialogue

The framework owns a reusable narrative model: quest definitions and instances, objectives and stages, conditions, dialogue nodes/choices, offering/refusal, continuation and branching. It owns quest progression and narrative save state. It evaluates conditions from game-provided facts/results and invokes game actions for physical effects or rewards. A completed objective never directly edits an inventory or grants an unsupported ability.

Each character's attached session can hold an ongoing quest history. A session mode may generate the initial quest, later quests after completion, additional tasks or a new branch following a player choice. The NPC can respond to an insult with a redemption story or withhold an existing offer.

CAI's session mode and quest generation are starting points for authoring the framework's narrative content. We can offer a reusable framework format or framework authoring tools rather than requiring a separate CAI schema for every game. Game-specific capability arguments still need validation. Review how CAI can emit this content or call these tools without prescribing an endpoint in advance.

The framework validates/registers generated narratives, tracks executable objectives and dialogue choices, and reports progress to CAI. The game remains authoritative for the facts that satisfy objectives and for every world-changing action. CAI remembers the narrative without becoming a second executable quest-state authority. Framework quest/dialogue saves and CAI session continuity have distinct roles. Proposed quest branches and save-history branching are different problems; the latter is deferred.

## Persistence and timing

Persist framework character/session bindings, quest instances, dialogue state and durable task references in coordination with host state. Physical entity references are optional. Ordinary restore reuses the same CAI session. Rewinding game history while retaining later remote memories is an unresolved later policy, not an initial branch-infrastructure requirement.

Save operation IDs and current execution steps, not promises, body handles, clients or route geometry. Restore reconciles host facts before activating tasks. A cargo transfer committed before a crash must not repeat because its response was lost.

The host advances framework execution and movement once under its timing policy. Workshop advancement retains one owner. Simulation deadlines and network timeouts have distinct meanings. Bound observation size, pending decisions and retries as the first integration establishes practical limits.

## Current integration limits

The earlier source inspection found Rocket's navigation/route following still planned and scene updates dependent on a view. Do not assume background execution or streamed collision readiness from roadmap prose.

CAI already has character suggestions, sessions, chat and chat-based quests. Which pieces can serve the game directly, which need a game mode and which need extension are questions for its maintainer. Personality-driven physical behavior is new work to design together. The [CAI discussion](COMPANIONAI-REQUESTS.md) describes desired scenarios rather than assigning endpoint implementations.

## Source references

Current sources inspected on 12 October 2026:

- [Original handoff](/home/maduser/Documents/Codex/2026-10-11/h/outputs/character-framework-brainstorm.txt)
- [Rocket architecture](/home/maduser/workspace/rocket-engine-v2/docs/ARCHITECTURE.md), [roadmap](/home/maduser/workspace/rocket-engine-v2/docs/ROADMAP.md), [runtime source](/home/maduser/workspace/rocket-engine-v2/src/Rocket.ts), [physics prototype](/home/maduser/workspace/rocket-engine-v2/src/physics/matter.ts) and [factory transport](/home/maduser/workspace/rocket-engine-v2/examples/workshop/FactoryDemo.ts)
- [Original ship controller](/home/maduser/workspace/rocket-engine/demo/src/components/ControllerComponent.js) and [cargo component](/home/maduser/workspace/rocket-engine/demo/src/components/CargoBayComponent.js)
- [CompanionAI handoff](/home/maduser/workspace/companion-ai/companion-ai-next/.context/06-developer-handoff.md), [turn agent](/home/maduser/workspace/companion-ai/companion-ai-next/apps/server/app/Companion/Agents/CharacterTurn.php), [turn application](/home/maduser/workspace/companion-ai/companion-ai-next/apps/server/app/Companion/Actions/SubmitCompanionTurn.php) and [API routes](/home/maduser/workspace/companion-ai/companion-ai-next/apps/server/routes/api.php)
- [Zemegagame vision](/home/maduser/workspace/godot/zemegagame/docs/vision/vision.md), [quest and dialogue reference](</home/maduser/workspace/godot/zemegagame/docs/implemented/Dialogue and Quest Systems.md>), [controller composition](/home/maduser/workspace/godot/zemegagame/scenes/characters/GameCharacter.gd) and [combat blueprint](/home/maduser/workspace/godot/zemegagame/docs/blueprints/combat_system_plan.md)
