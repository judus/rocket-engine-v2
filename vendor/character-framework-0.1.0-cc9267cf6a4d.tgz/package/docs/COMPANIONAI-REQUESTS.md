# CompanionAI Character Framework Discussion

We want the character framework to give characters a brain and own a universal quest/dialogue runtime: personality, memories, relationships and motives that influence dialogue, quests and eventually physical behavior. CompanionAI is intended to support this use. We would like to understand what its existing character/session machinery can already provide and which extensions would fit naturally.

Status: discussion proposal, revised 12 October 2026. This replaces the earlier endpoint-oriented implementation request. It is not an assignment to add the previously suggested context/profile/event APIs. Please review the scenarios below before designing infrastructure or routes.

## The intended connection

The framework creates a character instance associated with an existing or newly generated CAI character and one persistent game-owned CAI session. A physical NPC additionally references a game entity. An unseen story/lore director has no body. Both keep using the same session for narrative memory and reasoning; player chat is available where the role calls for it.

Game memories stay scoped to that session. It neither imports other session/global memories nor contributes its memories to other sessions. The character remains available outside the game for ordinary new chat sessions.

The requesting game instance owns write access to its game session. Other clients are read-only wherever otherwise allowed to read. Initially a simple game identity/key association on the backend is sufficient. Our applications run on the development server; detailed permission policies can evolve. All paths that mutate the session need to honor that ownership, but we are not asking for a sophisticated tenant/delegation system.

Please assess this existing-character/existing-session model directly. Separate profile snapshots, world contexts, history branches and a new event ledger are not initial requirements.

## First slice Profile generation

The game may already have workforce entities and factual stats. It can send prose such as:

> GrandQuest takes place in a fantasy world with these cultures and quirks. This entity is a forester with these qualifications and facts. Create a character who fits this world, with a distinct personality.

We would like a saved CAI character ID that the game can attach to its entity. The existing prose-based profile suggestion seems close. Single requests are enough initially; batched suggestions/creation could help populate a workforce later. The game remains authoritative for qualifications even if the generated profile describes an occupation.

What can the current suggestion and character-creation routes provide? Can the game compose those existing operations, or would a small generate-and-save convenience operation fit better? How should we supply game facts so a profile respects them while inventing personality?

## First slice Session creation and player chat

If an NPC has no session attached, the game creates one with its selected mode. It stores and reuses the session ID. The player chats with the NPC through that session; we want to retain CAI's personality, mood, relationship and memory behavior where applicable.

Can an existing session mode ensure session-only memory, including reads, writes and background maintenance? What small changes would make a session writable only by its requesting game instance across existing session-mutating routes? Which current chat operations can we reuse directly?

We are not proposing stateless reasoning or one session per interaction. Character-wide profile sharing remains intentional; evolving game conversation belongs in the attached session.

## First slice Quests attached to NPCs

Session creation may automatically generate an initial quest according to its mode. Each NPC can hold its own ongoing story. When a quest finishes, the same session remembers it and can offer another. A player's choice may produce new tasks or a new narrative branch, and CAI may introduce further quests during later interactions.

The character framework receives generated content and owns quest definitions, instances, progression, dialogue flow and narrative access. Games expose inspection/action capabilities through MCP. Framework objectives use game facts/results, and rewards or other world effects execute only through accepted game actions. The framework reports choices and actual progress to the session; CAI supplies generation and continuity rather than a second executable quest runtime.

Could current session/quest modes generate a reusable character-framework quest/dialogue format? Could CAI instead call framework authoring tools to create quests/tasks and use the game's MCP tools to inspect facts and request actions? We want games to supply capabilities rather than require a different narrative runtime or CAI quest schema for each game. What is the smallest useful first format/tool bridge and feedback mechanism?

Zemegagame's quest/dialogue system is a reference. Rocket has its own games, which consume the character framework's narrative runtime. We do not need a Godot bridge or multiple format targets in the first slice.

## Developing behavioral reasoning together

Profiles, sessions, quests and chat establish the first connection. The larger framework also includes movement, courier plans, autonomous goals and tactical decisions. CAI does not yet supply this physical-behavior integration; we want to develop it together rather than force it through an incompatible API.

Example: the player insults an NPC. CAI interprets the insult using personality and session history. The character responds with a comment and may propose walking away, refusing its quests or offering a redemption quest. The framework requests those supported operations; Rocket performs movement; the framework changes narrative access or registers the quest. Game actions still govern physical consequences. Actual outcomes return to the same session.

Work example: the game needs a profession and supplies job requirements plus the character's actual qualifications. Personality influences willingness. A lazy character may refuse, an ambitious one may negotiate, and a chaotic one may attempt a foolish action such as setting a valid game object on fire.

We imagine a turn that can combine dialogue, behavioral intentions and narrative proposals. The game exposes supported opportunities/capabilities and validates effects. CAI need not choose every route step or run per frame. Local execution remains responsive while remote reasoning considers meaningful situations.

How could existing turn machinery support this combined response? Would a game turn mode, an extended result schema or another session operation fit best? Which mood/relationship/memory behavior should remain part of the turn, and how should we report action outcomes without treating proposed behavior as completed behavior?

## Characters without a body

A character can be an omnipresent story/lore director behind the scenes. It can inspect game-wide context through tools supplied for that role, propose quests and branches, and request world events through available actions. It need not have a position, movement capability or player-facing chat window. Broad narrative presence does not automatically grant every possible action.

Can existing CAI profiles/sessions accommodate such a director role? How could the session discover and call game inspection/action tools plus framework narrative tools? Should CAI connect to MCP directly or should the framework bridge calls using its game association? Please suggest the simplest workable arrangement rather than a new generalized permission system.

## Boundaries and proportionate reliability

The framework owns quests, objective progression, dialogue and narrative access. The game owns entities, inventory, qualifications, rewards, fire and other world mechanics exposed through MCP. CAI owns character/session narrative behavior. A spoken claim does not commit a game operation, but the conversation and the character's intention can still matter to mood and memory. A failed attempt should remain a failed attempt in later reasoning.

Basic session ownership, request correlation and protection against repeated effects matter from the start. We can reuse CAI's existing mechanisms where they fit. We do not prescribe a general operation service, exactly-once provider execution, branching history system or complex projection cursors before establishing the first integration. Ordinary reconnect/load reuses the session; game rewind and remote-memory rollback are later questions.

## Concrete first contracts

The [MCP tool contracts](MCP-CONTRACTS.md) supply the initial four tools, request binding, successful/rejected forester and director examples, and typed feedback. The framework now implements its HTTP server with fake-client proofs; see [the connection handoff](MCP-SERVER.md). CAI connector/session changes remain a discussion, not an implementation assignment.

Could CAI's next proof attach its generic connector to this endpoint, preserve the raw tool results and request initial authoring through the bound session? The handoff supplies current binding generations and logical call/effect headers. CAI's reviewed journal/retry policy fits; the remaining question is how the framework can read an incomplete CAI turn's known and unresolved tool effects. No new universal operation service is needed for this first connection.

## What would help from your review

Please respond with:

1. The smallest concrete flow using existing character creation/suggestion, session creation, chat and quest facilities.
2. The missing pieces for game-owned sessions and session-only memories, with suggested small extensions.
3. A practical way for a session to generate framework-owned quests/dialogue and receive choices/progress.
4. A proposed path from that first slice to combined dialogue and behavioral intentions, including outcome feedback.
5. How a disembodied story/lore director can use game MCP capabilities and framework narrative tools.
6. Questions that prevent those examples from working, rather than decisions about infrastructure we have not requested.

Please distinguish existing behavior, plausible reuse and new work. A short example using one forester NPC and one unseen story director would help us agree on the connection before assigning implementation.
