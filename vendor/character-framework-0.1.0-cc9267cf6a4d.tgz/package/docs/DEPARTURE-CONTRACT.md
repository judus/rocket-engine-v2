# Departure admission and outcome proposal

Status: proposed for Rocket review after message186; not an implemented adapter or new API. Existing finite-world Movement/Journey support is sufficient for a bounded one-actor proof. CFW read Rocket navigation contracts, move/retry/dispose paths and keepAlive policy read-only. The reviewed CFW/Rocket package pin and working chat demo remain unchanged.

## Existing references

- src/types.ts: Decision.intention is a local proposal, Capability validates a game action, Admission schedules framework work, and CapabilityResult distinguishes running/completed/rejected. A local Decision is not a new CAI reply envelope.
- src/mcp/McpGateway.ts and src/mcp/HostLane.ts: granted custom game capabilities use original schemas, host advancement and scoped mutation receipts. Capability Invocation.requestId currently carries the trusted logical MCP call ID; the outer gateway receives and journals the mutation effect key, but does not expose that key in Invocation. These identities must not be silently equated.
- src/cai/types.ts: CaiFeedback carries sourceId, origin, type, summary and bounded string references. CaiConversation.enqueueFeedback reserves source_event_id; pending event UUID/version survives JSON restore and exact retry. CaiHostDriver.persistFeedback stores queued feedback before source acknowledgment while idle. The host retains source events during active driver work.
- Rocket src/navigation/contracts.ts and Movement.ts: game-owned MoveRequest, Journey and snapshots; moving/blocked are nonterminal; arrived/unreachable/cancelled are terminal. Journey IDs are controller-local, and repeating move creates a new journey.
- Rocket src/Rocket.ts: scene keepAlive is explicit, visibility/app stop still pause, and no offline elapsed time is accumulated. Current Mara scene does not select keepAlive.

## Proposed trusted action boundary

Expose a granted game_submit_departure mutation tool through the combined endpoint. Model arguments contain only an authored destination_ref. The game resolves it to bounded physical coordinates and supplies approved speed/tolerance/replan policy; the model cannot set actor identity, operation/effect identity, eligibility, physics or traversal permissions. Reject unknown destinations and stale actor generations before changing an existing journey.

The game adapter owns a maximum128-entry non-evicting ledger for this proof. Each admitted operation contains a host-generated opaque operation_ref, original trusted call identity, canonical destination arguments, actor identity, adapter incarnation and bound Journey. Exact replay returns the retained admission/outcome; changed arguments conflict. At capacity reject before move. Never treat journey-N alone as an idempotency key. The MCP gateway's mutation receipt and game operation ledger must be checkpointed coherently before claiming durable recovery. The first proof is volatile; after reload it must not resume/reissue unknown physical work.

One actor has at most one admitted nonterminal departure. Proposed default: reject another departure with actor_busy; do not automatically supersede. This leaves Rocket's move supersession behavior behind explicit game policy. A valid explicitly superseding game command, if later authorized, must capture the prior cancellation with its original identity before admitting the replacement.

A successful submission returns CapabilityResult running with the opaque operationId. It means the host admitted one journey; no arrival is claimed. Even immediate terminal planner results are correlated through the same operation. Poll authoritative snapshots once on the existing game update boundary; no presentation callback or new timer advances movement.

| Rocket state / event                                  | Proposed interpretation                                                            | CAI feedback                                                           |
| ----------------------------------------------------- | ---------------------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| moving                                                | admitted, still executing                                                          | No completion event                                                    |
| blocked                                               | waiting; retain reason and identity; existing retry/world-change policy may resume | No terminal rejection or arrival                                       |
| arrived                                               | host confirmed pose within game tolerance                                          | departure_arrived                                                      |
| unreachable                                           | finite discretized planner failure                                                 | departure_unreachable; no arbitrary-world impossibility claim          |
| cancelled under explicit game policy / supersession   | terminal cancellation of the original operation                                    | departure_cancelled with bounded reason                                |
| invalid destination/actor/capability before admission | rejected; no move and no previous journey cancellation                             | Tool rejection; optional authoritative departure_rejected source event |
| actor removal / scene teardown                        | invalidate incarnation and dispose movement owner; suppress late arrival           | Retain local retired/cancelled record; delivery policy below           |

## Feedback, lifetime and uncertainty

For each terminal transition, store one immutable source record before dispatch, with sourceId derived from opaque operation_ref and terminal revision. Use origin game_outcome, a bounded truthful summary and references operation_id, actor_ref, destination_ref and reason where relevant (leaving room for automatically added source_event_id). No executable payload or actor relationship partition is implied. After idle-driver persistFeedback succeeds, the source queue may acknowledge its record. Pending CAI event loss retries its original UUID/version; feedback replay never calls Movement.move. If storage fails, preserve the source/terminal record and block a replacement operation that would lose required evidence. Repeated snapshot observation cannot allocate another terminal source ID.

Before actor removal or scene teardown, dispose/invalidate movement ownership and retain the old operation's cancellation evidence in host storage. Do not manufacture arrival or route old evidence through a replacement actor generation/session. Proposed conservative first-proof policy: keep retired evidence local if the old binding cannot legally publish; require explicit host reconciliation before future session work that assumes it was delivered. Removal does not automatically reattach or republish a CAI session. This is not a general background outbox implementation.

View detach/stop-waiting only changes presentation. It neither cancels the journey nor invalidates host authority. Last-view pause follows the game's existing scene policy; a decision to use keepAlive belongs to the game. Resumption uses current physical state, with no catch-up movement. Cancellation of movement needs a separate explicit game command/policy, not the dialogue stop-waiting command.

## Review gates before implementation

Confirm the one-active-operation actor_busy default and retired-evidence policy. Confirm whether the adapter ledger should correlate trusted logical call IDs plus host operation_ref, or whether Invocation needs an additive trusted mutation effectKey for direct game-ledger recovery. The current outer gateway has the effect key, but custom capabilities receive only the call ID; no new model-supplied identity field is proposed.

Then prove exact submission replay calls move once, blocked waiting never yields success/failure prematurely, terminal feedback emits once, changed input conflicts, invalid submission does not supersede valid movement, disposal suppresses late outcomes and lost feedback retries without restarting movement. Any real Rocket consumer or checkpoint store remains owned by its project. No live-provider evaluation, network/browser authentication, navigation implementation or package repin is requested by this proposal.

## Additive mutation identity candidate after review189

The focused CFW candidate adds exported MutationIdentity with readonly id:string and optional readonly Invocation.mutation:MutationIdentity. The logical Invocation.requestId remains unchanged. A granted MCP action receives a detached frozen identity whose id is SHA256 of the exact canonical scoped receipt key already used by McpGateway. That scope includes game ID, stable binding ID, framework character ID and CAI character/session identity, followed by the trusted effect key. Delivery call IDs, turn IDs and arguments are excluded; arguments remain checked by the existing receipt digest. No raw secret or new model argument is exposed. The identity is a correlation key, not a capability grant.

Registration generation remains the existing separate authorization guard and is intentionally not added to the stable effect key; otherwise a rebind could silently turn retained physical work into another effect. Stale handles and old-generation publication remain rejected by current binding/lifetime checks. A replacement binding must reconcile prior evidence before interpreting a retained receipt as current permission.

Inspections and local CharacterRuntime calls omit mutation entirely. A game adapter that requires gateway mutation provenance returns rejected/missing_mutation_identity before admission when it is absent; it must not fall back to requestId. Custom model arguments cannot populate this field. Missing trusted effect headers still fail the existing mutation gateway guard. Unresolved gateway receipts still fail instead of reexecuting.

Files: src/types.ts and src/index.ts add/export the type; McpGateway computes the identity only inside mutation admission; HostLane captures it before execution and carries it into Invocation. Tests in tests/mcp.test.js cover changed delivery ID replay returning the original running operation, changed arguments conflicting, separate effects sharing a logical ID, separate binding/session scopes, attempted model-field forgery and absent inspection/local metadata. Existing receipt loss, unresolved-effect and late-registration tests remain required. The candidate does not implement departure or task persistence.

Packaging: keep accepted Rocket archive4541c2f48bae untouched. A separately hashed private review archive may be produced after the full gate; no publication/version bump or consumer repin is required. Rocket reviews the exact contract/candidate before its own adapter integration.

## Exact feedback persistence boundary

CaiBackend.event maps through CaiHttpBackend to POST /api/v1/companion/sessions/{session}/events. The retained input is event_id UUID, expected version, origin game_outcome/framework_narrative, bounded type/summary/references. The sourceId is automatically retained as references.source_event_id. CAI's owner/game-session binding and optimistic version checks apply; a version conflict is reconciliation, not permission to regenerate an event. Event response must match event_id and advance the saved version; CFW persists the acknowledged checkpoint before clearing pending work/reporting success.

CaiFeedback bounds: type80, summary2000, at most16 reference entries including source_event_id, key80/value160, nonblank valid strings and no control characters in identifiers. CaiConversation retains at most128 queued feedback and4096 queued+reported source IDs. On queue rejection or storage failure, the host source record remains unacknowledged; no arrival evidence is discarded or replaced with a new event ID. Before remote dispatch, retry persists the exact pending UUID/version/input. After lost reply or failed acknowledgment, retry uses that same input; new work cannot bypass pending events.

During active CaiHostDriver work, persistFeedback rejects before enqueue. The scene host retains terminal source records in its own bounded queue and tries only after the driver becomes idle; no extra timer is needed. Successful persistFeedback acknowledges transfer into the durable driver bundle, not remote delivery. If remote confirmation is required, it remains separately pending until the reported source ledger is durably updated. The volatile example cannot claim either store is production durable.

A retired binding with no legal delivery stays explicitly reconciliation_required in host status, with original operation/source/session/generation evidence retained locally. The proposed adapter must block work depending on that delivery and expose the reason; it cannot silently report delivery, send through a replacement binding or invent a session. This status is proposed host-owned state, not a new CAI route or completed outbox implementation.
