# Disposable CAI–CFW forester proof

CFW owns the actual MCP gateway, one Mara world and trusted host controls. CAI owns an isolated database/session harness, native game agent and API calls with provider HTTP faked. This fixture alone is preparatory evidence; the joint proof requires that CAI harness over actual HTTP.

Launch from the CFW repository:

```sh
CF_PROOF_LISTEN_IP=172.28.0.1 CF_PROOF_ALLOWED_HOST=host.docker.internal:8096 npm run proof:joint:fixture
```

The private bridge address above was verified locally on 13 October 2026, but Sail requests timed out and host.docker.internal resolved to172.17.0.1. For this bounded proof, CAI runs a disposable copy of the same built fixture and installed dependencies inside Sail on loopback (Node>=24, preserved ESM package type, no external-host environment settings). Network deployment remains deferred. Default launch listens on loopback for host-only runs. No public interface is supported. The process prints a private config path, never its random credential. Config is created exclusively with mode0600 and contains `url`, `controlUrl`, `credential`, `bindingKey`. Transfer its contents into the isolated harness without logs or durable user configuration. Restart for a fresh world/session. Stop with SIGINT/SIGTERM; discard the private config afterward.

All controls require `Authorization: Bearer <credential>` and the configured authority. POST JSON operations under `controlUrl`:

- `/bind`: `{sessionId: positive integer, characterId: positive integer}`. Registers exactly one forester and returns numeric identities as strings, immutable `headers` (binding key, session ID and fresh generation), and a schema-valid `definition` for create_quest. Repeating the same IDs returns the same binding; changing them returns409.
- `/drop-create`: `{}`. Arms one loss of the next successful committed create_quest reply. The actual gateway commits first; this wrapper discards that result and sends503 without an admitted:false claim. Reconcile using the original logical call, turn and effect identities; do not generate another quest call.
- `/accept`: `{effectKey: stable string}`. Chooses the one offer's accept choice as player-1 through the authoritative narrative runtime.
- `/complete`: `{}`. Records the authoritative grove-1 visit. The running host update loop computes objective completion.
- GET `/state`: returns quest IDs/status/progress, retained narrative `events`, droppedCreates and the example definition. Read at a settled command boundary; retry transient busy checkpoint failures.

The fixture pumps its real host runtime every10ms. Controls are private host operations, never model tools. MCP discovery exposes the actual scoped schema/inspection/authoring/progress tools. Mara can inspect grove-1 only; the initial local context includes player-1 and the winter firewood shortage.

Create an isolated CAI game session with selector `forester/workforce-17`, bind its actual IDs, then publish the returned generation using CAI's compare-and-set API. Authenticate/read the same session and persist the confirmed generation before the first turn. Fixture authorization and CAI operator credentials are separate.

Finish criteria: actual native HTTP discovery/inspection; exactly one created/offered quest; one lost committed reply reconciled with its original effect key and no second effect; authoritative accept and completion; deliver the retained quest_completed event through CAI's typed feedback route; successful follow-up dialogue with that consequence. Record receipt identity, counts and run commands without credentials.

Deferred: crash watchdog/outbox recovery, deployment, broader autonomous behavior and performance. This harness uses disposable data and a fake provider; it proves no paid-provider behavior or production readiness. Keep the browser demo and Rocket's pinned Mara package unchanged.

## Recorded joint result, 13 October 2026

CAI reports message123: `JointGameIntegrationTest` passed, one test/34 assertions in18.65s. CFW independently reviewed the maintained PHP harness read-only, including actual HTTP allowlisting, isolated test account/session, provider-only fake, corrected opaque definition arguments and bounded completion polling. CFW did not rerun CAI tests or access its testing database.

The run attached/bound/published/read an actual test session, discovered and inspected through the native MCP client, committed one quest before a deliberately lost503 response, retained the unknown call and reconciled its original logical call/effect identity without a second provider run. A fresh turn offered the existing quest. Host acceptance/visit completed it; typed feedback reached a follow-up inspection/dialogue. The harness asserts one quest/completion event, three attempts, two published turns, version3 and no CAI quest runtime records.

CAI's run command (requires a fresh in-container fixture and its private config):

```sh
vendor/bin/sail exec -u sail -e CFW_JOINT_CONFIG=/var/www/html/storage/app/private/cfw-joint-proof-20261013.json laravel.test php artisan test --compact tests/Feature/JointGameIntegrationTest.php
```

This proves the joint native HTTP/API/world path with provider responses faked. It does not establish real-model behavior, host-to-Sail ingress, a durable game host or a working browser live connector. CAI owns its separately authorized live-provider verification; CFW continues trusted host connection glue within its existing scope.

## CAI-owned live provider result

CAI message141 reports JointGameLiveTest passed: one test/28 assertions/30.76s, real OpenAI and actual disposable CFW world in Sail. CFW reviewed maintained test assertions read-only, without invoking a paid provider. The model created/offered one quest; authoritative acceptance/completion and typed feedback led to session-only memory, increased trust and two committed replies/version3, with no CAI quest runtime. CAI's strict final-output correction resolved omitted nullable reply fields while preserving discovered external schemas.

The probe uses a direct first CAI Action and HTTP follow-up. It does not yet exercise the CFW HTTP conversation adapter or establish host-network deployment. That adapter runner is ready for CAI's separate isolated deterministic HTTP harness.

## CFW HTTP adapter result

CAI message144 reports the unchanged bundled CFW adapter runner passed against the isolated real CAI API: quests=1, completed=true, confirmedGeneration=true, checkpointVersion=3. CFW independently reviewed the test-only e2e/SQLite router and outbound allowlist; it did not rerun the completed world. Authenticated attach, CAS binding publication, session confirmation, turn/event decoding and native MCP/world execution were exercised together with provider HTTP alone faked. CAI is recording persisted counts/full gates. Host-network ingress, durable storage and the actual in-process port conversation driver remain separate work.

CAI final record151 and maintained handoff confirm persisted isolated counts: one session, two turns, one session memory, one typed event, zero CAI quest runs and zero unresolved MCP calls. CAI reports1020 passed/three opt-in skips/7034assertions plus analysis/style. CFW verified the maintained handoff read-only; it preserved its existing proof rather than rerunning a completed world. Initial502 failures are safe message-only responses, without a public provider_failed code.
