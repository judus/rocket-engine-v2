# Interrupted CAI turn receipts

Status: CAI receipt-read routes and checked wire fixtures delivered in mailbox message 68; framework bounded HTTP receipt reader implemented. Explicit durable framework failure acknowledgment is implemented against CAI’s delivered settlement/sealing guard. Automatic reconciliation, actual MCP discovery and game turns remain pending. Read delivery does not establish safe execution transitions.

`CaiConversation` currently preserves the original request UUID, input/version and pending state on failure. Its retry path accepts only a completed dialogue receipt. A provider failure after an MCP mutation therefore needs explicit outcome inspection; it must not be converted into a fabricated successful reply, a fresh request or assumed rollback.

## Minimum read contract

An owner-association-only read for a known session and turn UUID should return:

- The request UUID and original input version, plus the current full game-session DTO (numeric wire ID, character/binding identity, version and nullable current generation). The UUID/input must remain conflict-checked against the originally accepted request.
- Dialogue status: `pending`, `completed`, `failed` or `interrupted`; completed text and its **committed version** only when actually committed. A safe error code/message may explain failure. Current session version is separate from the original completed receipt version.
- Durable logical calls with `call_id`, original MCP `tool_name`, original canonical argument object, generation used, mutation classification and nullable `effect_key`. Provider response-item IDs and provider aliases are not these identities.
- Per-call state: `not_dispatched`, `in_flight`, `resolved` or `unknown`. Resolved calls retain the raw MCP result, including content/structuredContent/isError/_meta. A structured domain rejection is a resolved result, not successful gameplay. Transport/admission errors need explicit classification; a lost response is unknown.
- An authoritative `continuation_allowed` flag, true only when the attempt is sealed against further calls/dialogue and no unresolved mutations remain. The host must not infer this from failed dialogue or from an empty/truncated call list.

Same UUID plus identical POST input replays the same logical attempt/receipt. It must not restart provider reasoning and assign fresh effect keys. Unknown calls can be reconciled through retained identities; a resumed read must not execute a game action. Unknown or missing receipts do not authorize a new mutating turn.

## Host behavior

Pending dialogue or unresolved calls retain the original checkpoint and block fresh dialogue/authoring. The UI may show a safe interrupted/pending explanation, without claiming cancellation undid effects. The host can inspect receipt status; it does not derive action success from prose.

Completed dialogue must match the retained request, identity and original input version, and must have a validated committed receipt. Preserve that original version on replay. A terminal failure/interruption with `continuation_allowed=true` can be acknowledged as failure without inventing dialogue, using the current verified session state for subsequent work. Persist this acknowledgment before clearing local pending state. A receipt read itself is not such an acknowledgment. Prefer host-local durable acknowledgment only if CAI’s continuation flag also permits the subsequent fresh versioned turn without a separate server release. If CAI requires acknowledgment to release its reservation, an explicit authenticated idempotent operation must be agreed first; local clearing alone would not suffice.

The first implementation may conservatively block fresh turns for any unresolved call, including inspections. This matches the existing one-request-per-conversation coordinator and avoids a new parallel policy.

`not_dispatched` means there is evidence that no dispatch occurred and the sealed attempt cannot dispatch later. `in_flight` means known work is still running; `unknown` means the outcome cannot be established. A timeout, worker crash, rebind or failed provider response never proves no effect. Rebind retains the old call generation/effect keys and journals late results rather than rewriting them to a new generation.

## Bounds and joint proof

Receipt reads need a bounded/pageable call list, with an explicit cursor when more calls exist. Continuation status must cover the entire sealed attempt, not just one page. Large raw results must remain retrievable under the same owner scope; omitted/pending data must not be reported as resolved without evidence. The current HTTP adapter has a 64 KiB response cap; even one near-limit MCP result can exceed that when text and structured content are both retained. Agree a separate bounded receipt read contract before implementing its decoder, rather than silently truncating envelopes.

Initial joint cases: completed-response loss; provider failure after a committed quest with a known result; committed quest with lost MCP response; interruption before dispatch; stale/rebound generation with a late result; exact same-request replay; changed-input conflict; cross-association denial; oversized/pageable results; and acknowledgment storage failure. Use disposable fixtures/fake providers. No live-provider permission or production recovery proof is implied.

## CAI bounds/rebind alignment (messages 52 and 55)

Agreed direction: the attempt GET returns small paged call summaries, current session and original completed receipt separately, with whole-attempt continuation status. A second owner-only GET under the same attempt retrieves one logical call's complete canonical arguments and retained raw result/admission data. Proposed detail response cap is 512 KiB; ordinary read/tool limits stay unchanged. Exact envelopes and CAI boundary fixtures were delivered in message 68. Account for additional receipt-wrapper nesting around the existing 32-level tool value limit rather than silently rejecting or truncating valid data.

`continuation_allowed` will mean the attempt is sealed and CAI's reservation is released atomically. CFW's persisted local failure acknowledgment suffices; no additional remote release endpoint is needed. Fresh requests still undergo normal authority/current-version checks.

The first bridge conservatively stops old-generation dispatch/dialogue and retains every late result. Unknown mutations are not retried automatically under a different generation. A known late result can settle the sealed attempt; otherwise continuation remains blocked. Explicit authorized cross-generation restoration/reconciliation is future work. Identical binding-key text alone does not prove the same durable framework receipt scope.

## Implemented framework reads

Trusted server-side `CaiHttpBackend` now implements the separate `CaiReceiptBackend` port. These GETs perform no conversation writes, pending-state acknowledgment, action dispatch or automatic pagination:

```ts
if (saved.pending?.kind !== 'turn') throw new Error('No pending turn');
const requestId = saved.pending.input.request_id;
const page = await backend.readAttempt(saved.session, requestId, signal);
const call = page.calls[0];
if (call !== undefined) {
  const detail = await backend.readCall(
    saved.session.id,
    requestId,
    call.call_id,
    signal,
  );
  // Present retained evidence without acknowledging the pending turn.
}
// A next page uses the exact returned ordinal cursor:
if (page.nextCursor !== null) {
  const next = await backend.readAttempt(
    saved.session,
    requestId,
    signal,
    page.nextCursor,
  );
}
```

Request, session, character and binding-key correlation are checked on attempt reads; call details check the requested turn/call IDs. Current generation may differ from the original attempt generation. Call summaries retain original generation, tool name, provider aliases/IDs, effect key and outcome classification separately. `turn.version` remains the immutable completed version, while `session.version` describes current state. A future acknowledgment coordinator must additionally match the retained input version before changing a checkpoint.

Summary responses allow 65,536 UTF-8 bytes, at most 20 ordered calls, and a positive safe-integer ordinal cursor or null. Detail responses allow 524,288 bytes. Both allow 40 nested object/array containers; ordinary HTTP responses retain their existing 64 KiB/32-container limits. Raw detail results preserve MCP content, structuredContent, isError and _meta, including empty objects/arrays. Returned data is detached and frozen. Mutations require a retained effect key in summaries and details. MCP result evidence passes the installed official SDK base result validator, including its compatibility allowance for omitted content; validation preserves the original object and unknown fields. Result and non-admission evidence are mutually exclusive. Resolved details require retained result or explicit non-admission evidence; a domain rejection remains a resolved result without claiming game success.

The whole-attempt `continuationAllowed` flag comes from CAI. A page containing unresolved calls contradicts a true flag and is rejected; an empty or resolved page cannot establish continuation by itself. Reads that fail authorization, have missing receipts, exceed bounds or return malformed correlations remain errors. No read clears `CaiConversation.pending`, updates its version, or retries a tool under a new generation.

Self-contained tests use `tests/fixtures/cai-receipts.json`, a snapshot of CAI's checked `apps/server/tests/Fixtures/companion-game-receipts.json` from message 68, plus HTTP simulations for pagination, committed/current versions, raw evidence, UTF-8 streaming and exact byte/depth limits. These tests are decoder proofs; no provider, credential provisioning or live CAI/MCP execution is involved.

## Explicit failure acknowledgment

After receipt inspection, a trusted host can call `conversation.acknowledgeFailure(receipts)`. It reads the known pending turn through `CaiReceiptBackend`, requires the original saved generation, matching request/input version/session identity, failed or interrupted status, no completed dialogue, and CAI's whole-attempt continuation gate. The current session version must not precede the original input. A paged list is not scanned to infer this gate; CAI's verified sealing/release guard covers all calls.

The method persists current verified session state with pending cleared before publishing the local change. A read or save failure leaves the original pending request/version intact for another inspection/acknowledgment. Feedback added during the save is retained; disposed/stale conversations discard late replies. This operation creates no dialogue, feedback success, tool dispatch or cross-generation retry. Hosts must still settle their binding publication before fresh reasoning. Older checkpoints without a known original generation remain blocked.

CAI's `SealGameTurnAttempt` and shared `GameAttemptContinuation` guard were verified read-only after message96: terminal failure sealing and reservation release are atomic, unresolved outcomes block continuation, and late settlement can release the original failed attempt. Public game POST and actual transport remain unavailable. Simulated acknowledgment tests cover storage failure, identity/version/status mismatches, missing receipts, unknown outcomes, disposal and feedback queued during saving; this is not a live integration proof.

## Recovering completed dialogue

`conversation.reconcileCompleted(receipts)` performs the same scoped receipt read/correlation and durable-save discipline for a completed turn. It additionally validates the immutable turn request, committed version and message, and requires CAI's whole-attempt continuation flag. It returns the retained reply only after saving the verified current session and clearing pending state. The immutable committed version is checked separately from the current session version. Read/save failure, mismatched generation/input, unsettled or failed dialogue keep pending unchanged. No provider run or tool retry is acquired. Hosts still need their own durable UI-delivery identity if they require exactly-once presentation.

The compact completed receipt and atomic CAI commit were reviewed after message104. Tests simulate committed-response loss and save failure, including a current session version/generation newer than the original receipt. Actual public game-turn execution and joint proof remain pending.
