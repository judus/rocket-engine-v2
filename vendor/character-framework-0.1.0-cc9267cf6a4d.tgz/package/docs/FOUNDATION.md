# Runtime Foundation

Phase 0 implements one headless runtime per game, registered characters, shared reasoning scheduling and character-bound capability dispatch. An embodied forester and a bodyless story director use the same services and retain independent state. The optional local narrative core is now implemented separately; see [NARRATIVE.md](NARRATIVE.md). The separate MCP adapter is now implemented; see [MCP-SERVER.md](MCP-SERVER.md). CAI remains a later milestone.

## Run and check

Requires Node.js 24 and npm. The core has no third-party imports. The optional MCP adapter uses the official SDK and Ajv; dependencies are pinned in the lockfile.

```sh
npm ci
npm run check
npm run demo
npm run demo:web
```

The browser demo runs at [127.0.0.1:8093](http://127.0.0.1:8093/). The server serves only `demo` and compiled `dist` files and binds to loopback. Stop it with Ctrl+C. Source changes require rebuilding and reloading the page.

`check` runs strict TypeScript, type-aware ESLint with zero warnings, Prettier verification, declaration/JavaScript compilation and Node behavioral tests. Tests cover actual admission, scheduling, isolation, cancellation, invalid results, immutability and lifecycle contracts. JavaScript test/server harnesses receive ESLint checks; runtime and demo TypeScript receive type-aware analysis. These checks do not prove production packaging, real-provider behavior, accessibility or game integrations.

## Ownership

The game constructs/disposes `CharacterRuntime` and advances it once per simulation update. The runtime owns registry state, pending request records, abort controllers and a bounded result/event queue. It does not create a recurring timer, view, entity or session.

Injected reasoning providers and capability adapters are externally owned. Runtime disposal aborts its requests but does not dispose a shared adapter or delete host entities or remote sessions. Host movement/physics/production advancement remains separate.

Characters are registrations, not separate intelligence services. `CharacterHandle` is a small reference to one registration lifetime. A handle becomes invalid when that registration is removed, even if the same ID is registered again. Character identity, name, grants and bindings are detached immutable copies. Returned snapshots and events cannot mutate runtime state.

Passing narrativeGame installs one shared narrative service, advanced and disposed by the runtime. Character narrative handles delegate to it; presentation nodes do not own quests. The original Phase 0 demo still exercises only registry/reasoning mechanics.

## API example

```ts
import { CharacterRuntime } from 'character-framework';

const runtime = new CharacterRuntime({
  gameId: 'grandquest',
  reasoning: {
    decide: () => ({ dialogue: 'Winter is coming.' }),
  },
});

const director = runtime.register({
  id: 'director',
  name: 'Story director',
  capabilities: [],
});

director.requestDecision({ event: 'winter_started' });
runtime.advance(0.05);
// Host continues; when async work has settled, a later advance commits it.
// director.snapshot() and runtime.drainEvents() expose committed state/results.
// runtime.dispose() ends this runtime's lifetime.
```

Optional `entityId` associates a physical game entity. Optional `cai: { characterId, sessionId }` stores references only; no backend call is made. It can be omitted completely in local proofs. The demo IDs are fictional and never used as credentials.

## Admission and scheduling

`requestDecision(observation)` and `dispatch(name, input)` return immediate `accepted` with a runtime request ID, or `rejected` with a stable local code/reason. Acceptance means queued for execution, not completed or permitted by current game rules.

Each character can have one pending decision and one pending capability request. The global FIFO scheduler defaults to four concurrently executing requests and 64 total pending records. Reasoning and capabilities share this budget in Phase 0. Limits are configurable; use at least two slots for the slow-forester/fast-director example. No guarantee can make another job run when all configured slots are occupied.

`advance(seconds)` increments host simulation time, commits settled replies, then starts queued work up to the concurrency limit. The callback receives the time of dispatch and a bound character/game/request context. Callbacks start inside the host update and must return promptly; replies are captured on settlement and update character state only on the next host advance. `advance(0)` can flush replies without advancing simulation time. Negative/nonfinite time and use after disposal throw.

A decision contains dialogue and an optional intention with a kind and JSON arguments. The intention is a proposal: Phase 0 displays it without automatically requesting actions. Capability results distinguish `completed` data, `running` with a host operation ID and `rejected` with a host reason. Long-running status polling, tasks and automatic decision-to-action orchestration are not implemented yet.

## Capability boundary

A capability supplies name, description, inspection/action kind, discovery schema, input validation and an execution callback. Registration grants installed capability names to a character. Discovery returns only that character's descriptors, and a handle can dispatch only its grants.

The runtime constructs the invocation context; input arguments cannot replace its game/character/session identity. The host must still validate contextual targets and current qualifications/resources in `execute`. For example, `request_work` can pass structural admission and later be rejected because the actor is unqualified. The fake game owns its assignments; assignment does not imply workplace attendance.

Discovery schemas describe the future tool surface. Phase 0 does not implement a general JSON Schema validator: each adapter's `validate` callback enforces its input contract. Runtime guards reject nonfinite/cyclic/non-JSON input and data exceeding 32 object/array levels and malformed result envelopes. Core cannot validate arbitrary game result data; that remains an adapter contract.

The later MCP adapter will authenticate/bind an external call before obtaining a character handle. These in-process handles and `gameId` strings are not external authentication. The runtime does not implement a server, session ownership or a CAI connector.

## Removal cancellation and failures

Unregistering releases the character's queued work, aborts active work and emits cancellation notices. Replies from removed registrations are discarded. Providers and adapters should honor `AbortSignal`; otherwise a cancelled running request retains its concurrency/pending slot until settlement. This bounds actual outstanding work instead of assuming abort forcibly stops a provider. Disposal detaches the entire runtime and discards all later replies.

An adapter must queue later asynchronous world effects into its own safe host boundary and check cancellation before committing them where appropriate. Removal cannot undo an effect already committed by the host. Do not retry unknown game effects blindly; durable host operation reconciliation belongs to a later milestone.

Thrown/rejected callbacks and invalid envelopes clear the pending lane on host advancement and emit `failed`. Private exception text is not copied to events. A previous successful snapshot remains the last successful result; use request-correlated events to observe failure of the new request. Runtime IDs are process-lifetime correlation identifiers, not durable idempotency keys across restore.

Events are bounded diagnostics/results for the current host consumer, not a persistent authoritative ledger. Default retention is 128; oldest events are dropped when full, and `stats.droppedEvents` reports the count. Drain them each host update. Last committed per-character snapshots remain available independently.

## Demo walkthrough

The headless demo exercises scoped inspection, independent decisions, a rejected job and removal. The browser demo adds controls for invalid arguments, assignment, pause/manual update and re-registration.

1. Ask both characters to think. The director answers sooner while the forester remains pending.
2. Try forbidden world inspection through the forester; admission rejects it.
3. Inspect both characters; their facts differ according to capabilities.
4. Ask for an unqualified job; admission succeeds but the fake host rejects execution.
5. Start reasoning and remove the forester; its reply cannot affect a fresh registration.
6. Pause host updates. Requests can be queued; step once to start them. Settled replies remain pending until another step commits them.
7. Dispose the runtime; registration/advance are no longer available and no session/entity is deleted.

Both demos contain canned reasoning. They demonstrate framework mechanics, not an intelligent model, quest authoring or real physical movement.
