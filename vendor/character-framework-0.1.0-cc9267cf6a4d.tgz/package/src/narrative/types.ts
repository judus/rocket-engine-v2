import type { Capability, CharacterDefinition, Json } from '../types.js';

export interface Condition {
  readonly tool: string;
  readonly arguments: { [key: string]: Json };
  readonly expect: {
    readonly path: readonly string[];
    readonly operator: 'equals' | 'at_least';
    readonly value: string | number | boolean | null;
  };
}
export interface Objective {
  readonly id: string;
  readonly description: string;
  readonly condition: Condition;
}
export interface QuestDefinition {
  readonly recipientRef: string;
  readonly title: string;
  readonly summary: string;
  readonly objectives: readonly Objective[];
  readonly flow?: QuestFlow;
}
export interface QuestStage {
  readonly id: string;
  readonly objectives: readonly string[];
  readonly dialogue?: string;
  readonly next?: string;
  readonly choices?: readonly {
    readonly id: string;
    readonly label: string;
    readonly next: string;
  }[];
}
export interface QuestFlow {
  readonly start: string;
  readonly stages: readonly QuestStage[];
}
export type ToolName =
  | 'inspect_context'
  | 'create_quest'
  | 'offer_quest'
  | 'inspect_quest'
  | 'inspect_quest_templates'
  | 'compose_quest_draft';
export interface Rejection {
  readonly status: 'rejected';
  readonly code: string;
  readonly message: string;
  readonly issues: readonly { path: string; code: string; message: string }[];
}
export type NarrativeResult =
  { readonly status: 'completed'; readonly data: Json } | Rejection;
export interface ContextInput {
  readonly scope: 'local' | 'world';
  readonly entityRefs?: readonly string[];
}
export interface NarrativeGame {
  /** Pure, trusted objective constructors; never perform game actions or inspections. */
  objectiveTemplates?(
    character: CharacterDefinition,
  ): readonly ObjectiveTemplate[];
  capabilities(character: CharacterDefinition): readonly Capability[];
  inspectContext(
    character: CharacterDefinition,
    input: ContextInput,
  ): NarrativeResult;
  recipientAvailable(
    character: CharacterDefinition,
    recipientRef: string,
  ): boolean;
  /** Check semantic target/reference permissions without executing a condition or action. */
  referencesAvailable(
    character: CharacterDefinition,
    condition: Condition,
  ): boolean;
}
export interface NarrativeEvent {
  readonly id: string;
  readonly origin: 'framework_narrative';
  readonly type:
    | 'quest_created'
    | 'quest_offered'
    | 'quest_accepted'
    | 'quest_declined'
    | 'quest_progressed'
    | 'quest_stage_entered'
    | 'quest_branch_selected'
    | 'quest_completed';
  readonly characterRef: string;
  readonly questId: string;
  readonly recipientRef: string;
  readonly revision: number;
  readonly stageId?: string;
  readonly choiceId?: string;
}
export interface ObjectiveProgress {
  readonly id: string;
  readonly status: 'pending' | 'satisfied' | 'unknown';
  readonly observed: Json;
}
export interface ObjectiveTemplate {
  readonly name: string;
  readonly description: string;
  readonly inputSchema: Json;
  build(recipientRef: string, arguments_: Json): Objective;
}
