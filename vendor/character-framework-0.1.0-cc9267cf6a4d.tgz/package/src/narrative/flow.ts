import { shape, text } from './validation.js';
import type { QuestFlow, QuestStage } from './types.js';

function stage(value: unknown): value is QuestStage {
  return (
    shape(
      value,
      ['id', 'objectives', 'dialogue', 'next', 'choices'],
      ['id', 'objectives'],
    ) &&
    text(value['id']) &&
    Array.isArray(value['objectives']) &&
    value['objectives'].length >= 1 &&
    value['objectives'].length <= 8 &&
    value['objectives'].every((id: unknown) => text(id)) &&
    (value['dialogue'] === undefined || text(value['dialogue'], 2000)) &&
    (value['next'] === undefined || text(value['next'])) &&
    (value['choices'] === undefined ||
      (Array.isArray(value['choices']) &&
        value['choices'].length >= 1 &&
        value['choices'].length <= 4 &&
        value['choices'].every(
          (choice: unknown) =>
            shape(choice, ['id', 'label', 'next']) &&
            text(choice['id']) &&
            text(choice['label']) &&
            text(choice['next']),
        ))) &&
    !(value['next'] !== undefined && value['choices'] !== undefined)
  );
}
export function destinations(stage_: QuestStage): readonly string[] {
  return stage_.next
    ? [stage_.next]
    : (stage_.choices?.map((choice) => choice.next) ?? []);
}
/** Bounded acyclic graph; each objective belongs to exactly one reachable stage. */
export function isFlow(
  value: unknown,
  objectiveIds: readonly string[],
): value is QuestFlow {
  if (!isFlowShape(value)) return false;
  const stages = value.stages;
  const byId = new Map(stages.map((entry) => [entry.id, entry]));
  const used = stages.flatMap((entry) => [...entry.objectives]);
  if (
    byId.size !== stages.length ||
    !byId.has(value.start) ||
    new Set(used).size !== used.length ||
    used.length !== objectiveIds.length ||
    used.some((id) => !objectiveIds.includes(id))
  )
    return false;
  for (const entry of stages) {
    if (
      destinations(entry).some((id) => !byId.has(id)) ||
      (entry.choices &&
        new Set(entry.choices.map((choice) => choice.id)).size !==
          entry.choices.length)
    )
      return false;
  }
  const visiting = new Set<string>(),
    reached = new Set<string>();
  const visit = (id: string): boolean => {
    if (visiting.has(id)) return false;
    if (reached.has(id)) return true;
    const entry = byId.get(id);
    if (!entry) return false;
    visiting.add(id);
    if (!destinations(entry).every(visit)) return false;
    visiting.delete(id);
    reached.add(id);
    return true;
  };
  return visit(value.start) && reached.size === stages.length;
}
/** Drafts may temporarily contain unresolved graph references. */
export function isFlowShape(value: unknown): value is QuestFlow {
  return (
    shape(value, ['start', 'stages']) &&
    text(value['start']) &&
    Array.isArray(value['stages']) &&
    value['stages'].length >= 1 &&
    value['stages'].length <= 8 &&
    value['stages'].every(stage)
  );
}
