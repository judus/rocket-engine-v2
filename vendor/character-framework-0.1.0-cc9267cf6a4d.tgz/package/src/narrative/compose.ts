import { immutable } from '../json.js';
import { isObjective, record } from './validation.js';
import type {
  ObjectiveTemplate,
  QuestDefinition,
  QuestFlow,
  QuestStage,
} from './types.js';
import type { Json } from '../types.js';

/** Pure transformations of caller-carried drafts. Publication is a separate operation. */
export function composeDraft(
  draft: QuestDefinition,
  change: Record<string, Json>,
  templates: readonly ObjectiveTemplate[],
): QuestDefinition {
  const objectives = [...draft.objectives];
  let flow = draft.flow;
  const kind = change['kind'];
  if (kind === 'append_stage') {
    const stage = change['stage'] as unknown as QuestStage;
    if (
      (flow?.stages.length ?? 0) >= 8 ||
      flow?.stages.some((entry) => entry.id === stage.id)
    )
      throw new TypeError('Invalid or duplicate stage');
    flow = {
      start: flow?.start ?? stage.id,
      stages: [...(flow?.stages ?? []), stage],
    };
  } else if (kind === 'set_flow')
    flow =
      change['flow'] === null
        ? undefined
        : (change['flow'] as unknown as QuestFlow);
  else if (kind === 'remove_objective') {
    const index = objectives.findIndex((entry) => entry.id === change['id']);
    if (index < 0) throw new TypeError('Objective is unavailable');
    objectives.splice(index, 1);
  } else if (kind !== 'validate') {
    let objective: unknown = change['objective'];
    if (kind === 'append_step') {
      const template = templates.find(
        (entry) => entry.name === change['template'],
      );
      if (!template || !record(change['arguments']))
        throw new TypeError('Template is unavailable');
      objective = template.build(
        draft.recipientRef,
        immutable(change['arguments']),
      );
    }
    if (!isObjective(objective))
      throw new TypeError('Invalid objective or template arguments');
    const index = objectives.findIndex((entry) => entry.id === objective.id);
    if (kind === 'replace_objective') {
      if (index < 0) throw new TypeError('Objective is unavailable');
      objectives[index] = objective;
    } else {
      if (objectives.length >= 8 || index >= 0)
        throw new TypeError('Invalid or duplicate objective');
      objectives.push(objective);
    }
  }
  return immutable({
    recipientRef: draft.recipientRef,
    title: draft.title,
    summary: draft.summary,
    objectives,
    ...(flow ? { flow } : {}),
  });
}
