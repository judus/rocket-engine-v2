import { immutable } from '../json.js';
import type { Json } from '../types.js';
import type { Objective, ObjectiveTemplate, QuestDefinition } from './types.js';
import { isObjective, isQuest } from './validation.js';

/** Local authoring helper. Draft changes do not edit a published quest. */
export class QuestDraft {
  readonly #header: Omit<QuestDefinition, 'objectives'>;
  readonly #templates = new Map<string, ObjectiveTemplate>();
  readonly #objectives: Objective[] = [];
  constructor(
    header: Omit<QuestDefinition, 'objectives'>,
    templates: readonly ObjectiveTemplate[] = [],
  ) {
    this.#header = immutable(header);
    for (const template of templates) {
      if (this.#templates.has(template.name))
        throw new TypeError('Duplicate objective template');
      this.#templates.set(template.name, template);
    }
  }
  addObjective(objective: Objective): this {
    if (
      !isObjective(objective) ||
      this.#objectives.length >= 8 ||
      this.#objectives.some((entry) => entry.id === objective.id)
    )
      throw new TypeError('Invalid or duplicate objective');
    this.#objectives.push(immutable(objective));
    return this;
  }
  addStep(templateName: string, input: Json): this {
    const template = this.#templates.get(templateName);
    if (!template) throw new TypeError('Unknown objective template');
    return this.addObjective(
      template.build(this.#header.recipientRef, immutable(input)),
    );
  }
  toInput(): { readonly quest: QuestDefinition } {
    const quest = { ...this.#header, objectives: this.#objectives };
    if (!isQuest(quest))
      throw new TypeError('A valid draft requires at least one objective');
    return immutable({ quest });
  }
}
