import type { CharacterHandle } from '../Runtime.js';
import { immutable, isJson } from '../json.js';
import type {
  CapabilityResult,
  CharacterDefinition,
  Json,
  Invocation,
} from '../types.js';
import type {
  Condition,
  ContextInput,
  NarrativeEvent,
  NarrativeGame,
  NarrativeResult,
  ObjectiveProgress,
  QuestDefinition,
  ToolName,
} from './types.js';
import {
  boundedJson,
  canonical,
  complete,
  isQuest,
  isDraftDefinition,
  record,
  reject,
  text,
  validInput,
} from './validation.js';
import { isNarrativeSave } from './state.js';
import type { NarrativeSave, QuestRecord, Receipt } from './state.js';
import type { QuestStage } from './types.js';
import { composeDraft } from './compose.js';

type Bound = () => CharacterDefinition;
interface Command {
  readonly run: () => NarrativeResult;
  readonly resolve: (result: NarrativeResult) => void;
}
interface Observation {
  readonly id: number;
  readonly epoch: number;
  readonly questId: string;
  readonly objectiveId: string;
  readonly owner: Bound;
  readonly controller: AbortController;
  readonly condition: Condition;
}
interface Observed {
  readonly job: Observation;
  readonly result: unknown;
}
function readObserved(
  data: Json,
  path: readonly string[],
): { found: boolean; value: Json } {
  let value = data;
  for (const part of path) {
    if (!record(value) || !Object.hasOwn(value, part))
      return { found: false, value: null };
    const next: unknown = value[part];
    if (!isJson(next)) return { found: false, value: null };
    value = next;
  }
  return { found: true, value };
}

/** Shared narrative state. Host advance commits commands and inspection results. */
export class NarrativeSystem {
  readonly #associationId: string;
  readonly #game: NarrativeGame;
  readonly #owners = new Map<string, Bound>();
  #quests = new Map<string, QuestRecord>();
  #receipts = new Map<string, Receipt>();
  #commands: Command[] = [];
  #events: NarrativeEvent[] = [];
  readonly #observations = new Map<number, Observation>();
  #inbox: Observed[] = [];
  #questSequence = 0;
  #offerSequence = 0;
  #eventSequence = 0;
  #jobSequence = 0;
  #epoch = 0;
  #scanCursor = 0;
  #time = 0;
  #droppedEvents = 0;
  #disposed = false;
  #advancing = false;

  constructor(options: { associationId: string; game: NarrativeGame }) {
    if (!text(options.associationId))
      throw new TypeError('associationId is required');
    this.#associationId = options.associationId;
    this.#game = options.game;
  }
  bind(handle: CharacterHandle): NarrativeHandle {
    this.#assertLive();
    const owner: Bound = () => handle.snapshot();
    this.#owners.set(this.#ownerKey(owner()), owner);
    return new NarrativeHandle((tool, input, effectKey) =>
      this.#enqueue(() => {
        let character: CharacterDefinition;
        try {
          character = owner();
        } catch {
          return reject(
            'unregistered',
            'Character registration is no longer current.',
          );
        }
        return this.#call(character, tool, input, effectKey);
      }, input),
    );
  }
  get stats() {
    return Object.freeze({
      quests: this.#quests.size,
      receipts: this.#receipts.size,
      pendingCommands: this.#commands.length,
      pendingInspections: this.#observations.size,
      time: this.#time,
      disposed: this.#disposed,
      droppedEvents: this.#droppedEvents,
    });
  }
  /** Host-authenticated player choice, not an AI tool. */
  choose(
    recipientRef: string,
    choiceId: string,
    effectKey: string,
  ): Promise<NarrativeResult> {
    return this.#enqueue(() =>
      this.#mutate(
        JSON.stringify([this.#associationId, 'player', recipientRef]),
        'choose',
        effectKey,
        { recipientRef, choiceId },
        () => {
          const quest = [...this.#quests.values()].find(
            (entry) =>
              (entry.offer &&
                [
                  entry.offer.id + '/accept',
                  entry.offer.id + '/decline',
                ].includes(choiceId)) ||
              this.#branchChoices(entry).some(
                (choice) => choice.id === choiceId,
              ),
          );
          if (!quest?.offer || quest.definition.recipientRef !== recipientRef)
            return reject(
              'choice_unavailable',
              'Choice is not available to this recipient.',
            );
          const owner = this.#owner(quest);
          if (!owner || !this.#game.recipientAvailable(owner, recipientRef))
            return reject(
              'recipient_unavailable',
              'Recipient cannot resolve this offer.',
            );
          if (quest.offer.status === 'active') {
            const choice = this.#branchChoices(quest).find(
              (entry) => entry.id === choiceId,
            );
            if (!choice)
              return reject('choice_unavailable', 'Branch is not available.');
            quest.revision++;
            this.#emit(quest, 'quest_branch_selected', choice.id);
            this.#enterStage(quest, choice.next);
            return complete({
              questId: quest.id,
              offerId: quest.offer.id,
              recipientRef,
              status: 'active',
              revision: quest.revision,
              stageId: choice.next,
              choiceId,
            });
          }
          if (quest.offer.status !== 'offered')
            return reject(
              'choice_unavailable',
              'This offer was already resolved.',
            );
          quest.offer.status = choiceId.endsWith('/accept')
            ? 'active'
            : 'declined';
          quest.revision++;
          this.#emit(
            quest,
            quest.offer.status === 'active'
              ? 'quest_accepted'
              : 'quest_declined',
          );
          if (quest.offer.status === 'active' && quest.flowState)
            this.#emit(quest, 'quest_stage_entered');
          return complete({
            questId: quest.id,
            offerId: quest.offer.id,
            recipientRef,
            status: quest.offer.status,
            revision: quest.revision,
          });
        },
      ),
    );
  }
  advance(seconds: number): void {
    this.#assertLive();
    if (
      this.#advancing ||
      !Number.isFinite(seconds) ||
      seconds < 0 ||
      !Number.isFinite(this.#time + seconds)
    )
      throw new TypeError(
        'Narrative advancement requires nonnegative seconds and cannot reenter.',
      );
    this.#advancing = true;
    try {
      this.#time += seconds;
      for (const job of this.#observations.values()) {
        try {
          job.owner();
        } catch {
          job.controller.abort();
        }
      }
      const commands = this.#commands;
      this.#commands = [];
      for (const command of commands) {
        try {
          command.resolve(
            this.#disposed
              ? reject('disposed', 'Narrative system is disposed.')
              : command.run(),
          );
        } catch {
          command.resolve(
            reject('host_failed', 'Host validation or inspection failed.'),
          );
        }
      }
      const inbox = this.#inbox;
      this.#inbox = [];
      for (const observed of inbox) this.#commit(observed);
      const candidates = [...this.#quests.values()]
        .filter((quest) => quest.offer?.status === 'active')
        .flatMap((quest) =>
          quest.definition.objectives
            .filter(
              (objective) =>
                (!quest.flowState ||
                  this.#stage(quest)?.objectives.includes(objective.id)) &&
                !quest.progress.some(
                  (progress) =>
                    progress.id === objective.id &&
                    progress.status === 'satisfied',
                ),
            )
            .map((objective) => ({ quest, objective })),
        );
      const start = this.#scanCursor % Math.max(1, candidates.length);
      for (let offset = 0; offset < candidates.length; offset++) {
        if (this.#disposed || this.#observations.size >= 8) break;
        const index = (start + offset) % candidates.length;
        const candidate = candidates[index];
        if (!candidate) continue;
        this.#scanCursor = index + 1;
        const { quest, objective } = candidate;
        if (
          [...this.#observations.values()].some(
            (job) =>
              job.epoch === this.#epoch &&
              job.questId === quest.id &&
              job.objectiveId === objective.id,
          )
        )
          continue;
        const owner = this.#owners.get(quest.ownerKey);
        if (!owner || !this.#owner(quest)) {
          this.#update(quest, {
            id: objective.id,
            status: 'unknown',
            observed: null,
          });
          continue;
        }
        this.#observe(quest, objective.id, objective.condition, owner);
      }
    } finally {
      this.#advancing = false;
    }
  }
  drainEvents(): readonly NarrativeEvent[] {
    const events = this.#events;
    this.#events = [];
    return events;
  }
  save(): NarrativeSave {
    this.#assertLive();
    if (this.#advancing || this.#commands.length)
      throw new Error('Save requires a safe boundary with no queued commands.');
    return immutable({
      schemaVersion: 1,
      associationId: this.#associationId,
      questSequence: this.#questSequence,
      offerSequence: this.#offerSequence,
      eventSequence: this.#eventSequence,
      time: this.#time,
      quests: [...this.#quests.values()],
      receipts: [...this.#receipts.values()],
      events: this.#events,
      droppedEvents: this.#droppedEvents,
    });
  }
  restore(input: unknown): void {
    this.#assertLive();
    if (this.#advancing || this.#commands.length)
      throw new Error(
        'Restore requires a safe boundary with no queued commands.',
      );
    if (!isNarrativeSave(input) || input.associationId !== this.#associationId)
      throw new TypeError('Invalid or incompatible narrative checkpoint.');
    const saved = structuredClone(input);
    this.#epoch++;
    for (const job of this.#observations.values()) job.controller.abort();
    this.#quests = new Map(saved.quests.map((quest) => [quest.id, quest]));
    this.#receipts = new Map(
      saved.receipts.map((receipt) => [receipt.key, receipt]),
    );
    this.#events = [...saved.events];
    this.#questSequence = saved.questSequence;
    this.#offerSequence = saved.offerSequence;
    this.#eventSequence = saved.eventSequence;
    this.#time = saved.time;
    this.#droppedEvents = saved.droppedEvents;
  }
  dispose(): void {
    if (this.#disposed) return;
    this.#disposed = true;
    for (const command of this.#commands)
      command.resolve(reject('disposed', 'Narrative system is disposed.'));
    for (const job of this.#observations.values()) job.controller.abort();
    this.#commands = [];
    this.#inbox = [];
    this.#observations.clear();
    this.#owners.clear();
  }
  #assertLive(): void {
    if (this.#disposed) throw new Error('Narrative system is disposed.');
  }
  #ownerKey(character: CharacterDefinition): string {
    if (!character.binding)
      throw new TypeError('Registered binding identity required.');
    return JSON.stringify([
      this.#associationId,
      character.binding.id,
      character.id,
      character.cai ?? null,
    ]);
  }
  #owner(quest: QuestRecord): CharacterDefinition | null {
    try {
      return this.#owners.get(quest.ownerKey)?.() ?? null;
    } catch {
      return null;
    }
  }
  #enqueue(run: () => NarrativeResult, input?: Json): Promise<NarrativeResult> {
    if (this.#disposed)
      return Promise.resolve(
        reject('disposed', 'Narrative system is disposed.'),
      );
    if (this.#commands.length >= 64)
      return Promise.resolve(
        reject('queue_full', 'Narrative command limit reached.'),
      );
    if (input !== undefined && !isJson(input))
      return Promise.resolve(
        reject(
          'invalid_arguments',
          'Arguments must be finite JSON within 64 KiB and 32 object/array levels.',
        ),
      );
    // Bound handle captures a detached input before invoking this method.
    return new Promise((resolve) => {
      this.#commands.push({ run, resolve });
    });
  }
  #call(
    character: CharacterDefinition,
    tool: ToolName,
    input: Json,
    effectKey?: string,
  ): NarrativeResult {
    const run = (): NarrativeResult => {
      if (!validInput(tool, input) || !record(input))
        return reject('invalid_arguments', 'Arguments do not match this tool.');
      switch (tool) {
        case 'inspect_quest_templates':
        case 'compose_quest_draft': {
          const templates = this.#game.objectiveTemplates?.(character) ?? [];
          if (
            templates.length > 16 ||
            new Set(templates.map((entry) => entry.name)).size !==
              templates.length ||
            templates.some(
              (entry) =>
                !text(entry.name) ||
                !text(entry.description, 2000) ||
                !record(entry.inputSchema) ||
                !boundedJson(entry.inputSchema),
            )
          )
            return reject(
              'invalid_templates',
              'Host objective templates are invalid or exceed bounds.',
            );
          if (tool === 'inspect_quest_templates') {
            const data = {
              templates: templates.map(
                ({ name, description, inputSchema }) => ({
                  name,
                  description,
                  inputSchema,
                }),
              ),
            };
            return boundedJson(data)
              ? complete(data)
              : reject(
                  'invalid_templates',
                  'Template catalogue exceeds JSON bounds.',
                );
          }
          if (!isDraftDefinition(input['draft']) || !record(input['change']))
            return reject('invalid_arguments', 'Invalid draft.');
          let draft: QuestDefinition;
          try {
            draft = composeDraft(input['draft'], input['change'], templates);
          } catch {
            return reject(
              'invalid_draft_change',
              'Draft edit or template arguments are invalid.',
            );
          }
          if (!boundedJson(draft))
            return reject(
              'invalid_draft_change',
              'Edited draft exceeds JSON bounds.',
            );
          const issues: { path: string; code: string; message: string }[] = [];
          if (draft.objectives.length === 0)
            issues.push({
              path: '/draft/objectives',
              code: 'missing_objectives',
              message: 'Add at least one objective.',
            });
          if (draft.flow && !isQuest(draft))
            issues.push({
              path: '/draft/flow',
              code: 'invalid_flow',
              message:
                'All stages must form a reachable acyclic graph and assign each objective exactly once.',
            });
          if (
            new Set(draft.objectives.map((entry) => entry.id)).size !==
            draft.objectives.length
          )
            issues.push({
              path: '/draft/objectives',
              code: 'duplicate_objective',
              message: 'Objective IDs must be unique.',
            });
          if (!this.#game.recipientAvailable(character, draft.recipientRef))
            issues.push({
              path: '/draft/recipientRef',
              code: 'recipient_unavailable',
              message: 'Recipient is unavailable.',
            });
          for (const [index, objective] of draft.objectives.entries()) {
            if (!this.#conditionAvailable(character, objective.condition))
              issues.push({
                path: `/draft/objectives/${String(index)}/condition`,
                code: 'invalid_condition',
                message:
                  'Use a permitted inspection capability and accessible references.',
              });
          }
          const data = { draft, valid: issues.length === 0, issues };
          return boundedJson(data)
            ? complete(data)
            : reject(
                'invalid_draft_change',
                'Draft validation result exceeds JSON bounds.',
              );
        }
        case 'inspect_context': {
          const query: ContextInput = {
            scope: input['scope'] === 'world' ? 'world' : 'local',
            ...(Array.isArray(input['entityRefs'])
              ? {
                  entityRefs: input['entityRefs'].filter(
                    (ref): ref is string => typeof ref === 'string',
                  ),
                }
              : {}),
          };
          const result = this.#game.inspectContext(character, query);
          return immutable(result);
        }
        case 'create_quest':
          return isQuest(input['quest'])
            ? this.#create(character, input['quest'])
            : reject('invalid_arguments', 'Invalid quest definition.');
        case 'offer_quest':
          return typeof input['questId'] === 'string' &&
            typeof input['recipientRef'] === 'string' &&
            typeof input['dialogue'] === 'string'
            ? this.#offer(
                character,
                input['questId'],
                input['recipientRef'],
                input['dialogue'],
              )
            : reject('invalid_arguments', 'Invalid offer.');
        case 'inspect_quest':
          return typeof input['questId'] === 'string'
            ? this.#inspect(
                character,
                input['questId'],
                typeof input['recipientRef'] === 'string'
                  ? input['recipientRef']
                  : undefined,
              )
            : reject('invalid_arguments', 'Invalid inspection.');
      }
    };
    return tool === 'create_quest' || tool === 'offer_quest'
      ? this.#mutate(this.#ownerKey(character), tool, effectKey, input, run)
      : run();
  }
  #mutate(
    scope: string,
    tool: string,
    effectKey: string | undefined,
    input: Json,
    run: () => NarrativeResult,
  ): NarrativeResult {
    if (!text(effectKey))
      return reject('missing_effect_key', 'A stable effect key is required.');
    const key = JSON.stringify([scope, tool, effectKey]),
      digest = canonical(input),
      previous = this.#receipts.get(key);
    if (previous)
      return previous.digest === digest
        ? immutable(previous.result)
        : reject(
            'effect_key_conflict',
            'Effect key was previously used with different arguments.',
          );
    if (this.#receipts.size >= 4096)
      return reject('capacity_exceeded', 'Narrative receipt capacity reached.');
    const result = immutable(run());
    this.#receipts.set(key, { key, digest, result });
    return result;
  }
  #create(
    character: CharacterDefinition,
    definition: QuestDefinition,
  ): NarrativeResult {
    if (this.#quests.size >= 256)
      return reject('capacity_exceeded', 'Quest capacity reached.');
    if (!this.#game.recipientAvailable(character, definition.recipientRef))
      return reject('recipient_unavailable', 'Quest recipient is unavailable.');
    if (
      new Set(definition.objectives.map((objective) => objective.id)).size !==
      definition.objectives.length
    )
      return reject(
        'duplicate_objective',
        'Objective IDs must be unique.',
        '/quest/objectives',
      );
    for (const [index, objective] of definition.objectives.entries()) {
      if (!this.#conditionAvailable(character, objective.condition))
        return reject(
          'invalid_condition',
          'Condition must use a permitted valid inspection capability.',
          `/quest/objectives/${String(index)}/condition/tool`,
        );
    }
    const quest: QuestRecord = {
      id: `quest-${String(++this.#questSequence)}`,
      ownerKey: this.#ownerKey(character),
      authorRef: character.id,
      definition: immutable(definition),
      revision: 1,
      offer: null,
      progress: definition.objectives.map((objective) => ({
        id: objective.id,
        status: 'pending',
        observed: null,
      })),
      ...(definition.flow
        ? {
            flowState: {
              current: definition.flow.start,
              visited: [definition.flow.start],
            },
          }
        : {}),
    };
    this.#quests.set(quest.id, quest);
    this.#emit(quest, 'quest_created');
    return complete({
      questId: quest.id,
      authorRef: character.id,
      revision: quest.revision,
      status: 'registered',
    });
  }
  #accessible(
    character: CharacterDefinition,
    questId: string,
  ): QuestRecord | undefined {
    const quest = this.#quests.get(questId);
    return quest?.ownerKey === this.#ownerKey(character) ? quest : undefined;
  }
  #offer(
    character: CharacterDefinition,
    questId: string,
    recipientRef: string,
    dialogue: string,
  ): NarrativeResult {
    const quest = this.#accessible(character, questId);
    if (!quest)
      return reject(
        'quest_unavailable',
        'Quest is not available in this character context.',
      );
    if (!this.#game.recipientAvailable(character, recipientRef))
      return reject(
        'recipient_unavailable',
        'Recipient cannot receive this offer.',
      );
    if (recipientRef !== quest.definition.recipientRef)
      return reject('recipient_mismatch', 'Quest targets another recipient.');
    if (quest.offer && quest.offer.status !== 'offered')
      return reject('offer_resolved', 'This offer was already resolved.');
    if (quest.offer && quest.offer.dialogue !== dialogue)
      return reject(
        'offer_conflict',
        'Outstanding offer has different dialogue.',
      );
    if (!quest.offer) {
      quest.offer = {
        id: `offer-${String(++this.#offerSequence)}`,
        dialogue,
        status: 'offered',
      };
      quest.revision++;
      this.#emit(quest, 'quest_offered');
    }
    return complete({
      questId,
      offerId: quest.offer.id,
      recipientRef,
      status: 'offered',
      revision: quest.revision,
      dialogue: quest.offer.dialogue,
      choices: this.#choices(quest),
    });
  }
  #choices(quest: QuestRecord) {
    return quest.offer?.status === 'offered'
      ? [
          { id: quest.offer.id + '/accept', label: 'Accept' },
          { id: quest.offer.id + '/decline', label: 'Decline' },
        ]
      : this.#branchChoices(quest).map(({ id, label }) => ({ id, label }));
  }
  #inspect(
    character: CharacterDefinition,
    questId: string,
    recipientRef?: string,
  ): NarrativeResult {
    const quest = this.#accessible(character, questId);
    if (!quest)
      return reject(
        'quest_unavailable',
        'Quest is not available in this character context.',
      );
    if (
      recipientRef !== undefined &&
      (!this.#game.recipientAvailable(character, recipientRef) ||
        recipientRef !== quest.definition.recipientRef)
    )
      return reject(
        'recipient_unavailable',
        'Recipient is unavailable for this quest.',
      );
    return complete({
      questId,
      title: quest.definition.title,
      recipientRef: recipientRef ?? null,
      revision: quest.revision,
      status: recipientRef
        ? (quest.offer?.status ?? 'registered')
        : 'registered',
      objectives: quest.definition.objectives.map((objective) => ({
        id: objective.id,
        description: objective.description,
        status: recipientRef
          ? (quest.progress.find((entry) => entry.id === objective.id)
              ?.status ?? 'pending')
          : 'pending',
        observed: recipientRef
          ? (quest.progress.find((entry) => entry.id === objective.id)
              ?.observed ?? null)
          : null,
      })),
      choices: recipientRef ? this.#choices(quest) : [],
      ...(quest.definition.flow
        ? {
            flow: {
              definition: quest.definition.flow,
              currentStage: recipientRef
                ? (quest.flowState?.current ?? null)
                : null,
              visited: recipientRef ? (quest.flowState?.visited ?? []) : [],
              dialogue: recipientRef
                ? (this.#stage(quest)?.dialogue ?? null)
                : null,
            },
          }
        : {}),
    });
  }
  #conditionAvailable(
    character: CharacterDefinition,
    condition: Condition,
  ): boolean {
    const capability = this.#game
      .capabilities(character)
      .find((entry) => entry.name === condition.tool);
    return (
      capability?.kind === 'inspection' &&
      capability.validate(condition.arguments) &&
      this.#game.referencesAvailable(character, condition) &&
      (condition.expect.operator !== 'at_least' ||
        typeof condition.expect.value === 'number')
    );
  }
  #observe(
    quest: QuestRecord,
    objectiveId: string,
    condition: Condition,
    owner: Bound,
  ): void {
    const job: Observation = {
      id: ++this.#jobSequence,
      epoch: this.#epoch,
      questId: quest.id,
      objectiveId,
      condition,
      owner,
      controller: new AbortController(),
    };
    this.#observations.set(job.id, job);
    try {
      const character = owner();
      if (!this.#conditionAvailable(character, condition))
        throw new Error('Condition unavailable');
      const capability = this.#game
        .capabilities(character)
        .find((entry) => entry.name === condition.tool);
      if (!capability) throw new Error('Capability unavailable');
      const context: Invocation = {
        gameId: this.#associationId,
        character,
        requestId: `narrative-${String(job.id)}`,
        time: this.#time,
        signal: job.controller.signal,
      };
      const result = capability.execute(context, condition.arguments);
      void Promise.resolve(result).then(
        (value) => {
          this.#receive(job, value);
        },
        () => {
          this.#receive(job, null);
        },
      );
    } catch {
      this.#receive(job, null);
    }
  }
  #receive(job: Observation, result: CapabilityResult | null): void {
    if (!this.#disposed)
      this.#inbox.push({
        job,
        result: isJson(result) ? immutable(result) : null,
      });
  }
  #commit({ job, result }: Observed): void {
    this.#observations.delete(job.id);
    const quest = this.#quests.get(job.questId);
    if (
      job.epoch !== this.#epoch ||
      !quest ||
      quest.offer?.status !== 'active' ||
      this.#owners.get(quest.ownerKey) !== job.owner ||
      (quest.flowState &&
        !this.#stage(quest)?.objectives.includes(job.objectiveId))
    )
      return;
    try {
      job.owner();
    } catch {
      return;
    }
    const reading =
      record(result) &&
      result['status'] === 'completed' &&
      isJson(result['data'])
        ? readObserved(result['data'], job.condition.expect.path)
        : { found: false, value: null };
    const expected = job.condition.expect;
    const comparable =
      reading.found &&
      (expected.operator === 'equals'
        ? typeof reading.value === typeof expected.value &&
          (reading.value === null ||
            ['string', 'number', 'boolean'].includes(typeof reading.value))
        : typeof reading.value === 'number');
    const satisfied =
      comparable &&
      (expected.operator === 'equals'
        ? reading.value === expected.value
        : typeof reading.value === 'number' &&
          typeof expected.value === 'number' &&
          reading.value >= expected.value);
    this.#update(quest, {
      id: job.objectiveId,
      status: !comparable ? 'unknown' : satisfied ? 'satisfied' : 'pending',
      observed: reading.value,
    });
  }
  #update(quest: QuestRecord, progress: ObjectiveProgress): void {
    const index = quest.progress.findIndex((entry) => entry.id === progress.id),
      previous = quest.progress[index];
    if (previous && canonical({ ...previous }) === canonical({ ...progress }))
      return;
    quest.progress[index] = immutable(progress);
    quest.revision++;
    this.#emit(quest, 'quest_progressed');
    if (quest.flowState && quest.offer?.status === 'active') {
      const stage = this.#stage(quest);
      if (stage && this.#stageSatisfied(quest, stage)) {
        if (stage.next) this.#enterStage(quest, stage.next);
        else if (!stage.choices) {
          quest.offer.status = 'completed';
          quest.revision++;
          this.#emit(quest, 'quest_completed');
        }
      }
      return;
    }
    if (
      quest.offer?.status === 'active' &&
      quest.progress.every((entry) => entry.status === 'satisfied')
    ) {
      quest.offer.status = 'completed';
      quest.revision++;
      this.#emit(quest, 'quest_completed');
    }
  }
  #stage(quest: QuestRecord): QuestStage | undefined {
    return quest.definition.flow?.stages.find(
      (entry) => entry.id === quest.flowState?.current,
    );
  }
  #stageSatisfied(quest: QuestRecord, stage: QuestStage): boolean {
    return stage.objectives.every((id) =>
      quest.progress.some(
        (entry) => entry.id === id && entry.status === 'satisfied',
      ),
    );
  }
  #branchChoices(quest: QuestRecord) {
    const stage = this.#stage(quest);
    return quest.offer?.status === 'active' &&
      stage &&
      this.#stageSatisfied(quest, stage)
      ? (stage.choices ?? []).map((choice) => ({
          id: `${quest.id}/stage/${encodeURIComponent(stage.id)}/${encodeURIComponent(choice.id)}`,
          label: choice.label,
          next: choice.next,
        }))
      : [];
  }
  #enterStage(quest: QuestRecord, id: string): void {
    if (!quest.flowState) throw new Error('Quest has no stage flow');
    quest.flowState.current = id;
    quest.flowState.visited.push(id);
    quest.revision++;
    this.#emit(quest, 'quest_stage_entered');
  }
  #emit(
    quest: QuestRecord,
    type: NarrativeEvent['type'],
    choiceId?: string,
  ): void {
    if (this.#events.length === 512) {
      this.#events.shift();
      this.#droppedEvents++;
    }
    this.#events.push(
      immutable({
        id: `${this.#associationId}/narrative-event-${String(++this.#eventSequence)}`,
        origin: 'framework_narrative',
        type,
        characterRef: quest.authorRef,
        questId: quest.id,
        recipientRef: quest.definition.recipientRef,
        revision: quest.revision,
        ...(quest.flowState ? { stageId: quest.flowState.current } : {}),
        ...(choiceId === undefined ? {} : { choiceId }),
      }),
    );
  }
}

export class NarrativeHandle {
  readonly #submit: (
    tool: ToolName,
    input: Json,
    effectKey?: string,
  ) => Promise<NarrativeResult>;
  constructor(
    submit: (
      tool: ToolName,
      input: Json,
      effectKey?: string,
    ) => Promise<NarrativeResult>,
  ) {
    this.#submit = submit;
  }
  call(
    tool: ToolName,
    input: unknown,
    effectKey?: string,
  ): Promise<NarrativeResult> {
    if (!boundedJson(input))
      return Promise.resolve(
        reject(
          'invalid_arguments',
          'Arguments must be finite JSON within 64 KiB and 32 object/array levels.',
        ),
      );
    return this.#submit(tool, immutable(input), effectKey);
  }
}
