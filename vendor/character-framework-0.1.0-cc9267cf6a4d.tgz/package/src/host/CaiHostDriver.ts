import { immutable, isJson } from '../json.js';
import { canonical, record, shape, text } from '../narrative/validation.js';
import { CaiConversation } from '../cai/CaiConversation.js';
import { isSave, isSession } from '../cai/validation.js';
import type {
  CaiBackend,
  CaiConversationSave,
  CaiTurnInput,
  CaiTurnReceipt,
  CaiFeedback,
} from '../cai/types.js';
import type {
  HostDriver,
  HostIntent,
  HostChoice,
} from './CharacterHostPort.js';

interface RetainedOperation {
  readonly id: string;
  readonly effectKey: string;
  readonly intent: HostIntent;
  readonly input: CaiTurnInput | null;
  readonly receipt: CaiTurnReceipt | null;
  readonly result: string | null;
}
export interface CaiHostDriverSave {
  readonly schemaVersion: 1;
  readonly conversation: CaiConversationSave;
  readonly operations: readonly RetainedOperation[];
}
const inputKey = (input: CaiTurnInput) =>
  canonical({
    request_id: input.request_id,
    version: input.version,
    origin: input.origin,
    message: input.message,
  });
function validIntent(value: unknown): value is HostIntent {
  return (
    (shape(value, ['kind', 'message']) &&
      value['kind'] === 'dialogue' &&
      text(value['message'], 8000) &&
      value['message'].trim().length > 0) ||
    (shape(value, ['kind', 'choiceId']) &&
      value['kind'] === 'choice' &&
      text(value['choiceId'], 1000))
  );
}
function validCheckpoint(value: unknown): value is CaiHostDriverSave {
  if (
    !isJson(value) ||
    !shape(value, ['schemaVersion', 'conversation', 'operations']) ||
    value['schemaVersion'] !== 1 ||
    !isSave(value['conversation']) ||
    !Array.isArray(value['operations']) ||
    value['operations'].length > 128
  )
    return false;
  const session = value['conversation'].session;
  const ids: string[] = [];
  const effects: string[] = [];
  for (const raw of value['operations']) {
    if (
      !shape(raw, [
        'id',
        'effectKey',
        'intent',
        'input',
        'receipt',
        'result',
      ]) ||
      !text(raw['id']) ||
      ids.includes(raw['id']) ||
      !text(raw['effectKey']) ||
      effects.includes(raw['effectKey']) ||
      !validIntent(raw['intent']) ||
      (raw['result'] !== null && !text(raw['result'], 32000))
    )
      return false;
    ids.push(raw['id']);
    effects.push(raw['effectKey']);
    const input = raw['input'],
      receipt = raw['receipt'];
    if (
      input !== null &&
      (!shape(input, ['request_id', 'version', 'origin', 'message']) ||
        !text(input['request_id']) ||
        !Number.isSafeInteger(input['version']) ||
        typeof input['version'] !== 'number' ||
        input['version'] < 0 ||
        input['origin'] !== 'player_dialogue' ||
        raw['intent'].kind !== 'dialogue' ||
        input['message'] !== raw['intent'].message)
    )
      return false;
    if (
      receipt !== null &&
      (!shape(receipt, ['requestId', 'message', 'session']) ||
        !record(input) ||
        receipt['requestId'] !== input['request_id'] ||
        !text(receipt['message'], 32000) ||
        !isSession(receipt['session']) ||
        receipt['session'].id !== session.id ||
        receipt['session'].characterId !== session.characterId ||
        receipt['session'].bindingKey !== session.bindingKey ||
        receipt['session'].version !== Number(input['version']) + 1 ||
        raw['result'] !== receipt['message'])
    )
      return false;
    if (raw['intent'].kind === 'choice' && (input !== null || receipt !== null))
      return false;
    if (
      raw['intent'].kind === 'dialogue' &&
      raw['result'] !== null &&
      receipt === null
    )
      return false;
  }
  return true;
}

/** Trusted driver. Persist this bundle with the host port/game/publication checkpoint. */
export class CaiHostDriver implements HostDriver {
  readonly #persist: (saved: CaiHostDriverSave) => void | Promise<void>;
  readonly #current: () => void;
  readonly #choices: () => readonly HostChoice[];
  readonly #choose:
    ((choiceId: string, effectKey: string) => Promise<string>) | undefined;
  readonly #conversation: CaiConversation;
  #operations: readonly RetainedOperation[];
  #activeId: string | undefined;
  #disposed = false;
  constructor(options: {
    readonly backend: CaiBackend;
    readonly saved: unknown;
    readonly persist: (saved: CaiHostDriverSave) => void | Promise<void>;
    readonly current: () => void;
    readonly choices?: () => readonly HostChoice[];
    readonly choose?: (choiceId: string, effectKey: string) => Promise<string>;
  }) {
    if (!validCheckpoint(options.saved))
      throw new TypeError('Invalid CAI host driver checkpoint');
    this.#operations = immutable(options.saved.operations);
    this.#persist = options.persist;
    this.#current = options.current;
    this.#choices = options.choices ?? (() => []);
    this.#choose = options.choose;
    const backend: CaiBackend = {
      attach: (input, signal) => options.backend.attach(input, signal),
      event: (id, input, signal) => options.backend.event(id, input, signal),
      turn: async (id, input, signal) => {
        this.current();
        const op = this.#operation();
        if (!op.input || inputKey(op.input) !== inputKey(input))
          throw new Error('CAI host input correlation failed');
        const receipt =
          op.receipt ?? (await options.backend.turn(id, input, signal));
        this.current();
        const session = this.#conversation.save().session;
        if (
          receipt.requestId !== input.request_id ||
          !text(receipt.message, 32000) ||
          !isSession(receipt.session) ||
          receipt.session.id !== session.id ||
          receipt.session.characterId !== session.characterId ||
          receipt.session.bindingKey !== session.bindingKey ||
          receipt.session.version !== input.version + 1
        )
          throw new Error('Invalid retained CAI reply');
        // Captured before CaiConversation persists its acknowledgment. That same
        // storage callback includes this receipt, closing the port-ack crash gap.
        this.#replace({
          ...op,
          receipt: immutable(receipt),
          result: receipt.message,
        });
        return receipt;
      },
    };
    this.#conversation = new CaiConversation(
      backend,
      options.saved.conversation,
      () => {
        this.current();
      },
      async (conversation) => {
        const op = this.#operation();
        if (conversation.pending?.kind === 'turn') {
          if (
            op.intent.kind !== 'dialogue' ||
            (op.input &&
              inputKey(op.input) !== inputKey(conversation.pending.input))
          )
            throw new Error('CAI host input changed');
          this.#replace({ ...op, input: conversation.pending.input });
        }
        await this.#store(conversation);
      },
    );
  }
  current(): void {
    if (this.#disposed) throw new Error('CAI host driver disposed');
    this.#current();
  }
  choices(): readonly HostChoice[] {
    return this.#choices();
  }
  save(): CaiHostDriverSave {
    return immutable({
      schemaVersion: 1,
      conversation: this.#conversation.save(),
      operations: this.#operations,
    });
  }
  async run(
    id: string,
    effectKey: string,
    intent: HostIntent,
  ): Promise<string> {
    this.current();
    if (this.#activeId) throw new Error('CAI host driver busy');
    if (!text(id) || !text(effectKey) || !validIntent(intent))
      throw new TypeError('Invalid host operation');
    let op = this.#operations.find((item) => item.id === id);
    if (
      op &&
      (op.effectKey !== effectKey || canonical(op.intent) !== canonical(intent))
    )
      throw new Error('CAI host operation identity conflict');
    if (!op) {
      if (this.#operations.some((item) => item.effectKey === effectKey))
        throw new Error('CAI host effect identity conflict');
      if (this.#operations.some((item) => item.result === null))
        throw new Error('Resolve retained host driver operation first');
      if (this.#conversation.save().pending)
        throw new Error('Unmapped pending CAI operation');
      if (this.#operations.length >= 128)
        throw new Error('CAI host driver ledger saturated');
      op = immutable({
        id,
        effectKey,
        intent,
        input: null,
        receipt: null,
        result: null,
      });
      this.#operations = immutable([...this.#operations, op]);
    }
    this.#activeId = id;
    try {
      await this.#store(this.#conversation.save());
      if (intent.kind === 'choice') {
        if (!this.#choose) throw new Error('Host choice driver unavailable');
        const result =
          op.result ?? (await this.#choose(intent.choiceId, effectKey));
        this.current();
        if (!text(result, 32000)) throw new Error('Invalid host choice result');
        this.#replace({ ...op, result });
        await this.#store(this.#conversation.save());
        return result;
      }
      let pending = this.#conversation.save().pending;
      if (pending?.kind === 'event') {
        // Feedback flush runs before this operation allocates its dialogue UUID.
        // Reconcile that original event first; dialogue remains unallocated.
        if (op.input || op.receipt)
          throw new Error('Resolve original CAI pending operation');
        await this.#conversation.retry();
        pending = this.#conversation.save().pending;
      }
      if (pending) {
        if (
          !op.input ||
          pending.kind !== 'turn' ||
          inputKey(pending.input) !== inputKey(op.input)
        )
          throw new Error('Resolve original CAI pending operation');
        const result = await this.#conversation.retry();
        if (result === null) throw new Error('Dialogue receipt missing');
        return result;
      }
      if (op.receipt) return op.receipt.message; // Already durable: never regenerate.
      if (op.input)
        throw new Error(
          'Retained CAI request requires explicit receipt recovery',
        );
      return await this.#conversation.dialogue(intent.message);
    } finally {
      this.#activeId = undefined;
    }
  }
  async persistFeedback(feedback: CaiFeedback): Promise<void> {
    this.current();
    if (this.#activeId)
      throw new Error(
        'Queue host feedback until the active driver operation settles',
      );
    this.#conversation.enqueueFeedback(feedback);
    await this.#store(this.#conversation.save());
  }
  dispose(): void {
    this.#disposed = true;
    this.#conversation.dispose();
  }
  #operation(): RetainedOperation {
    const op = this.#operations.find((item) => item.id === this.#activeId);
    if (!op) throw new Error('No active host operation');
    return op;
  }
  #replace(op: RetainedOperation): void {
    this.#operations = immutable(
      this.#operations.map((item) => (item.id === op.id ? op : item)),
    );
  }
  async #store(conversation: CaiConversationSave): Promise<void> {
    this.current();
    await this.#persist(
      immutable({
        schemaVersion: 1,
        conversation,
        operations: this.#operations,
      }),
    );
    this.current();
  }
}
