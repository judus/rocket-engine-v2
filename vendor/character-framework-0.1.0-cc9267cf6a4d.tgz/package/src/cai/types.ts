import type { Json } from '../types.js';

export interface CaiSessionState {
  readonly id: string;
  readonly characterId: string;
  readonly bindingKey: string;
  readonly version: number;
  readonly mode: 'game';
  readonly continuityMode: 'session';
  readonly bindingGeneration?: string | null;
}

export interface CaiBindingInput {
  readonly binding_key: string;
  readonly binding_generation: string;
  readonly expected_binding_generation: string | null;
}
export interface CaiBindingReceipt {
  readonly sessionId: string;
  readonly bindingKey: string;
  readonly generation: string;
  /** Informational only; never acknowledges a conversation operation. */
  readonly version: number;
}
export interface CaiBindingBackend {
  publishBinding(
    sessionId: string,
    input: CaiBindingInput,
    signal: AbortSignal,
  ): Promise<CaiBindingReceipt>;
}
export interface CaiBindingSave {
  readonly schemaVersion: 1;
  readonly sessionId: string;
  readonly bindingKey: string;
  readonly acceptedGeneration: string | null;
  readonly pending: CaiBindingInput | null;
}
export interface CaiTurnInput {
  readonly request_id: string;
  readonly version: number;
  readonly origin: 'player_dialogue' | 'framework_request';
  readonly message: string;
  readonly context?: { readonly facts: string; readonly actor_ref?: string };
}
export interface CaiFeedback {
  readonly sourceId: string;
  readonly type: string;
  readonly summary: string;
  readonly references: Record<string, string>;
  readonly origin: 'framework_narrative' | 'game_outcome';
}
export interface CaiEventInput {
  readonly event_id: string;
  readonly version: number;
  readonly origin: CaiFeedback['origin'];
  readonly type: string;
  readonly summary: string;
  readonly references: Record<string, string>;
}
export interface CaiTurnReceipt {
  readonly requestId: string;
  readonly message: string;
  readonly session: CaiSessionState;
}
export interface CaiEventReceipt {
  readonly eventId: string;
  readonly version: number;
}
/** CAI owns its API/journal; this port keeps HTTP and pending draft envelopes outside the core. */
export interface CaiBackend {
  attach(
    input: { characterId: string; bindingKey: string; sessionId?: string },
    signal: AbortSignal,
  ): Promise<CaiSessionState>;
  turn(
    sessionId: string,
    input: CaiTurnInput,
    signal: AbortSignal,
  ): Promise<CaiTurnReceipt>;
  event(
    sessionId: string,
    input: CaiEventInput,
    signal: AbortSignal,
  ): Promise<CaiEventReceipt>;
}
export type CaiPending =
  | { readonly kind: 'turn'; readonly input: CaiTurnInput }
  | {
      readonly kind: 'event';
      readonly input: CaiEventInput;
      readonly sourceId: string;
    };
export interface CaiConversationSave {
  readonly schemaVersion: 1;
  readonly session: CaiSessionState;
  readonly pending: CaiPending | null;
  readonly feedback: readonly CaiFeedback[];
  readonly reported: readonly string[];
}
export type CaiHttpDecoder = (body: Json) => CaiEventReceipt;
