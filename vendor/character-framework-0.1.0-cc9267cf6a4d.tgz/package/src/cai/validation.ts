import { integer, shape, text, record } from '../narrative/validation.js';
import { boundedJson } from '../narrative/validation.js';
import type {
  CaiConversationSave,
  CaiFeedback,
  CaiSessionState,
} from './types.js';

const wireReference = (value: unknown, max = 160): value is string =>
  text(value, max) && value.trim().length > 0 && !/\p{Cc}/u.test(value);
export const bindingSelector = (value: unknown): value is string =>
  wireReference(value);

/** Validate prose without trimming or rewriting the exact replay input. */
export const turnProse = (value: unknown, max: number): value is string =>
  text(value, max) && /\S/u.test(value);
export function isTurnContext(value: unknown): boolean {
  return (
    value === undefined ||
    (shape(value, ['facts', 'actor_ref'], ['facts']) &&
      turnProse(value['facts'], 4000) &&
      (value['actor_ref'] === undefined || turnProse(value['actor_ref'], 160)))
  );
}

export function isSession(value: unknown): value is CaiSessionState {
  return (
    shape(
      value,
      [
        'id',
        'characterId',
        'bindingKey',
        'version',
        'mode',
        'continuityMode',
        'bindingGeneration',
      ],
      ['id', 'characterId', 'bindingKey', 'version', 'mode', 'continuityMode'],
    ) &&
    text(value['id']) &&
    text(value['characterId']) &&
    bindingSelector(value['bindingKey']) &&
    (value['bindingGeneration'] === undefined ||
      value['bindingGeneration'] === null ||
      bindingSelector(value['bindingGeneration'])) &&
    integer(value['version']) &&
    value['mode'] === 'game' &&
    value['continuityMode'] === 'session'
  );
}
export function isFeedback(value: unknown): value is CaiFeedback {
  return (
    shape(value, ['sourceId', 'type', 'summary', 'references', 'origin']) &&
    wireReference(value['sourceId']) &&
    wireReference(value['type'], 80) &&
    text(value['summary'], 2000) &&
    /\S/u.test(value['summary']) &&
    shape(value['references'], Object.keys(value['references'] ?? {})) &&
    Object.keys(value['references']).length <= 16 &&
    Object.keys(value['references']).every((key) => wireReference(key, 80)) &&
    Object.values(value['references']).every((item: unknown) =>
      wireReference(item),
    ) &&
    ['framework_narrative', 'game_outcome'].includes(String(value['origin']))
  );
}
export function isSave(value: unknown): value is CaiConversationSave {
  if (
    !shape(value, [
      'schemaVersion',
      'session',
      'pending',
      'feedback',
      'reported',
    ]) ||
    value['schemaVersion'] !== 1 ||
    !isSession(value['session']) ||
    !Array.isArray(value['feedback']) ||
    value['feedback'].length > 128 ||
    !value['feedback'].every(isFeedback) ||
    !Array.isArray(value['reported']) ||
    value['reported'].length > 4096 ||
    !value['reported'].every((item: unknown) => wireReference(item))
  )
    return false;
  const reported = value['reported'];
  if (reported.length + value['feedback'].length > 4096) return false;
  const queued = value['feedback'].map((item: CaiFeedback) => item.sourceId);
  if (
    new Set(reported).size !== reported.length ||
    new Set(queued).size !== queued.length ||
    queued.some((id) => reported.includes(id))
  )
    return false;
  const pending = value['pending'];
  if (pending === null) return true;
  if (
    !boundedJson(pending) ||
    !shape(pending, ['kind', 'input', 'sourceId'], ['kind', 'input'])
  )
    return false;
  const input = pending['input'];
  if (
    !shape(
      input,
      pending['kind'] === 'turn'
        ? ['request_id', 'version', 'origin', 'message', 'context']
        : ['event_id', 'version', 'origin', 'type', 'summary', 'references'],
      pending['kind'] === 'turn'
        ? ['request_id', 'version', 'origin', 'message']
        : ['event_id', 'version', 'origin', 'type', 'summary', 'references'],
    ) ||
    input['version'] !== value['session'].version
  )
    return false;
  if (pending['kind'] === 'turn')
    return (
      pending['sourceId'] === undefined &&
      text(input['request_id']) &&
      turnProse(input['message'], 8000) &&
      (input['origin'] === 'player_dialogue' ||
        input['origin'] === 'framework_request') &&
      isTurnContext(input['context'])
    );
  if (
    pending['kind'] !== 'event' ||
    !text(pending['sourceId']) ||
    pending['sourceId'] !== queued[0] ||
    !text(input['event_id'])
  )
    return false;
  const feedback = value['feedback'][0];
  return (
    feedback !== undefined &&
    input['origin'] === feedback.origin &&
    input['type'] === feedback.type &&
    input['summary'] === feedback.summary &&
    JSON.stringify(input['references']) === JSON.stringify(feedback.references)
  );
}

export function decodeSession(value: unknown): CaiSessionState {
  if (
    !record(value) ||
    !record(value['character']) ||
    !bindingSelector(value['binding_key']) ||
    !(
      value['binding_generation'] === null ||
      bindingSelector(value['binding_generation'])
    ) ||
    !integer(value['version']) ||
    value['mode'] !== 'game' ||
    value['continuity_mode'] !== 'session'
  )
    throw new Error(
      'CAI did not confirm exclusive game mode and session continuity',
    );
  const id = value['id'];
  const characterId = value['character']['id'];
  if (!(
    (text(id) || integer(id)) &&
    (text(characterId) || integer(characterId))
  ))
    throw new Error('Invalid CAI session IDs');
  return {
    id: String(id),
    characterId: String(characterId),
    bindingKey: value['binding_key'],
    version: value['version'],
    mode: 'game',
    continuityMode: 'session',
    bindingGeneration: value['binding_generation'],
  };
}
