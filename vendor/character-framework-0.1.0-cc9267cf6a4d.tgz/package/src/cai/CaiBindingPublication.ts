import { immutable } from '../json.js';
import { boundedJson, integer, shape, text } from '../narrative/validation.js';
import { bindingSelector } from './validation.js';
import type { CaiBindingBackend, CaiBindingSave } from './types.js';

function validSave(value: unknown): value is CaiBindingSave {
  if (
    !boundedJson(value) ||
    !shape(value, [
      'schemaVersion',
      'sessionId',
      'bindingKey',
      'acceptedGeneration',
      'pending',
    ]) ||
    value['schemaVersion'] !== 1 ||
    !text(value['sessionId']) ||
    !bindingSelector(value['bindingKey']) ||
    !(
      value['acceptedGeneration'] === null ||
      bindingSelector(value['acceptedGeneration'])
    )
  )
    return false;
  const pending = value['pending'];
  return (
    pending === null ||
    (shape(pending, [
      'binding_key',
      'binding_generation',
      'expected_binding_generation',
    ]) &&
      pending['binding_key'] === value['bindingKey'] &&
      bindingSelector(pending['binding_generation']) &&
      pending['expected_binding_generation'] === value['acceptedGeneration'])
  );
}

/** Trusted host journal. Reconcile pending publication before publishing a restored generation. */
export class CaiBindingPublication {
  readonly #backend: CaiBindingBackend;
  readonly #persist: (state: CaiBindingSave) => void | Promise<void>;
  readonly #current: () => void;
  #state: CaiBindingSave;
  #active = false;
  #disposed = false;
  #controller: AbortController | undefined;
  constructor(
    backend: CaiBindingBackend,
    state: unknown,
    persist: (state: CaiBindingSave) => void | Promise<void> = () => undefined,
    current: () => void = () => undefined,
  ) {
    if (!validSave(state)) throw new TypeError('Invalid binding checkpoint');
    this.#backend = backend;
    this.#state = immutable(state);
    this.#persist = persist;
    this.#current = current;
  }
  get status() {
    return Object.freeze({
      acceptedGeneration: this.#state.acceptedGeneration,
      pending: this.#state.pending !== null,
      active: this.#active,
    });
  }
  save(): CaiBindingSave {
    return immutable(this.#state);
  }
  async publish(generation: string): Promise<void> {
    this.#assertAvailable();
    if (this.#state.pending)
      throw new Error('Reconcile the pending binding before new publication');
    if (!bindingSelector(generation))
      throw new TypeError('Invalid binding generation');
    this.#state = immutable({
      ...this.#state,
      pending: {
        binding_key: this.#state.bindingKey,
        binding_generation: generation,
        expected_binding_generation: this.#state.acceptedGeneration,
      },
    });
    await this.retry();
  }
  async retry(): Promise<void> {
    this.#assertAvailable();
    const pending = this.#state.pending;
    if (!pending) throw new Error('No binding publication to reconcile');
    this.#active = true;
    const controller = new AbortController();
    this.#controller = controller;
    try {
      await this.#persist(this.save());
      this.#assertLive();
      controller.signal.throwIfAborted();
      const receipt = await this.#backend.publishBinding(
        this.#state.sessionId,
        pending,
        controller.signal,
      );
      this.#assertLive();
      controller.signal.throwIfAborted();
      if (
        receipt.sessionId !== this.#state.sessionId ||
        receipt.bindingKey !== this.#state.bindingKey ||
        receipt.generation !== pending.binding_generation ||
        !integer(receipt.version)
      )
        throw new Error('Invalid binding acknowledgment');
      const acknowledged = immutable({
        ...this.#state,
        acceptedGeneration: receipt.generation,
        pending: null,
      });
      await this.#persist(acknowledged);
      this.#assertLive();
      controller.signal.throwIfAborted();
      this.#state = acknowledged;
    } finally {
      this.#active = false;
      this.#controller = undefined;
    }
  }
  dispose(): void {
    this.#disposed = true;
    this.#controller?.abort();
  }
  #assertLive(): void {
    if (this.#disposed) throw new Error('Binding publication is disposed');
    this.#current();
  }
  #assertAvailable(): void {
    this.#assertLive();
    if (this.#active) throw new Error('Binding publication already active');
  }
}
