import type { CaiReceiptBackend } from './receipts.js';
import { immutable } from '../json.js';
import { canonical, integer, text } from '../narrative/validation.js';
import {
  isFeedback,
  isSave,
  isSession,
  turnProse,
  isTurnContext,
} from './validation.js';
import type {
  CaiBackend,
  CaiConversationSave,
  CaiFeedback,
  CaiPending,
  CaiSessionState,
  CaiTurnInput,
} from './types.js';

/** One persistent conversation per character; remote versions and requests stay independent. */
export class CaiConversation {
  readonly #backend: CaiBackend;
  readonly #current: () => void;
  readonly #persist: (state: CaiConversationSave) => void | Promise<void>;
  #state: CaiConversationSave;
  #active = false;
  #controller: AbortController | undefined;
  #disposed = false;
  constructor(
    backend: CaiBackend,
    state: CaiConversationSave,
    current: () => void = () => undefined,
    persist: (state: CaiConversationSave) => void | Promise<void> = () =>
      undefined,
  ) {
    if (!isSave(state))
      throw new TypeError('Invalid CAI conversation checkpoint');
    this.#backend = backend;
    this.#state = immutable(state);
    this.#current = current;
    this.#persist = persist;
  }
  static async attach(
    backend: CaiBackend,
    binding: { characterId: string; bindingKey: string; sessionId?: string },
    signal: AbortSignal,
    current: () => void = () => undefined,
    persist: (state: CaiConversationSave) => void | Promise<void> = () =>
      undefined,
  ): Promise<CaiConversation> {
    current();
    const session = await backend.attach(binding, signal);
    current();
    if (
      signal.aborted ||
      !isSession(session) ||
      session.characterId !== binding.characterId ||
      session.bindingKey !== binding.bindingKey ||
      (binding.sessionId !== undefined && session.id !== binding.sessionId)
    )
      throw new Error('CAI did not confirm the requested game/session binding');
    return new CaiConversation(
      backend,
      { schemaVersion: 1, session, pending: null, feedback: [], reported: [] },
      current,
      persist,
    );
  }
  get status() {
    return Object.freeze({
      session: this.#state.session,
      pending: this.#state.pending?.kind ?? null,
      active: this.#active,
      queuedFeedback: this.#state.feedback.length,
    });
  }
  save(): CaiConversationSave {
    return immutable(this.#state);
  }
  enqueueFeedback(feedback: CaiFeedback): void {
    this.#assertLive();
    if (!isFeedback(feedback)) throw new TypeError('Invalid typed feedback');
    const source = feedback.references['source_event_id'];
    if (source !== undefined && source !== feedback.sourceId)
      throw new TypeError(
        'source_event_id must match the authoritative source ID',
      );
    feedback = {
      ...feedback,
      references: {
        ...feedback.references,
        source_event_id: feedback.sourceId,
      },
    };
    if (!isFeedback(feedback))
      throw new TypeError(
        'Feedback references must leave room for source_event_id',
      );
    if (this.#state.reported.includes(feedback.sourceId)) return;
    const queued = this.#state.feedback.find(
      (entry) => entry.sourceId === feedback.sourceId,
    );
    if (queued) {
      if (
        canonical({ ...queued, references: { ...queued.references } }) !==
        canonical({ ...feedback, references: { ...feedback.references } })
      )
        throw new Error('Feedback identity conflicts with queued input');
      return;
    }
    if (
      this.#state.feedback.length >= 128 ||
      this.#state.feedback.length + this.#state.reported.length >= 4096
    )
      throw new Error('Feedback capacity reached');
    this.#state = immutable({
      ...this.#state,
      feedback: [...this.#state.feedback, feedback],
    });
  }
  async flushFeedback(): Promise<void> {
    this.#assertAvailable();
    if (this.#state.pending)
      throw new Error(
        'Reconcile the pending CAI request before sending new work',
      );
    while (this.#state.feedback[0]) {
      const feedback = this.#state.feedback[0];
      this.#state = immutable({
        ...this.#state,
        pending: {
          kind: 'event',
          sourceId: feedback.sourceId,
          input: {
            event_id: crypto.randomUUID(),
            version: this.#state.session.version,
            origin: feedback.origin,
            type: feedback.type,
            summary: feedback.summary,
            references: feedback.references,
          },
        },
      });
      await this.retry();
    }
  }
  async dialogue(
    message: string,
    context?: CaiTurnInput['context'],
  ): Promise<string> {
    return this.#turn('player_dialogue', message, context);
  }
  async requestNarrative(
    message: string,
    context?: CaiTurnInput['context'],
  ): Promise<string> {
    return this.#turn('framework_request', message, context);
  }
  async #turn(
    origin: CaiTurnInput['origin'],
    message: string,
    context?: CaiTurnInput['context'],
  ): Promise<string> {
    this.#assertAvailable();
    if (!turnProse(message, 8000))
      throw new TypeError(
        'Dialogue must contain nonblank prose of 1–8000 characters',
      );
    if (!isTurnContext(context)) throw new TypeError('Invalid turn context');
    const retainedContext =
      context === undefined ? undefined : immutable(context);
    await this.flushFeedback();
    this.#assertAvailable();
    if (this.#state.pending) throw new Error('CAI request already pending');
    const pending: CaiPending = {
      kind: 'turn',
      input: {
        request_id: crypto.randomUUID(),
        version: this.#state.session.version,
        origin,
        message,
        ...(retainedContext === undefined ? {} : { context: retainedContext }),
      },
    };
    const next = { ...this.#state, pending };
    if (!isSave(next)) throw new TypeError('Invalid turn context');
    this.#state = immutable(next);
    return (await this.retry()) ?? '';
  }
  /** Retry exact persisted input; do not refresh its version or generate a new request identity. */
  async retry(): Promise<string | null> {
    this.#assertAvailable();
    const pending = this.#state.pending;
    if (!pending) throw new Error('No request to reconcile');
    this.#active = true;
    const controller = new AbortController();
    this.#controller = controller;
    try {
      // Durable hosts store the exact pending input before a remote effect can begin.
      await this.#persist(this.save());
      this.#assertLive();
      controller.signal.throwIfAborted();
      if (pending.kind === 'turn') {
        const receipt = await this.#backend.turn(
          this.#state.session.id,
          pending.input,
          controller.signal,
        );
        this.#assertLive();
        if (
          receipt.requestId !== pending.input.request_id ||
          !text(receipt.message, 32000) ||
          !this.#sameSession(receipt.session) ||
          receipt.session.version <= pending.input.version
        )
          throw new Error('Invalid or stale CAI turn receipt');
        await this.#commitAcknowledgment((state) => ({
          ...state,
          session: receipt.session,
          pending: null,
        }));
        return receipt.message;
      }
      const receipt = await this.#backend.event(
        this.#state.session.id,
        pending.input,
        controller.signal,
      );
      this.#assertLive();
      if (
        receipt.eventId !== pending.input.event_id ||
        !integer(receipt.version) ||
        receipt.version <= pending.input.version
      )
        throw new Error('Invalid CAI feedback receipt');
      await this.#commitAcknowledgment((state) => ({
        ...state,
        session: { ...state.session, version: receipt.version },
        pending: null,
        feedback: state.feedback.slice(1),
        reported: [...state.reported, pending.sourceId],
      }));
      return null;
    } finally {
      this.#active = false;
      this.#controller = undefined;
    }
  }
  /** Explicitly retire a sealed failed turn; never retries tools or invents dialogue. */
  async acknowledgeFailure(receipts: CaiReceiptBackend): Promise<void> {
    await this.#reconcileTurn(receipts, 'failure');
  }
  /** Recover a committed reply by GET, without acquiring another provider run. */
  async reconcileCompleted(receipts: CaiReceiptBackend): Promise<string> {
    return (await this.#reconcileTurn(receipts, 'completed')) ?? '';
  }
  async #reconcileTurn(
    receipts: CaiReceiptBackend,
    kind: 'failure' | 'completed',
  ): Promise<string | null> {
    this.#assertAvailable();
    const pending = this.#state.pending;
    const original = this.#state.session;
    if (pending?.kind !== 'turn')
      throw new Error('No pending turn to acknowledge');
    if (typeof original.bindingGeneration !== 'string')
      throw new Error(
        'Original turn generation required for failure acknowledgment',
      );
    this.#active = true;
    const controller = new AbortController();
    this.#controller = controller;
    try {
      const page = await receipts.readAttempt(
        original,
        pending.input.request_id,
        controller.signal,
      );
      this.#assertLive();
      controller.signal.throwIfAborted();
      if (
        page.requestId !== pending.input.request_id ||
        page.inputVersion !== pending.input.version ||
        page.bindingGeneration !== original.bindingGeneration ||
        !this.#sameSession(page.session) ||
        page.session.version < pending.input.version ||
        !page.continuationAllowed
      )
        throw new Error('CAI failure receipt does not authorize continuation');
      if (kind === 'failure') {
        if (
          (page.dialogueStatus !== 'failed' &&
            page.dialogueStatus !== 'interrupted') ||
          page.turn !== null
        )
          throw new Error(
            'CAI failure receipt does not authorize continuation',
          );
      } else if (
        page.dialogueStatus !== 'completed' ||
        page.turn === null ||
        page.turn.requestId !== pending.input.request_id ||
        !integer(page.turn.version) ||
        page.turn.version <= pending.input.version ||
        page.turn.version > page.session.version ||
        !text(page.turn.message, 32000)
      ) {
        throw new Error(
          'CAI completed receipt does not authorize reconciliation',
        );
      }
      await this.#commitAcknowledgment((state) => ({
        ...state,
        session: page.session,
        pending: null,
      }));
      return kind === 'completed' ? (page.turn?.message ?? null) : null;
    } finally {
      this.#active = false;
      this.#controller = undefined;
    }
  }
  dispose(): void {
    this.#disposed = true;
    this.#controller?.abort();
  }
  async #commitAcknowledgment(
    build: (state: CaiConversationSave) => CaiConversationSave,
  ): Promise<void> {
    // Keep the pending request/version live until its acknowledgment is durable.
    // If the host adds feedback while saving, include it before publishing the checkpoint.
    for (;;) {
      this.#assertLive();
      const before = this.#state;
      const acknowledged = immutable(build(before));
      await this.#persist(acknowledged);
      this.#assertLive();
      if (this.#state !== before) continue;
      this.#state = acknowledged;
      return;
    }
  }
  #sameSession(session: CaiSessionState): boolean {
    return (
      isSession(session) &&
      session.id === this.#state.session.id &&
      session.characterId === this.#state.session.characterId &&
      session.bindingKey === this.#state.session.bindingKey
    );
  }
  #assertLive(): void {
    if (this.#disposed) throw new Error('Conversation disposed');
    this.#current();
  }
  #assertAvailable(): void {
    this.#assertLive();
    if (this.#active) throw new Error('CAI conversation is busy');
  }
}
