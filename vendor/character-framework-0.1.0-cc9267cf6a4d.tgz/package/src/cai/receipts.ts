import { CallToolResultSchema } from '@modelcontextprotocol/sdk/types.js';
import type { Json } from '../types.js';
import { immutable } from '../json.js';
import { integer, record, text } from '../narrative/validation.js';
import { bindingSelector, decodeSession } from './validation.js';
import type { CaiSessionState } from './types.js';

type JsonObject = { [key: string]: Json };
export interface CaiCallSummary {
  readonly call_id: string;
  readonly ordinal: number;
  readonly tool_name: string;
  readonly provider_alias: string;
  readonly provider_call_id: string | null;
  readonly binding_generation: string;
  readonly mutation: boolean;
  readonly effect_key: string | null;
  readonly state: 'not_dispatched' | 'in_flight' | 'resolved' | 'unknown';
  readonly outcome_kind:
    'mcp_result' | 'not_admitted' | 'transport_error' | null;
}
export interface CaiCallDetail extends CaiCallSummary {
  readonly arguments: JsonObject;
  readonly result: JsonObject | null;
  readonly admission: JsonObject | null;
}
export interface CaiAttemptPage {
  readonly requestId: string;
  readonly inputVersion: number;
  readonly bindingGeneration: string;
  /** Current identity/version, distinct from the original attempt and completed turn. */
  readonly session: CaiSessionState;
  readonly dialogueStatus: 'pending' | 'completed' | 'failed' | 'interrupted';
  /** Server's sealed/released whole-attempt gate; never inferred from this page. */
  readonly continuationAllowed: boolean;
  readonly turn: {
    readonly requestId: string;
    readonly version: number;
    readonly message: string;
  } | null;
  readonly calls: readonly CaiCallSummary[];
  readonly nextCursor: string | null;
}
/** Pure reads. No pending-state acknowledgment, reconciliation or action dispatch. */
export interface CaiReceiptBackend {
  readAttempt(
    session: CaiSessionState,
    requestId: string,
    signal: AbortSignal,
    cursor?: string,
  ): Promise<CaiAttemptPage>;
  readCall(
    sessionId: string,
    requestId: string,
    callId: string,
    signal: AbortSignal,
  ): Promise<CaiCallDetail>;
}

/** Receipt envelopes allow eight wrapper containers beyond the ordinary tool limit. */
export function receiptJson(value: unknown, depth = 0): value is Json {
  if (value === null || typeof value === 'string' || typeof value === 'boolean')
    return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (depth >= 40 || (!record(value) && !Array.isArray(value))) return false;
  return Object.values(value).every((item: unknown) =>
    receiptJson(item, depth + 1),
  );
}
export function receiptCursor(value: unknown): value is string {
  return (
    typeof value === 'string' &&
    value.length <= 16 &&
    /^[1-9][0-9]*$/u.test(value) &&
    BigInt(value) <= BigInt(Number.MAX_SAFE_INTEGER)
  );
}
function summary(value: unknown): CaiCallSummary {
  if (
    !record(value) ||
    !bindingSelector(value['call_id']) ||
    !integer(value['ordinal']) ||
    value['ordinal'] < 1 ||
    !text(value['tool_name'], 255) ||
    !text(value['provider_alias'], 64) ||
    !(
      value['provider_call_id'] === null || text(value['provider_call_id'], 255)
    ) ||
    !bindingSelector(value['binding_generation']) ||
    typeof value['mutation'] !== 'boolean' ||
    !(value['effect_key'] === null || bindingSelector(value['effect_key'])) ||
    (value['mutation'] && value['effect_key'] === null) ||
    !(
      value['state'] === 'not_dispatched' ||
      value['state'] === 'in_flight' ||
      value['state'] === 'resolved' ||
      value['state'] === 'unknown'
    ) ||
    !(
      value['outcome_kind'] === null ||
      value['outcome_kind'] === 'mcp_result' ||
      value['outcome_kind'] === 'not_admitted' ||
      value['outcome_kind'] === 'transport_error'
    )
  )
    throw new Error('Invalid CAI call summary');
  return {
    call_id: value['call_id'],
    ordinal: value['ordinal'],
    tool_name: value['tool_name'],
    provider_alias: value['provider_alias'],
    provider_call_id: value['provider_call_id'],
    binding_generation: value['binding_generation'],
    mutation: value['mutation'],
    effect_key: value['effect_key'],
    state: value['state'],
    outcome_kind: value['outcome_kind'],
  };
}
export function decodeAttempt(
  body: Json,
  expected: CaiSessionState,
  requestId: string,
  cursor?: string,
): CaiAttemptPage {
  if (!record(body) || !record(body['data']))
    throw new Error('Invalid CAI attempt envelope');
  const data = body['data'];
  const session = decodeSession(data['session']);
  if (
    data['request_id'] !== requestId ||
    session.id !== expected.id ||
    session.characterId !== expected.characterId ||
    session.bindingKey !== expected.bindingKey ||
    !integer(data['input_version']) ||
    data['input_version'] > session.version ||
    !bindingSelector(data['binding_generation']) ||
    typeof data['continuation_allowed'] !== 'boolean' ||
    !(
      data['dialogue_status'] === 'pending' ||
      data['dialogue_status'] === 'completed' ||
      data['dialogue_status'] === 'failed' ||
      data['dialogue_status'] === 'interrupted'
    ) ||
    !Array.isArray(data['calls']) ||
    data['calls'].length > 20 ||
    !(data['next_cursor'] === null || receiptCursor(data['next_cursor']))
  )
    throw new Error('Invalid CAI attempt correlation or metadata');
  const calls = data['calls'].map(summary);
  let previous = cursor === undefined ? 0n : BigInt(cursor);
  const ids = new Set<string>();
  for (const call of calls) {
    if (
      BigInt(call.ordinal) <= previous ||
      ids.has(call.call_id) ||
      call.binding_generation !== data['binding_generation']
    )
      throw new Error('Invalid CAI call page ordering or generation');
    previous = BigInt(call.ordinal);
    ids.add(call.call_id);
  }
  if (
    data['next_cursor'] !== null &&
    (calls.length === 0 || BigInt(data['next_cursor']) !== previous)
  )
    throw new Error('Invalid CAI next cursor');
  if (
    data['continuation_allowed'] &&
    (data['dialogue_status'] === 'pending' ||
      calls.some(
        (call) =>
          call.state !== 'not_dispatched' &&
          (call.state !== 'resolved' ||
            (call.outcome_kind !== 'mcp_result' &&
              call.outcome_kind !== 'not_admitted')),
      ))
  )
    throw new Error('Contradictory CAI continuation gate');
  let turn: CaiAttemptPage['turn'] = null;
  if (data['dialogue_status'] === 'completed') {
    const receipt = data['turn'];
    if (
      !record(receipt) ||
      receipt['request_id'] !== requestId ||
      !integer(receipt['version']) ||
      receipt['version'] <= data['input_version'] ||
      receipt['version'] > session.version ||
      !text(receipt['message'], 32000)
    )
      throw new Error('Invalid CAI completed receipt');
    turn = {
      requestId,
      version: receipt['version'],
      message: receipt['message'],
    };
  } else if (data['turn'] !== null)
    throw new Error('Unexpected CAI completed receipt');
  return immutable({
    requestId,
    inputVersion: data['input_version'],
    bindingGeneration: data['binding_generation'],
    session,
    dialogueStatus: data['dialogue_status'],
    continuationAllowed: data['continuation_allowed'],
    turn,
    calls,
    nextCursor: data['next_cursor'],
  });
}
export function decodeCall(
  body: Json,
  requestId: string,
  callId: string,
): CaiCallDetail {
  if (
    !record(body) ||
    !record(body['data']) ||
    body['data']['request_id'] !== requestId ||
    !record(body['data']['call'])
  )
    throw new Error('Invalid CAI call envelope');
  const call = body['data']['call'];
  const decoded = summary(call);
  const args = call['arguments'],
    result = call['result'],
    admission = call['admission'];
  if (
    decoded.call_id !== callId ||
    !record(args) ||
    !receiptJson(args) ||
    !(result === null || (record(result) && receiptJson(result))) ||
    !(admission === null || (record(admission) && receiptJson(admission))) ||
    (result !== null && !CallToolResultSchema.safeParse(result).success) ||
    (decoded.outcome_kind === 'mcp_result' &&
      (result === null || admission !== null)) ||
    (decoded.outcome_kind === 'not_admitted' &&
      (result !== null ||
        admission === null ||
        admission['admitted'] !== false)) ||
    ((decoded.outcome_kind === null ||
      decoded.outcome_kind === 'transport_error') &&
      (result !== null || admission !== null)) ||
    (decoded.state === 'resolved' &&
      !(
        (decoded.outcome_kind === 'mcp_result' && result !== null) ||
        (decoded.outcome_kind === 'not_admitted' &&
          admission !== null &&
          admission['admitted'] === false)
      ))
  )
    throw new Error('Invalid CAI call correlation or retained evidence');
  return immutable({ ...decoded, arguments: args, result, admission });
}
