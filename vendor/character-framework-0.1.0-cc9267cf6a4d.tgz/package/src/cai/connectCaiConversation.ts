import { immutable } from '../json.js';
import { CaiConversation } from './CaiConversation.js';
import { isSave, isSession } from './validation.js';
import type { CaiBindingPublication } from './CaiBindingPublication.js';
import type { CaiBackend, CaiConversationSave } from './types.js';

/** Trusted bootstrap after publication. Never refresh an uncertain conversation. */
export async function connectCaiConversation(options: {
  readonly backend: CaiBackend;
  readonly publication: CaiBindingPublication;
  readonly generation: string;
  readonly saved: CaiConversationSave;
  readonly signal: AbortSignal;
  readonly current: () => void;
  readonly persist: (state: CaiConversationSave) => void | Promise<void>;
}): Promise<CaiConversation> {
  const saved = immutable(options.saved);
  if (!isSave(saved) || saved.pending !== null)
    throw new Error('Connection requires a settled conversation checkpoint');
  const assertReady = () => {
    options.signal.throwIfAborted();
    options.current();
    const publication = options.publication.save();
    if (
      options.publication.status.active ||
      publication.pending !== null ||
      publication.sessionId !== saved.session.id ||
      publication.bindingKey !== saved.session.bindingKey ||
      publication.acceptedGeneration !== options.generation
    )
      throw new Error('Connection requires the current settled publication');
  };
  assertReady();
  const session = await options.backend.attach(
    {
      characterId: saved.session.characterId,
      bindingKey: saved.session.bindingKey,
      sessionId: saved.session.id,
    },
    options.signal,
  );
  assertReady();
  if (
    !isSession(session) ||
    session.id !== saved.session.id ||
    session.characterId !== saved.session.characterId ||
    session.bindingKey !== saved.session.bindingKey ||
    session.bindingGeneration !== options.generation ||
    session.version !== saved.session.version
  )
    throw new Error('CAI did not confirm the settled host session');
  const confirmed = immutable({ ...saved, session });
  await options.persist(confirmed);
  assertReady();
  return new CaiConversation(
    options.backend,
    confirmed,
    assertReady,
    options.persist,
  );
}
