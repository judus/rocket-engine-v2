import type { Json } from './types.js';

export function isJson(
  value: unknown,
  ancestors = new Set<unknown>(),
): value is Json {
  if (value === null || typeof value === 'string' || typeof value === 'boolean')
    return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (typeof value !== 'object' || ancestors.has(value) || ancestors.size >= 32)
    return false;
  if (
    !Array.isArray(value) &&
    Object.getPrototypeOf(value) !== Object.prototype
  )
    return false;
  ancestors.add(value);
  const valid = Object.values(value).every((item: unknown) =>
    isJson(item, ancestors),
  );
  ancestors.delete(value);
  return valid;
}

/** Detached and deeply frozen data prevents providers and callers from sharing mutable state. */
export function immutable<T>(value: T): T {
  const copy: T = structuredClone(value);
  const freeze = (item: unknown): void => {
    if (item !== null && typeof item === 'object') {
      for (const child of Object.values(item)) freeze(child);
      Object.freeze(item);
    }
  };
  freeze(copy);
  return copy;
}
