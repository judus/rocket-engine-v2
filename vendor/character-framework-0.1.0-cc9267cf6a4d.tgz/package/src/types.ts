import type { NarrativeGame } from './narrative/types.js';

export type Json =
  null | boolean | number | string | Json[] | { [key: string]: Json };

export interface CaiBinding {
  readonly characterId: string;
  readonly sessionId: string;
}
export interface CharacterBinding {
  readonly id: string;
  readonly generation: string;
}

export interface CharacterDefinition {
  readonly id: string;
  readonly name: string;
  readonly entityId?: string;
  readonly cai?: CaiBinding;
  readonly capabilities: readonly string[];
  /** Host may explicitly restore an identity; runtime always issues a fresh generation. */
  readonly binding?: CharacterBinding;
}

/** Opaque gateway-scoped mutation identity; never accepted from tool arguments. */
export interface MutationIdentity {
  readonly id: string;
}

export interface Invocation {
  readonly gameId: string;
  readonly character: CharacterDefinition;
  readonly requestId: string;
  /** Present only for trusted MCP mutation execution; absent for inspections/local work. */
  readonly mutation?: MutationIdentity;
  readonly time: number;
  readonly signal: AbortSignal;
}

export interface Decision {
  readonly dialogue: string;
  readonly intention?: {
    readonly kind: string;
    readonly args: Json;
  };
}

export interface ReasoningProvider {
  decide(context: Invocation, observation: Json): Decision | Promise<Decision>;
}

export type CapabilityResult =
  | { readonly status: 'completed'; readonly data: Json }
  | { readonly status: 'running'; readonly operationId: string }
  | {
      readonly status: 'rejected';
      readonly code: string;
      readonly message: string;
    };

export interface Capability {
  readonly name: string;
  readonly description: string;
  readonly kind: 'inspection' | 'action';
  /** JSON Schema description for future discovery. validate is the current admission guard. */
  readonly inputSchema: Json;
  validate(input: Json): boolean;
  execute(
    context: Invocation,
    input: Json,
  ): CapabilityResult | Promise<CapabilityResult>;
}

export type Admission =
  | { readonly status: 'accepted'; readonly requestId: string }
  | {
      readonly status: 'rejected';
      readonly code: string;
      readonly message: string;
    };

export interface CharacterSnapshot extends CharacterDefinition {
  readonly binding: CharacterBinding;
  readonly pendingDecision: string | null;
  readonly pendingCapability: string | null;
  readonly lastDecision: Decision | null;
  readonly lastCapabilityResult: CapabilityResult | null;
}

export interface RuntimeEvent {
  readonly kind: 'decision' | 'capability' | 'failed' | 'cancelled';
  readonly characterId: string;
  readonly requestId: string;
  readonly data: Json;
}

export interface RuntimeOptions {
  readonly gameId: string;
  readonly reasoning: ReasoningProvider;
  readonly capabilities?: readonly Capability[];
  readonly maxConcurrent?: number;
  readonly maxPending?: number;
  readonly maxEvents?: number;
  readonly narrativeGame?: NarrativeGame;
}
