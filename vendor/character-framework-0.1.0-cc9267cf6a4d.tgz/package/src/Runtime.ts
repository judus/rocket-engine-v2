import { immutable, isJson } from './json.js';
import { NarrativeSystem } from './narrative/NarrativeSystem.js';
import type {
  Admission,
  Capability,
  CapabilityResult,
  CharacterDefinition,
  CharacterSnapshot,
  Decision,
  Invocation,
  Json,
  RuntimeEvent,
  RuntimeOptions,
} from './types.js';

interface Entry {
  readonly definition: CharacterDefinition & {
    readonly binding: NonNullable<CharacterDefinition['binding']>;
  };
  pendingDecision: string | null;
  pendingCapability: string | null;
  lastDecision: Decision | null;
  lastCapabilityResult: CapabilityResult | null;
}
interface Job {
  readonly id: string;
  readonly entry: Entry;
  readonly kind: 'decision' | 'capability';
  readonly input: Json;
  readonly capability?: Capability;
  readonly controller: AbortController;
  started: boolean;
  cancelled: boolean;
}
interface Completion {
  readonly job: Job;
  readonly result: unknown;
  readonly failed: boolean;
}
const rejected = (code: string, message: string): Admission => ({
  status: 'rejected',
  code,
  message,
});
const positiveInteger = (value: number, name: string): number => {
  if (!Number.isSafeInteger(value) || value < 1)
    throw new TypeError(`${name} must be a positive integer`);
  return value;
};
const nonempty = (value: unknown): value is string =>
  typeof value === 'string' && value.trim().length > 0;

function validDecision(value: unknown): value is Decision {
  if (
    !isJson(value) ||
    value === null ||
    Array.isArray(value) ||
    typeof value !== 'object'
  )
    return false;
  if (typeof value['dialogue'] !== 'string') return false;
  const intention = value['intention'];
  return (
    intention === undefined ||
    (intention !== null &&
      typeof intention === 'object' &&
      !Array.isArray(intention) &&
      nonempty(intention['kind']) &&
      intention['args'] !== undefined)
  );
}
function validResult(value: unknown): value is CapabilityResult {
  if (
    !isJson(value) ||
    value === null ||
    Array.isArray(value) ||
    typeof value !== 'object'
  )
    return false;
  const status = value['status'];
  if (typeof status !== 'string') return false;
  switch (status) {
    case 'completed':
      return value['data'] !== undefined;
    case 'running':
      return nonempty(value['operationId']);
    case 'rejected':
      return nonempty(value['code']) && typeof value['message'] === 'string';
    default:
      return false;
  }
}

/** One game-owned runtime. Async work only publishes state during host advance(). */
export class CharacterRuntime {
  readonly narrative: NarrativeSystem | undefined;
  readonly #gameId: string;
  readonly #reasoning: RuntimeOptions['reasoning'];
  readonly #maxConcurrent: number;
  readonly #maxPending: number;
  readonly #maxEvents: number;
  readonly #characters = new Map<string, Entry>();
  readonly #capabilities = new Map<string, Capability>();
  readonly #jobs = new Map<string, Job>();
  #inbox: Completion[] = [];
  #events: RuntimeEvent[] = [];
  #active = 0;
  #sequence = 0;
  #time = 0;
  #disposed = false;
  #advancing = false;
  #droppedEvents = 0;

  constructor(options: RuntimeOptions) {
    this.narrative = options.narrativeGame
      ? new NarrativeSystem({
          associationId: options.gameId,
          game: options.narrativeGame,
        })
      : undefined;
    if (!nonempty(options.gameId)) throw new TypeError('gameId is required');
    this.#gameId = options.gameId;
    this.#reasoning = options.reasoning;
    this.#maxConcurrent = positiveInteger(
      options.maxConcurrent ?? 4,
      'maxConcurrent',
    );
    this.#maxPending = positiveInteger(options.maxPending ?? 64, 'maxPending');
    this.#maxEvents = positiveInteger(options.maxEvents ?? 128, 'maxEvents');
    for (const capability of options.capabilities ?? []) {
      if (!nonempty(capability.name) || this.#capabilities.has(capability.name))
        throw new TypeError('Capability names must be nonempty and unique');
      if (!isJson(capability.inputSchema))
        throw new TypeError('Capability schema must be JSON');
      this.#capabilities.set(
        capability.name,
        Object.freeze({
          ...capability,
          inputSchema: immutable(capability.inputSchema),
        }),
      );
    }
  }

  get stats() {
    return Object.freeze({
      gameId: this.#gameId,
      time: this.#time,
      characters: this.#characters.size,
      pending: this.#jobs.size,
      active: this.#active,
      disposed: this.#disposed,
      droppedEvents: this.#droppedEvents,
    });
  }

  register(definition: CharacterDefinition): CharacterHandle {
    this.#assertLive();
    if (
      !nonempty(definition.id) ||
      !nonempty(definition.name) ||
      this.#characters.has(definition.id)
    )
      throw new TypeError('Character identity must be nonempty and unique');
    if (definition.entityId !== undefined && !nonempty(definition.entityId))
      throw new TypeError('entityId must be nonempty');
    if (
      definition.cai &&
      (!nonempty(definition.cai.characterId) ||
        !nonempty(definition.cai.sessionId))
    )
      throw new TypeError('CAI binding requires characterId and sessionId');
    if (
      definition.binding &&
      (!nonempty(definition.binding.id) ||
        !nonempty(definition.binding.generation))
    )
      throw new TypeError('Binding identity and generation must be nonempty');
    if (
      definition.binding &&
      [...this.#characters.values()].some(
        (entry) => entry.definition.binding.id === definition.binding?.id,
      )
    )
      throw new TypeError('Binding identity is already registered');
    if (
      definition.cai &&
      [...this.#characters.values()].some(
        (entry) =>
          entry.definition.cai?.sessionId === definition.cai?.sessionId,
      )
    )
      throw new TypeError(
        'CAI session is already attached to a registered character',
      );
    const binding = {
      id: definition.binding?.id ?? crypto.randomUUID(),
      generation: crypto.randomUUID(),
    };
    const grants = new Set(definition.capabilities);
    for (const name of grants)
      if (!this.#capabilities.has(name))
        throw new TypeError(`Unknown capability: ${name}`);
    const entry: Entry = {
      definition: immutable({
        id: definition.id,
        name: definition.name,
        ...(definition.entityId !== undefined
          ? { entityId: definition.entityId }
          : {}),
        ...(definition.cai ? { cai: definition.cai } : {}),
        binding,
        capabilities: [...grants],
      }),
      pendingDecision: null,
      pendingCapability: null,
      lastDecision: null,
      lastCapabilityResult: null,
    };
    this.#characters.set(definition.id, entry);
    return new CharacterHandle(
      () => this.#snapshot(entry),
      (observation) => this.#request(entry, 'decision', observation),
      (name, input) => this.#dispatch(entry, name, input),
      () => this.#remove(entry),
    );
  }

  characters(): readonly CharacterSnapshot[] {
    return [...this.#characters.values()].map((entry) => this.#snapshot(entry));
  }

  /** Discovery is bound to a registered character, not to an ID supplied inside tool arguments. */
  capabilities(characterId: string) {
    this.#assertLive();
    const entry = this.#characters.get(characterId);
    if (!entry) throw new Error('Character is not registered');
    return entry.definition.capabilities.map((name) => {
      const capability = this.#capabilities.get(name);
      if (!capability) throw new Error('Capability disappeared');
      return immutable({
        name,
        description: capability.description,
        kind: capability.kind,
        inputSchema: capability.inputSchema,
      });
    });
  }

  advance(seconds: number): void {
    this.#assertLive();
    if (
      !Number.isFinite(seconds) ||
      seconds < 0 ||
      !Number.isFinite(this.#time + seconds)
    )
      throw new TypeError('advance requires finite nonnegative seconds');
    if (this.#advancing) throw new Error('Reentrant advance is not allowed');
    this.#advancing = true;
    try {
      this.#time += seconds;
      const inbox = this.#inbox;
      this.#inbox = [];
      for (const completion of inbox) this.#commit(completion);
      for (const job of this.#jobs.values()) {
        if (this.#active >= this.#maxConcurrent) break;
        if (job.started || job.cancelled) continue;
        job.started = true;
        this.#active++;
        const context: Invocation = Object.freeze({
          gameId: this.#gameId,
          character: job.entry.definition,
          requestId: job.id,
          time: this.#time,
          signal: job.controller.signal,
        });
        try {
          // Start host commands inside its update boundary. Adapters must queue
          // any later asynchronous world effects into their own host boundary.
          const result =
            job.kind === 'decision'
              ? this.#reasoning.decide(context, job.input)
              : job.capability?.execute(context, job.input);
          void Promise.resolve(result).then(
            (value: unknown) => {
              this.#receive({ job, result: value, failed: false });
            },
            () => {
              this.#receive({ job, result: null, failed: true });
            },
          );
        } catch {
          this.#receive({ job, result: null, failed: true });
        }
      }
      this.narrative?.advance(seconds);
    } finally {
      this.#advancing = false;
    }
  }

  drainEvents(): readonly RuntimeEvent[] {
    const events = this.#events;
    this.#events = [];
    return events;
  }

  dispose(): void {
    if (this.#disposed) return;
    this.#disposed = true;
    this.narrative?.dispose();
    for (const entry of this.#characters.values()) this.#cancel(entry);
    this.#characters.clear();
    this.#jobs.clear();
    this.#inbox = [];
    this.#active = 0;
  }

  #snapshot(entry: Entry): CharacterSnapshot {
    if (!this.#current(entry))
      throw new Error('Character handle is no longer registered');
    return immutable({
      ...entry.definition,
      pendingDecision: entry.pendingDecision,
      pendingCapability: entry.pendingCapability,
      lastDecision: entry.lastDecision,
      lastCapabilityResult: entry.lastCapabilityResult,
    });
  }
  #current(entry: Entry): boolean {
    return (
      !this.#disposed && this.#characters.get(entry.definition.id) === entry
    );
  }
  #assertLive(): void {
    if (this.#disposed) throw new Error('Runtime is disposed');
  }
  #dispatch(entry: Entry, name: string, input: Json): Admission {
    if (!this.#current(entry))
      return rejected(
        'unregistered',
        'Character handle is no longer registered',
      );
    if (!entry.definition.capabilities.includes(name))
      return rejected(
        'unsupported_capability',
        'Capability is not available to this character',
      );
    const capability = this.#capabilities.get(name);
    if (!capability)
      return rejected('unsupported_capability', 'Capability is not installed');
    if (!isJson(input))
      return rejected('invalid_input', 'Input must be finite JSON data');
    const ownedInput = immutable(input);
    try {
      if (!capability.validate(ownedInput))
        return rejected('invalid_input', 'Capability input was rejected');
    } catch {
      return rejected('invalid_input', 'Capability input validation failed');
    }
    return this.#request(entry, 'capability', ownedInput, capability);
  }
  #request(
    entry: Entry,
    kind: Job['kind'],
    input: Json,
    capability?: Capability,
  ): Admission {
    if (!this.#current(entry))
      return rejected(
        'unregistered',
        'Character handle is no longer registered',
      );
    const key = kind === 'decision' ? 'pendingDecision' : 'pendingCapability';
    if (entry[key] !== null)
      return rejected('busy', `A ${kind} request is already pending`);
    if (this.#jobs.size >= this.#maxPending)
      return rejected('queue_full', 'Runtime pending work limit reached');
    if (!isJson(input))
      return rejected('invalid_input', 'Input must be finite JSON data');
    const id = `${this.#gameId}/${String(++this.#sequence)}`;
    const job: Job = {
      id,
      entry,
      kind,
      input: immutable(input),
      controller: new AbortController(),
      started: false,
      cancelled: false,
      ...(capability ? { capability } : {}),
    };
    entry[key] = id;
    this.#jobs.set(id, job);
    return Object.freeze({ status: 'accepted', requestId: id });
  }
  #receive(completion: Completion): void {
    if (this.#disposed) return;
    // Capture at settlement: a provider must not mutate its reply before the host commits it.
    let result: Json = null;
    let failed = completion.failed;
    try {
      if (isJson(completion.result)) result = immutable(completion.result);
    } catch {
      // Adapter objects may have throwing accessors or fail structured cloning.
      // Capture failure must settle the original job and release its capacity.
      failed = true;
    }
    this.#queueCompletion({ ...completion, result, failed });
  }
  #queueCompletion(completion: Completion): void {
    // Capture can invoke adapter accessors that dispose the runtime.
    if (!this.#disposed) this.#inbox.push(completion);
  }
  #commit({ job, result, failed }: Completion): void {
    this.#jobs.delete(job.id);
    this.#active--;
    if (job.cancelled || !this.#current(job.entry)) return;
    if (job.kind === 'decision') job.entry.pendingDecision = null;
    else job.entry.pendingCapability = null;
    if (
      failed ||
      (job.kind === 'decision' ? !validDecision(result) : !validResult(result))
    ) {
      this.#event({
        kind: 'failed',
        characterId: job.entry.definition.id,
        requestId: job.id,
        data: { code: failed ? 'execution_failed' : 'invalid_result' },
      });
    } else if (job.kind === 'decision' && validDecision(result)) {
      job.entry.lastDecision = result;
      this.#event({
        kind: 'decision',
        characterId: job.entry.definition.id,
        requestId: job.id,
        data: {
          dialogue: result.dialogue,
          ...(result.intention ? { intention: { ...result.intention } } : {}),
        },
      });
    } else if (validResult(result)) {
      job.entry.lastCapabilityResult = result;
      this.#event({
        kind: 'capability',
        characterId: job.entry.definition.id,
        requestId: job.id,
        data: { ...result },
      });
    }
  }
  #event(event: RuntimeEvent): void {
    if (this.#events.length === this.#maxEvents) {
      this.#events.shift();
      this.#droppedEvents++;
    }
    this.#events.push(immutable(event));
  }
  #cancel(entry: Entry): void {
    for (const job of this.#jobs.values()) {
      if (job.entry !== entry || job.cancelled) continue;
      job.cancelled = true;
      job.controller.abort();
      if (!job.started) this.#jobs.delete(job.id);
      this.#event({
        kind: 'cancelled',
        characterId: entry.definition.id,
        requestId: job.id,
        data: null,
      });
    }
    entry.pendingDecision = null;
    entry.pendingCapability = null;
  }
  #remove(entry: Entry): boolean {
    if (!this.#current(entry)) return false;
    this.#characters.delete(entry.definition.id);
    this.#cancel(entry);
    return true;
  }
}

/** A handle is bound to one registration lifetime, even when an ID is reused later. */
export class CharacterHandle {
  constructor(
    readonly snapshot: () => CharacterSnapshot,
    readonly requestDecision: (observation: Json) => Admission,
    readonly dispatch: (capability: string, input: Json) => Admission,
    readonly unregister: () => boolean,
  ) {}
}
