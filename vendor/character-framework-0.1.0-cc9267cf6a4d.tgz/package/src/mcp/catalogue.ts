import { Ajv2020 } from 'ajv/dist/2020.js';
import type { ValidateFunction } from 'ajv';
import { ToolSchema } from '@modelcontextprotocol/sdk/types.js';
import type { Tool } from '@modelcontextprotocol/sdk/types.js';
import catalogue from '../../docs/contracts/tools.json' with { type: 'json' };
import { immutable } from '../json.js';
import type { Capability } from '../types.js';

const ajv = new Ajv2020({
  strict: true,
  allErrors: true,
  allowUnionTypes: true,
});
export interface ToolContract {
  readonly tool: Tool;
  readonly input: ValidateFunction;
  readonly output: ValidateFunction | undefined;
}
export const narrativeContracts = new Map<string, ToolContract>(
  catalogue.tools.map((entry) => {
    const tool = ToolSchema.parse({
      ...entry,
      annotations: {
        readOnlyHint:
          entry.name.startsWith('inspect_') ||
          entry.name === 'compose_quest_draft',
        destructiveHint: false,
        idempotentHint:
          entry.name.startsWith('inspect_') ||
          entry.name === 'compose_quest_draft',
        openWorldHint: false,
      },
    });
    return [
      entry.name,
      {
        tool: immutable(tool),
        input: ajv.compile(entry.inputSchema),
        output: ajv.compile(entry.outputSchema),
      },
    ];
  }),
);
export function capabilityContract(capability: Capability): ToolContract {
  const tool = ToolSchema.parse({
    name: capability.name,
    description: capability.description,
    inputSchema: capability.inputSchema,
    annotations: {
      readOnlyHint: capability.kind === 'inspection',
      destructiveHint: capability.kind === 'action',
      idempotentHint: capability.kind === 'inspection',
      openWorldHint: false,
    },
  });
  return {
    tool: immutable(tool),
    input: ajv.compile(tool.inputSchema),
    output: undefined,
  };
}
