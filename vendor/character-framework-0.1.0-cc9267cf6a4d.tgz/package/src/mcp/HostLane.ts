import { McpError, ErrorCode } from '@modelcontextprotocol/sdk/types.js';
import { immutable, isJson } from '../json.js';
import type {
  Capability,
  CapabilityResult,
  CharacterSnapshot,
  Json,
  MutationIdentity,
} from '../types.js';
import { boundedJson, reject, text } from '../narrative/validation.js';

interface Job {
  readonly owner: () => CharacterSnapshot;
  readonly capability: Capability;
  readonly input: Json;
  readonly callId: string;
  readonly mutation?: MutationIdentity;
  readonly controller: AbortController;
  readonly resolve: (result: CapabilityResult) => void;
  readonly fail: (error: Error) => void;
  started: boolean;
}
interface Completion {
  readonly job: Job;
  readonly result: unknown;
  readonly failed: boolean;
}

/** Independent execution capacity: a pending reasoning turn cannot block its own tools. */
export class HostLane {
  readonly #gameId: string;
  readonly #jobs = new Set<Job>();
  #inbox: Completion[] = [];
  #active = 0;
  #time = 0;
  #disposed = false;
  constructor(gameId: string) {
    this.#gameId = gameId;
  }
  call(
    owner: () => CharacterSnapshot,
    capability: Capability,
    input: Json,
    callId: string,
    mutation?: MutationIdentity,
  ): Promise<CapabilityResult> {
    if (this.#disposed)
      return Promise.reject(
        new McpError(ErrorCode.InternalError, 'Tool lane is closed.'),
      );
    if (this.#jobs.size >= 64)
      return Promise.resolve(reject('queue_full', 'Host tool queue is full.'));
    return new Promise((resolve, fail) => {
      this.#jobs.add({
        owner,
        capability,
        input: immutable(input),
        callId,
        ...(mutation ? { mutation: immutable(mutation) } : {}),
        resolve,
        fail,
        controller: new AbortController(),
        started: false,
      });
    });
  }
  advance(seconds: number): void {
    if (this.#disposed) throw new Error('Tool lane is closed');
    if (
      !Number.isFinite(seconds) ||
      seconds < 0 ||
      !Number.isFinite(this.#time + seconds)
    )
      throw new TypeError('Invalid host advancement');
    this.#time += seconds;
    const inbox = this.#inbox;
    this.#inbox = [];
    for (const completion of inbox) {
      this.#jobs.delete(completion.job);
      this.#active--;
      if (completion.failed || !validResult(completion.result)) {
        completion.job.fail(
          new McpError(
            ErrorCode.InternalError,
            'Host tool outcome is unresolved; do not repeat an action with a new effect key.',
          ),
        );
      } else completion.job.resolve(immutable(completion.result));
    }
    for (const job of this.#jobs) {
      let character: CharacterSnapshot;
      try {
        character = job.owner();
      } catch {
        job.controller.abort();
        if (!job.started) {
          this.#jobs.delete(job);
          job.resolve(
            reject(
              'unregistered',
              'Character registration is no longer current.',
            ),
          );
        }
        continue;
      }
      if (job.started || this.#active >= 8) continue;
      job.started = true;
      this.#active++;
      try {
        const result = job.capability.execute(
          {
            gameId: this.#gameId,
            character,
            requestId: job.callId,
            ...(job.mutation ? { mutation: job.mutation } : {}),
            time: this.#time,
            signal: job.controller.signal,
          },
          job.input,
        );
        void Promise.resolve(result).then(
          (value: unknown) => {
            this.#receive(job, value, false);
          },
          () => {
            this.#receive(job, null, true);
          },
        );
      } catch {
        this.#receive(job, null, true);
      }
    }
  }
  get pending(): number {
    return this.#jobs.size;
  }
  dispose(): void {
    if (this.#disposed) return;
    this.#disposed = true;
    for (const job of this.#jobs) {
      job.controller.abort();
      job.fail(
        new McpError(
          ErrorCode.InternalError,
          'Tool lane closed; execution may have occurred.',
        ),
      );
    }
    this.#jobs.clear();
    this.#inbox = [];
  }
  #receive(job: Job, result: unknown, failed: boolean): void {
    if (!this.#disposed)
      this.#inbox.push({
        job,
        result: isJson(result) ? immutable(result) : null,
        failed,
      });
  }
}
export function validResult(value: unknown): value is CapabilityResult {
  if (
    !boundedJson(value) ||
    value === null ||
    typeof value !== 'object' ||
    Array.isArray(value)
  )
    return false;
  if (value['status'] === 'completed') return Object.hasOwn(value, 'data');
  if (value['status'] === 'running') return text(value['operationId']);
  return (
    value['status'] === 'rejected' &&
    text(value['code']) &&
    text(value['message'], 1000)
  );
}
