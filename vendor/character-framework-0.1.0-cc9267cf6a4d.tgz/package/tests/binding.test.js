import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CaiBindingPublication,
  CaiHttpBackend,
  CaiHttpError,
  CaiConversation,
} from '../dist/src/cai/index.js';
import { FakeCaiBackend } from '../dist/examples/fake-cai-backend.js';

const initial = (acceptedGeneration = null) => ({
  schemaVersion: 1,
  sessionId: '81',
  bindingKey: 'forester',
  acceptedGeneration,
  pending: null,
});

test('HTTP game reads preserve nullable binding generation and reject missing or invalid metadata', async () => {
  const wire = {
    id: 81,
    character: { id: 42 },
    binding_key: 'forester',
    binding_generation: null,
    mode: 'game',
    continuity_mode: 'session',
    version: 0,
  };
  let value = wire;
  const backend = new CaiHttpBackend({
    origin: 'http://cai.test',
    token: 'test-only-token',
    enableGameDraft: true,
    fetch: async () => Response.json({ data: value }),
  });
  const read = () =>
    backend.attach(
      { characterId: '42', bindingKey: 'forester', sessionId: '81' },
      new AbortController().signal,
    );
  assert.equal((await read()).bindingGeneration, null);
  value = { ...wire, binding_generation: 'G1' };
  assert.equal((await read()).bindingGeneration, 'G1');
  for (const generation of [undefined, '', 'G\u0085', 'x'.repeat(161)]) {
    value = { ...wire, binding_generation: generation };
    await assert.rejects(read(), /CAI did not confirm/);
  }
});
function fixture() {
  let generation = null;
  let drop = false;
  let responseOverride;
  const calls = [];
  const backend = new CaiHttpBackend({
    origin: 'http://cai.test',
    token: 'test-only-token',
    enableGameDraft: true,
    fetch: async (url, init) => {
      const input = JSON.parse(init.body);
      calls.push({ url, input, init });
      if (
        input.binding_key !== 'forester' ||
        (generation !== input.binding_generation &&
          generation !== input.expected_binding_generation)
      )
        return Response.json(
          { error: { code: 'binding_conflict' } },
          { status: 409 },
        );
      generation = input.binding_generation;
      if (drop) {
        drop = false;
        throw new Error('Lost response');
      }
      return Response.json({
        data: responseOverride ?? {
          session_id: 81,
          binding_key: 'forester',
          binding_generation: generation,
          version: 17,
        },
      });
    },
  });
  return {
    backend,
    calls,
    generation: () => generation,
    dropNext: () => {
      drop = true;
    },
    override: (value) => {
      responseOverride = value;
    },
  };
}

test('binding HTTP publication uses exact PUT metadata and keeps conversation version informational', async () => {
  const f = fixture();
  const stored = [];
  const journal = new CaiBindingPublication(f.backend, initial(), (state) => {
    stored.push(state);
  });
  await journal.publish('G1');
  assert.equal(
    f.calls[0].url,
    'http://cai.test/api/v1/companion/sessions/81/mcp-binding',
  );
  assert.equal(f.calls[0].init.method, 'PUT');
  assert.equal(f.calls[0].init.redirect, 'error');
  assert.deepEqual(f.calls[0].input, {
    binding_key: 'forester',
    binding_generation: 'G1',
    expected_binding_generation: null,
  });
  assert.equal(stored[0].pending.binding_generation, 'G1');
  assert.equal(stored[1].pending, null);
  assert.equal(journal.status.acceptedGeneration, 'G1');
  assert.ok(!Object.hasOwn(journal.save(), 'version'));
  await journal.publish('G1');
  await journal.publish('G2');
  assert.equal(f.calls[2].input.expected_binding_generation, 'G1');
});

test('lost binding response restores exact pending publication before a fresh generation', async () => {
  const f = fixture();
  const journal = new CaiBindingPublication(f.backend, initial());
  await journal.publish('G1');
  f.dropNext();
  await assert.rejects(journal.publish('G2'), /Lost/);
  assert.equal(f.generation(), 'G2');
  assert.equal(journal.status.acceptedGeneration, 'G1');
  await assert.rejects(journal.publish('G3'), /Reconcile/);
  const restored = new CaiBindingPublication(
    f.backend,
    JSON.parse(JSON.stringify(journal.save())),
  );
  await restored.retry();
  assert.deepEqual(f.calls[1].input, f.calls[2].input);
  await restored.publish('G3');
  assert.equal(f.calls[3].input.expected_binding_generation, 'G2');
  assert.equal(f.generation(), 'G3');
});

test('binding acknowledgment storage failure and competing CAS writer retain the original request', async () => {
  const f = fixture();
  const journal = new CaiBindingPublication(f.backend, initial(), (state) => {
    if (!state.pending) throw new Error('Storage failed');
  });
  await assert.rejects(journal.publish('G1'), /Storage/);
  assert.equal(journal.status.acceptedGeneration, null);
  assert.ok(journal.status.pending);
  const restored = new CaiBindingPublication(f.backend, journal.save());
  await restored.retry();
  await f.backend.publishBinding(
    '81',
    {
      binding_key: 'forester',
      binding_generation: 'other-writer',
      expected_binding_generation: 'G1',
    },
    new AbortController().signal,
  );
  await assert.rejects(
    restored.publish('G2'),
    (error) => error instanceof CaiHttpError && error.status === 409,
  );
  assert.equal(restored.save().pending.expected_binding_generation, 'G1');
  assert.equal(f.generation(), 'other-writer');
});

test('invalid binding receipt or checkpoint cannot fabricate a published generation', async () => {
  const f = fixture();
  f.override({
    session_id: '81',
    binding_key: 'forester',
    binding_generation: 'G1',
    version: 0,
  });
  const journal = new CaiBindingPublication(f.backend, initial());
  await assert.rejects(journal.publish('G1'), /Invalid binding receipt/);
  assert.equal(journal.status.acceptedGeneration, null);
  assert.ok(journal.status.pending);
  for (const state of [
    { ...initial(), bindingKey: 'bad\nkey' },
    { ...initial(), acceptedGeneration: '' },
    {
      ...initial('G1'),
      pending: {
        binding_key: 'forester',
        binding_generation: 'G2',
        expected_binding_generation: null,
      },
    },
  ])
    assert.throws(
      () => new CaiBindingPublication(f.backend, state),
      /Invalid binding checkpoint/,
    );
  await assert.rejects(
    f.backend.publishBinding(
      '81',
      {
        binding_key: 'forester',
        binding_generation: 'G\u0085',
        expected_binding_generation: null,
      },
      new AbortController().signal,
    ),
    /selectors/,
  );
});

test('binding persistence precedes HTTP and disposal ignores a late acknowledgment', async () => {
  const f = fixture();
  const journal = new CaiBindingPublication(f.backend, initial(), () => {
    throw new Error('Disk unavailable');
  });
  await assert.rejects(journal.publish('G1'), /Disk/);
  assert.equal(f.calls.length, 0);
  let resolve;
  const pending = new Promise((r) => {
    resolve = r;
  });
  const slow = new CaiBindingPublication(
    { publishBinding: () => pending },
    initial(),
  );
  const request = slow.publish('G1');
  await new Promise((r) => setImmediate(r));
  await assert.rejects(slow.publish('G2'), /active/);
  slow.dispose();
  resolve({
    sessionId: '81',
    bindingKey: 'forester',
    generation: 'G1',
    version: 0,
  });
  await assert.rejects(request, /disposed/);
  assert.equal(slow.status.acceptedGeneration, null);
  assert.ok(slow.save().pending);
});

test('typed feedback rejects CAI-delivered type and reference-key limits before dispatch', async () => {
  const conversation = await CaiConversation.attach(
    new FakeCaiBackend(async () => {}),
    { characterId: 'demo-profile-1', bindingKey: 'forester' },
    new AbortController().signal,
  );
  const feedback = {
    sourceId: 'event-1',
    origin: 'framework_narrative',
    type: 'x'.repeat(80),
    summary: 'Done',
    references: { ['k'.repeat(80)]: 'value' },
  };
  conversation.enqueueFeedback(feedback);
  assert.throws(
    () =>
      conversation.enqueueFeedback({
        ...feedback,
        sourceId: 'event-2',
        type: 'x'.repeat(81),
      }),
    /feedback/,
  );
  assert.throws(
    () =>
      conversation.enqueueFeedback({
        ...feedback,
        sourceId: 'event-3',
        references: { ['k'.repeat(81)]: 'value' },
      }),
    /feedback/,
  );
  assert.equal(conversation.status.queuedFeedback, 1);
});

test('feedback enqueue and restored checkpoints reject invalid wire strings without normalizing valid text', async () => {
  const backend = new FakeCaiBackend(async () => {});
  const conversation = await CaiConversation.attach(
    backend,
    { characterId: 'demo-profile-1', bindingKey: 'forester' },
    new AbortController().signal,
  );
  const base = {
    sourceId: ' source ',
    origin: 'framework_narrative',
    type: ' quest_completed ',
    summary: ' Done\nwith work. ',
    references: { ' quest_id ': ' quest-1 ' },
  };
  const bad = [
    { ...base, sourceId: 'source\u0085' },
    { ...base, type: 'quest\u0000' },
    { ...base, references: { 'key\n': 'value' } },
    { ...base, references: { key: 'value\u007f' } },
    { ...base, summary: ' \t\n ' },
    { ...base, type: '   ' },
    { ...base, references: { '   ': 'value' } },
    { ...base, references: { key: '   ' } },
    { ...base, sourceId: '   ' },
  ];
  for (const input of bad) {
    assert.throws(() => conversation.enqueueFeedback(input), /feedback/);
    assert.equal(conversation.status.queuedFeedback, 0);
    const checkpoint = structuredClone(conversation.save());
    checkpoint.feedback = [input];
    assert.throws(() => new CaiConversation(backend, checkpoint), /checkpoint/);
  }
  conversation.enqueueFeedback(base);
  const stored = conversation.save().feedback[0];
  assert.equal(stored.type, base.type);
  assert.equal(stored.summary, base.summary);
  assert.equal(stored.references[' quest_id '], ' quest-1 ');
  assert.equal(stored.references.source_event_id, ' source ');
  await conversation.flushFeedback();
  assert.equal(conversation.status.queuedFeedback, 0);
});

test('binding selectors reject blank strings before persistence and preserve valid surrounding spaces', async () => {
  const f = fixture();
  let saves = 0;
  const journal = new CaiBindingPublication(f.backend, initial(), () => {
    saves++;
  });
  for (const generation of ['   ', '\t', '\u0085']) {
    await assert.rejects(
      journal.publish(generation),
      /Invalid binding generation/,
    );
    assert.equal(journal.status.pending, false);
    assert.throws(
      () =>
        new CaiBindingPublication(f.backend, {
          ...initial(),
          acceptedGeneration: generation,
        }),
      /checkpoint/,
    );
    await assert.rejects(
      f.backend.publishBinding(
        '81',
        {
          binding_key: 'forester',
          binding_generation: generation,
          expected_binding_generation: null,
        },
        new AbortController().signal,
      ),
      /selectors/,
    );
  }
  assert.equal(saves, 0);
  assert.equal(f.calls.length, 0);
  await journal.publish(' G1 ');
  assert.equal(journal.status.acceptedGeneration, ' G1 ');
  assert.equal(f.calls[0].input.binding_generation, ' G1 ');
});
