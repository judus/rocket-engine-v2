import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CaiBindingPublication,
  connectCaiConversation,
} from '../dist/src/cai/index.js';

function fixture() {
  const session = {
    id: '81',
    characterId: '42',
    bindingKey: 'forester',
    version: 0,
    mode: 'game',
    continuityMode: 'session',
    bindingGeneration: null,
  };
  const saved = {
    schemaVersion: 1,
    session,
    pending: null,
    feedback: [],
    reported: [],
  };
  const calls = [];
  const backend = {
    attach: async (input) => {
      calls.push(['read', input]);
      return { ...session, bindingGeneration: 'G1' };
    },
    publishBinding: async () => {
      throw new Error('No publication in confirmation');
    },
    turn: async (_, input) => {
      calls.push(['turn', input]);
      return {
        requestId: input.request_id,
        message: 'Hello',
        session: { ...session, version: 1, bindingGeneration: 'G1' },
      };
    },
  };
  const publication = new CaiBindingPublication(backend, {
    schemaVersion: 1,
    sessionId: '81',
    bindingKey: 'forester',
    acceptedGeneration: 'G1',
    pending: null,
  });
  const options = {
    backend,
    publication,
    generation: 'G1',
    saved,
    signal: new AbortController().signal,
    current: () => undefined,
    persist: async (state) => {
      calls.push(['save', state]);
    },
  };
  return { options, calls, backend };
}
test('host connection confirms original identity/generation and persists before exposing dialogue', async () => {
  const f = fixture();
  const conversation = await connectCaiConversation(f.options);
  assert.deepEqual(f.calls[0], [
    'read',
    { characterId: '42', bindingKey: 'forester', sessionId: '81' },
  ]);
  assert.equal(f.calls[1][1].session.bindingGeneration, 'G1');
  assert.equal(f.options.saved.session.bindingGeneration, null);
  assert.equal(await conversation.dialogue('Hello'), 'Hello');
  assert.equal(f.calls[2][0], 'save');
  assert.equal(f.calls[3][0], 'turn');
});
test('connection rejects pending work and foreign or changed session state without dispatch', async () => {
  const f = fixture();
  f.options.saved.pending = {
    kind: 'turn',
    input: {
      request_id: '00000000-0000-4000-8000-000000000001',
      version: 0,
      origin: 'player_dialogue',
      message: 'Hello',
    },
  };
  await assert.rejects(
    connectCaiConversation(f.options),
    /settled conversation/,
  );
  assert.equal(f.calls.length, 0);
  f.options.saved.pending = null;
  for (const override of [
    { id: '82' },
    { bindingGeneration: 'G2' },
    { version: 1 },
  ]) {
    f.backend.attach = async () => ({
      ...f.options.saved.session,
      bindingGeneration: 'G1',
      ...override,
    });
    await assert.rejects(connectCaiConversation(f.options), /did not confirm/);
  }
  assert.equal(f.calls.length, 0);
});
test('failed storage or retired registration prevents a connected conversation', async () => {
  const f = fixture();
  f.options.persist = async () => {
    throw new Error('storage unavailable');
  };
  await assert.rejects(
    connectCaiConversation(f.options),
    /storage unavailable/,
  );
  let live = true;
  f.options.current = () => {
    if (!live) throw new Error('retired');
  };
  f.options.persist = async () => {
    live = false;
  };
  await assert.rejects(connectCaiConversation(f.options), /retired/);
});
