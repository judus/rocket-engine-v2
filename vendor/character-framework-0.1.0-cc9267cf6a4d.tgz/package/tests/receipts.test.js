import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { CaiHttpBackend, CaiHttpError } from '../dist/src/cai/index.js';

// Snapshot of CAI's checked HTTP fixture, delivered in mailbox message 68.
const wire = JSON.parse(
  readFileSync(
    new URL('./fixtures/cai-receipts.json', import.meta.url),
    'utf8',
  ),
);
const session = {
  id: '1001',
  characterId: '1002',
  bindingKey: 'forester/mara',
  version: 0,
  mode: 'game',
  continuityMode: 'session',
  bindingGeneration: 'generation-1',
};
const requestId = wire.attempt.data.request_id;
const callId = wire.call.data.call.call_id;
const signal = new AbortController().signal;
function fixture(initial = wire.attempt) {
  let body = structuredClone(initial);
  const requests = [];
  const backend = new CaiHttpBackend({
    origin: 'http://cai.test',
    token: 'fixture-only-token',
    enableGameDraft: true,
    fetch: async (url, init) => {
      requests.push({ url, init });
      return body instanceof Response ? body : Response.json(body);
    },
  });
  return {
    backend,
    requests,
    set: (value) => {
      body = value;
    },
    read: (cursor) => backend.readAttempt(session, requestId, signal, cursor),
    detail: () => backend.readCall(session.id, requestId, callId, signal),
  };
}

test('checked CAI receipt fixtures preserve original/current generations and canonical objects', async () => {
  const f = fixture();
  const attempt = await f.read();
  assert.equal(attempt.inputVersion, 0);
  assert.equal(attempt.bindingGeneration, 'generation-1');
  assert.equal(attempt.session.bindingGeneration, 'generation-2');
  assert.equal(attempt.session.version, 2);
  assert.equal(attempt.continuationAllowed, false);
  assert.equal(attempt.calls[0].state, 'unknown');
  f.set(wire.call);
  const detail = await f.detail();
  assert.deepEqual(detail.arguments, { empty: {}, array: [] });
  assert.equal(detail.result, null);
  assert.equal(detail.admission, null);
  assert.ok(Object.isFrozen(detail.arguments));
  assert.equal(
    f.requests[0].url,
    `http://cai.test/api/v1/companion/sessions/1001/turn-attempts/${requestId}`,
  );
  assert.equal(f.requests[1].url, `${f.requests[0].url}/calls/${callId}`);
  for (const { init } of f.requests) {
    assert.equal(init.method, 'GET');
    assert.equal(init.body, undefined);
    assert.equal(init.redirect, 'error');
    assert.equal(init.signal, signal);
    assert.equal(init.headers.Authorization, 'Bearer fixture-only-token');
  }
  assert.equal(session.version, 0);
});

test('attempt reads page by ordinal, enforce correlation and never infer continuation', async () => {
  const f = fixture();
  const body = structuredClone(wire.attempt);
  body.data.calls[0].ordinal = 2;
  body.data.next_cursor = '2';
  f.set(body);
  const page = await f.read('1');
  assert.equal(page.nextCursor, '2');
  assert.equal(page.continuationAllowed, false);
  assert.ok(f.requests.at(-1).url.endsWith('?cursor=1'));
  for (const mutate of [
    (b) => {
      b.data.request_id = 'different';
    },
    (b) => {
      b.data.session.character.id = 9;
    },
    (b) => {
      b.data.session.binding_key = 'other';
    },
    (b) => {
      b.data.session.id = 9;
    },
    (b) => {
      b.data.next_cursor = '3';
    },
    (b) => {
      b.data.calls.push(b.data.calls[0]);
    },
    (b) => {
      b.data.calls[0].binding_generation = 'generation-2';
    },
    (b) => {
      b.data.continuation_allowed = true;
    },
  ]) {
    const invalid = structuredClone(body);
    mutate(invalid);
    f.set(invalid);
    await assert.rejects(f.read('1'));
  }
  for (const cursor of [
    '',
    '0',
    '-1',
    '1&other=1',
    '01',
    '9007199254740992',
    '9'.repeat(1000),
  ])
    await assert.rejects(f.read(cursor), TypeError);
  const empty = structuredClone(wire.attempt);
  empty.data.calls = [];
  f.set(empty);
  assert.equal((await f.read()).continuationAllowed, false);
});

test('completed receipt version remains distinct from current session; malformed completion fails', async () => {
  const f = fixture();
  const body = structuredClone(wire.attempt);
  body.data.calls = [];
  body.data.dialogue_status = 'completed';
  body.data.continuation_allowed = true;
  body.data.turn = { request_id: requestId, version: 1, message: 'Done.' };
  f.set(body);
  const page = await f.read();
  assert.equal(page.turn.version, 1);
  assert.equal(page.session.version, 2);
  for (const receipt of [
    null,
    { ...body.data.turn, version: 0 },
    { ...body.data.turn, version: 3 },
    { ...body.data.turn, request_id: 'other' },
  ]) {
    f.set({ data: { ...body.data, turn: receipt } });
    await assert.rejects(f.read());
  }
  body.data.dialogue_status = 'pending';
  f.set(body);
  await assert.rejects(f.read());
});

test('resolved detail preserves raw MCP rejection/meta and requires retained outcome evidence', async () => {
  const body = structuredClone(wire.call);
  const call = body.data.call;
  call.state = 'resolved';
  call.outcome_kind = 'mcp_result';
  call.result = {
    content: [{ type: 'text', text: 'Rejected' }],
    structuredContent: { accepted: false, empty: {} },
    isError: true,
    _meta: { custom: [] },
  };
  const f = fixture(body);
  const detail = await f.detail();
  assert.deepEqual(detail.result, call.result);
  call.result = null;
  f.set(body);
  await assert.rejects(f.detail());
  call.outcome_kind = 'not_admitted';
  call.admission = { admitted: false, code: 'receipt_limit' };
  f.set(body);
  assert.deepEqual((await f.detail()).admission, call.admission);
  call.admission.admitted = true;
  f.set(body);
  await assert.rejects(f.detail());
  for (const mutate of [
    (b) => {
      b.data.request_id = 'other';
    },
    (b) => {
      b.data.call.call_id = 'other';
    },
    (b) => {
      b.data.call.arguments = [];
    },
    (b) => {
      b.data.call.result = [];
    },
  ]) {
    const invalid = structuredClone(wire.call);
    mutate(invalid);
    f.set(invalid);
    await assert.rejects(f.detail());
  }
});
function padded(body, size, character = 'x') {
  const copy = structuredClone(body);
  copy.padding = '';
  const bytes = Buffer.byteLength(JSON.stringify(copy));
  copy.padding = character.repeat(
    Math.floor((size - bytes) / Buffer.byteLength(character)),
  );
  return copy;
}
function nested(containers) {
  let value = 'leaf';
  for (let n = 0; n < containers; n++) value = { value };
  return value;
}

test('receipt reads enforce separate UTF-8 byte caps; ordinary responses retain 64KiB limit', async () => {
  const f = fixture(padded(wire.attempt, 65536));
  assert.equal((await f.read()).requestId, requestId);
  f.set(padded(wire.attempt, 65537));
  await assert.rejects(f.read(), /response limit/);
  f.set(padded(wire.call, 524288));
  assert.equal((await f.detail()).call_id, callId);
  f.set(padded(wire.call, 524289));
  await assert.rejects(f.detail(), /response limit/);
  const unicode = padded(wire.attempt, 65536, '🌲');
  unicode.padding += '🌲';
  f.set(unicode);
  await assert.rejects(f.read(), /response limit/);
  f.set(padded({ data: wire.attempt.data.session }, 65537));
  await assert.rejects(
    f.backend.attach(
      {
        characterId: session.characterId,
        bindingKey: session.bindingKey,
        sessionId: session.id,
      },
      signal,
    ),
    /response limit/,
  );
});

test('receipt wrappers accept 40 containers, reject 41, and preserve 32-container raw tool data', async () => {
  const f = fixture();
  const body = structuredClone(wire.call);
  body.data.call.state = 'resolved';
  body.data.call.outcome_kind = 'mcp_result';
  body.data.call.result = {
    content: [{ type: 'text', text: 'x'.repeat(63000) }],
    structuredContent: { nested: nested(32), text: 'x'.repeat(63000) },
  };
  f.set(body);
  assert.deepEqual((await f.detail()).result, body.data.call.result);
  body.padding = nested(39);
  f.set(body);
  await f.detail();
  body.padding = nested(40);
  f.set(body);
  await assert.rejects(f.detail(), /bounded CAI JSON/);
  const ordinary = { data: wire.attempt.data.session, padding: nested(32) };
  f.set(ordinary);
  await assert.rejects(
    f.backend.attach(
      {
        characterId: session.characterId,
        bindingKey: session.bindingKey,
        sessionId: session.id,
      },
      signal,
    ),
    /bounded CAI JSON/,
  );
});

test('UTF-8 streaming handles split multibyte characters and rejects invalid encoding', async () => {
  const body = structuredClone(wire.attempt);
  body.data.calls = [];
  body.data.dialogue_status = 'completed';
  body.data.turn = { request_id: requestId, version: 1, message: '🌲' };
  const bytes = new TextEncoder().encode(JSON.stringify(body));
  const split = bytes.indexOf(0xf0) + 1;
  const f = fixture();
  f.set(
    new Response(
      new ReadableStream({
        start(controller) {
          controller.enqueue(bytes.slice(0, split));
          controller.enqueue(bytes.slice(split));
          controller.close();
        },
      }),
    ),
  );
  assert.equal((await f.read()).turn.message, '🌲');
  f.set(new Response(new Uint8Array([0xff])));
  await assert.rejects(f.read());
});

test('HTTP denial, missing receipt and receipt_limit remain errors with no write or invented result', async () => {
  const f = fixture();
  for (const status of [401, 403, 404, 422, 503]) {
    f.set(
      Response.json(
        { error: { code: 'receipt_limit', secret: 'must not appear' } },
        { status },
      ),
    );
    await assert.rejects(
      f.read(),
      (e) =>
        e instanceof CaiHttpError &&
        e.status === status &&
        !e.message.includes('secret'),
    );
  }
  assert.ok(f.requests.every(({ init }) => init.method === 'GET'));
});

test('journaled mutations retain effect identity in summaries and details', async () => {
  const f = fixture();
  const body = structuredClone(wire.attempt);
  body.data.calls[0].effect_key = null;
  f.set(body);
  await assert.rejects(f.read(), /call summary/);
  const detail = structuredClone(wire.call);
  detail.data.call.effect_key = null;
  detail.data.call.state = 'resolved';
  detail.data.call.outcome_kind = 'mcp_result';
  detail.data.call.result = { content: [] };
  f.set(detail);
  await assert.rejects(f.detail(), /call summary/);
  detail.data.call.mutation = false;
  f.set(detail);
  assert.equal((await f.detail()).effect_key, null);
});

test('MCP result evidence validates the base envelope without rewriting unknown fields', async () => {
  const f = fixture();
  const body = structuredClone(wire.call);
  const call = body.data.call;
  call.state = 'resolved';
  call.outcome_kind = 'mcp_result';
  for (const result of [
    { content: 'invalid' },
    { content: null },
    { content: [{ type: 'text' }] },
    { content: [], isError: 'true' },
    { content: [], structuredContent: [] },
    { content: [], _meta: [] },
  ]) {
    call.result = result;
    f.set(body);
    await assert.rejects(f.detail(), /retained evidence/);
  }
  call.result = {};
  f.set(body);
  assert.deepEqual((await f.detail()).result, {}); // SDK defaults omitted content; preserve raw wire.
  call.result = {
    content: [{ type: 'text', text: '', custom: {} }],
    isError: true,
    structuredContent: { quest: 'not interpreted' },
    _meta: { vendor: [] },
    extension: { opaque: {} },
  };
  f.set(body);
  assert.deepEqual((await f.detail()).result, call.result);
  call.admission = { admitted: false, code: 'receipt_limit' };
  f.set(body);
  await assert.rejects(f.detail(), /retained evidence/);
  call.outcome_kind = 'not_admitted';
  f.set(body);
  await assert.rejects(f.detail(), /retained evidence/);
  call.result = null;
  f.set(body);
  assert.deepEqual((await f.detail()).admission, call.admission);
});
