<?php

declare(strict_types=1);

// Optional interoperability proof. Load vendor code only; never bootstrap CAI or touch its database.
require $argv[1].'/vendor/autoload.php';

use Illuminate\Container\Container;
use Illuminate\Http\Client\Factory;
use Illuminate\Support\Facades\Facade;
use Illuminate\Support\Facades\Http;
use Laravel\Mcp\Client\Transport\HttpTransport;
use Laravel\Mcp\WebClient;
use Laravel\Mcp\Schema\Implementation;

$container = new Container;
Container::setInstance($container);
Facade::setFacadeApplication($container);
$factory = new Factory;
$container->instance('http', $factory);
$container->instance(Factory::class, $factory);
$config = json_decode(file_get_contents($argv[2]), true, flags: JSON_THROW_ON_ERROR);
$clients = [];
$transports = [];
foreach (['forester', 'director'] as $role) {
    $transport = new HttpTransport($config['url']);
    $client = new WebClient($transport, new Implementation('framework-php-proof', '1'));
    $client->withToken($config['credential'])->withHeaders($config[$role])->withoutCache()->withTimeout(5);
    $clients[$role] = $client;
    $transports[$role] = $transport;
}
function check(bool $condition, string $message): void {
    if (! $condition) throw new RuntimeException($message);
}
function prepare(WebClient $client, string $call, ?string $effect = null): void {
    $client->withHeaders(['X-CF-Call-Id' => $call, 'X-CF-Turn-Request-Id' => 'php-proof', 'X-CF-Effect-Key' => $effect ?? '']);
}
try {
    $local = $clients['forester']->tools()->keys()->all();
    $world = $clients['director']->tools()->keys()->all();
    check(in_array('request_work', $local, true) && ! in_array('request_work', $world, true), 'Scoped discovery failed');
    prepare($clients['forester'], 'local-context');
    $context = $clients['forester']->callTool('inspect_context', ['scope' => 'local']);
    check(! $context->isError && $context->structuredContent['data']['characterRef'] === 'forester', 'Raw completed result failed');
    check(json_decode($context->text(), true, flags: JSON_THROW_ON_ERROR) === $context->structuredContent, 'Text/structured result mismatch');
    $denied = $clients['forester']->callTool('inspect_context', ['scope' => 'world']);
    check($denied->isError && $denied->structuredContent['code'] === 'scope_denied', 'Raw rejected result failed');

    $quest = ['quest' => ['recipientRef' => 'player-1', 'title' => 'PHP woodland survey', 'summary' => 'Visit the grove.', 'objectives' => [['id' => 'visit', 'description' => 'Visit the Old Grove.', 'condition' => ['tool' => 'game_inspect_location', 'arguments' => ['playerRef' => 'player-1', 'locationRef' => 'grove-1'], 'expect' => ['path' => ['visited'], 'operator' => 'equals', 'value' => true]]]]]];
    $dropNext = false;
    $factory->globalResponseMiddleware(function ($response) use (&$dropNext) {
        if ($dropNext) {
            $dropNext = false;
            throw new RuntimeException('simulated_lost_response');
        }
        return $response;
    });
    prepare($clients['forester'], 'lost-create', 'retained-create');
    $dropNext = true;
    try {
        $clients['forester']->callTool('create_quest', $quest);
        throw new RuntimeException('Lost response was not simulated');
    } catch (RuntimeException $error) {
        check($error->getMessage() === 'simulated_lost_response', 'Unexpected lost-response failure');
    }
    $replay = $clients['forester']->callTool('create_quest', $quest);
    check(! $replay->isError && $replay->structuredContent['data']['questId'] === 'quest-1', 'Retained-key replay failed');
    $quest['quest']['title'] = 'Different intention';
    $conflict = $clients['forester']->callTool('create_quest', $quest);
    check($conflict->isError && $conflict->structuredContent['code'] === 'effect_key_conflict', 'Public conflict code failed');

    $sessionProperty = new ReflectionProperty(HttpTransport::class, 'sessionId');
    $oldSession = $sessionProperty->getValue($transports['director']);
    $response = Http::withToken($config['credential'])->withHeaders([...$config['director'], 'Mcp-Session-Id' => $oldSession, 'MCP-Protocol-Version' => '2025-11-25'])->delete($config['url']);
    check($response->successful(), 'Session deletion failed');
    $clients['director']->tools();
    check($sessionProperty->getValue($transports['director']) !== $oldSession, 'Expired session did not reinitialize');

    $stale = new WebClient(new HttpTransport($config['url']), new Implementation('stale-proof', '1'));
    $stale->withToken($config['credential'])->withHeaders([...$config['forester'], 'X-CF-Binding-Generation' => 'retired-generation']);
    try {
        $stale->tools();
        throw new RuntimeException('Stale generation was accepted');
    } catch (Laravel\Mcp\Client\Exceptions\AuthorizationRequiredException) {
        // Expected HTTP 403 before discovery.
    }
    echo json_encode(['status' => 'passed', 'protocol' => $clients['forester']->protocolVersion()->value, 'checks' => ['two scoped discoveries', 'raw completed/rejected envelopes', 'lost-response retained-key replay', 'conflict code', 'session-expiry reinitialization', 'stale-generation refusal']], JSON_THROW_ON_ERROR).PHP_EOL;
} finally {
    foreach ($clients as $client) $client->disconnect();
}
