import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import Ajv2020 from 'ajv/dist/2020.js';

const catalogue = JSON.parse(
  await readFile(
    new URL('../docs/contracts/tools.json', import.meta.url),
    'utf8',
  ),
);
const fixtures = JSON.parse(
  await readFile(
    new URL('../docs/contracts/examples.json', import.meta.url),
    'utf8',
  ),
);
const ajv = new Ajv2020({
  strict: true,
  allErrors: true,
  allowUnionTypes: true,
});
const tools = new Map(
  catalogue.tools.map((tool) => [
    tool.name,
    {
      input: ajv.compile(tool.inputSchema),
      output: ajv.compile(tool.outputSchema),
    },
  ]),
);

test('every proposed tool has a valid input/output example and semantic rejection for both character roles', () => {
  assert.equal(catalogue.contractVersion, fixtures.contractVersion);
  assert.equal(tools.size, 6);
  assert.equal(fixtures.cases.length, 16);
  for (const role of ['forester', 'director']) {
    for (const [name, validators] of [...tools].filter(
      ([name]) =>
        !['inspect_quest_templates', 'compose_quest_draft'].includes(name),
    )) {
      const cases = fixtures.cases.filter(
        (example) => example.actor === role && example.tool === name,
      );
      assert.equal(cases.length, 2, `${role}/${name}`);
      assert.deepEqual(
        new Set(cases.map((example) => example.result.status)),
        new Set(['completed', 'rejected']),
      );
      for (const example of cases) {
        assert.ok(
          validators.input(example.arguments),
          `${example.id}: ${ajv.errorsText(validators.input.errors)}`,
        );
        assert.ok(
          validators.output(example.result),
          `${example.id}: ${ajv.errorsText(validators.output.errors)}`,
        );
        if (['create_quest', 'offer_quest'].includes(name))
          assert.ok(example.effectKey);
      }
    }
  }
  assert.equal(fixtures.actors.director.entityRef, null);
  assert.notEqual(
    fixtures.actors.forester.caiSessionId,
    fixtures.actors.director.caiSessionId,
  );
});

test('schemas reject identity injection, incomplete conditions and fake completion envelopes', () => {
  assert.equal(
    tools
      .get('inspect_context')
      .input({ scope: 'local', characterRef: 'director' }),
    false,
  );
  assert.equal(
    tools.get('offer_quest').input({ questId: 'q', recipientRef: 'player-1' }),
    false,
  );
  const quest = structuredClone(
    fixtures.cases.find((example) => example.id === 'forester-create-ok')
      .arguments,
  );
  delete quest.quest.objectives[0].condition.expect;
  assert.equal(tools.get('create_quest').input(quest), false);
  assert.equal(
    tools
      .get('create_quest')
      .output({ status: 'accepted', requestId: 'phase-0-admission' }),
    false,
  );
  assert.equal(
    tools
      .get('offer_quest')
      .output({ status: 'completed', data: { status: 'completed' } }),
    false,
  );
  assert.equal(
    tools
      .get('inspect_quest')
      .output({ status: 'rejected', code: 'not_found' }),
    false,
  );
});

test('incremental authoring examples conform to the discovered schemas', () => {
  for (const example of fixtures.authoringCases) {
    const validators = tools.get(example.tool);
    assert.ok(
      validators.input(example.arguments),
      ajv.errorsText(validators.input.errors),
    );
    assert.ok(
      validators.output(example.result),
      ajv.errorsText(validators.output.errors),
    );
  }
});
