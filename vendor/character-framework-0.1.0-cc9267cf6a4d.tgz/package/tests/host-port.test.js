import test from 'node:test';
import assert from 'node:assert/strict';
import { CharacterHostPort } from '../dist/src/host/index.js';
function fixture() {
  const calls = [],
    effects = new Map(),
    stored = [];
  let lose = false,
    failSave = false;
  const driver = {
    current() {},
    choices: () => [{ id: 'offer/accept', label: 'Accept' }],
    async run(id, effect, intent, retry) {
      calls.push({ id, effect, intent, retry });
      const result = effects.get(effect) ?? 'A retained reply';
      effects.set(effect, result);
      if (lose) {
        lose = false;
        throw new Error('lost');
      }
      return result;
    },
  };
  const persist = async (save) => {
    if (failSave) throw new Error('disk');
    stored.push(structuredClone(save));
  };
  const port = new CharacterHostPort(driver, persist);
  return {
    port,
    driver,
    persist,
    calls,
    effects,
    stored,
    lose: () => {
      lose = true;
    },
    fail: (value) => {
      failSave = value;
    },
  };
}
const dialogue = (requestId, expectedRevision = 0, message = 'Hello') => ({
  kind: 'dialogue',
  requestId,
  expectedRevision,
  message,
});
test('immutable shared host views retain one operation; replay precedes stale new-command check', async () => {
  const f = fixture();
  let first = 0,
    second = 0;
  const detach = f.port.subscribe(() => {
    first++;
  });
  const detachSecond = f.port.subscribe(() => {
    second++;
  });
  assert.ok(Object.isFrozen(f.port.read().messages));
  detach();
  await f.port.dispatch(dialogue('one'));
  assert.equal(first, 1);
  assert.ok(second > 1);
  await f.port.dispatch(dialogue('one')); // revision0 is stale now, exact original replay is valid.
  assert.equal(f.calls.length, 1);
  await assert.rejects(f.port.dispatch(dialogue('two')), /Stale/);
  await assert.rejects(
    f.port.dispatch(dialogue('one', 0, 'Changed')),
    /conflict/,
  );
  detachSecond();
  assert.equal(f.port.read().state, 'idle');
});
test('lost outcome restores original operation/effect with new UI retry delivery identity', async () => {
  const f = fixture();
  f.lose();
  await assert.rejects(f.port.dispatch(dialogue('one')), /lost/);
  const saved = f.stored.at(-1);
  const restored = new CharacterHostPort(
    f.driver,
    f.persist,
    JSON.parse(JSON.stringify(saved)),
  );
  assert.equal(restored.read().state, 'uncertain');
  await assert.rejects(
    restored.dispatch(dialogue('fresh', restored.read().revision)),
    /Resolve/,
  );
  await restored.dispatch({
    kind: 'retry',
    requestId: 'ui-retry',
    failedRequestId: 'one',
  });
  assert.equal(f.calls.length, 2);
  assert.equal(f.calls[0].effect, f.calls[1].effect);
  assert.equal(f.calls[1].id, 'one');
  assert.equal(f.calls[1].retry, true);
  assert.equal(f.effects.size, 1);
  assert.equal(restored.read().messages.length, 2);
  await restored.dispatch({
    kind: 'retry',
    requestId: 'after-done',
    failedRequestId: 'one',
  });
  await assert.rejects(
    restored.dispatch(dialogue('after-done', restored.read().revision)),
    /conflict/,
  );
  assert.equal(f.calls.length, 2);
});
test('failed durable prepare never dispatches; retry remains gated and restores a known result', async () => {
  const f = fixture();
  f.fail(true);
  await assert.rejects(f.port.dispatch(dialogue('one')), /disk/);
  assert.equal(f.calls.length, 0);
  assert.equal(f.port.read().state, 'uncertain');
  f.fail(false);
  await f.port.dispatch({
    kind: 'retry',
    requestId: 'again',
    failedRequestId: 'one',
  });
  assert.equal(f.effects.size, 1);
  assert.equal(
    new CharacterHostPort(f.driver, f.persist, f.port.save()).read().state,
    'idle',
  );
});
test('failed durable acknowledgment exposes no message and retries storage without another effect', async () => {
  const f = fixture();
  const original = f.driver.run;
  f.driver.run = async (...args) => {
    const value = await original(...args);
    f.fail(true);
    return value;
  };
  await assert.rejects(f.port.dispatch(dialogue('one')), /disk/);
  assert.equal(f.port.read().messages.length, 0);
  f.fail(false);
  await f.port.dispatch({
    kind: 'retry',
    requestId: 'again',
    failedRequestId: 'one',
  });
  assert.equal(f.calls.length, 1);
  assert.equal(f.port.read().messages.length, 2);
});
test('presentation stop-waiting does not cancel shared pending operation or host authority', async () => {
  const f = fixture();
  let release;
  f.driver.run = () =>
    new Promise((resolve) => {
      release = resolve;
    });
  const pending = f.port.dispatch(dialogue('one'));
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(f.port.read().state, 'pending');
  await f.port.dispatch({
    kind: 'stop_waiting',
    requestId: 'stop',
    pendingRequestId: 'one',
  });
  assert.equal(f.port.read().state, 'pending');
  await assert.rejects(
    f.port.dispatch(dialogue('new', f.port.read().revision)),
    /pending/,
  );
  release('Late retained result');
  await pending;
  assert.equal(f.port.read().state, 'idle');
  assert.equal(f.port.read().messages[1].text, 'Late retained result');
});
test('host disposal ignores late results but durable pending operation remains restorable', async () => {
  const f = fixture();
  let release;
  f.driver.run = () =>
    new Promise((resolve) => {
      release = resolve;
    });
  const pending = f.port.dispatch(dialogue('one'));
  const rejected = assert.rejects(pending, /disposed/);
  await new Promise((resolve) => setImmediate(resolve));
  f.port.dispose();
  release('late');
  await rejected;
  assert.equal(f.port.read().state, 'disposed');
  assert.equal(
    new CharacterHostPort(f.driver, f.persist, f.stored.at(-1)).read().state,
    'uncertain',
  );
});
test('foreign choices and saturated ledgers cannot execute new effects', async () => {
  const f = fixture();
  await assert.rejects(
    f.port.dispatch({
      kind: 'choice',
      requestId: 'foreign',
      expectedRevision: 0,
      choiceId: 'foreign/accept',
    }),
    /Unavailable/,
  );
  await f.port.dispatch({
    kind: 'choice',
    requestId: 'accept',
    expectedRevision: 0,
    choiceId: 'offer/accept',
  });
  assert.equal(f.effects.size, 1);
  const full = structuredClone(f.port.save());
  full.deliveries = Array.from({ length: 128 }, (_, i) => ({
    id: 'id-' + i,
    digest: 'retained',
    operationId: 'accept',
  }));
  const port = new CharacterHostPort(f.driver, f.persist, full);
  assert.deepEqual(port.read().commands, []);
  await assert.rejects(
    port.dispatch(dialogue('new', port.read().revision)),
    /saturated/,
  );
});

test('valid long CAI replies retain exact content through presentation and JSON restore', async () => {
  for (const reply of ['森'.repeat(12000), '🌲'.repeat(16000)]) {
    const f = fixture();
    f.driver.run = async () => reply;
    await f.port.dispatch(dialogue('long-reply'));
    assert.equal(f.port.read().messages[1].text, reply);
    const restored = new CharacterHostPort(
      f.driver,
      f.persist,
      JSON.parse(JSON.stringify(f.port.save())),
    );
    assert.equal(restored.read().messages[1].text, reply);
    assert.equal(restored.save().operations[0].result, reply);
    await restored.dispatch(dialogue('long-reply'));
    assert.equal(restored.read().messages.length, 2);
  }
  const f = fixture();
  f.driver.run = async () => 'x'.repeat(32001);
  await assert.rejects(
    f.port.dispatch(dialogue('too-long')),
    /Invalid host operation result/,
  );
  assert.equal(f.port.read().messages.length, 0);
  assert.equal(f.port.read().state, 'uncertain');
});

test('host authority publication versions committed choice additions/removals for both views', async () => {
  const f = fixture();
  let choices = [];
  f.driver.choices = () => choices;
  const port = new CharacterHostPort(f.driver, f.persist);
  const a = [],
    b = [];
  const detachA = port.subscribe((state) => a.push(state));
  const detachB = port.subscribe((state) => b.push(state));
  const before = port.read();
  choices = [{ id: 'offer/accept', label: 'Accept' }];
  assert.equal(port.read().choices.length, 0); // read is the published projection, not an unversioned live sample.
  await port.publishAuthority();
  assert.equal(port.read().revision, before.revision + 1);
  assert.equal(a.length, 2);
  assert.equal(b.length, 2);
  assert.equal(a[1].choices.length, 1);
  assert.ok(Object.isFrozen(a[1].choices[0]));
  choices[0].label = 'Changed externally';
  assert.equal(a[1].choices[0].label, 'Accept');
  await assert.rejects(
    port.dispatch(dialogue('stale', before.revision)),
    /Publish|Stale/,
  );
  await port.publishAuthority();
  const revision = port.read().revision,
    stores = f.stored.length,
    emissions = b.length;
  await port.publishAuthority();
  await port.publishAuthority();
  assert.equal(f.stored.length, stores);
  assert.equal(b.length, emissions);
  detachA();
  choices = [];
  await port.publishAuthority();
  assert.equal(a.length, 3);
  assert.equal(b.at(-1).choices.length, 0);
  assert.equal(port.read().revision, revision + 1);
  await assert.rejects(
    port.dispatch(dialogue('stale-after-removal', revision)),
    /Stale/,
  );
  detachB();
  port.dispose();
  await assert.rejects(port.publishAuthority(), /disposed/);
  assert.equal(b.at(-1).state, 'idle');
});
test('failed authority storage keeps the old projection and gates new commands until publication succeeds', async () => {
  const f = fixture();
  let choices = [];
  f.driver.choices = () => choices;
  const port = new CharacterHostPort(f.driver, f.persist);
  const original = port.read();
  choices = [{ id: 'new', label: 'New' }];
  f.fail(true);
  await assert.rejects(port.publishAuthority(), /disk/);
  assert.equal(port.read().choices.length, 0);
  assert.equal(port.read().revision, original.revision);
  assert.equal(port.read().authorityPending, true);
  await assert.rejects(
    port.dispatch(dialogue('new-command', original.revision)),
    /Publish/,
  );
  f.fail(false);
  await port.publishAuthority();
  assert.equal(port.read().choices.length, 1);
  assert.equal(port.read().authorityPending, false);
});
test('authority changes during pending dialogue coalesce at its checkpoint without a second clock', async () => {
  const f = fixture();
  let choices = [],
    release;
  f.driver.choices = () => choices;
  f.driver.run = () =>
    new Promise((resolve) => {
      release = resolve;
    });
  const port = new CharacterHostPort(f.driver, f.persist);
  const snapshots = [];
  port.subscribe((state) => snapshots.push(state));
  const pending = port.dispatch(dialogue('one'));
  await new Promise((resolve) => setImmediate(resolve));
  const stores = f.stored.length;
  choices = [{ id: 'offer/accept', label: 'Accept' }];
  await port.publishAuthority();
  await port.publishAuthority();
  assert.equal(f.stored.length, stores);
  assert.equal(port.read().authorityPending, true);
  assert.equal(port.read().state, 'pending');
  release('Done');
  await pending;
  assert.equal(port.read().choices.length, 1);
  assert.equal(port.read().authorityPending, false);
  assert.equal(f.stored.at(-1).choices.length, 1);
  assert.equal(snapshots.at(-1).state, 'idle');
});
test('restore compares published choice projection with current authority before new commands', async () => {
  const f = fixture();
  let choices = [];
  f.driver.choices = () => choices;
  const port = new CharacterHostPort(f.driver, f.persist);
  const saved = JSON.parse(JSON.stringify(port.save()));
  choices = [{ id: 'late-offer', label: 'Accept' }];
  const restored = new CharacterHostPort(f.driver, f.persist, saved);
  assert.equal(restored.read().authorityPending, true);
  await assert.rejects(
    restored.dispatch(dialogue('new', restored.read().revision)),
    /Publish/,
  );
  await restored.publishAuthority();
  assert.equal(restored.read().choices[0].id, 'late-offer');
  assert.equal(restored.read().revision, saved.revision + 1);
});

test('saturated uncertain host advertises actionable replay without another delivery or effect', async () => {
  const f = fixture();
  for (let i = 0; i < 127; i++)
    await f.port.dispatch(dialogue('completed-' + i, f.port.read().revision));
  f.lose();
  const original = dialogue('last', f.port.read().revision);
  await assert.rejects(f.port.dispatch(original), /lost/);
  const saved = JSON.parse(JSON.stringify(f.port.save()));
  const effect = saved.operations.at(-1).effectKey;
  const restored = new CharacterHostPort(f.driver, f.persist, saved);
  assert.deepEqual(restored.read().commands, ['replay', 'stop_waiting']);
  await assert.rejects(
    restored.dispatch({
      kind: 'retry',
      requestId: 'fresh',
      failedRequestId: 'last',
    }),
    /saturated/,
  );
  await assert.rejects(
    restored.dispatch({ kind: 'replay', operationId: 'missing' }),
    /Unknown/,
  );
  await assert.rejects(
    restored.dispatch({
      kind: 'replay',
      operationId: 'last',
      message: 'changed',
    }),
    /Invalid/,
  );
  await restored.dispatch({ kind: 'replay', operationId: 'last' });
  assert.equal(restored.read().state, 'idle');
  assert.equal(restored.save().deliveries.length, 128);
  assert.equal(restored.save().operations.length, 128);
  assert.equal(f.calls.at(-1).id, 'last');
  assert.equal(f.calls.at(-1).effect, effect);
  assert.equal(f.calls.at(-1).retry, true);
  const callCount = f.calls.length;
  const revision = restored.read().revision;
  await restored.dispatch({ kind: 'replay', operationId: 'last' });
  await restored.dispatch(original);
  assert.equal(f.calls.length, callCount);
  assert.equal(restored.read().revision, revision);
  assert.equal(
    restored.read().messages.filter((m) => m.id === 'last/player').length,
    1,
  );
  assert.deepEqual(restored.read().commands, []);
});

test('replay known receipt retries failed acknowledgment without reexecuting driver', async () => {
  const f = fixture();
  let failAck = true;
  const port = new CharacterHostPort(f.driver, async (save) => {
    if (save.operations.some((op) => op.done) && failAck)
      throw new Error('ack disk');
  });
  await assert.rejects(port.dispatch(dialogue('original')), /ack disk/);
  const count = f.calls.length;
  failAck = false;
  await port.dispatch({ kind: 'replay', operationId: 'original' });
  assert.equal(f.calls.length, count);
  assert.equal(port.read().messages.length, 2);
  assert.equal(port.save().deliveries.length, 1);
});

test('replay rejects concurrent work and suppresses late presentation after disposal', async () => {
  const f = fixture();
  f.lose();
  await assert.rejects(f.port.dispatch(dialogue('original')), /lost/);
  let resolve, started;
  const gate = new Promise((yes) => {
    resolve = yes;
  });
  const active = new Promise((yes) => {
    started = yes;
  });
  f.driver.run = () => {
    started();
    return gate;
  };
  const replay = f.port.dispatch({ kind: 'replay', operationId: 'original' });
  await active;
  await assert.rejects(
    f.port.dispatch({ kind: 'replay', operationId: 'original' }),
    /pending/,
  );
  f.port.dispose();
  resolve('late retained result');
  await assert.rejects(replay, /disposed/);
  assert.equal(f.port.read().messages.length, 0);
  assert.equal(f.port.save().operations[0].done, false);
});
