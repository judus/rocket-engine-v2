import test from 'node:test';
import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { createStationScenario } from '../dist/examples/station-scenario.js';
import { createNarrativeScenario } from '../dist/examples/narrative-scenario.js';

async function settle(host, promise) {
  let done = false;
  promise.then(
    () => {
      done = true;
    },
    () => {
      done = true;
    },
  );
  for (let i = 0; i < 1000 && !done; i++) {
    host.advance(0);
    await setImmediate();
  }
  assert.ok(done);
  return promise;
}
test('one narrative runtime contract handles a different station game and rejects woodland mechanics', async (t) => {
  const station = createStationScenario();
  const woods = createNarrativeScenario();
  t.after(() => {
    station.dispose();
    woods.dispose();
  });
  const input = {
    quest: {
      recipientRef: 'crew-player',
      title: 'Restore the oxygen loop',
      summary: 'The crew needs clean air.',
      objectives: [
        {
          id: 'oxygen',
          description: 'Restore efficiency to at least 80%.',
          condition: {
            tool: 'station_inspect_system',
            arguments: { systemRef: 'oxygen-loop' },
            expect: { path: ['efficiency'], operator: 'at_least', value: 80 },
          },
        },
      ],
    },
  };
  const created = await settle(
    station,
    station.mechanic.call('create_quest', input, 'oxygen-create'),
  );
  assert.equal(created.status, 'completed');
  const offered = await settle(
    station,
    station.mechanic.call(
      'offer_quest',
      {
        questId: created.data.questId,
        recipientRef: 'crew-player',
        dialogue: 'Please fix the air system.',
      },
      'oxygen-offer',
    ),
  );
  await settle(
    station,
    station.narrative.choose(
      'crew-player',
      offered.data.choices[0].id,
      'crew-choice',
    ),
  );
  station.advance();
  await setImmediate();
  station.advance();
  assert.equal(station.narrative.save().quests[0].offer.status, 'active');
  station.repair('oxygen-loop');
  for (
    let step = 0;
    step < 10 &&
    station.narrative.save().quests[0].offer.status !== 'completed';
    step++
  ) {
    station.advance();
    await setImmediate();
  }
  assert.equal(station.narrative.save().quests[0].offer.status, 'completed');
  const copied = await settle(
    woods,
    woods.foresterNarrative.call(
      'create_quest',
      { quest: { ...input.quest, recipientRef: 'player-1' } },
      'wrong-game',
    ),
  );
  assert.equal(copied.status, 'rejected');
  assert.equal(woods.narrative.stats.quests, 0);
  const denied = await settle(
    station,
    station.mechanic.call(
      'create_quest',
      {
        quest: {
          ...input.quest,
          objectives: [
            {
              ...input.quest.objectives[0],
              condition: {
                ...input.quest.objectives[0].condition,
                arguments: { systemRef: 'reactor' },
              },
            },
          ],
        },
      },
      'private-system',
    ),
  );
  assert.equal(denied.status, 'rejected');
  const director = await settle(
    station,
    station.director.call('inspect_context', { scope: 'world' }),
  );
  assert.equal(director.data.entityRef, null);
  assert.equal(station.narrative.stats.quests, 1);
});
