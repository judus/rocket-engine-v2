import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { setImmediate } from 'node:timers/promises';
import { createJointFixture } from '../dist/examples/joint-fixture.js';
import { FakeCaiClient } from '../examples/fake-cai-client.js';

const authority = '127.0.0.1:8096';
const credential = 'disposable-fixture-test';
async function pump(fixture, promise) {
  let settled = false;
  let result;
  let failure;
  void promise.then(
    (value) => {
      result = value;
      settled = true;
    },
    (error) => {
      failure = error;
      settled = true;
    },
  );
  for (let i = 0; i < 200 && !settled; i++) {
    fixture.advance();
    await setImmediate();
  }
  assert.ok(settled, 'host operation settled');
  if (failure) throw failure;
  return result;
}
function control(fixture, path, input, key = credential) {
  return fixture.handle(
    new Request(`http://${authority}/fixture/${path}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}` },
      body: JSON.stringify(input),
    }),
  );
}
test('joint fixture authenticates and binds one real numeric CAI identity', async (t) => {
  const fixture = createJointFixture(credential, [authority]);
  t.after(() => fixture.dispose());
  assert.equal(
    (await control(fixture, 'bind', { sessionId: 12, characterId: 3 }, 'wrong'))
      .status,
    403,
  );
  const first = await (
    await control(fixture, 'bind', { sessionId: 12, characterId: 3 })
  ).json();
  const replay = await (
    await control(fixture, 'bind', { sessionId: 12, characterId: 3 })
  ).json();
  assert.deepEqual(first.headers, replay.headers);
  assert.equal(
    (await control(fixture, 'bind', { sessionId: 13, characterId: 3 })).status,
    409,
  );
});
test('actual MCP fixture loses committed create reply, replays one effect and completes via host fact', async (t) => {
  const fixture = createJointFixture(credential, [authority]);
  t.after(() => fixture.dispose());
  const bound = await (
    await control(fixture, 'bind', { sessionId: 12, characterId: 3 })
  ).json();
  const client = new FakeCaiClient(
    new URL(`http://${authority}/mcp`),
    bound.headers,
    credential,
    (target, init) => fixture.handle(new Request(target, init)),
  );
  await client.connect();
  t.after(() => client.close());
  const discovered = await client.client.listTools();
  assert.ok(discovered.tools.some((tool) => tool.name === 'create_quest'));
  assert.ok(discovered.tools.every((tool) => !tool.name.startsWith('fixture')));
  const identity = () => ({
    callId: randomUUID(),
    turnId: randomUUID(),
    effectKey: randomUUID(),
  });
  const inspected = await pump(
    fixture,
    client.call('inspect_context', { scope: 'local' }, identity()),
  );
  assert.equal(inspected.structuredContent.status, 'completed');
  await control(fixture, 'drop-create', {});
  const createIdentity = identity();
  await assert.rejects(
    pump(
      fixture,
      client.call('create_quest', bound.definition, createIdentity),
    ),
    (error) => error.code === 503,
  );
  assert.equal(fixture.state().quests.length, 1);
  assert.equal(fixture.state().droppedCreates, 1);
  const created = await pump(
    fixture,
    client.call('create_quest', bound.definition, createIdentity),
  );
  const questId = created.structuredContent.data.questId;
  assert.equal(fixture.state().quests.length, 1);
  assert.equal(fixture.state().quests[0].questId, questId);
  const offered = await pump(
    fixture,
    client.call(
      'offer_quest',
      {
        questId,
        recipientRef: 'player-1',
        dialogue: 'Please survey the grove.',
      },
      identity(),
    ),
  );
  assert.equal(offered.structuredContent.status, 'completed');
  const accepted = await pump(
    fixture,
    control(fixture, 'accept', { effectKey: randomUUID() }),
  );
  assert.equal(accepted.status, 200);
  assert.equal(fixture.state().quests[0].status, 'active');
  assert.equal((await control(fixture, 'complete', {})).status, 200);
  for (let i = 0; i < 20; i++) {
    fixture.advance();
    await setImmediate();
  }
  assert.equal(fixture.state().quests[0].status, 'completed');
  assert.ok(
    fixture.state().events.some((event) => event.type === 'quest_completed'),
  );
});
