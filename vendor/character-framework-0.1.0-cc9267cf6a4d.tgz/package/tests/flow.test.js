import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import Ajv2020 from 'ajv/dist/2020.js';
import { createNarrativeScenario } from '../dist/examples/narrative-scenario.js';

const catalogue = JSON.parse(
  await readFile(
    new URL('../docs/contracts/tools.json', import.meta.url),
    'utf8',
  ),
);
const ajv = new Ajv2020({ strict: true, allowUnionTypes: true });
const inputs = ajv.compile(
  catalogue.tools.find((t) => t.name === 'create_quest').inputSchema,
);
const outputs = ajv.compile(
  catalogue.tools.find((t) => t.name === 'inspect_quest').outputSchema,
);
const commit = (s, promise) => {
  s.advance(0);
  return promise;
};
const data = (result) => {
  assert.equal(result.status, 'completed', JSON.stringify(result));
  return result.data;
};
async function poll(s) {
  for (let i = 0; i < 6; i++) {
    s.advance(0.1);
    await new Promise((resolve) => setImmediate(resolve));
  }
}
function draft(s, branching = false) {
  const first = s.draft('Choose a winter route', 'grove-1').toInput();
  const second = s.draft('Town', 'river-town').toInput();
  return {
    quest: {
      ...first.quest,
      objectives: [
        { ...first.quest.objectives[0], id: 'survey' },
        { ...second.quest.objectives[0], id: 'town' },
        ...(branching ? [{ ...first.quest.objectives[0], id: 'return' }] : []),
      ],
      flow: {
        start: 'survey',
        stages: [
          {
            id: 'survey',
            objectives: ['survey'],
            dialogue: 'Choose where we should help.',
            ...(branching
              ? {
                  choices: [
                    { id: 'town', label: 'Help the town', next: 'town' },
                    { id: 'grove', label: 'Stay in the grove', next: 'grove' },
                  ],
                }
              : { next: 'town' }),
          },
          { id: 'town', objectives: ['town'], dialogue: 'Check the town.' },
          ...(branching ? [{ id: 'grove', objectives: ['return'] }] : []),
        ],
      },
    },
  };
}
async function start(s, input) {
  assert.ok(inputs(input), ajv.errorsText(inputs.errors));
  const questId = data(
    await commit(s, s.directorNarrative.call('create_quest', input, 'create')),
  ).questId;
  const offer = data(
    await commit(
      s,
      s.directorNarrative.call(
        'offer_quest',
        {
          questId,
          recipientRef: 'player-1',
          dialogue: 'Help with winter?',
        },
        'offer',
      ),
    ),
  );
  data(
    await commit(
      s,
      s.narrative.choose('player-1', offer.choices[0].id, 'accept'),
    ),
  );
  return questId;
}
async function inspect(s, questId) {
  const result = await commit(
    s,
    s.directorNarrative.call('inspect_quest', {
      questId,
      recipientRef: 'player-1',
    }),
  );
  assert.ok(outputs(result), ajv.errorsText(outputs.errors));
  return data(result);
}

test('ordered stages inspect only current objectives and advance from authoritative facts', async () => {
  const s = createNarrativeScenario();
  try {
    s.visit('river-town');
    const id = await start(s, draft(s));
    await poll(s);
    let state = await inspect(s, id);
    assert.equal(state.flow.currentStage, 'survey');
    assert.equal(state.objectives[1].observed, null);
    s.visit('grove-1');
    await poll(s);
    state = await inspect(s, id);
    assert.equal(state.status, 'completed');
    assert.deepEqual(state.flow.visited, ['survey', 'town']);
    assert.equal(state.flow.dialogue, 'Check the town.');
    assert.ok(state.objectives.every((o) => o.status === 'satisfied'));
    const checkpoint = s.narrative.save();
    s.narrative.restore(JSON.parse(JSON.stringify(checkpoint)));
    assert.deepEqual(await inspect(s, id), state);
  } finally {
    s.dispose();
  }
});

test('player branches are gated, recipient-bound, replayable and complete only the selected path', async () => {
  const s = createNarrativeScenario();
  try {
    const id = await start(s, draft(s, true));
    await poll(s);
    assert.deepEqual((await inspect(s, id)).choices, []);
    assert.equal(
      (
        await commit(
          s,
          s.narrative.choose('player-1', `${id}/stage/survey/town`, 'early'),
        )
      ).code,
      'choice_unavailable',
    );
    s.visit('grove-1');
    await poll(s);
    const waiting = await inspect(s, id);
    assert.equal(waiting.status, 'active');
    assert.equal(waiting.choices.length, 2);
    const checkpoint = s.narrative.save();
    s.narrative.restore(JSON.parse(JSON.stringify(checkpoint)));
    assert.deepEqual(await inspect(s, id), waiting);
    assert.equal(
      (
        await commit(
          s,
          s.narrative.choose('other-player', waiting.choices[0].id, 'other'),
        )
      ).code,
      'choice_unavailable',
    );
    const selected = await commit(
      s,
      s.narrative.choose('player-1', waiting.choices[0].id, 'route'),
    );
    assert.equal(data(selected).stageId, 'town');
    assert.deepEqual(
      await commit(
        s,
        s.narrative.choose('player-1', waiting.choices[0].id, 'route'),
      ),
      selected,
    );
    assert.equal(
      (
        await commit(
          s,
          s.narrative.choose('player-1', waiting.choices[1].id, 'late'),
        )
      ).code,
      'choice_unavailable',
    );
    await poll(s);
    assert.equal((await inspect(s, id)).status, 'active');
    s.visit('river-town');
    await poll(s);
    const completed = await inspect(s, id);
    assert.equal(completed.status, 'completed');
    assert.equal(completed.objectives[2].status, 'pending');
    assert.equal(completed.objectives[2].observed, null);
    assert.deepEqual(completed.flow.visited, ['survey', 'town']);
    s.narrative.restore(JSON.parse(JSON.stringify(s.narrative.save())));
    assert.deepEqual(await inspect(s, id), completed);
    assert.equal(
      s.narrative
        .drainEvents()
        .filter((e) => e.type === 'quest_branch_selected').length,
      1,
    );
  } finally {
    s.dispose();
  }
});

test('invalid graphs reject atomically and corrupt flow checkpoints cannot replace live state', async () => {
  const s = createNarrativeScenario();
  try {
    const base = draft(s, true);
    const invalid = [
      (q) => {
        q.flow.stages[1].next = 'survey';
      },
      (q) => {
        q.flow.stages[0].choices[0].next = 'missing';
      },
      (q) => {
        q.flow.stages[0].choices.pop();
      },
      (q) => {
        q.flow.stages[2].objectives = ['survey'];
      },
      (q) => {
        q.flow.stages[0].next = 'town';
      },
      (q) => {
        q.flow.stages[0].choices[1].id = 'town';
      },
    ];
    for (const [index, mutate] of invalid.entries()) {
      const input = structuredClone(base);
      mutate(input.quest);
      const result = await commit(
        s,
        s.directorNarrative.call('create_quest', input, `bad-${index}`),
      );
      assert.equal(result.code, 'invalid_arguments');
      assert.equal(s.narrative.stats.quests, 0);
    }
    await start(s, base);
    await poll(s);
    const saved = s.narrative.save();
    for (const mutate of [
      (q) => {
        q.flowState.current = 'town';
      },
      (q) => {
        q.flowState.visited = ['survey', 'grove', 'town'];
        q.flowState.current = 'town';
      },
      (q) => {
        q.progress[1] = { id: 'town', status: 'satisfied', observed: true };
      },
      (q) => {
        q.offer.status = 'completed';
      },
    ]) {
      const bad = structuredClone(saved);
      mutate(bad.quests[0]);
      assert.throws(() => s.narrative.restore(bad), /Invalid/);
      assert.deepEqual(s.narrative.save(), saved);
    }
  } finally {
    s.dispose();
  }
});

for (const choiceCount of [3, 4]) {
  test(`narrative returns ${choiceCount} branch choices conforming to its output schema`, async () => {
    const s = createNarrativeScenario();
    try {
      const input = draft(s);
      delete input.quest.flow.stages[0].next;
      input.quest.flow.stages[0].choices = Array.from(
        { length: choiceCount },
        (_, i) => ({
          id: '森'.repeat(159) + i,
          label: `Route ${i}`,
          next: 'town',
        }),
      );
      const id = await start(s, input);
      s.visit('grove-1');
      await poll(s);
      const state = await inspect(s, id);
      assert.equal(state.choices.length, choiceCount);
      assert.ok(state.choices[0].id.length > 160);
      const selected = await commit(
        s,
        s.narrative.choose('player-1', state.choices.at(-1).id, 'route'),
      );
      assert.equal(data(selected).stageId, 'town');
      const branch = s.narrative
        .drainEvents()
        .find((event) => event.type === 'quest_branch_selected');
      assert.equal(branch.stageId, 'survey');
      assert.equal(branch.choiceId, data(selected).choiceId);
      const source = input.quest.flow.stages.find(
        (stage) => stage.id === branch.stageId,
      );
      const authored = source.choices.find(
        (choice) =>
          `${id}/stage/${encodeURIComponent(source.id)}/${encodeURIComponent(choice.id)}` ===
          branch.choiceId,
      );
      assert.equal(authored.id, input.quest.flow.stages[0].choices.at(-1).id);
      assert.equal(authored.next, data(selected).stageId);
      assert.ok(authored.id.length <= 160);
      assert.deepEqual((await inspect(s, id)).choices, []);
    } finally {
      s.dispose();
    }
  });
}
