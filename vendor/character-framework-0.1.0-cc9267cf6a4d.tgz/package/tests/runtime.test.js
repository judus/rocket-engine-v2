import test from 'node:test';
import assert from 'node:assert/strict';
import { CharacterRuntime } from '../dist/src/index.js';

const settle = () => new Promise((resolve) => setImmediate(resolve));
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => {
    resolve = yes;
    reject = no;
  });
  return { promise, resolve, reject };
};
const character = (id = 'forester', capabilities = []) => ({
  id,
  name: id,
  capabilities,
});
const decision = (dialogue) => ({ dialogue });
const inspection = (execute) => ({
  name: 'inspect',
  description: 'inspect',
  kind: 'inspection',
  inputSchema: { type: 'object' },
  validate: (input) =>
    input !== null &&
    typeof input === 'object' &&
    !Array.isArray(input) &&
    Object.keys(input).length === 0,
  execute,
});

test('host capability commands start only inside advancement, and reentrant advancement is rejected', async () => {
  let calls = 0;
  const runtime = new CharacterRuntime({
    gameId: 'game',
    reasoning: { decide: () => decision('hello') },
    capabilities: [
      inspection(() => {
        calls++;
        assert.throws(() => runtime.advance(0), /Reentrant/);
        return { status: 'completed', data: null };
      }),
    ],
  });
  try {
    const actor = runtime.register(character('a', ['inspect']));
    actor.dispatch('inspect', {});
    await settle();
    assert.equal(calls, 0);
    runtime.advance(0);
    assert.equal(calls, 1);
    await settle();
    runtime.advance(0);
    assert.equal(actor.snapshot().lastCapabilityResult.status, 'completed');
  } finally {
    runtime.dispose();
  }
});

test('one runtime separates embodied and bodyless characters, bindings and grants', async () => {
  const calls = [];
  const runtime = new CharacterRuntime({
    gameId: 'game',
    reasoning: { decide: () => decision('hello') },
    capabilities: [
      inspection((context) => {
        calls.push(context);
        return { status: 'completed', data: { who: context.character.id } };
      }),
    ],
  });
  try {
    const forester = runtime.register({
      ...character('forester', ['inspect']),
      entityId: 'worker-17',
      cai: { characterId: '42', sessionId: '81' },
    });
    const director = runtime.register(character('director'));
    assert.equal(director.snapshot().entityId, undefined);
    assert.deepEqual(director.dispatch('inspect', {}), {
      status: 'rejected',
      code: 'unsupported_capability',
      message: 'Capability is not available to this character',
    });
    assert.equal(
      forester.dispatch('inspect', { unexpected: 'argument' }).code,
      'invalid_input',
    );
    assert.equal(runtime.stats.pending, 0);
    assert.equal(forester.dispatch('inspect', {}).status, 'accepted');
    runtime.advance(0.1);
    await settle();
    assert.equal(forester.snapshot().lastCapabilityResult, null);
    runtime.advance(0.1);
    assert.equal(calls[0].gameId, 'game');
    assert.equal(calls[0].character.cai.sessionId, '81');
    assert.equal(calls[0].time, 0.1);
    assert.deepEqual(forester.snapshot().lastCapabilityResult, {
      status: 'completed',
      data: { who: 'forester' },
    });
    assert.equal(director.snapshot().lastCapabilityResult, null);
    assert.equal(runtime.capabilities('director').length, 0);
    assert.equal(runtime.capabilities('forester')[0].name, 'inspect');
  } finally {
    runtime.dispose();
  }
});

test('slow reasoning does not block another character; settlement waits for host advancement', async () => {
  const slow = deferred();
  const runtime = new CharacterRuntime({
    gameId: 'game',
    maxConcurrent: 2,
    reasoning: {
      decide: ({ character }) =>
        character.id === 'slow' ? slow.promise : decision('fast'),
    },
  });
  try {
    const a = runtime.register(character('slow')),
      b = runtime.register(character('fast'));
    a.requestDecision({});
    b.requestDecision({});
    runtime.advance(1);
    await settle();
    assert.equal(a.requestDecision({}).code, 'busy');
    assert.equal(b.snapshot().lastDecision, null);
    runtime.advance(0);
    assert.equal(a.snapshot().lastDecision, null);
    assert.equal(b.snapshot().lastDecision.dialogue, 'fast');
    assert.equal(runtime.stats.active, 1);
    slow.resolve(decision('slow'));
    await settle();
    runtime.advance(0);
    assert.equal(a.snapshot().lastDecision.dialogue, 'slow');
    assert.equal(runtime.stats.pending, 0);
  } finally {
    runtime.dispose();
  }
});

test('queued and active work remain bounded; cancelled noncooperative work retains its slot until settlement', async () => {
  const old = deferred();
  let calls = 0;
  const runtime = new CharacterRuntime({
    gameId: 'game',
    maxConcurrent: 1,
    maxPending: 2,
    reasoning: {
      decide: () => {
        calls++;
        return calls === 1 ? old.promise : decision('new');
      },
    },
  });
  try {
    const a = runtime.register(character('a')),
      b = runtime.register(character('b')),
      c = runtime.register(character('c'));
    a.requestDecision({});
    b.requestDecision({});
    assert.equal(c.requestDecision({}).code, 'queue_full');
    runtime.advance(0);
    await settle();
    a.unregister();
    runtime.advance(0);
    await settle();
    assert.equal(calls, 1);
    assert.equal(runtime.stats.active, 1);
    old.resolve(decision('obsolete'));
    await settle();
    runtime.advance(0);
    await settle();
    runtime.advance(0);
    assert.equal(b.snapshot().lastDecision.dialogue, 'new');
    assert.equal(
      runtime.drainEvents().filter((e) => e.kind === 'decision').length,
      1,
    );
  } finally {
    runtime.dispose();
  }
});

test('removal and reuse of an ID reject old handles and late results', async () => {
  const old = deferred();
  let signal;
  const runtime = new CharacterRuntime({
    gameId: 'game',
    reasoning: {
      decide: (context) => {
        signal = context.signal;
        return old.promise;
      },
    },
  });
  try {
    const a = runtime.register(character());
    a.requestDecision({});
    runtime.advance(0);
    await settle();
    assert.equal(a.unregister(), true);
    assert.equal(signal.aborted, true);
    assert.equal(a.unregister(), false);
    const fresh = runtime.register(character());
    assert.equal(a.requestDecision({}).code, 'unregistered');
    assert.throws(() => a.snapshot(), /no longer registered/);
    old.resolve(decision('obsolete'));
    await settle();
    runtime.advance(0);
    assert.equal(fresh.snapshot().lastDecision, null);
    assert.equal(
      runtime.drainEvents().some((e) => e.kind === 'decision'),
      false,
    );
  } finally {
    runtime.dispose();
  }
});

test('queued work is never invoked after removal; disposal is idempotent and aborts active work', async () => {
  let calls = 0,
    signal;
  const job = deferred();
  const runtime = new CharacterRuntime({
    gameId: 'game',
    reasoning: {
      decide: (context) => {
        calls++;
        signal = context.signal;
        return job.promise;
      },
    },
  });
  const queued = runtime.register(character('queued'));
  queued.requestDecision({});
  queued.unregister();
  const active = runtime.register(character('active'));
  active.requestDecision({});
  runtime.advance(0);
  await settle();
  assert.equal(calls, 1);
  runtime.dispose();
  runtime.dispose();
  assert.equal(signal.aborted, true);
  assert.equal(runtime.stats.characters, 0);
  assert.equal(active.requestDecision({}).code, 'unregistered');
  assert.throws(() => runtime.advance(0), /disposed/);
  assert.throws(() => runtime.register(character()), /disposed/);
  job.resolve(decision('late'));
  await settle();
  assert.equal(runtime.stats.pending, 0);
  assert.equal(
    runtime.drainEvents().filter((e) => e.kind === 'decision').length,
    0,
  );
});

test('errors and malformed adapter results clear pending work without committing fake success', async () => {
  for (const value of [
    null,
    { dialogue: 4 },
    { dialogue: 'x', intention: { kind: 'x' } },
    new Error('private error'),
  ]) {
    const runtime = new CharacterRuntime({
      gameId: 'game',
      reasoning: {
        decide: () => {
          if (value instanceof Error) throw value;
          return value;
        },
      },
    });
    try {
      const a = runtime.register(character());
      a.requestDecision({});
      runtime.advance(0);
      await settle();
      runtime.advance(0);
      assert.equal(a.snapshot().pendingDecision, null);
      assert.equal(a.snapshot().lastDecision, null);
      assert.equal(runtime.drainEvents()[0].kind, 'failed');
    } finally {
      runtime.dispose();
    }
  }
});

test('capability acceptance is distinct from host rejection and long-running operation status', async () => {
  let result = {
    status: 'rejected',
    code: 'stock_changed',
    message: 'No stock remains',
  };
  const runtime = new CharacterRuntime({
    gameId: 'game',
    reasoning: { decide: () => decision('hello') },
    capabilities: [inspection(() => result)],
  });
  try {
    const a = runtime.register(character('a', ['inspect']));
    assert.equal(a.dispatch('inspect', {}).status, 'accepted');
    runtime.advance(0);
    await settle();
    runtime.advance(0);
    assert.equal(a.snapshot().lastCapabilityResult.status, 'rejected');
    result = { status: 'running', operationId: 'journey-1' };
    a.dispatch('inspect', {});
    runtime.advance(0);
    await settle();
    runtime.advance(0);
    assert.deepEqual(a.snapshot().lastCapabilityResult, result);
    result = { status: 'completed' };
    a.dispatch('inspect', {});
    runtime.advance(0);
    await settle();
    runtime.advance(0);
    assert.equal(runtime.drainEvents().at(-1).data.code, 'invalid_result');
  } finally {
    runtime.dispose();
  }
});

test('snapshots, inputs and settled replies are detached from caller/provider mutation', async () => {
  const reply = {
    dialogue: 'original',
    intention: { kind: 'inspect', args: { x: 1 } },
  };
  let observed;
  const runtime = new CharacterRuntime({
    gameId: 'game',
    reasoning: {
      decide: (_, input) => {
        observed = input;
        return reply;
      },
    },
  });
  try {
    const definition = character();
    const a = runtime.register(definition);
    definition.name = 'mutated';
    const input = { nested: { x: 1 } };
    a.requestDecision(input);
    input.nested.x = 2;
    runtime.advance(0);
    await settle();
    reply.dialogue = 'mutated';
    reply.intention.args.x = 2;
    runtime.advance(0);
    assert.equal(a.snapshot().name, 'forester');
    assert.equal(observed.nested.x, 1);
    assert.equal(a.snapshot().lastDecision.dialogue, 'original');
    assert.equal(a.snapshot().lastDecision.intention.args.x, 1);
    assert.throws(() => {
      a.snapshot().lastDecision.intention.args.x = 3;
    }, TypeError);
    const cyclic = {};
    cyclic.self = cyclic;
    assert.equal(a.requestDecision(cyclic).code, 'invalid_input');
    assert.equal(a.requestDecision({ x: Infinity }).code, 'invalid_input');
  } finally {
    runtime.dispose();
  }
});

test('identity/configuration/time guards and event retention are explicit', async () => {
  assert.throws(
    () =>
      new CharacterRuntime({ gameId: 'x', maxConcurrent: 0, reasoning: {} }),
    /positive integer/,
  );
  const runtime = new CharacterRuntime({
    gameId: 'game',
    maxEvents: 1,
    reasoning: { decide: () => decision('x') },
  });
  try {
    const a = runtime.register(character('a')),
      b = runtime.register(character('b'));
    assert.throws(() => runtime.register(character('a')), /unique/);
    assert.throws(
      () => runtime.register(character('c', ['unknown'])),
      /Unknown capability/,
    );
    assert.throws(() => runtime.advance(-1), /nonnegative/);
    assert.throws(() => runtime.advance(NaN), /nonnegative/);
    a.requestDecision({});
    b.requestDecision({});
    runtime.advance(0.2);
    await settle();
    runtime.advance(0.3);
    assert.equal(runtime.stats.time, 0.5);
    assert.equal(runtime.stats.droppedEvents, 1);
    assert.equal(runtime.drainEvents().length, 1);
    assert.equal(runtime.drainEvents().length, 0);
  } finally {
    runtime.dispose();
  }
});

test('throwing adapter capture settles as failure and releases capacity for subsequent work', async (t) => {
  for (const throwOnRead of [1, 2]) {
    let calls = 0;
    const runtime = new CharacterRuntime({
      gameId: 'capture-failure',
      maxConcurrent: 1,
      reasoning: {
        decide: () => {
          if (++calls > 1) return { dialogue: 'next decision' };
          let reads = 0;
          return Object.defineProperty({}, 'dialogue', {
            enumerable: true,
            get() {
              if (++reads === throwOnRead)
                throw new Error('adapter accessor failed');
              return 'captured before clone';
            },
          });
        },
      },
    });
    t.after(() => runtime.dispose());
    const actor = runtime.register(character());
    actor.requestDecision({});
    runtime.advance(0);
    await settle();
    runtime.advance(0);
    assert.equal(runtime.stats.pending, 0);
    assert.equal(runtime.stats.active, 0);
    assert.equal(actor.snapshot().pendingDecision, null);
    assert.equal(runtime.drainEvents()[0].kind, 'failed');
    assert.equal(actor.requestDecision({}).status, 'accepted');
    runtime.advance(0);
    await settle();
    runtime.advance(0);
    assert.equal(actor.snapshot().lastDecision.dialogue, 'next decision');
    assert.equal(runtime.stats.active, 0);
  }
});

test('reentrant capture advancement and disposal cannot publish obsolete results or strand next job', async () => {
  let runtime,
    calls = 0;
  runtime = new CharacterRuntime({
    gameId: 'reentrant-capture',
    maxConcurrent: 1,
    reasoning: {
      decide: () => {
        if (++calls > 1) return { dialogue: 'second actor' };
        return Object.defineProperty({}, 'dialogue', {
          enumerable: true,
          get() {
            runtime.advance(0);
            throw new Error('reentrant capture');
          },
        });
      },
    },
  });
  const first = runtime.register(character('first'));
  const second = runtime.register(character('second'));
  first.requestDecision({});
  second.requestDecision({});
  runtime.advance(0);
  await settle();
  runtime.advance(0);
  await settle();
  runtime.advance(0);
  assert.equal(second.snapshot().lastDecision.dialogue, 'second actor');
  assert.equal(runtime.stats.active, 0);
  assert.equal(runtime.stats.pending, 0);
  runtime.dispose();
  const disposed = new CharacterRuntime({
    gameId: 'dispose-capture',
    reasoning: {
      decide: () =>
        Object.defineProperty({}, 'dialogue', {
          enumerable: true,
          get() {
            disposed.dispose();
            throw new Error('dispose during capture');
          },
        }),
    },
  });
  disposed.register(character()).requestDecision({});
  disposed.advance(0);
  await settle();
  assert.equal(disposed.stats.disposed, true);
  assert.equal(
    disposed
      .drainEvents()
      .filter((event) => event.kind === 'decision' || event.kind === 'failed')
      .length,
    0,
  );
});
