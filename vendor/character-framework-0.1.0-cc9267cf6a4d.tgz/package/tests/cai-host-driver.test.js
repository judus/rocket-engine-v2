import test from 'node:test';
import assert from 'node:assert/strict';
import { CaiHostDriver, CharacterHostPort } from '../dist/src/host/index.js';
const session = {
  id: '81',
  characterId: '42',
  bindingKey: 'forester',
  version: 0,
  mode: 'game',
  continuityMode: 'session',
  bindingGeneration: 'G1',
};
const initial = () => ({
  schemaVersion: 1,
  conversation: {
    schemaVersion: 1,
    session,
    pending: null,
    feedback: [],
    reported: [],
  },
  operations: [],
});
function fixture() {
  const calls = [],
    receipts = new Map(),
    stored = [];
  let lose = false,
    failAck = false;
  const backend = {
    attach: async () => session,
    event: async () => {
      throw new Error('No events');
    },
    turn: async (_, input) => {
      calls.push(structuredClone(input));
      let reply = receipts.get(input.request_id);
      if (!reply) {
        reply = {
          requestId: input.request_id,
          message: 'A durable reply',
          session: { ...session, version: input.version + 1 },
        };
        receipts.set(input.request_id, reply);
      }
      if (lose) {
        lose = false;
        throw new Error('lost');
      }
      return reply;
    },
  };
  const persist = async (saved) => {
    if (
      failAck &&
      !saved.conversation.pending &&
      saved.operations.some((op) => op.receipt)
    )
      throw new Error('disk');
    stored.push(structuredClone(saved));
  };
  const create = (saved = initial()) =>
    new CaiHostDriver({ backend, saved, persist, current: () => undefined });
  return {
    backend,
    calls,
    receipts,
    stored,
    persist,
    create,
    lose: () => {
      lose = true;
    },
    failAck: (value) => {
      failAck = value;
    },
  };
}
const intent = { kind: 'dialogue', message: 'Hello' };
test('driver receipt is stored atomically with conversation acknowledgment before port acknowledgment', async () => {
  const f = fixture(),
    driver = f.create();
  assert.equal(
    await driver.run('host-one', 'effect-one', intent),
    'A durable reply',
  );
  const durable = f.stored.at(-1);
  assert.equal(durable.conversation.pending, null);
  assert.equal(durable.conversation.session.version, 1);
  assert.equal(
    durable.operations[0].input.request_id,
    durable.operations[0].receipt.requestId,
  );
  const restored = f.create(JSON.parse(JSON.stringify(durable)));
  assert.equal(
    await restored.run('host-one', 'effect-one', intent),
    'A durable reply',
  );
  assert.equal(f.calls.length, 1);
  await assert.rejects(
    restored.run('host-one', 'different-effect', intent),
    /conflict/,
  );
  await assert.rejects(
    restored.run('host-one', 'effect-one', {
      kind: 'dialogue',
      message: 'Changed',
    }),
    /conflict/,
  );
});
test('lost reply restore retries exact CAI UUID/input/version without creating another turn', async () => {
  const f = fixture(),
    driver = f.create();
  f.lose();
  await assert.rejects(driver.run('host-one', 'effect-one', intent), /lost/);
  const durable = f.stored.at(-1);
  assert.equal(durable.conversation.pending.kind, 'turn');
  const restored = f.create(JSON.parse(JSON.stringify(durable)));
  assert.equal(
    await restored.run('host-one', 'effect-one', intent),
    'A durable reply',
  );
  assert.deepEqual(f.calls[0], f.calls[1]);
  assert.equal(f.receipts.size, 1);
});
test('failed conversation acknowledgment stores no port result; live retry persists known receipt without I/O', async () => {
  const f = fixture(),
    driver = f.create();
  f.failAck(true);
  await assert.rejects(driver.run('host-one', 'effect-one', intent), /disk/);
  assert.notEqual(driver.save().conversation.pending, null);
  f.failAck(false);
  assert.equal(
    await driver.run('host-one', 'effect-one', intent),
    'A durable reply',
  );
  assert.equal(f.calls.length, 1);
  assert.equal(
    f.stored.at(-1).operations[0].receipt.message,
    'A durable reply',
  );
});
test('port acknowledgment crash restores known CAI result without provider regeneration', async () => {
  const f = fixture(),
    driver = f.create();
  let portSaved;
  const port = new CharacterHostPort(driver, async (saved) => {
    if (saved.operations.some((op) => op.done)) throw new Error('port disk');
    portSaved = structuredClone(saved);
  });
  await assert.rejects(
    port.dispatch({
      kind: 'dialogue',
      requestId: 'ui-one',
      expectedRevision: 0,
      message: 'Hello',
    }),
    /port disk/,
  );
  const restoredDriver = f.create(f.stored.at(-1));
  const restored = new CharacterHostPort(
    restoredDriver,
    () => undefined,
    portSaved,
  );
  await restored.dispatch({
    kind: 'retry',
    requestId: 'ui-retry',
    failedRequestId: 'ui-one',
  });
  assert.equal(f.calls.length, 1);
  assert.equal(restored.read().messages.length, 2);
});
test('trusted choice callback retains its original effect and result without CAI invocation', async () => {
  const f = fixture();
  let choices = 0;
  const options = {
    backend: f.backend,
    saved: initial(),
    persist: f.persist,
    current: () => undefined,
    choices: () => [{ id: 'offer/accept', label: 'Accept' }],
    choose: async (id, effect) => {
      assert.equal(id, 'offer/accept');
      assert.equal(effect, 'same-effect');
      choices++;
      return 'Accepted';
    },
  };
  const driver = new CaiHostDriver(options);
  assert.equal(
    await driver.run('choice', 'same-effect', {
      kind: 'choice',
      choiceId: 'offer/accept',
    }),
    'Accepted',
  );
  const restored = new CaiHostDriver({ ...options, saved: f.stored.at(-1) });
  assert.equal(
    await restored.run('choice', 'same-effect', {
      kind: 'choice',
      choiceId: 'offer/accept',
    }),
    'Accepted',
  );
  assert.equal(choices, 1);
  assert.equal(f.calls.length, 0);
});
test('driver disposal blocks late acknowledgment while preserving original pending checkpoint', async () => {
  const f = fixture();
  let release;
  f.backend.turn = () =>
    new Promise((resolve) => {
      release = resolve;
    });
  const driver = f.create();
  const pending = driver.run('host-one', 'effect-one', intent);
  const rejected = assert.rejects(pending, /disposed/);
  await new Promise((resolve) => setImmediate(resolve));
  const input = driver.save().conversation.pending.input;
  driver.dispose();
  release({
    requestId: input.request_id,
    message: 'late',
    session: { ...session, version: 1 },
  });
  await rejected;
  assert.notEqual(f.stored.at(-1).conversation.pending, null);
});

test('durable authoritative feedback flushes before the mapped dialogue and advances its original version', async () => {
  const f = fixture();
  const events = [];
  f.backend.event = async (_, input) => {
    events.push(structuredClone(input));
    return { eventId: input.event_id, version: input.version + 1 };
  };
  const driver = f.create();
  await driver.persistFeedback({
    sourceId: 'world/quest-completed',
    origin: 'game_outcome',
    type: 'quest_completed',
    summary: 'The world confirms completion.',
    references: {},
  });
  assert.equal(f.stored.at(-1).conversation.feedback.length, 1);
  assert.equal(
    await driver.run('followup', 'effect-followup', intent),
    'A durable reply',
  );
  assert.equal(events.length, 1);
  assert.equal(events[0].references.source_event_id, 'world/quest-completed');
  assert.equal(f.calls[0].version, 1);
  assert.equal(f.stored.at(-1).conversation.session.version, 2);
  assert.equal(f.stored.at(-1).conversation.feedback.length, 0);
  assert.equal(
    new CaiHostDriver({
      backend: f.backend,
      saved: f.stored.at(-1),
      persist: f.persist,
      current: () => undefined,
    }).save().conversation.session.version,
    2,
  );
});

for (const failure of ['event-transport', 'event-ack-storage']) {
  test(`pre-dialogue feedback ${failure} survives driver/port JSON restore with exact event and one turn`, async () => {
    const f = fixture();
    const eventCalls = [],
      eventReceipts = new Map();
    let failOnce = true,
      durableDriver,
      durablePort;
    f.backend.event = async (_, input) => {
      eventCalls.push(structuredClone(input));
      const receipt = eventReceipts.get(input.event_id) ?? {
        eventId: input.event_id,
        version: input.version + 1,
      };
      eventReceipts.set(input.event_id, receipt);
      if (failure === 'event-transport' && failOnce) {
        failOnce = false;
        throw new Error('lost event');
      }
      return receipt;
    };
    const persist = async (saved) => {
      if (
        failure === 'event-ack-storage' &&
        failOnce &&
        saved.conversation.session.version === 1 &&
        saved.conversation.pending === null
      ) {
        failOnce = false;
        throw new Error('event acknowledgment disk');
      }
      durableDriver = structuredClone(saved);
    };
    let driver = new CaiHostDriver({
      backend: f.backend,
      saved: initial(),
      persist,
      current: () => undefined,
    });
    await driver.persistFeedback({
      sourceId: 'quest/completed',
      origin: 'game_outcome',
      type: 'quest_completed',
      summary: 'Confirmed by the game.',
      references: {},
    });
    let port = new CharacterHostPort(driver, (saved) => {
      durablePort = structuredClone(saved);
    });
    await assert.rejects(
      port.dispatch({
        kind: 'dialogue',
        requestId: 'original-ui',
        expectedRevision: 0,
        message: 'Hello',
      }),
      /lost event|event acknowledgment disk/,
    );
    assert.equal(f.calls.length, 0);
    assert.equal(durableDriver.conversation.pending.kind, 'event');
    const eventInput = structuredClone(
      durableDriver.conversation.pending.input,
    );
    port.dispose();
    driver.dispose();
    driver = new CaiHostDriver({
      backend: f.backend,
      saved: JSON.parse(JSON.stringify(durableDriver)),
      persist,
      current: () => undefined,
    });
    port = new CharacterHostPort(
      driver,
      (saved) => {
        durablePort = structuredClone(saved);
      },
      JSON.parse(JSON.stringify(durablePort)),
    );
    await port.dispatch({
      kind: 'retry',
      requestId: 'new-ui-delivery',
      failedRequestId: 'original-ui',
    });
    assert.equal(eventCalls.length, 2);
    assert.deepEqual(eventCalls[0], eventCalls[1]);
    assert.deepEqual(eventCalls[1], eventInput);
    assert.equal(eventReceipts.size, 1);
    assert.equal(f.calls.length, 1);
    assert.equal(f.calls[0].version, 1);
    assert.equal(port.read().messages.length, 2);
    assert.equal(port.read().state, 'idle');
    assert.equal(durableDriver.conversation.session.version, 2);
    assert.equal(durableDriver.conversation.pending, null);
    assert.equal(
      durableDriver.operations[0].input.request_id,
      durableDriver.operations[0].receipt.requestId,
    );
  });
}
