import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import Ajv2020 from 'ajv/dist/2020.js';
import { createNarrativeScenario } from '../dist/examples/narrative-scenario.js';
import { createMcpScenario } from '../dist/examples/mcp-scenario.js';
import { FakeCaiClient } from '../examples/fake-cai-client.js';

const catalogue = JSON.parse(
  await readFile(
    new URL('../docs/contracts/tools.json', import.meta.url),
    'utf8',
  ),
);
const ajv = new Ajv2020({ strict: true, allowUnionTypes: true });
const outputs = new Map(
  catalogue.tools.map((tool) => [tool.name, ajv.compile(tool.outputSchema)]),
);
const empty = () => ({
  recipientRef: 'player-1',
  title: 'Small winter tasks',
  summary: 'Discover the winter story.',
  objectives: [],
});
async function pump(s, promise) {
  let done = false;
  promise.then(
    () => {
      done = true;
    },
    () => {
      done = true;
    },
  );
  for (let i = 0; i < 100 && !done; i++) {
    s.advance(0);
    await new Promise((r) => setImmediate(r));
  }
  assert.ok(done);
  return promise;
}
async function call(s, name, input, handle = s.directorNarrative, key) {
  const result = await pump(s, handle.call(name, input, key));
  const validate = outputs.get(name);
  assert.ok(validate(result), ajv.errorsText(validate.errors));
  return result;
}
async function compose(s, draft, change, handle) {
  const result = await call(
    s,
    'compose_quest_draft',
    { draft, change },
    handle,
  );
  assert.equal(result.status, 'completed', JSON.stringify(result));
  return result.data;
}

test('AI can compose individual template tasks and stages then publish once, without draft side effects', async () => {
  const s = createNarrativeScenario();
  try {
    const templates = await call(s, 'inspect_quest_templates', {});
    assert.equal(templates.data.templates[0].name, 'visit_location');
    let state = await compose(s, empty(), { kind: 'validate' });
    assert.equal(state.valid, false);
    assert.equal(state.issues[0].code, 'missing_objectives');
    state = await compose(s, state.draft, {
      kind: 'append_step',
      template: 'visit_location',
      arguments: { id: 'survey', locationRef: 'grove-1' },
    });
    assert.equal(state.valid, true);
    state = await compose(s, state.draft, {
      kind: 'append_stage',
      stage: { id: 'survey', objectives: ['survey'], next: 'town' },
    });
    assert.equal(state.valid, false);
    assert.equal(state.issues[0].code, 'invalid_flow');
    state = await compose(s, state.draft, {
      kind: 'append_step',
      template: 'visit_location',
      arguments: { id: 'town', locationRef: 'river-town' },
    });
    state = await compose(s, state.draft, {
      kind: 'append_stage',
      stage: { id: 'town', objectives: ['town'] },
    });
    assert.equal(state.valid, true);
    assert.deepEqual(
      (await compose(s, state.draft, { kind: 'validate' })).draft,
      state.draft,
    );
    assert.equal(s.narrative.stats.quests, 0);
    assert.equal(s.narrative.stats.receipts, 0);
    assert.equal(s.narrative.stats.pendingInspections, 0);
    assert.deepEqual(s.narrative.drainEvents(), []);
    const created = await call(
      s,
      'create_quest',
      { quest: state.draft },
      undefined,
      'publish',
    );
    assert.equal(created.status, 'completed');
    assert.equal(s.narrative.stats.quests, 1);
    assert.deepEqual(
      await call(
        s,
        'create_quest',
        { quest: state.draft },
        undefined,
        'publish',
      ),
      created,
    );
    state = await compose(s, state.draft, {
      kind: 'remove_objective',
      id: 'town',
    });
    assert.equal(state.valid, false);
    assert.equal(s.narrative.save().quests[0].definition.objectives.length, 2);
  } finally {
    s.dispose();
  }
});

test('draft corrections respect actor scope and invalid edits cannot publish or modify prior data', async () => {
  const s = createNarrativeScenario();
  try {
    const state = await compose(
      s,
      empty(),
      {
        kind: 'append_step',
        template: 'visit_location',
        arguments: { id: 'task', locationRef: 'river-town' },
      },
      s.foresterNarrative,
    );
    assert.equal(state.valid, false);
    assert.equal(state.issues[0].code, 'invalid_condition');
    assert.equal(
      (
        await call(
          s,
          'create_quest',
          { quest: state.draft },
          s.foresterNarrative,
          'bad',
        )
      ).status,
      'rejected',
    );
    const objective = s.draft('Corrected', 'grove-1').toInput().quest
      .objectives[0];
    const corrected = await compose(
      s,
      state.draft,
      { kind: 'replace_objective', objective: { ...objective, id: 'task' } },
      s.foresterNarrative,
    );
    assert.equal(corrected.valid, true);
    assert.equal(
      state.draft.objectives[0].condition.arguments.locationRef,
      'river-town',
    );
    for (const change of [
      { kind: 'append_step', template: 'invented', arguments: {} },
      {
        kind: 'append_step',
        template: 'visit_location',
        arguments: { id: 'other', locationRef: 3 },
      },
      { kind: 'append_objective', objective: corrected.draft.objectives[0] },
      { kind: 'remove_objective', id: 'missing' },
    ])
      assert.equal(
        (
          await call(s, 'compose_quest_draft', {
            draft: corrected.draft,
            change,
          })
        ).code,
        'invalid_draft_change',
      );
    assert.equal(
      (
        await call(s, 'compose_quest_draft', {
          draft: empty(),
          change: { kind: 'validate' },
          characterRef: 'director',
        })
      ).code,
      'invalid_arguments',
    );
    assert.equal(s.narrative.stats.quests, 0);
    const withoutFlow = await compose(s, corrected.draft, {
      kind: 'set_flow',
      flow: null,
    });
    assert.ok(!Object.hasOwn(withoutFlow.draft, 'flow'));
  } finally {
    s.dispose();
  }
});

test('official MCP discovery supports pure incremental authoring without effect keys and registers only at publish', async (t) => {
  const s = createMcpScenario('test-authoring-only');
  t.after(() => s.dispose());
  const client = new FakeCaiClient(
    new URL('http://127.0.0.1:8094/mcp'),
    s.directorHeaders,
    'test-authoring-only',
    (url, init) => s.gateway.handle(new Request(url, init)),
  );
  await client.connect();
  t.after(() => client.close());
  const tools = await client.client.listTools();
  assert.equal(
    tools.tools.find((tool) => tool.name === 'compose_quest_draft').annotations
      .readOnlyHint,
    true,
  );
  const templates = await pump(
    s,
    client.call(
      'inspect_quest_templates',
      {},
      { callId: 'templates', turnId: 'author' },
    ),
  );
  assert.equal(
    templates.structuredContent.data.templates[0].name,
    'visit_location',
  );
  const input = {
    draft: empty(),
    change: {
      kind: 'append_step',
      template: 'visit_location',
      arguments: { id: 'task', locationRef: 'grove-1' },
    },
  };
  const first = await pump(
    s,
    client.call('compose_quest_draft', input, {
      callId: 'step-1',
      turnId: 'author',
    }),
  );
  const second = await pump(
    s,
    client.call('compose_quest_draft', input, {
      callId: 'step-2',
      turnId: 'author',
    }),
  );
  assert.deepEqual(first.structuredContent, second.structuredContent);
  assert.equal(s.narrative.stats.quests, 0);
  assert.equal(s.gateway.saveReceipts().receipts.length, 0);
  const published = await pump(
    s,
    client.call(
      'create_quest',
      { quest: first.structuredContent.data.draft },
      { callId: 'publish', turnId: 'author', effectKey: 'publish-once' },
    ),
  );
  assert.equal(published.structuredContent.status, 'completed');
  assert.equal(s.narrative.stats.quests, 1);
});

test('draft capacities and retired registrations reject edits without shared authoring state', async () => {
  const s = createNarrativeScenario();
  try {
    let state = { draft: empty() };
    for (let i = 0; i < 8; i++)
      state = await compose(s, state.draft, {
        kind: 'append_step',
        template: 'visit_location',
        arguments: { id: `o${i}`, locationRef: 'grove-1' },
      });
    assert.equal(
      (
        await call(s, 'compose_quest_draft', {
          draft: state.draft,
          change: {
            kind: 'append_step',
            template: 'visit_location',
            arguments: { id: 'ninth', locationRef: 'grove-1' },
          },
        })
      ).code,
      'invalid_draft_change',
    );
    for (let i = 0; i < 8; i++)
      state = await compose(s, state.draft, {
        kind: 'append_stage',
        stage: {
          id: `s${i}`,
          objectives: [`o${i}`],
          ...(i < 7 ? { next: `s${i + 1}` } : {}),
        },
      });
    assert.equal(state.valid, true);
    assert.equal(
      (
        await call(s, 'compose_quest_draft', {
          draft: state.draft,
          change: {
            kind: 'append_stage',
            stage: { id: 'ninth', objectives: ['o0'] },
          },
        })
      ).code,
      'invalid_draft_change',
    );
    const arguments_ = Object.fromEntries(
      Array.from({ length: 17 }, (_, i) => [`a${i}`, 'value']),
    );
    assert.equal(
      (
        await call(s, 'compose_quest_draft', {
          draft: empty(),
          change: {
            kind: 'append_step',
            template: 'visit_location',
            arguments: arguments_,
          },
        })
      ).code,
      'invalid_arguments',
    );
    const pending = s.directorNarrative.call('compose_quest_draft', {
      draft: state.draft,
      change: { kind: 'validate' },
    });
    s.director.unregister();
    assert.equal((await pump(s, pending)).code, 'unregistered');
    assert.equal(s.narrative.stats.quests, 0);
    assert.equal(s.narrative.stats.receipts, 0);
    assert.deepEqual(s.narrative.drainEvents(), []);
  } finally {
    s.dispose();
  }
});
