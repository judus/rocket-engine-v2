import test from 'node:test';
import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import {
  CaiConversation,
  CaiHttpBackend,
  CaiHttpError,
  decodeCaiEventReceipt,
} from '../dist/src/cai/index.js';
import { FakeCaiBackend } from '../dist/examples/fake-cai-backend.js';
import { createChatScenario } from '../dist/examples/chat-scenario.js';

const binding = { characterId: 'demo-profile-1', bindingKey: 'forester' };
const signal = () => new AbortController().signal;
const feedback = (id = 'framework-event-1') => ({
  sourceId: id,
  origin: 'framework_narrative',
  type: 'quest_completed',
  summary: 'Player visited the grove.',
  references: { quest_id: 'quest-1' },
});
async function pump(scenario, promise) {
  let done = false;
  promise.then(
    () => {
      done = true;
    },
    () => {
      done = true;
    },
  );
  for (let i = 0; i < 1000 && !done; i++) {
    scenario.advance(0);
    await setImmediate();
  }
  assert.ok(done);
  return promise;
}

test('persistent sessions isolate characters and feedback reaches the same session before player dialogue', async () => {
  const backend = new FakeCaiBackend(async () => {});
  const mara = await CaiConversation.attach(backend, binding, signal());
  const director = await CaiConversation.attach(
    backend,
    { characterId: 'demo-profile-2', bindingKey: 'director' },
    signal(),
  );
  assert.notEqual(mara.status.session.id, director.status.session.id);
  mara.enqueueFeedback(feedback());
  mara.enqueueFeedback(feedback());
  assert.equal(mara.status.queuedFeedback, 1);
  assert.match(await mara.dialogue('Did you notice my work?'), /remember/);
  assert.doesNotMatch(
    await director.dialogue('Did you notice my work?'),
    /remember/,
  );
  assert.equal(mara.status.session.version, 2);
  assert.equal(director.status.session.version, 1);
  const reopened = await CaiConversation.attach(
    backend,
    { ...binding, sessionId: mara.status.session.id },
    signal(),
  );
  assert.equal(reopened.status.session.id, mara.status.session.id);
  assert.match(await reopened.dialogue('Hello again'), /remember/);
});

test('unknown turn outcomes retain exact IDs/versions through JSON restore and block fresh turns', async () => {
  const real = new FakeCaiBackend(async () => {});
  const calls = [];
  let drop = true;
  const backend = {
    attach: (...args) => real.attach(...args),
    event: (...args) => real.event(...args),
    turn: async (...args) => {
      calls.push(structuredClone(args[1]));
      const receipt = await real.turn(...args);
      if (drop) {
        drop = false;
        throw new Error('Lost reply');
      }
      return receipt;
    },
  };
  const conversation = await CaiConversation.attach(backend, binding, signal());
  await assert.rejects(conversation.dialogue('Hello'), /Lost reply/);
  await assert.rejects(conversation.dialogue('A new request'), /pending/);
  const saved = JSON.parse(JSON.stringify(conversation.save()));
  const restored = new CaiConversation(backend, saved);
  assert.match(await restored.retry(), /Trees/);
  assert.deepEqual(calls[0], calls[1]);
  assert.equal(restored.status.session.version, 1);
  assert.equal(restored.status.pending, null);
});

test('feedback outbox persists failed delivery with one event ID and does not generate dialogue', async () => {
  const real = new FakeCaiBackend(async () => {});
  let drop = true;
  let turns = 0;
  const calls = [];
  const backend = {
    attach: (...args) => real.attach(...args),
    turn: (...args) => {
      turns++;
      return real.turn(...args);
    },
    event: async (...args) => {
      calls.push(structuredClone(args[1]));
      const receipt = await real.event(...args);
      if (drop) {
        drop = false;
        throw new Error('Lost event ack');
      }
      return receipt;
    },
  };
  const conversation = await CaiConversation.attach(backend, binding, signal());
  conversation.enqueueFeedback(feedback());
  await assert.rejects(conversation.flushFeedback(), /Lost event ack/);
  const restored = new CaiConversation(
    backend,
    JSON.parse(JSON.stringify(conversation.save())),
  );
  await restored.retry();
  assert.deepEqual(calls[0], calls[1]);
  assert.equal(turns, 0);
  assert.equal(restored.status.queuedFeedback, 0);
  assert.equal(restored.status.session.version, 1);
  restored.enqueueFeedback(feedback());
  assert.equal(restored.status.queuedFeedback, 0);
});

test('registration removal ignores late replies while retaining the uncertain request', async () => {
  let settle;
  let current = true;
  const session = {
    id: 'session',
    characterId: binding.characterId,
    bindingKey: binding.bindingKey,
    version: 0,
    mode: 'game',
    continuityMode: 'session',
  };
  const backend = {
    attach: async () => session,
    turn: (_, input) =>
      new Promise((resolve) => {
        settle = () =>
          resolve({
            requestId: input.request_id,
            message: 'Late reply',
            session: { ...session, version: 1 },
          });
      }),
    event: async () => {
      throw new Error('unused');
    },
  };
  const conversation = await CaiConversation.attach(
    backend,
    binding,
    signal(),
    () => {
      if (!current) throw new Error('Retired binding');
    },
  );
  const pending = conversation.dialogue('Hello');
  await setImmediate();
  await assert.rejects(conversation.dialogue('Concurrent'), /busy/);
  current = false;
  settle();
  await assert.rejects(pending, /Retired/);
  assert.equal(conversation.save().session.version, 0);
  assert.equal(conversation.save().pending.kind, 'turn');
});

test('invalid receipts and corrupt checkpoints cannot advance state or invent success', async () => {
  const real = new FakeCaiBackend(async () => {});
  const backend = {
    attach: (...args) => real.attach(...args),
    event: (...args) => real.event(...args),
    turn: async (...args) => ({
      ...(await real.turn(...args)),
      requestId: 'wrong-id',
    }),
  };
  const conversation = await CaiConversation.attach(backend, binding, signal());
  await assert.rejects(conversation.dialogue('Hello'), /receipt/);
  assert.equal(conversation.status.session.version, 0);
  const saved = conversation.save();
  assert.throws(
    () =>
      new CaiConversation(backend, {
        ...saved,
        session: { ...saved.session, mode: 'standalone' },
      }),
    /checkpoint/,
  );
  assert.throws(
    () =>
      new CaiConversation(backend, {
        ...saved,
        pending: {
          ...saved.pending,
          input: { ...saved.pending.input, version: 10 },
        },
      }),
    /checkpoint/,
  );
  const fresh = await CaiConversation.attach(real, binding, signal());
  fresh.enqueueFeedback(feedback());
  assert.throws(
    () => fresh.enqueueFeedback({ ...feedback(), summary: 'Changed fact' }),
    /conflicts/,
  );
});

test('HTTP adapter uses agreed route families, verifies game mode and leaves credentials out of errors', async () => {
  const calls = [];
  const wireSession = {
    id: 81,
    character: { id: 42 },
    binding_key: 'forester',
    binding_generation: null,
    mode: 'game',
    continuity_mode: 'session',
    version: 0,
  };
  let next = { data: wireSession };
  const backend = new CaiHttpBackend({
    origin: 'http://cai.test',
    token: 'private-token',
    enableGameDraft: true,
    decodeEvent: (body) => ({
      eventId: body.data.event_id,
      version: body.data.version,
    }),
    fetch: async (url, init) => {
      calls.push({ url, init });
      return Response.json(next);
    },
  });
  const attached = await backend.attach(
    { characterId: '42', bindingKey: 'forester' },
    signal(),
  );
  assert.equal(attached.id, '81');
  assert.equal(
    calls[0].url,
    'http://cai.test/api/v1/companion/characters/42/sessions',
  );
  assert.deepEqual(JSON.parse(calls[0].init.body), {
    mode: 'game',
    continuity_mode: 'session',
    binding_key: 'forester',
  });
  assert.equal(calls[0].init.redirect, 'error');
  const input = {
    request_id: 'retained-id',
    version: 0,
    origin: 'player_dialogue',
    message: 'Hi',
  };
  next = {
    data: {
      turn: { request_id: input.request_id, message: 'Hello' },
      session: { ...wireSession, version: 1 },
    },
  };
  assert.equal((await backend.turn('81', input, signal())).session.version, 1);
  assert.deepEqual(JSON.parse(calls[1].init.body), input);
  next = { data: { event_id: 'event-1', version: 2 } };
  assert.equal(
    (
      await backend.event(
        '81',
        {
          event_id: 'event-1',
          version: 1,
          origin: 'framework_narrative',
          type: 'quest_completed',
          summary: 'Done',
          references: {},
        },
        signal(),
      )
    ).version,
    2,
  );
  next = { data: { ...wireSession, mode: undefined } };
  await assert.rejects(
    backend.attach(
      { characterId: '42', bindingKey: 'forester', sessionId: '81' },
      signal(),
    ),
    /game mode/,
  );
  const failing = new CaiHttpBackend({
    origin: 'http://cai.test',
    token: 'private-token',
    enableGameDraft: true,
    decodeEvent: () => {
      throw new Error('unused');
    },
    fetch: async () =>
      Response.json({ message: 'private-token' }, { status: 409 }),
  });
  await assert.rejects(
    failing.turn('81', input, signal()),
    (error) =>
      error instanceof CaiHttpError &&
      error.status === 409 &&
      !error.message.includes('private-token'),
  );
});

test('simple demo completes one framework quest then recalls confirmed completion', async (t) => {
  const scenario = createChatScenario();
  t.after(() => scenario.dispose());
  const { forester, director } = await scenario.attach();
  assert.equal(
    forester.status.session.id,
    scenario.forester.snapshot().cai.sessionId,
  );
  await pump(
    scenario,
    forester.requestNarrative('Offer the player a woodland errand.'),
  );
  const quest = scenario.narrative.save().quests[0];
  assert.equal(quest.offer.status, 'offered');
  await pump(
    scenario,
    scenario.narrative.choose(
      'player-1',
      quest.offer.id + '/accept',
      'player-accept',
    ),
  );
  scenario.visit('grove-1');
  scenario.advance(0);
  await setImmediate();
  scenario.advance(0);
  assert.equal(scenario.narrative.save().quests[0].offer.status, 'completed');
  for (const event of scenario.narrative.drainEvents())
    forester.enqueueFeedback({
      sourceId: event.id,
      origin: event.origin,
      type: event.type,
      summary: event.type,
      references: { quest_id: event.questId },
    });
  assert.match(await forester.dialogue('I visited the grove.'), /remember/);
  assert.equal(director.status.session.version, 0);
  assert.equal(scenario.narrative.stats.quests, 1);
});

test('host persistence precedes remote dispatch and storage failure leaves a retryable exact request', async () => {
  const real = new FakeCaiBackend(async () => {});
  let durable = null,
    fail = true,
    calls = 0;
  const backend = {
    attach: (...args) => real.attach(...args),
    event: (...args) => real.event(...args),
    turn: (...args) => {
      calls++;
      assert.deepEqual(durable.pending.input, args[1]);
      return real.turn(...args);
    },
  };
  const conversation = await CaiConversation.attach(
    backend,
    binding,
    signal(),
    () => {},
    (snapshot) => {
      if (fail) throw new Error('Storage unavailable');
      durable = structuredClone(snapshot);
    },
  );
  await assert.rejects(conversation.dialogue('Hello'), /Storage unavailable/);
  assert.equal(calls, 0);
  const original = conversation.save().pending.input;
  fail = false;
  await conversation.retry();
  assert.equal(calls, 1);
  assert.equal(durable.pending, null);
  assert.equal(durable.session.version, 1);
  assert.equal(original.request_id.length, 36);
});

for (const kind of ['turn', 'event']) {
  test(`failed ${kind} acknowledgment storage retains live recovery and exact input`, async () => {
    const real = new FakeCaiBackend(async () => {});
    const calls = [];
    let failAck = true,
      durable;
    const backend = {
      attach: (...args) => real.attach(...args),
      turn: (...args) => {
        calls.push(structuredClone(args[1]));
        return real.turn(...args);
      },
      event: (...args) => {
        calls.push(structuredClone(args[1]));
        return real.event(...args);
      },
    };
    const conversation = await CaiConversation.attach(
      backend,
      binding,
      signal(),
      () => {},
      (state) => {
        if (failAck && state.pending === null && state.session.version > 0)
          throw new Error('Ack storage unavailable');
        durable = structuredClone(state);
      },
    );
    if (kind === 'event') conversation.enqueueFeedback(feedback());
    await assert.rejects(
      kind === 'turn'
        ? conversation.dialogue('Hello')
        : conversation.flushFeedback(),
      /Ack storage/,
    );
    assert.equal(conversation.status.pending, kind);
    assert.equal(conversation.status.session.version, 0);
    assert.equal(conversation.status.queuedFeedback, kind === 'event' ? 1 : 0);
    assert.deepEqual(conversation.save().pending, durable.pending);
    await assert.rejects(conversation.dialogue('Fresh request'), /pending/);
    assert.equal(calls.length, 1);
    failAck = false;
    const reply = await conversation.retry();
    assert.deepEqual(calls[1], calls[0]);
    assert.equal(conversation.status.session.version, 1);
    assert.equal(conversation.status.pending, null);
    assert.equal(durable.pending, null);
    if (kind === 'turn') assert.match(reply, /Trees/);
    else {
      assert.equal(reply, null);
      assert.equal(conversation.status.queuedFeedback, 0);
    }
  });
}

test('source-event reference is automatic, immutable on replay and rejects conflicting caller values', async () => {
  const real = new FakeCaiBackend(async () => {});
  const calls = [];
  let lose = true;
  const backend = {
    attach: (...args) => real.attach(...args),
    turn: (...args) => real.turn(...args),
    event: async (...args) => {
      calls.push(structuredClone(args[1]));
      const receipt = await real.event(...args);
      if (lose) {
        lose = false;
        throw new Error('Lost ack');
      }
      return receipt;
    },
  };
  const conversation = await CaiConversation.attach(backend, binding, signal());
  assert.throws(
    () =>
      conversation.enqueueFeedback({
        ...feedback(),
        references: { source_event_id: 'forged-source' },
      }),
    /source_event_id/,
  );
  assert.equal(conversation.status.queuedFeedback, 0);
  conversation.enqueueFeedback(feedback());
  await assert.rejects(conversation.flushFeedback(), /Lost ack/);
  const restored = new CaiConversation(
    backend,
    JSON.parse(JSON.stringify(conversation.save())),
  );
  await restored.retry();
  assert.equal(calls[0].references.source_event_id, feedback().sourceId);
  assert.equal(calls[0].references.quest_id, 'quest-1');
  assert.deepEqual(calls[1], calls[0]);
});

test('feedback added during acknowledgment persistence is durably retained', async () => {
  const real = new FakeCaiBackend(async () => {});
  let conversation,
    added = false,
    durable;
  conversation = await CaiConversation.attach(
    real,
    binding,
    signal(),
    () => {},
    (state) => {
      if (state.session.version === 1 && !state.pending && !added) {
        added = true;
        conversation.enqueueFeedback(feedback('second-event'));
      }
      durable = structuredClone(state);
    },
  );
  await conversation.dialogue('Hello');
  assert.equal(conversation.status.queuedFeedback, 1);
  assert.equal(durable.feedback[0].sourceId, 'second-event');
  await conversation.flushFeedback();
  assert.equal(durable.feedback.length, 0);
  assert.equal(conversation.status.session.version, 2);
});

test('agreed draft HTTP event receipts replay after a lost response with the same source and UUID', async () => {
  const requests = [];
  let receipt,
    lose = true;
  const backend = new CaiHttpBackend({
    origin: 'http://cai.test',
    token: 'fake-only',
    enableGameDraft: true,
    fetch: async (url, init) => {
      if (!url.endsWith('/events'))
        return Response.json(
          {
            data: {
              id: '81',
              character: { id: '42' },
              binding_key: 'forester',
              binding_generation: null,
              mode: 'game',
              continuity_mode: 'session',
              version: 0,
            },
          },
          { status: 201 },
        );
      const input = JSON.parse(init.body);
      requests.push(input);
      if (!receipt)
        receipt = { data: { event_id: input.event_id, version: 1 } };
      if (lose) {
        lose = false;
        throw new Error('Lost HTTP acknowledgment after commit');
      }
      return Response.json(receipt, { status: 200 });
    },
  });
  const conversation = await CaiConversation.attach(
    backend,
    { characterId: '42', bindingKey: 'forester' },
    signal(),
  );
  conversation.enqueueFeedback(feedback('host-event-17'));
  await assert.rejects(conversation.flushFeedback(), /Lost HTTP/);
  await conversation.retry();
  assert.deepEqual(requests[0], requests[1]);
  assert.equal(requests[0].references.source_event_id, 'host-event-17');
  assert.equal(conversation.status.session.version, 1);
  assert.equal(conversation.status.pending, null);
  assert.deepEqual(
    decodeCaiEventReceipt({ data: { event_id: 'event-2', version: 2 } }),
    { eventId: 'event-2', version: 2 },
  );
  for (const malformed of [
    {},
    { data: { event_id: '', version: 2 } },
    { data: { event_id: 'event-2', version: '2' } },
    { data: { event_id: 'event-2', version: -1 } },
    { data: { queued: true } },
  ])
    assert.throws(
      () => decodeCaiEventReceipt(malformed),
      /acknowledgment envelope/,
    );
});

test('nonblank turn validation runs before feedback dispatch or checkpoint persistence', async () => {
  const real = new FakeCaiBackend(async () => {});
  const requests = [],
    persisted = [];
  const backend = {
    attach: (...args) => real.attach(...args),
    event: async (...args) => {
      requests.push(args[1]);
      return real.event(...args);
    },
    turn: async (...args) => {
      requests.push(args[1]);
      return real.turn(...args);
    },
  };
  const conversation = await CaiConversation.attach(
    backend,
    binding,
    signal(),
    () => {},
    (state) => {
      persisted.push(state);
    },
  );
  conversation.enqueueFeedback(feedback());
  const before = conversation.save();
  for (const [message, context] of [
    [' \t\n', undefined],
    ['Hello', { facts: ' \n' }],
    ['Hello', { facts: 'World', actor_ref: ' \t' }],
    ['Hello', { facts: 'World', unsupported: true }],
    ['Hello', null],
    ['Hello', { facts: 'x'.repeat(4001) }],
    ['Hello', { facts: 'World', actor_ref: 'x'.repeat(161) }],
  ]) {
    await assert.rejects(conversation.dialogue(message, context), TypeError);
    await assert.rejects(
      conversation.requestNarrative(message, context),
      TypeError,
    );
    assert.deepEqual(conversation.save(), before);
  }
  assert.equal(requests.length, 0);
  assert.equal(persisted.length, 0);
  for (const mutate of [
    (input) => {
      input.message = ' \n';
    },
    (input) => {
      input.context.facts = ' \t';
    },
    (input) => {
      input.context.actor_ref = '\n';
    },
  ]) {
    const saved = structuredClone(before);
    saved.pending = {
      kind: 'turn',
      input: {
        request_id: crypto.randomUUID(),
        version: saved.session.version,
        origin: 'player_dialogue',
        message: 'Hello',
        context: { facts: 'World', actor_ref: 'actor' },
      },
    };
    mutate(saved.pending.input);
    assert.throws(() => new CaiConversation(backend, saved), /checkpoint/);
  }
});

test('valid multiline turn prose survives lost response, caller mutation and exact retry', async () => {
  const real = new FakeCaiBackend(async () => {});
  const requests = [],
    persisted = [];
  let lose = true;
  const backend = {
    attach: (...args) => real.attach(...args),
    event: (...args) => real.event(...args),
    turn: async (...args) => {
      requests.push(structuredClone(args[1]));
      const receipt = await real.turn(...args);
      if (lose) {
        lose = false;
        throw new Error('Lost reply');
      }
      return receipt;
    },
  };
  const conversation = await CaiConversation.attach(
    backend,
    binding,
    signal(),
    () => {},
    (state) => {
      persisted.push(state);
    },
  );
  const context = {
    facts: '  Forest\nThe grove is nearby.  ',
    actor_ref: '  workforce-17  ',
  };
  const original = structuredClone(context),
    message = '  Hello\nMara!  ';
  const pending = conversation.requestNarrative(message, context);
  context.facts = 'Changed after submission';
  context.actor_ref = 'other';
  await assert.rejects(pending, /Lost reply/);
  assert.deepEqual(requests[0].context, original);
  assert.equal(requests[0].message, message);
  assert.equal(persisted[0].pending.input.origin, 'framework_request');
  const restored = new CaiConversation(
    backend,
    JSON.parse(JSON.stringify(conversation.save())),
  );
  await restored.retry();
  assert.deepEqual(requests[0], requests[1]);
});

function failedTurnState() {
  return {
    schemaVersion: 1,
    session: {
      id: '1001',
      characterId: '1002',
      bindingKey: 'forester',
      version: 0,
      mode: 'game',
      continuityMode: 'session',
      bindingGeneration: 'G1',
    },
    pending: {
      kind: 'turn',
      input: {
        request_id: crypto.randomUUID(),
        version: 0,
        origin: 'player_dialogue',
        message: 'Hello',
      },
    },
    feedback: [],
    reported: [],
  };
}
function failurePage(state) {
  return {
    requestId: state.pending.input.request_id,
    inputVersion: 0,
    bindingGeneration: 'G1',
    session: { ...state.session, version: 1 },
    dialogueStatus: 'interrupted',
    continuationAllowed: true,
    turn: null,
    calls: [],
    nextCursor: null,
  };
}
test('failure acknowledgment persists before clearing pending and never dispatches or invents dialogue', async () => {
  const state = failedTurnState(),
    backend = {
      turn: async () => {
        throw new Error('Must not dispatch');
      },
    };
  let failSave = true;
  const snapshots = [],
    reads = [];
  const conversation = new CaiConversation(
    backend,
    state,
    () => {},
    (saved) => {
      snapshots.push(saved);
      if (failSave) throw new Error('Disk failure');
    },
  );
  const receipts = {
    readAttempt: async (...args) => {
      reads.push(args);
      return failurePage(state);
    },
  };
  await assert.rejects(
    conversation.acknowledgeFailure(receipts),
    /Disk failure/,
  );
  assert.deepEqual(conversation.save(), state);
  failSave = false;
  assert.equal(await conversation.acknowledgeFailure(receipts), undefined);
  assert.equal(conversation.status.pending, null);
  assert.equal(conversation.status.session.version, 1);
  assert.equal(reads[0][1], reads[1][1]);
  assert.equal(snapshots[0].pending, null);
  assert.deepEqual(conversation.save().reported, []);
});
test('failure acknowledgment blocks unknown, completed, mismatched and missing receipts', async () => {
  const state = failedTurnState();
  const conversation = new CaiConversation({}, state);
  for (const patch of [
    { continuationAllowed: false },
    { dialogueStatus: 'pending' },
    { dialogueStatus: 'completed' },
    { requestId: 'other' },
    { inputVersion: 1 },
    { bindingGeneration: 'G2' },
    { session: { ...state.session, id: 'other' } },
    {
      turn: {
        requestId: state.pending.input.request_id,
        version: 1,
        message: 'Done',
      },
    },
  ]) {
    await assert.rejects(
      conversation.acknowledgeFailure({
        readAttempt: async () => ({ ...failurePage(state), ...patch }),
      }),
      /does not authorize/,
    );
    assert.deepEqual(conversation.save(), state);
  }
  await assert.rejects(
    conversation.acknowledgeFailure({
      readAttempt: async () => {
        throw new Error('Missing receipt');
      },
    }),
    /Missing/,
  );
  assert.deepEqual(conversation.save(), state);
  const noGeneration = structuredClone(state);
  noGeneration.session.bindingGeneration = null;
  await assert.rejects(
    new CaiConversation({}, noGeneration).acknowledgeFailure({}),
    /generation required/,
  );
});
test('late acknowledgment is discarded on disposal and preserves feedback queued during persistence', async () => {
  const state = failedTurnState();
  let resolveRead;
  const disposed = new CaiConversation({}, state);
  const pending = disposed.acknowledgeFailure({
    readAttempt: () =>
      new Promise((resolve) => {
        resolveRead = resolve;
      }),
  });
  disposed.dispose();
  resolveRead(failurePage(state));
  await assert.rejects(pending, /disposed/);
  assert.deepEqual(disposed.save(), state);
  let saves = 0;
  let conversation;
  conversation = new CaiConversation(
    {},
    state,
    () => {},
    () => {
      if (++saves === 1) conversation.enqueueFeedback(feedback());
    },
  );
  await conversation.acknowledgeFailure({
    readAttempt: async () => failurePage(state),
  });
  assert.equal(saves, 2);
  assert.equal(conversation.status.queuedFeedback, 1);
  assert.equal(conversation.status.pending, null);
});

test('completed receipt read recovers dialogue once durable without regenerating or adopting committed version as current', async () => {
  const state = failedTurnState();
  let failSave = true;
  let reads = 0;
  const page = {
    ...failurePage(state),
    dialogueStatus: 'completed',
    session: { ...state.session, version: 3, bindingGeneration: 'G2' },
    turn: {
      requestId: state.pending.input.request_id,
      version: 1,
      message: 'Retained reply',
    },
  };
  const backend = {
    turn: async () => {
      throw new Error('No provider retry');
    },
  };
  const conversation = new CaiConversation(
    backend,
    state,
    () => {},
    () => {
      if (failSave) throw new Error('Disk failure');
    },
  );
  const receipts = {
    readAttempt: async () => {
      reads++;
      return page;
    },
  };
  await assert.rejects(
    conversation.reconcileCompleted(receipts),
    /Disk failure/,
  );
  assert.deepEqual(conversation.save(), state);
  failSave = false;
  assert.equal(
    await conversation.reconcileCompleted(receipts),
    'Retained reply',
  );
  assert.equal(reads, 2);
  assert.equal(conversation.status.pending, null);
  assert.equal(conversation.status.session.version, 3);
  assert.equal(conversation.status.session.bindingGeneration, 'G2');
});
test('completed reconciliation rejects unsettled, failed, mismatched and invalid committed replies', async () => {
  const state = failedTurnState();
  const conversation = new CaiConversation({}, state);
  const page = {
    ...failurePage(state),
    dialogueStatus: 'completed',
    turn: {
      requestId: state.pending.input.request_id,
      version: 1,
      message: 'Reply',
    },
  };
  for (const patch of [
    { continuationAllowed: false },
    { dialogueStatus: 'interrupted' },
    { turn: null },
    { inputVersion: 1 },
    { bindingGeneration: 'G2' },
    { turn: { ...page.turn, requestId: 'other' } },
    { turn: { ...page.turn, version: 0 } },
    { turn: { ...page.turn, version: 2 } },
    { turn: { ...page.turn, message: '' } },
  ]) {
    await assert.rejects(
      conversation.reconcileCompleted({
        readAttempt: async () => ({ ...page, ...patch }),
      }),
    );
    assert.deepEqual(conversation.save(), state);
  }
});
