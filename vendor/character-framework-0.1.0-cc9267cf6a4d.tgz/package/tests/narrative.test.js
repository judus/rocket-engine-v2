import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import Ajv2020 from 'ajv/dist/2020.js';
import {
  CharacterRuntime,
  NarrativeSystem,
  QuestDraft,
} from '../dist/src/index.js';
import { createNarrativeScenario } from '../dist/examples/narrative-scenario.js';

const schemas = JSON.parse(
  await readFile(
    new URL('../docs/contracts/tools.json', import.meta.url),
    'utf8',
  ),
);
const fixtures = JSON.parse(
  await readFile(
    new URL('../docs/contracts/examples.json', import.meta.url),
    'utf8',
  ),
);
const ajv = new Ajv2020({ strict: true, allowUnionTypes: true });
const validators = new Map(
  schemas.tools.map((tool) => [tool.name, ajv.compile(tool.outputSchema)]),
);
const settle = () => new Promise((resolve) => setImmediate(resolve));
async function commit(scenario, request) {
  scenario.advance(0);
  return request;
}
async function poll(scenario, count = 3) {
  for (let i = 0; i < count; i++) {
    scenario.advance(0.1);
    await settle();
  }
}
function data(result) {
  assert.equal(result.status, 'completed', JSON.stringify(result));
  return result.data;
}
async function create(
  scenario,
  handle = scenario.foresterNarrative,
  location = 'grove-1',
  key = 'create',
) {
  return data(
    await commit(
      scenario,
      handle.call(
        'create_quest',
        scenario.draft('Survey', location).toInput(),
        key,
      ),
    ),
  ).questId;
}
async function offer(
  scenario,
  questId,
  handle = scenario.foresterNarrative,
  key = 'offer',
) {
  return data(
    await commit(
      scenario,
      handle.call(
        'offer_quest',
        {
          questId,
          recipientRef: 'player-1',
          dialogue: 'Investigate this place.',
        },
        key,
      ),
    ),
  );
}
async function inspect(
  scenario,
  questId,
  handle = scenario.foresterNarrative,
  recipientRef = 'player-1',
) {
  return data(
    await commit(
      scenario,
      handle.call('inspect_quest', {
        questId,
        ...(recipientRef === null ? {} : { recipientRef }),
      }),
    ),
  );
}

test('forester and bodyless director independently create, offer, accept and complete schema-valid quests', async () => {
  const scenario = createNarrativeScenario();
  try {
    for (const [role, handle, location] of [
      ['forester', scenario.foresterNarrative, 'grove-1'],
      ['director', scenario.directorNarrative, 'river-town'],
    ]) {
      const scope = role === 'director' ? 'world' : 'local';
      const context = await commit(
        scenario,
        handle.call('inspect_context', { scope }),
      );
      assert.ok(validators.get('inspect_context')(context));
      assert.equal(
        context.data.entityRef,
        role === 'director' ? null : 'workforce-17',
      );
      const questId = await create(
        scenario,
        handle,
        location,
        role + '-create',
      );
      assert.equal(
        (await inspect(scenario, questId, handle)).status,
        'registered',
      );
      const offered = await offer(scenario, questId, handle, role + '-offer');
      assert.equal(offered.status, 'offered');
      assert.equal(
        (await inspect(scenario, questId, handle)).status,
        'offered',
      );
      assert.equal(scenario.narrative.stats.pendingInspections, 0);
      await commit(
        scenario,
        scenario.narrative.choose(
          'player-1',
          offered.choices[0].id,
          role + '-accept',
        ),
      );
      scenario.visit(location);
      await poll(scenario);
      const result = await commit(
        scenario,
        handle.call('inspect_quest', { questId, recipientRef: 'player-1' }),
      );
      assert.ok(
        validators.get('inspect_quest')(result),
        ajv.errorsText(validators.get('inspect_quest').errors),
      );
      assert.equal(result.data.status, 'completed');
      assert.equal(result.data.objectives[0].observed, true);
      assert.equal(result.data.choices.length, 0);
    }
    assert.equal(
      scenario.narrative
        .drainEvents()
        .filter((event) => event.type === 'quest_completed').length,
      2,
    );
  } finally {
    scenario.dispose();
  }
});

test('the proposed rejected examples execute as rejections and do not leave partial state', async () => {
  const scenario = createNarrativeScenario();
  try {
    for (const role of ['forester', 'director']) {
      const handle =
        role === 'forester'
          ? scenario.foresterNarrative
          : scenario.directorNarrative;
      const questId = await create(
        scenario,
        handle,
        role === 'director' ? 'river-town' : 'grove-1',
        role + '/create',
      );
      for (const fixture of fixtures.cases.filter(
        (example) =>
          example.actor === role && example.result.status === 'rejected',
      )) {
        const input = structuredClone(fixture.arguments);
        if (fixture.tool === 'offer_quest') input.questId = questId;
        const before = scenario.narrative.stats.quests;
        const result = await commit(
          scenario,
          handle.call(fixture.tool, input, fixture.effectKey),
        );
        assert.equal(result.status, 'rejected', fixture.id);
        assert.equal(result.code, fixture.result.code, fixture.id);
        assert.ok(validators.get(fixture.tool)(result));
        assert.equal(scenario.narrative.stats.quests, before);
      }
    }
  } finally {
    scenario.dispose();
  }
});

test('tool writes commit only under host advancement and cannot select a different character', async () => {
  const scenario = createNarrativeScenario();
  try {
    const promise = scenario.foresterNarrative.call(
      'create_quest',
      scenario.draft('Survey', 'grove-1').toInput(),
      'create',
    );
    await settle();
    assert.equal(scenario.narrative.stats.quests, 0);
    const questId = data(await commit(scenario, promise)).questId;
    assert.equal(
      (
        await commit(
          scenario,
          scenario.directorNarrative.call('inspect_quest', { questId }),
        )
      ).code,
      'quest_unavailable',
    );
    assert.equal(
      (
        await commit(
          scenario,
          scenario.foresterNarrative.call('inspect_context', {
            scope: 'world',
            characterRef: 'director',
          }),
        )
      ).code,
      'invalid_arguments',
    );
    const pending = scenario.foresterNarrative.call('inspect_context', {
      scope: 'local',
    });
    scenario.forester.unregister();
    assert.equal((await commit(scenario, pending)).code, 'unregistered');
    scenario.runtime.narrative.bind(scenario.registerForester());
    assert.equal(
      (
        await commit(
          scenario,
          scenario.foresterNarrative.call('inspect_context', {
            scope: 'local',
          }),
        )
      ).code,
      'unregistered',
    );
  } finally {
    scenario.dispose();
  }
});

test('canonical mutation replay, conflicts, terminal rejections and receipts survive checkpoint restore', async () => {
  const scenario = createNarrativeScenario();
  try {
    const input = scenario.draft('Survey', 'grove-1').toInput();
    const first = await commit(
      scenario,
      scenario.foresterNarrative.call('create_quest', input, 'create'),
    );
    const reordered = {
      quest: {
        summary: input.quest.summary,
        objectives: input.quest.objectives,
        title: input.quest.title,
        recipientRef: input.quest.recipientRef,
      },
    };
    assert.deepEqual(
      await commit(
        scenario,
        scenario.foresterNarrative.call('create_quest', reordered, 'create'),
      ),
      first,
    );
    assert.equal(scenario.narrative.stats.quests, 1);
    assert.equal(
      (
        await commit(
          scenario,
          scenario.foresterNarrative.call(
            'create_quest',
            { quest: { ...input.quest, title: 'Different' } },
            'create',
          ),
        )
      ).code,
      'effect_key_conflict',
    );
    const bad = { quest: { ...input.quest, objectives: [] } };
    const rejection = await commit(
      scenario,
      scenario.foresterNarrative.call('create_quest', bad, 'bad'),
    );
    const saved = JSON.parse(JSON.stringify(scenario.narrative.save()));
    scenario.narrative.restore(saved);
    assert.deepEqual(
      await commit(
        scenario,
        scenario.foresterNarrative.call('create_quest', input, 'create'),
      ),
      first,
    );
    assert.deepEqual(
      await commit(
        scenario,
        scenario.foresterNarrative.call('create_quest', bad, 'bad'),
      ),
      rejection,
    );
    assert.equal(
      (
        await commit(
          scenario,
          scenario.foresterNarrative.call('create_quest', input, 'bad'),
        )
      ).code,
      'effect_key_conflict',
    );
    assert.equal(
      scenario.narrative
        .drainEvents()
        .filter((event) => event.type === 'quest_created').length,
      1,
    );
  } finally {
    scenario.dispose();
  }
});

test('offers and player choices are independent, recipient-bound and replay safe', async () => {
  const scenario = createNarrativeScenario();
  try {
    const questId = await create(scenario),
      offered = await offer(scenario, questId);
    assert.deepEqual(
      await offer(scenario, questId, scenario.foresterNarrative, 'offer-again'),
      offered,
    );
    assert.equal(
      (
        await commit(
          scenario,
          scenario.narrative.choose(
            'someone-else',
            offered.choices[0].id,
            'bad-choice',
          ),
        )
      ).code,
      'choice_unavailable',
    );
    const declined = await commit(
      scenario,
      scenario.narrative.choose('player-1', offered.choices[1].id, 'decline'),
    );
    assert.equal(data(declined).status, 'declined');
    assert.deepEqual(
      await commit(
        scenario,
        scenario.narrative.choose('player-1', offered.choices[1].id, 'decline'),
      ),
      declined,
    );
    assert.equal((await inspect(scenario, questId)).status, 'declined');
    assert.equal(
      (
        await commit(
          scenario,
          scenario.foresterNarrative.call(
            'offer_quest',
            {
              questId,
              recipientRef: 'player-1',
              dialogue: 'Investigate this place.',
            },
            'new-offer',
          ),
        )
      ).code,
      'offer_resolved',
    );
    scenario.visit('grove-1');
    await poll(scenario);
    assert.equal(
      scenario.narrative
        .drainEvents()
        .some((event) => event.type === 'quest_completed'),
      false,
    );
  } finally {
    scenario.dispose();
  }
});

test('unready facts stay unknown, confirmed objective completion is latched, and inspect does not evaluate conditions', async () => {
  const scenario = createNarrativeScenario();
  try {
    const questId = await create(scenario),
      offered = await offer(scenario, questId);
    scenario.setUnavailable(true);
    await commit(
      scenario,
      scenario.narrative.choose('player-1', offered.choices[0].id, 'accept'),
    );
    await poll(scenario);
    assert.equal(
      (await inspect(scenario, questId)).objectives[0].status,
      'unknown',
    );
    scenario.setUnavailable(false);
    scenario.visit('grove-1');
    await poll(scenario);
    assert.equal((await inspect(scenario, questId)).status, 'completed');
    scenario.gameRestore([]);
    await poll(scenario);
    assert.equal((await inspect(scenario, questId)).status, 'completed');
    assert.equal(
      (await inspect(scenario, questId, scenario.foresterNarrative, null))
        .status,
      'registered',
    );
  } finally {
    scenario.dispose();
  }
});

test('drafts accept whole objectives or small templates and cannot mutate a published quest', async () => {
  const scenario = createNarrativeScenario();
  try {
    const draft = new QuestDraft(
      {
        recipientRef: 'player-1',
        title: 'Small steps',
        summary: 'Visit two places.',
      },
      [scenario.visitTemplate],
    );
    assert.throws(() => draft.toInput(), /at least one/);
    draft.addStep('visit_location', { id: 'grove', locationRef: 'grove-1' });
    const before = draft.toInput();
    const questId = data(
      await commit(
        scenario,
        scenario.directorNarrative.call('create_quest', before, 'create'),
      ),
    ).questId;
    draft.addStep('visit_location', { id: 'town', locationRef: 'river-town' });
    assert.equal(
      (await inspect(scenario, questId, scenario.directorNarrative)).objectives
        .length,
      1,
    );
    assert.equal(draft.toInput().quest.objectives.length, 2);
    assert.throws(
      () =>
        draft.addStep('visit_location', {
          id: 'town',
          locationRef: 'river-town',
        }),
      /duplicate/,
    );
    assert.throws(() => draft.addStep('invented-template', {}), /Unknown/);
    assert.throws(
      () => draft.addStep('visit_location', { id: 'extra', locationRef: 4 }),
      /Invalid/,
    );
  } finally {
    scenario.dispose();
  }
});

test('restore validation is atomic and save requires a safe command boundary', async () => {
  const scenario = createNarrativeScenario();
  try {
    const pending = scenario.foresterNarrative.call(
      'create_quest',
      scenario.draft('Survey', 'grove-1').toInput(),
      'create',
    );
    assert.throws(() => scenario.narrative.save(), /safe boundary/);
    await commit(scenario, pending);
    const saved = scenario.narrative.save();
    const badReceipt = structuredClone(saved);
    badReceipt.receipts[0].result.data.questId = 'quest-999';
    for (const bad of [
      { ...saved, schemaVersion: 2 },
      { ...saved, associationId: 'another-game' },
      { ...saved, questSequence: 0 },
      { ...saved, eventSequence: 0 },
      badReceipt,
      { ...saved, quests: [...saved.quests, ...saved.quests] },
    ]) {
      assert.throws(() => scenario.narrative.restore(bad), /Invalid/);
      assert.deepEqual(scenario.narrative.save(), saved);
    }
    assert.throws(() => {
      saved.quests[0].definition.title = 'tampered';
    }, TypeError);
  } finally {
    scenario.dispose();
  }
});

test('oversized/deep input is rejected before admission and concurrent CAI session attachment is forbidden', async () => {
  const scenario = createNarrativeScenario();
  try {
    assert.equal(
      (
        await scenario.foresterNarrative.call(
          'create_quest',
          { title: 'x'.repeat(70000) },
          'large',
        )
      ).code,
      'invalid_arguments',
    );
    let nested = {};
    for (let i = 0; i < 40; i++) nested = { child: nested };
    assert.equal(
      (await scenario.foresterNarrative.call('create_quest', nested, 'deep'))
        .code,
      'invalid_arguments',
    );
    assert.equal(scenario.narrative.stats.pendingCommands, 0);
    assert.throws(
      () =>
        scenario.runtime.register({
          id: 'duplicate',
          name: 'duplicate',
          capabilities: [],
          cai: scenario.forester.snapshot().cai,
        }),
      /session is already/,
    );
  } finally {
    scenario.dispose();
  }
});

test('numeric conditions use strict types and inspection failures never count as success', async () => {
  let reading = { status: 'completed', data: { amount: '2' } };
  const capability = {
    name: 'observe',
    kind: 'inspection',
    description: 'observe',
    inputSchema: {},
    validate: () => true,
    execute: () => reading,
  };
  const runtime = new CharacterRuntime({
    gameId: 'numeric',
    reasoning: { decide: () => ({ dialogue: '' }) },
    narrativeGame: {
      capabilities: () => [capability],
      recipientAvailable: () => true,
      referencesAvailable: () => true,
      inspectContext: () => ({ status: 'completed', data: {} }),
    },
  });
  const narrative = runtime.narrative,
    scenario = { advance: (dt) => runtime.advance(dt) };
  try {
    const handle = narrative.bind(
      runtime.register({ id: 'a', name: 'a', capabilities: [] }),
    );
    const input = {
      quest: {
        recipientRef: 'p',
        title: 'Supplies',
        summary: 'Find two.',
        objectives: [
          {
            id: 'supplies',
            description: 'Find two.',
            condition: {
              tool: 'observe',
              arguments: {},
              expect: { path: ['amount'], operator: 'at_least', value: 2 },
            },
          },
        ],
      },
    };
    const questId = data(
      await commit(scenario, handle.call('create_quest', input, 'create')),
    ).questId;
    const offered = data(
      await commit(
        scenario,
        handle.call(
          'offer_quest',
          { questId, recipientRef: 'p', dialogue: 'Help?' },
          'offer',
        ),
      ),
    );
    await commit(
      scenario,
      narrative.choose('p', offered.choices[0].id, 'accept'),
    );
    await poll(scenario);
    assert.equal(
      data(
        await commit(
          scenario,
          handle.call('inspect_quest', { questId, recipientRef: 'p' }),
        ),
      ).objectives[0].status,
      'unknown',
    );
    reading = { status: 'completed', data: {} };
    await poll(scenario);
    assert.equal(
      data(
        await commit(
          scenario,
          handle.call('inspect_quest', { questId, recipientRef: 'p' }),
        ),
      ).objectives[0].status,
      'unknown',
    );
    reading = { status: 'completed', data: { amount: 1 } };
    await poll(scenario);
    assert.equal(
      data(
        await commit(
          scenario,
          handle.call('inspect_quest', { questId, recipientRef: 'p' }),
        ),
      ).objectives[0].status,
      'pending',
    );
    reading = { status: 'completed', data: { amount: 2 } };
    await poll(scenario);
    assert.equal(
      data(
        await commit(
          scenario,
          handle.call('inspect_quest', { questId, recipientRef: 'p' }),
        ),
      ).status,
      'completed',
    );
  } finally {
    runtime.dispose();
  }
});

test('new registrations cannot replay retired binding receipts; explicit identity restore preserves them with a fresh generation', async () => {
  const scenario = createNarrativeScenario();
  try {
    const input = scenario.draft('Survey', 'grove-1').toInput();
    const first = await commit(
      scenario,
      scenario.foresterNarrative.call('create_quest', input, 'create'),
    );
    const original = scenario.forester.snapshot();
    scenario.forester.unregister();
    const replacement = scenario.registerForester();
    const newHandle = scenario.narrative.bind(replacement);
    const second = await commit(
      scenario,
      newHandle.call('create_quest', input, 'create'),
    );
    assert.notEqual(data(first).questId, data(second).questId);
    assert.notEqual(replacement.snapshot().binding.id, original.binding.id);
    replacement.unregister();
    const restored = scenario.runtime.register(original);
    assert.equal(restored.snapshot().binding.id, original.binding.id);
    assert.notEqual(
      restored.snapshot().binding.generation,
      original.binding.generation,
    );
    const restoredHandle = scenario.narrative.bind(restored);
    assert.deepEqual(
      await commit(
        scenario,
        restoredHandle.call('create_quest', input, 'create'),
      ),
      first,
    );
    assert.equal(
      (
        await commit(
          scenario,
          scenario.foresterNarrative.call('inspect_context', {
            scope: 'local',
          }),
        )
      ).code,
      'unregistered',
    );
  } finally {
    scenario.dispose();
  }
});

test('old asynchronous inspections cannot complete a restored or replaced character state', async () => {
  let resolve;
  const slow = new Promise((yes) => {
    resolve = yes;
  });
  let calls = 0;
  const capability = {
    name: 'observe',
    description: 'observe',
    kind: 'inspection',
    inputSchema: {},
    validate: () => true,
    execute: () =>
      ++calls === 1 ? slow : { status: 'completed', data: { done: false } },
  };
  const runtime = new CharacterRuntime({
    gameId: 'game',
    reasoning: { decide: () => ({ dialogue: '' }) },
  });
  const narrative = new NarrativeSystem({
    associationId: 'game',
    game: {
      capabilities: () => [capability],
      recipientAvailable: () => true,
      referencesAvailable: () => true,
      inspectContext: () => ({ status: 'completed', data: {} }),
    },
  });
  const scenario = {
    advance: (dt) => {
      runtime.advance(dt);
      narrative.advance(dt);
    },
  };
  try {
    const character = runtime.register({
        id: 'a',
        name: 'a',
        capabilities: [],
      }),
      handle = narrative.bind(character);
    const input = {
      quest: {
        recipientRef: 'p',
        title: 'Test',
        summary: 'Test',
        objectives: [
          {
            id: 'o',
            description: 'Test',
            condition: {
              tool: 'observe',
              arguments: {},
              expect: { path: ['done'], operator: 'equals', value: true },
            },
          },
        ],
      },
    };
    const questId = data(
      await commit(scenario, handle.call('create_quest', input, 'create')),
    ).questId;
    const offered = data(
      await commit(
        scenario,
        handle.call(
          'offer_quest',
          { questId, recipientRef: 'p', dialogue: 'Test' },
          'offer',
        ),
      ),
    );
    await commit(
      scenario,
      narrative.choose('p', offered.choices[0].id, 'accept'),
    );
    const saved = narrative.save();
    narrative.restore(saved);
    resolve({ status: 'completed', data: { done: true } });
    await settle();
    await poll(scenario);
    assert.equal(
      data(
        await commit(
          scenario,
          handle.call('inspect_quest', { questId, recipientRef: 'p' }),
        ),
      ).status,
      'active',
    );
    character.unregister();
    await poll(scenario);
    assert.equal(
      narrative.drainEvents().some((event) => event.type === 'quest_completed'),
      false,
    );
  } finally {
    narrative.dispose();
    runtime.dispose();
  }
});

test('runtime disposal resolves queued narrative requests and blocks new work', async () => {
  const scenario = createNarrativeScenario();
  const pending = scenario.foresterNarrative.call('inspect_context', {
    scope: 'local',
  });
  scenario.runtime.dispose();
  assert.equal((await pending).code, 'disposed');
  assert.equal(
    (
      await scenario.directorNarrative.call('inspect_context', {
        scope: 'world',
      })
    ).code,
    'disposed',
  );
  assert.equal(scenario.narrative.stats.disposed, true);
});
