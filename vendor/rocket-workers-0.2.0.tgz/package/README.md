# Rocket-Workers

Standalone TypeScript execution in native browser module workers. M2 supports 1–16 workers, a finite FIFO queue, AbortSignal and explicit failed-slot restart. Defaults retain one worker with no waiting queue. Rocket, rendering, world state and terrain algorithms are not dependencies.

```sh
npm ci
npm run check
npm run smoke
npm start
```

Open [the local demo](http://127.0.0.1:8126/) and click **Run browser acceptance proof**. This uses real module workers, transfers, deliberate errors, timeouts and disposal. The missing-worker 404 is an intentional startup-failure check. The finite slow task blocks its worker for at most one second; it does not block the main thread. The demo worker can be disposed separately. There is no performance benchmark in M1.

Open [the pool demo](http://127.0.0.1:8126/pool.html) for saturation, queued/running cancellation, failure/restart and final disposal controls plus the multi-worker proof.

The package has no runtime dependencies. Build/check dependencies are pinned in package-lock.json. Only `rocket-workers` and `rocket-workers/worker` are public entry points. [API and usage](docs/API.md), [M1 acceptance](docs/M1-ACCEPTANCE.md), and [roadmap](PLAN.md) describe the contract and review gates.

M1 correction1 is accepted. M2 is a completed review candidate under its separate approval and awaits independent acceptance. Rocket integration and performance evidence require later gates.
