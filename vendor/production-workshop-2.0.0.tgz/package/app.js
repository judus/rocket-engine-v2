import { Clock } from "./dist/index.js";
import { createSettlement, createShip } from "./dist/examples.js";
const $ = (id) => document.getElementById(id);
const label = (id) =>
  id.replaceAll("-", " ").replace(/\b\w/g, (c) => c.toUpperCase());
let mode = "settlement",
  filter = "all",
  sim,
  lastPaint = 0,
  clock;
let inspectorJobs = "", itemOffset = 0;
const catalogNodes = new Map(),
  jobNodes = new Map(),
  inventoryNodes = new Map();
const resourceLabel = (id) => sim.registry.resource(id).label;
const quantities = (q) =>
  Object.entries(q)
    .map(([p, n]) => `${n} ${resourceLabel(p)}`)
    .join(" + ");
const description = (d) =>
  d.recipes
    .map((id) => {
      const r = sim.registry.recipe(id);
      return `${quantities(r.inputs) || "No inputs"} → ${quantities(r.outputs)} · ${r.durationSeconds}s`;
    })
    .join("<br>") || `+${d.capacityProvided ?? 0} capacity per material`;
function blockers(d) {
  const b = sim.constructionBlockers(d.id, mode);
  return [
    Object.keys(b.materials).length ? `Needs ${quantities(b.materials)}` : "",
    Object.keys(b.workers).length
      ? `Needs ${Object.entries(b.workers)
          .map(([id, n]) => `${n} free ${id}`)
          .join(", ")}`
      : "",
  ]
    .filter(Boolean)
    .join(" · ");
}
function renderCatalog() {
  const query = $("search").value.toLowerCase();
  catalogNodes.clear();
  const list = sim.registry.facilities.filter(
    (d) =>
      (filter === "all" || d.category === filter) &&
      `${d.label} ${description(d)}`.toLowerCase().includes(query),
  );
  $("catalog-count").textContent = `${list.length} options`;
  $("catalog").innerHTML =
    list
      .map(
        (d) =>
          `<article class="catalog-item"><h3>${d.label}</h3><div class="recipe">${description(d)}</div><div class="cost">${quantities(d.constructionCost) || "No construction cost"}<br>${
            Object.entries(d.workersProvided ?? {})
              .map(([id, n]) => `+${n} ${id}`)
              .join(" · ") ||
            Object.entries(d.workersRequired ?? {})
              .map(([id, n]) => `${n} ${id}`)
              .join(" · ") ||
            "No workforce required"
          }</div><button class="build" data-build="${d.id}"></button></article>`,
      )
      .join("") || '<p class="empty-message">No matching facilities.</p>';
  document
    .querySelectorAll("[data-build]")
    .forEach((btn) => catalogNodes.set(btn.dataset.build, btn));
  refreshButtons();
}
function refreshButtons() {
  for (const [id, btn] of catalogNodes) {
    const reason = blockers(sim.registry.facility(id));
    btn.disabled = !!reason;
    btn.textContent = reason || "+ Add building";
  }
}
function renderFacilities() {
  jobNodes.clear();
  const state = {facilities: sim.facilityIds().map(id => sim.facilitySnapshot(id))};
  $("buildings").innerHTML = state.facilities
    .map((f) => {
      const d = sim.registry.facility(f.definitionId);
      return `<article class="building"><div class="building-top"><h3>${d.label}</h3><button class="toggle" data-toggle="${f.id}">${f.enabled ? "Suspend" : "Enable"}</button></div><div class="inspector-controls"><button data-drain="${f.id}">${f.draining ? "Resume new batches" : "Drain batches"}</button><button data-remove="${f.id}">Remove</button></div><div class="recipe">${description(d)}</div><div class="production-controls">
      <strong data-productivity="${f.id}"></strong>
      ${f.workerSlots.length ? `<label>Worker efficiency <input type="range" min="0" max="100" value="${Math.round((f.workerSlots.reduce((n, w) => n + (w?.efficiency ?? 0), 0) / (f.workerSlots.filter(Boolean).length || 1)) * 100)}" data-efficiency="${f.id}" aria-label="${d.label} worker efficiency"></label><small>${f.workerSlots.length} slots · empty slots contribute zero; attendance minimum applies</small><small data-worker-summary="${f.id}"></small><label>Workers on site <input type="range" min="0" max="${f.workerSlots.length}" value="${f.workerSlots.filter(Boolean).length}" data-occupancy="${f.id}" aria-label="${d.label} occupied slots"></label>` : "<small>Autonomous · no worker slots</small>"}
      <label><input type="checkbox" data-specialist="${f.id}" ${f.modifiers.specialist ? "checked" : ""}> Specialist (+20% speed, +10 health, +0.1 precision)</label>
      <label><input type="checkbox" data-failure="${f.id}" ${f.modifiers["factory-health"] ? "checked" : ""}> Factory failure (stop work)</label>
      ${d.recipes.some((id) => Object.keys(sim.registry.recipe(id).optionalInputs ?? {}).length) ? `<label><input type="checkbox" data-ingredient="${f.id}" ${f.jobs.some((j) => j.selectedOptionalInputs.reinforcement) ? "checked" : ""}> Reinforce next weapons (+10 health, consumes reinforcement)</label>` : ""}
      </div>${f.jobs.map((j) => `<div class="job" data-job="${j.id}"><div class="job-info"><span>${quantities(sim.registry.recipe(j.recipeId).outputs)}</span><span class="job-status"></span></div><progress max="1" value="0" aria-label="${d.label} progress"></progress><small class="batch-count"></small></div>`).join("")}${Object.keys(d.workersProvided ?? {}).length ? '<div class="cost">Residents added to workforce</div>' : ""}</article>`;
    })
    .join("");
  document.querySelectorAll("[data-job]").forEach((node) =>
    jobNodes.set(node.dataset.job, {
      progress: node.querySelector("progress"),
      status: node.querySelector(".job-status"),
      count: node.querySelector(".batch-count"),
    }),
  );
}
function paint(force = false) {
  const now = performance.now();
  if (!force && now - lastPaint < 100) return;
  lastPaint = now;
  const state = {...sim.summary(), facilities: sim.facilityIds().map(id => sim.facilitySnapshot(id))},
    inventory = sim.inventory(mode).summary();
  if (itemOffset >= inventory.itemCount) itemOffset = Math.max(0, Math.floor((inventory.itemCount - 1) / 50) * 50);
  const page = sim.inventory(mode).itemPage({offset: itemOffset, limit: 50});
  $("items-page").textContent = page.total ? `${page.offset + 1}–${page.offset + page.items.length} of ${page.total} items` : "No individual goods";
  $("items-prev").disabled = itemOffset === 0;
  $("items-next").disabled = itemOffset + page.items.length >= page.total;
  $("clock").textContent = `${Math.floor(state.timeSeconds / 60)
    .toString()
    .padStart(2, "0")}:${Math.floor(state.timeSeconds % 60)
    .toString()
    .padStart(2, "0")}`;
  $("count").textContent =
    `${state.facilities.length} ${mode === "ship" ? "modules" : "buildings"}`;
  $("capacity").textContent = `${inventory.capacityPerMaterial} per material`;
  $("credits").textContent = inventory.quantities.credits.toLocaleString();
  $("people").innerHTML =
    Object.entries(inventory.workforce)
      .map(
        ([id, p]) =>
          `<span>${label(id)} <b>${p.total - p.assigned} / ${p.total}</b></span>`,
      )
      .join("") || "<span>No workforce required</span>";
  for (const f of state.facilities) {
    const remove = document.querySelector(`[data-remove="${f.id}"]`);
    const reasons = sim.removalBlockers(f.id);
    if (remove) {
      remove.disabled = reasons.length > 0;
      remove.title = reasons.map(b => b.code === "active-batch" ? "Drain current batches before removal" : b.code === "workforce" ? `${b.shortage} ${b.workerId} still needed` : `${b.excess} ${b.resourceId} exceeds remaining capacity`).join("; ");
    }
    const rate = document.querySelector(`[data-productivity="${f.id}"]`);
    const workers = document.querySelector(`[data-worker-summary="${f.id}"]`);
    if (workers)
      workers.textContent = `${f.workerSlots.filter(Boolean).length}/${f.workerSlots.length} occupied · efficiencies: ${f.workerSlots
        .slice(0, 5)
        .map((w) => (w ? `${Math.round(w.efficiency * 100)}%` : "empty"))
        .join(", ")}${f.workerSlots.length > 5 ? " …" : ""}`;
    if (rate)
      rate.textContent = `${(f.productivity * 100).toFixed(1)}% productivity`;
    for (const j of f.jobs) {
      const node = jobNodes.get(j.id);
      node.progress.value = j.progress;
      node.count.textContent = `${j.batchesCompleted} batches completed`;
      node.status.textContent =
        j.state === "waiting-inputs"
          ? `Waiting${Object.keys(j.missingInputs).length ? " for " + quantities(j.missingInputs) : " in queue"}`
          : j.state === "output-blocked"
            ? "Storage full"
            : label(j.state);
    }
  }
  $("items").replaceChildren(
    ...page.items.map((item) => {
      const row = document.createElement("p");
      row.textContent = `${resourceLabel(item.resourceId)} · ${Object.entries(
        item.attributes,
      )
        .map(([key, n]) => `${key}: ${n.toFixed(2)}`)
        .join(" · ")}`;
      const identity = document.createElement("code");
      identity.className = "item-identity";
      identity.textContent = item.id;
      row.append(identity);
      return row;
    }),
  );
  for (const [id, node] of inventoryNodes) {
    const n = inventory.quantities[id];
    node.row.classList.toggle("empty", n === 0);
    node.qty.textContent = `${n} / ${inventory.capacityPerMaterial}`;
    node.progress.value = n / inventory.capacityPerMaterial;
  }
  paintInspector(state);
  refreshButtons();
  $("pause").textContent = clock.paused ? "Resume" : "Pause";
  $("state").textContent = clock.paused ? "Paused" : "Running";
}
function reset() {
  itemOffset = 0;
  sim = mode === "ship" ? createShip() : createSettlement();
  clock = new Clock((dt) => sim.advance(dt));
  $("diagnostic-tracing").checked = false;
  $("validation-status").textContent = "Validation runs only when requested.";
  $("inspect-item").value = "";
  inspectorJobs = "";
  clock.speed = Number($("speed").value);
  filter = "all";
  $("search").value = "";
  document.querySelectorAll("[data-filter]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.filter === "all");
    btn.setAttribute("aria-pressed", String(btn.dataset.filter === "all"));
    btn.hidden = mode === "ship" && btn.dataset.filter !== "all";
  });
  $("scenario-hint").textContent =
    mode === "ship"
      ? "Cargo feeds the refinery, circuit printer and sensor fabricator. No workforce; instant access to onboard materials. Weapons carry individual quality attributes."
      : "A residence supplies farmers. The forester makes logs. The sawmill turns them into timber.";
  $("inventory-hint").textContent =
    mode === "ship"
      ? "Finite cargo: production waits when inputs run out. Resupply uses the same validated inventory API."
      : "Inputs are allocated fairly and consumed once at batch start. Coal mines roll a 1% diamond bonus per completed batch.";
  $("resupply").hidden = mode !== "ship";
  $("location-label").textContent =
    mode === "ship" ? "ONBOARD MODULES" : "SETTLEMENT";
  $("catalog-title").textContent =
    mode === "ship" ? "Add a module" : "Add a building";
  $("floor-title").textContent =
    mode === "ship" ? "On the ship" : "On the floor";
  renderCatalog();
  renderFacilities();
  inventoryNodes.clear();
  $("inventory").innerHTML = sim.registry.resources
    .filter((r) => r.kind === "material")
    .map(
      (r) =>
        `<div class="inventory-row" data-stock="${r.id}"><div><span>${r.label}</span><b></b></div><progress value="0" max="1" aria-label="${r.label} storage"></progress></div>`,
    )
    .join("");
  document.querySelectorAll("[data-stock]").forEach((row) =>
    inventoryNodes.set(row.dataset.stock, {
      row,
      qty: row.querySelector("b"),
      progress: row.querySelector("progress"),
    }),
  );
  $("notice").textContent =
    mode === "ship"
      ? "Ship fabricator online. Cargo loaded."
      : "Settlement ready. Construction now uses materials and credits.";
  paint(true);
}
$("catalog").addEventListener("click", (e) => {
  const btn = e.target.closest("[data-build]");
  if (!btn) return;
  const result = sim.addFacility(btn.dataset.build, mode);
  if(result.ok) sim.setFacilityAttendance(result.facilityId,sim.registry.facility(btn.dataset.build).workersRequired ?? {});
  $("notice").textContent = result.ok
    ? `${sim.registry.facility(btn.dataset.build).label} added.`
    : result.reason;
  if (result.ok) {
    renderFacilities();
    paint(true);
  }
});
$("buildings").addEventListener("click", (e) => {
  const drain = e.target.closest("[data-drain]");
  const remove = e.target.closest("[data-remove]");
  if (drain) {
    const f = sim.facilitySnapshot(drain.dataset.drain);
    sim.setFacilityDraining(f.id, !f.draining);
    $("notice").textContent = f.draining ? "New batches resumed." : "Draining: current batches finish; no new batch starts. Power, staff and output space are still needed.";
    renderFacilities(); paint(true); return;
  }
  if (remove) {
    const result = sim.removeFacility(remove.dataset.remove);
    $("notice").textContent = result.ok ? "Factory removed. Stored goods remain; construction costs are not refunded." : "Factory still has work, workforce or storage dependencies.";
    renderFacilities(); paint(true); return;
  }
  const btn = e.target.closest("[data-toggle]");
  if (!btn) return;
  const f = sim.facilitySnapshot(btn.dataset.toggle);
  sim.setFacilityEnabled(f.id, !f.enabled);
  renderFacilities();
  paint(true);
});
$("search").addEventListener("input", renderCatalog);
document.querySelectorAll("[data-filter]").forEach((btn) =>
  btn.addEventListener("click", () => {
    filter = btn.dataset.filter;
    document.querySelectorAll("[data-filter]").forEach((b) => {
      b.classList.toggle("active", b === btn);
      b.setAttribute("aria-pressed", String(b === btn));
    });
    renderCatalog();
  }),
);
$("pause").addEventListener("click", () => {
  clock.setPaused(!clock.paused);
  paint(true);
});
$("speed").addEventListener(
  "change",
  () => (clock.speed = Number($("speed").value)),
);
$("reset").addEventListener("click", reset);
$("scenario").addEventListener("change", () => {
  mode = $("scenario").value;
  reset();
});
$("resupply").addEventListener("click", () => {
  const inventory = sim.inventory("ship");
  if (inventory.quantity("credits") < 50) {
    $("notice").textContent = "Resupply needs 50 credits.";
    return;
  }
  if (!inventory.canDeposit({ ore: 30, silica: 10 })) {
    $("notice").textContent = "Not enough cargo space for this shipment.";
    return;
  }
  sim.withdraw("ship", { credits: 50 });
  sim.deposit("ship", { ore: 30, silica: 10 });
  $("notice").textContent = "Delivered 30 ore and 10 silica for 50 credits.";
  paint(true);
});
// Background tabs explicitly pause wall-clock accounting. No silently discarded elapsed time.
let hiddenPause = false;
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    hiddenPause = !clock.paused;
    clock.setPaused(true);
  } else if (hiddenPause) {
    clock.setPaused(false);
    hiddenPause = false;
  }
  paint(true);
});
reset();
function frame(now) {
  clock.sample(now);
  paint();
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

$("buildings").addEventListener("input", (e) => {
  const input = e.target;
  const id =
    input.dataset.efficiency ||
    input.dataset.occupancy ||
    input.dataset.specialist ||
    input.dataset.failure ||
    input.dataset.ingredient;
  if (!id) return;
  if (input.dataset.occupancy) {
    const f = sim.facilitySnapshot(id);
    const count = Number(input.value);
    f.workerSlots.forEach((worker, slot) =>
      sim.setWorkerSlot(
        id,
        slot,
        slot < count
          ? (worker ?? { id: `${id}.worker-${slot}`, efficiency: 1 })
          : null,
      ),
    );
    const required=sim.registry.facility(f.definitionId).workersRequired ?? {};let remaining=count;
    const present={};for(const [type,n] of Object.entries(required)){present[type]=Math.min(n,remaining);remaining-=present[type];}
    sim.setFacilityAttendance(id,present);
  } else if (input.dataset.efficiency) {
    const f = sim.facilitySnapshot(id);
    f.workerSlots.forEach((worker, slot) => {
      if (worker)
        sim.setWorkerSlot(id, slot, {
          ...worker,
          efficiency: Number(input.value) / 100,
        });
    });
  } else if (input.dataset.specialist) {
    sim.setProductionModifier(
      id,
      "specialist",
      input.checked
        ? {
            productivityMultiplier: 1.2,
            attributeBonuses: { maxHealth: 10, precision: 0.1 },
          }
        : null,
    );
  } else if (input.dataset.failure) {
    sim.setProductionModifier(
      id,
      "factory-health",
      input.checked ? { productivityMultiplier: 0 } : null,
    );
  } else if (input.dataset.ingredient) {
    sim.setOptionalInputs(
      id,
      "weapons",
      input.checked ? { reinforcement: 1 } : {},
    );
  }
  paint(true);
});

function paintInspector(state) {
  if (!$("inspector").open) return;
  const ids = state.facilities.flatMap(f => f.jobs.map(j => j.id)).join("|");
  if (ids !== inspectorJobs) {
    const previous = $("inspect-job").value;
    $("inspect-job").replaceChildren(...state.facilities.flatMap(f => f.jobs.map(j => {
      const option = document.createElement("option");
      option.value = j.id;
      option.textContent = `${sim.registry.facility(f.definitionId).label} · ${j.id}`;
      return option;
    })));
    if (state.facilities.some(f => f.jobs.some(j => j.id === previous))) $("inspect-job").value = previous;
    inspectorJobs = ids;
  }
  const jobId = $("inspect-job").value;
  if (jobId) {
    const view = sim.explainJob(jobId);
    const f = state.facilities.find(f => f.id === view.facilityId);
    const lines = [
      `${view.phase} · ${(view.productivity.base * 100).toFixed(1)}% worker/base rate × ${Object.entries(view.productivity.modifiers).map(([id,n]) => `${id} ${n}×`).join(" × ") || "no modifiers"} → ${(view.productivity.effective * 100).toFixed(1)}% productivity`,
      `Remaining nominal work: ${view.remainingWorkSeconds.toFixed(2)}s. ${view.estimatedCompletionSeconds === null ? "No completion estimate while blocked or idle." : `Estimated completion: ${view.estimatedCompletionSeconds.toFixed(2)}s at the current rate.`}`,
      ...view.blockers.map(b => b.code === "condition" ? `Requires condition: ${b.conditionId}` :
        "quantities" in b ? `${label(b.code)}: ${quantities(b.quantities)}` : "itemIds" in b ? `${label(b.code)}: ${b.itemIds.join(", ")}` : label(b.code)),
      `Inputs held for this job: ${quantities(Object.fromEntries(Object.entries(view.reservedInputs).filter(([,n]) => n > 0))) || "none"}`,
      `Available physical inputs: ${quantities(view.availableInputs) || "none"}`,
      `Committed incoming cargo: ${quantities(view.inboundInputs) || "none"}`,
    ];
    $("job-explanation").replaceChildren(...lines.map(text => { const row = document.createElement("p"); row.textContent = text; return row; }));
    $("reservation-inspection").textContent = JSON.stringify(sim.inspectReservations(f.inputInventoryId), null, 2);
  }
  if (!jobId) {
    $("job-explanation").textContent = "No live production jobs to inspect.";
    $("reservation-inspection").textContent = "[]";
  }
  const itemId = $("inspect-item").value.trim();
  $("item-location").textContent = itemId ? JSON.stringify(sim.locateItem(itemId)) || "Unknown item identity." : "Enter an identity to inspect its owner.";
  $("diagnostic-trace").textContent = sim.diagnosticTrace().slice(-20).map(e =>
    `#${e.sequence} tick ${e.tick} · ${e.kind} ${e.subject} ${JSON.stringify(e.details)}`).join("\n") || "Trace disabled or no activity recorded yet. Showing the latest 20 entries of a 200-entry buffer.";
}
$("inspector").addEventListener("toggle", () => paint(true));
$("inspect-job").addEventListener("change", () => paint(true));
$("inspect-item").addEventListener("input", () => paint(true));
$("diagnostic-tracing").addEventListener("change", () => { sim.enableDiagnostics($("diagnostic-tracing").checked ? 200 : 0); paint(true); });
$("validate-state").addEventListener("click", () => {
  const result = sim.validateState();
  $("validation-status").textContent = result.ok ? "State valid: ownership, reservations, workforce, counters and manifests agree." : result.issues.map(i => i.message).join("; ");
});

$("items-prev").addEventListener("click", () => { itemOffset = Math.max(0,itemOffset - 50); paint(true); });
$("items-next").addEventListener("click", () => { itemOffset += 50; paint(true); });
