import assert from 'node:assert/strict';
import {Simulation} from '../dist/index.js';
let sim=new Simulation({resources:[{id:'wood',label:'Wood',kind:'material'},{id:'ore',label:'Ore',kind:'material'},{id:'alloy',label:'Alloy',kind:'material'}],
 recipes:[{id:'smelt',label:'Smelt',durationSeconds:1,inputs:{ore:1},outputs:{alloy:1}}],
 facilities:[{id:'home',label:'Home',category:'town',recipes:[],constructionCost:{},workersProvided:{smith:2}},
 {id:'smelter',label:'Smelter',category:'production',recipes:['smelt'],constructionCost:{wood:2},workersRequired:{smith:2}}]});
sim.createInventory({id:'site',capacityPerMaterial:10,initial:{ore:3}});sim.createInventory({id:'warehouse',capacityPerMaterial:10,initial:{wood:4}});
sim.addFacility('home','site'); // Existing instant API still immediate.
const order=sim.createConstructionOrder('smelter','site',{durationSeconds:2});
const delivery=sim.reserveDelivery('warehouse','site',{wood:2});sim.pickupDelivery(delivery.deliveryId);
sim.advance(1);assert.equal(sim.constructionOrderSnapshot(order).progress,0); // Host has not reported arrival.
sim.arriveDelivery(delivery.deliveryId);sim.advance(1);assert.equal(sim.constructionOrderSnapshot(order).progress,.5);
sim=Simulation.restore(JSON.parse(JSON.stringify(sim.save())));sim.advance(1);
const finished=sim.constructionOrderSnapshot(order);assert.equal(finished.state,'completed');const factory=finished.facilityId;
sim.advance(1);assert.equal(sim.inventory('site').quantity('alloy'),0); // Pool allocation is not attendance.
sim.setFacilityAttendance(factory,{smith:2});sim.advance(.5);sim.setFacilityEnabled(factory,false);
const progress=sim.facilitySnapshot(factory).jobs[0].progress;sim.advance(1);assert.equal(sim.facilitySnapshot(factory).jobs[0].progress,progress);
sim.setFacilityEnabled(factory,true);sim.advance(1);assert.ok(sim.inventory('site').quantity('alloy')>0);
const cancelled=sim.createConstructionOrder('smelter','site',{durationSeconds:2});sim.advance(.05);const receipt=sim.cancelConstructionOrder(cancelled);assert.ok(receipt.ok);assert.deepEqual(receipt.consumedMaterials,{});
console.log('Timed construction: arrived site materials, reserved work, exact reload/completion, explicit attendance, independent pause and non-destructive cancellation.');
