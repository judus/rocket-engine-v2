import { createSettlement } from "../dist/examples.js";
const sim = createSettlement();
// addFacility validates and charges construction costs, then assigns workforce.
const home = sim.addFacility("farmer-residence", "settlement");
if (!home.ok) throw new Error(home.reason);
const warehouse = sim.addFacility("small-warehouse", "settlement");
if (!warehouse.ok) throw new Error(warehouse.reason);
sim.advance(10);
const snapshot = sim.snapshot();
console.log("Settlement after 10 seconds:", snapshot.inventories[0].quantities);
console.log("Workforce:", snapshot.inventories[0].workforce);
