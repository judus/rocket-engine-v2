import assert from 'node:assert/strict';
import {Simulation} from '../dist/index.js';
const sim=new Simulation({tickMilliseconds:50,resources:[{id:'weapon',label:'Weapon',kind:'material',storage:'individual'}],
  recipes:[{id:'forge',label:'Forge',durationSeconds:.5,inputs:{},outputs:{weapon:1},itemAttributes:{weapon:{health:{min:90,max:100}}}}],
  facilities:[{id:'forge',label:'Forge',category:'ship',recipes:['forge'],constructionCost:{}}]});
sim.createInventory({id:'ship',capacityPerMaterial:20});sim.createInventory({id:'planet',capacityPerMaterial:20});
const factory=sim.addFacility('forge','ship').facilityId;
sim.advance(.1);
assert.equal(sim.removeFacility(factory).ok,false); // Existing work is protected.
sim.setFacilityDraining(factory,true);
sim.advance(.5); // Host continues to advance; drain is not a second timer.
assert.equal(sim.facilitySnapshot(factory).jobs[0].state,'drained');
const weapon=sim.inventory('ship').itemPage().items[0];
const delivery=sim.reserveDelivery('ship','planet',{},[weapon.id]);sim.pickupDelivery(delivery.deliveryId);
assert.deepEqual(sim.removalBlockers(factory),[]);
assert.ok(sim.removeFacility(factory).ok);
const restored=Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
assert.ok(restored.arriveDelivery(delivery.deliveryId));
assert.deepEqual(restored.inventory('planet').item(weapon.id),weapon);
assert.equal(restored.summary().facilityCount,0);
assert.deepEqual(restored.validateState(),{ok:true});
console.log('Factory removal: drained safely; produced weapon retained its identity through transit and restore.');
