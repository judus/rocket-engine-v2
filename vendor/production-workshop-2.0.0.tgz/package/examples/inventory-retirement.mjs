import assert from 'node:assert/strict';
import {Simulation} from '../dist/index.js';
const sim=new Simulation({resources:[{id:'weapon',label:'Weapon',kind:'material',storage:'individual'}],recipes:[],facilities:[]});
sim.createInventory({id:'buffer',capacityPerMaterial:10});sim.createInventory({id:'ship',capacityPerMaterial:10});
const id=sim.spawnItem('buffer','weapon',{health:87,precision:.9});
assert.equal(sim.removeInventory('buffer').ok,false); // Goods block final cleanup.
const delivery=sim.reserveDelivery('buffer','ship',{},[id]);assert.ok(delivery.ok);
sim.pickupDelivery(delivery.deliveryId);assert.equal(sim.removeInventory('buffer').ok,false); // Cargo still references its source.
sim.arriveDelivery(delivery.deliveryId);
assert.deepEqual(sim.removeInventory('buffer'),{ok:true,inventoryId:'buffer',prunedDeliveryIds:[delivery.deliveryId]});
const restored=Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
assert.equal(restored.locateItem(id).inventoryId,'ship');assert.equal(restored.inventory('ship').item(id).attributes.health,87);
assert.throws(()=>restored.inventory('buffer'),/unknown inventory/);
console.log('Inventory retirement: stock evacuated explicitly; active cargo blocked cleanup; terminal history pruned; weapon identity/quality survived reload.');
