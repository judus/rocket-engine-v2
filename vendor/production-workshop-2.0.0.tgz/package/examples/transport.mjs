import assert from "node:assert/strict";
import { TransportExample } from "../dist/transport-example.js";
const world = new TransportExample();
world.advance(0.05); // Host dispatched one batch of ore; nothing has arrived.
assert.equal(world.simulation.inventory("smelter-input").quantity("ore"), 0);
assert.equal(world.simulation.inventory("warehouse").quantity("ore"), 58);
assert.equal(world.journeys()[0].quantities.ore, 2);
world.advance(3); // Arrival starts production.
assert.equal(
  world.simulation.snapshot().facilities[0].jobs[0].state,
  "producing",
);
world.advance(1); // Work completes, output is picked up for its return journey.
assert.equal(world.simulation.inventory("warehouse").quantity("alloy"), 0);
world.advance(3);
assert.equal(world.simulation.inventory("warehouse").quantity("alloy"), 1);
console.log(
  "First alloy returned after 3s delivery + 1s work + 3s collection:",
  world.simulation.snapshot().timeSeconds,
);
world.automaticCollection = false;
world.advance(30);
assert.equal(
  world.simulation.snapshot().facilities[0].jobs[0].state,
  "output-blocked",
);
assert.ok(world.collectOutput());
world.advance(0.05);
assert.notEqual(
  world.simulation.snapshot().facilities[0].jobs[0].state,
  "output-blocked",
);
console.log("Manual collection frees the output buffer; production resumes.");
