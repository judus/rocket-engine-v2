import {Worker} from 'node:worker_threads';
/** Node transport adapter for the same request bridge; never imported by browser code. */
export class NodeWorkerTransport {
  #worker;
  #terminated=false;
  onmessage=null;
  onerror=null;
  onmessageerror=null;
  constructor(url) {
    this.#worker=new Worker(url);
    this.#worker.on('message',data=>this.onmessage?.({data}));
    this.#worker.on('error',error=>this.onerror?.({message:error.message}));
    this.#worker.on('messageerror',()=>this.onmessageerror?.());
    this.#worker.on('exit',code=>{if(!this.#terminated)this.onerror?.({message:`Worker exited unexpectedly (${code})`});});
  }
  postMessage(value) {this.#worker.postMessage(value);}
  terminate() {this.#terminated=true;return this.#worker.terminate();}
}
