import assert from 'node:assert/strict';
import {Simulation} from '../dist/index.js';
const configuration = {
  resources:[{id:'ore',label:'Ore',kind:'material'},{id:'alloy',label:'Alloy',kind:'material'}],
  recipes:[{id:'large',label:'Large batch',durationSeconds:1,inputs:{ore:2},outputs:{alloy:1}},
    {id:'small',label:'Small batch',durationSeconds:1,inputs:{ore:1},outputs:{alloy:1}}],
  facilities:[{id:'large',label:'Large',category:'test',recipes:['large'],constructionCost:{}},
    {id:'small',label:'Small',category:'test',recipes:['small'],constructionCost:{}}],
};
const s = new Simulation(configuration);
s.createInventory({id:'store',capacityPerMaterial:10000});
s.addFacility('large','store'); s.addFacility('small','store');
for(let i=0;i<100;i++) {s.deposit('store',{ore:1}); s.advanceTicks(1);}
const batches=s.snapshot().facilities.map(f=>f.jobs[0].batchesCompleted);
assert.ok(batches.every(n=>n>0));
console.log('Large and small batches both get inputs:',batches);
const fastConfig=structuredClone(configuration);
fastConfig.recipes[0].inputs={};
const fast=new Simulation(fastConfig);
fast.createInventory({id:'store',capacityPerMaterial:10000});
const factory=fast.addFacility('large','store');
fast.setProductionModifier(factory.facilityId,'specialist',{productivityMultiplier:100});
fast.advanceTicks(1);
const partitioned=Simulation.restore(JSON.parse(JSON.stringify(fast.save())));
fast.advance(1);
for(let i=0;i<60;i++) partitioned.advance(1/60);
assert.equal(fast.inventory('store').quantity('alloy'),100);
assert.deepEqual(partitioned.snapshot(),fast.snapshot());
console.log('100x productivity produces 100 batches per working second, including at 60Hz.');
