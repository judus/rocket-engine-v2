# Timed construction, pause and local staffing

Workshop owns orders, stock, reservations, ticks, production and checkpoints. The host owns placement, transport journeys, real worker attendance and UI. No paths, movement simulation, wall-clock timer, offline progression or demolition scheduler are introduced. Rocket Engine is unchanged.

## Explicit construction API

`addFacility(definitionId, inventoryId, options?)` still constructs immediately, charges once, allocates the existing workforce pool and grants benefits. It never silently creates an order. Timed construction uses a separate call:

```js
const orderId = sim.createConstructionOrder('smelter', 'site', {
  durationSeconds: 2,
  inputInventoryId: 'input-buffer', // defaults to site
  outputInventoryId: 'output-buffer', // defaults to site
});
const order = sim.constructionOrderSnapshot(orderId);
sim.advance(0.05); // Or use advanceTicks; the existing shared clock owns progress.
```

Durations are positive safe-integer microseconds expressed in seconds. Endpoints and the definition must exist at creation; materials and available workforce need not exist yet. IDs are monotonic `construction-N` and persist. `constructionOrderIds()` lists retained history. All snapshots/receipts are detached.

| State | Ownership and behavior |
| --- | --- |
| `waiting-materials` | In creation order, hold whatever bulk construction materials are available at the site. Partial reservations do not start progress. |
| `building` | All construction costs are reserved at the site. Each shared tick adds tick-duration work, capped at the configured duration. No construction speed multiplier or workforce-attendance rule is inferred. |
| `awaiting-activation` | Progress is complete, but activation cannot safely apply workforce/capacity/ID effects. Materials stay reserved and unconsumed until the requirements are satisfied. |
| `completed` | Consume the reservation once, apply construction effects once, activate exactly one facility, and retain its `facilityId` association and `consumedMaterials` receipt. |
| `cancelled` | Release all unused reservations. Keep progress/history but create no facility and consume no materials. |

A fully funded order gains its first tick of construction work on the tick that acquires its complete reservation. Unfunded time is never banked. Construction allocation precedes production allocation; existing reservations remain protected. Orders allocate in creation order and are restored in that order. A newly activated autonomous building may start its first batch in the completion tick, but earns production work from later ticks. A staffed building initially has no attendance.

Unfinished orders provide no jobs, population or storage capacity. Costs are the existing registered `constructionCost`, bulk-only; credits are included. Incoming cargo commitments do not constitute site stock, so progress stays at zero until the host calls arrival successfully. Reservations prevent instant construction, production, evacuation or competing orders from spending the same materials. If a material cost exceeds site capacity, the order waits without allocating; unfinished capacity benefits cannot make that cost fit. The host must provide adequate capacity or cancel.

`constructionOrderSnapshot()` includes `progress`, `reservedMaterials`, `consumedMaterials`, `missingMaterials`, site-wide `incomingMaterials`, and typed blockers. Missing quantities describe arrived stock only; incoming quantities are information for host logistics. `constructionDemands()` predicts shortages across all unfinished orders without promising the same free stock twice. The host should account for existing inbound commitments when choosing new shipments; the framework does not dispatch or deduplicate host logistics intent automatically.

Blockers are `materials` with quantities, `material-capacity` with resource/required/capacity, and, once ready, `workforce` with quantities, `capacity-overflow`, `workforce-overflow` or `facility-id-exhausted`. Workforce allocation is checked at activation, not reserved during construction. Another facility can claim the pool first; the order then waits. Overflow/exhaustion leaves holdings and association intact with no partial activation. Production slots and attendance are independent from that activation check.

## Non-destructive cancellation

`cancelConstructionOrder(id)` returns `{ok:true, orderId, releasedMaterials, consumedMaterials:{}}` for any unfinished phase, or `{ok:false, reason:'terminal-order'}` for a completed/cancelled order. Unknown IDs throw. It does not alter site contents, pending deliveries, capacity, population or item identities.

**Materials are consumed only at successful activation.** Unfinished cancellation therefore requires no refund, consumes no materials and selects no destructive policy. It loses elapsed construction work only. Completed buildings cannot be cancelled through this API; use the existing guarded factory-removal contract. Returning shipments, evacuating goods and selecting destinations remain host decisions. There is no abort/refund/discard API for active production in this slice.

`pruneConstructionOrders()` explicitly removes completed/cancelled history, never unfinished owners. Archive associations/receipts externally if needed. Counters are preserved. Terminal construction history may refer to inventories or producers that have since been removed; these are historical references, not goods owners.

## Local workforce, capacity and minimums

These concepts are independent:

- `workersRequired` retains its existing meaning: typed workforce claimed from the construction inventory at activation. That pool allocation is not proof of attendance.
- `workerSlots` defines efficiency capacity. Occupied slots hold worker IDs and efficiency values; occupancy is not automatically physical presence.
- `minimumWorkforce` defines typed local-attendance thresholds. By default, one worker of each positive required type is enough. `{smith:10}` explicitly requires ten smiths before any start, progress or publication. Counts must not exceed the configured workforce claim. An explicitly zero minimum does not permit a staffed factory to work remotely with zero total attendance.
- `setFacilityAttendance(id, {smith:1})` is the host's authoritative report. Initially attendance is empty, including after instant/timed activation. Reported counts must be safe nonnegative integers, known claimed types, and no greater than their allocated counts. Hosts own actual character identities, exclusivity and movement; counts do not infer arrival from coordinates, worker IDs, slot allocation or workforce capacity.

With ten occupied slots at 100% efficiency and one attendee, base productivity is **10%**. Ten attendees gives 100%. Efficiency is averaged over occupied slots and scaled down when fewer workers attend; empty slots contribute zero. For heterogeneous efficiencies, the host should populate slots with the actual attending workers (clearing absent slots) so the mean reflects those workers. Otherwise attendance counts scale the mean of the still-assigned slot roster; they cannot identify which specific worker attended. Optional slots on a definition with no workforce claim retain their existing efficiency-only behavior.

Productivity modifiers multiply this attended base. Below the minimum, effective productivity is zero and an independent attendance gate blocks even already-resolved output publication. A specialist cannot bypass it. `facilitySnapshot()` exposes saved `attendance`, `missingWorkforce` thresholds and effective productivity; `explainJob()` includes a `missing-workforce` blocker.

This release does not change construction-time workforce allocation: a building declaring ten claimed workers still needs that pool at activation, even if only one initially attends. Worker movement/character truth is host-owned. Restore preserves exactly the reported attendance and validates its bounds; it neither infers nor creates staff. Restore host worker/travel state and reconcile attendance before advancing the resumed game.

## Pause and drain remain separate

`setFacilityEnabled(id, false)` freezes that building's active progress/deferred work and owned inputs. It prevents new starts and pending-output publication. Other factories, construction orders and explicitly controlled shipments continue. Idle allocations are released; active batches retain consumed inputs. Resume proceeds on later ticks, subject to attendance and other conditions.

`setFacilityDraining(id, true)` prevents new batches and suppresses recipe demands, while allowing current work and unloading to finish. A disabled or under-staffed draining factory still cannot progress/publish. Both flags persist independently; neither cancels incoming cargo or implements inventory-wide dispatch suppression.

## Save, retirement and limits

Current save format **4** stores orders, counter, progress, consumed receipts and site reservations, plus facility attendance and the existing delivery manifests. Only format 4 is accepted; no migrations or fallback reconstruction are added. Runtime ownership is still exclusive. Restore rejects duplicate order/facility associations, counter collisions, invalid phases/costs/progress, misplaced/orphan reservations, missing active endpoints, impossible attendance and other ownership contradictions. Complete pending cargo and the clock remainder are preserved. No duplicate charge, completion, reroll or offline work occurs.

Existing inventory retirement is final cleanup. Unfinished orders now add an explicit `construction-reference` blocker for site/input/output endpoints, just as live jobs or cargo do. Refusal still changes no state or traces. Its success receipt and selective terminal-delivery pruning contract are unchanged. Terminal construction history is not implicitly pruned by retirement and remains reloadable with historical endpoints. `removeFacility()` remains unchanged. Required attendance is separate from demolition: hosts must bring workers back if draining needs them.

Order history is explicitly prunable; the tick loop visits only unfinished orders. Save/presentation costs still scale with retained history. Construction has tick-resolution completion, fixed configured work duration, no construction-specific pause/labor/speed rules and no automatic dispatch, placement or cancellation of cargo. Saved state is structurally validated, not authenticated against deliberate fabrication.

Run `node examples/timed-construction.mjs` after building. Tests cover missing/delayed materials, competing holds, atomic activation failures, cancellation phases, elapsed partitions, exact reload, malformed ownership, inventory retirement, independent production pause/drain, autonomous producers, departing/returning attendees, minimums and bonus/quality preservation.
