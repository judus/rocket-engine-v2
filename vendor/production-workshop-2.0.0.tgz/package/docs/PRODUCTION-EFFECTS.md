# Workers, effects and individual goods

The framework owns slots, rate aggregation, work progress, input ownership, outcome generation and delivery. Your game owns worker experience/mood calculations, perks, factory health, equipment wear, repair costs and character availability. There is no character AI or perk taxonomy in the core.

## Productivity during a batch

`workerSlots` is the nominal slot count. An assigned worker occupies one slot regardless of efficiency. Empty slots contribute zero. A facility with zero slots runs autonomously at base rate 1.

```
base rate = sum(assigned worker efficiencies) / number of slots
production rate = base rate × product(named productivity multipliers)
```

Three slots with efficiencies 0.8, 0.2 and empty give 1/3 productivity. Ten workers, half at 0.5 and half at 1, give 0.75; a specialist multiplier of 1.2 produces 0.9. Efficiencies and multipliers are nonnegative finite numbers from 0 to 100, where 1 means 100%. This generous numerical guard is not a game balance rule. Aggregate rates above 1,000,000 are rejected atomically. Rates are cached on command changes, not recalculated by scanning every worker on every tick.

```js
sim.setWorkerSlot(factoryId, 0, { id: "alice", efficiency: 0.8 });
sim.setWorkerSlot(factoryId, 1, { id: "bob", efficiency: 0.2 });
sim.setWorkerSlot(factoryId, 2, null);
sim.setProductionModifier(factoryId, "specialist:hana", {
  productivityMultiplier: 1.2,
  attributeBonuses: { maxHealth: 10, precision: 0.1 },
});
sim.setProductionModifier(factoryId, "factory-health", {
  productivityMultiplier: 0.5,
});
// Repair removes only this source; the specialist remains.
sim.setProductionModifier(factoryId, "factory-health", null);
```

A worker ID cannot occupy two slots in the same simulation. Updating an occupied slot with the same ID changes its efficiency. Setting efficiency 0 leaves the slot occupied; `null` frees it. Slots are shared by all concurrent recipes at a facility; the framework does not split worker effort between those recipes.

Each tick adds `rate` nominal ticks of work to active batches. New rates affect the next tick, including an already active batch, and never recalculate completed work. Tick resolution defaults to 50 ms. Commands should be submitted after advancing the host's elapsed time to the desired change boundary. Partial pending tick time is not split around commands. A zero rate pauses work and prevents new batches consuming inputs. Inputs and progress remain held. A resolved batch can still be delivered at zero rate; explicit suspension or an unfulfilled operating condition also blocks delivery. Surplus work can advance another immediately available batch in the same tick. The bounded processing limit retains deferred active work; waiting/blockage does not earn or bank idle work.

### Construction population and production slots

The `workersRequired`/`workersProvided` pool is a **construction eligibility and reserved capacity** model. Its reserved counts do not represent tracked characters. By default, required workers become nominal slots and start with generated anonymous workers at efficiency 1, providing default staffing for settlement buildings. Removing a slot assignment does not refund that construction reservation. Real character integration should define `workerSlots` and let its own workforce service assign workers; it need not use the construction pool. Explicit slots without `workersRequired` start empty. If slots exceed the construction requirement, only the required count starts occupied. The ship defines neither and runs at baseline 1.

## Variable quality, same product

Declare equipment as individual storage; bulk materials continue using counters.

```js
const weapon = {
  id: "weapon",
  label: "Ship weapon",
  kind: "material",
  storage: "individual",
};
const recipe = {
  id: "weapons",
  label: "Fabricate weapon",
  durationSeconds: 4,
  inputs: { alloy: 1, circuit: 1 },
  outputs: { weapon: 1 },
  itemAttributes: {
    weapon: {
      maxHealth: { min: 80, max: 90 },
      precision: { min: 0.8, max: 0.9 },
    },
  },
  optionalInputs: { reinforcement: 1 },
  optionalAttributeBonuses: { reinforcement: { maxHealth: 10 } },
};
```

Attribute names are domain data. Each item gets a stable identity and independently sampled numeric attributes. Nonconstant ranges are sampled uniformly in `[min, max)`; equal endpoints are fixed. All current modifier bonuses shift the range additively. Optional ingredient bonuses shift the same ranges. No attribute is automatically clamped to 100 or 1; reinforced weapons may exceed ordinary maximum health. Attribute values must be finite. Range endpoints and individual bonus values are bounded to absolute value 1e12 as a numerical guard; final summed attributes can exceed this. Attribute bonuses affect declared attributes only; the core does not invent an attribute from a bonus alone.

```js
sim.setOptionalInputs(factoryId, "weapons", { reinforcement: 1 });
// Next batches require and consume that ingredient, alongside mandatory inputs.
// {} disables the selection for the next batch; active batches retain their selection.
sim.setOptionalInputs(factoryId, "weapons", {});

const cargo = sim.inventory("ship");
const item = cargo.snapshot().items[0];
sim.updateItemAttributes(cargo.id, item.id, { currentHealth: 40 }); // Game applies wear.
sim.updateItemAttributes(cargo.id, item.id, {
  currentHealth: item.attributes.maxHealth,
}); // Game applies repair.
sim.transferItem(cargo.id, planetInventory.id, item.id); // Identity and attributes move together.
```

`maxHealth` is manufactured potential; `currentHealth` is current condition. The example deliberately applies current condition through host commands. The framework does not initialize or clamp it, spend repair ingredients or interpret these names. Item mutations validate finite numbers and return detached snapshots.

`quantity('weapon')` includes individual goods. Counter-based withdrawal, bulk reservations and quantity transfers cannot remove them. Use `sim.transferItem` for instant transfers, or [delivery manifests](LOGISTICS.md) with selected item IDs for transport. Individual recipe inputs require exact one-shot selection with `sim.setInputItems`; [the selection contract](API.md#selecting-individual-recipe-inputs) covers reservations and captured attributes. Construction costs remain bulk-only. Bulk lots with quality are also not implemented. Outcome publication is internal and atomic. Hosts create new equipment through `sim.spawnItem`; its IDs must be unused across the simulation. Consumed identities cannot be reused. Use `sim.consumeItem` to explicitly destroy an unreserved item.

## Bonus goods and outcome timing

```js
bonusOutputs: [{ chance: 0.01, outputs: { diamond: 1 } }];
```

Each entry rolls independently once when a batch's work finishes. Chance 0 never produces a bonus, chance 1 always does; 1% is a probability, not one guaranteed diamond per hundred batches. Bonuses join primary goods in one atomic delivery. They can also be individual goods with declared attributes.

At work completion the engine reads current specialist/quality modifiers, samples item attributes and rolls bonuses. Optional ingredient effects come from the selection captured at batch start. The engine stores this complete `BatchOutcome`; full storage, suspension and changing specialists afterward cannot change it. `pendingOutcome` in a job snapshot exposes blocked results. `batch-completed` reports successful delivery, not the earlier resolution instant.

Configuration `seed` defaults to 1. A deterministic per-batch stream is derived from seed, job instance ID and batch index. Delivery retries and unrelated producers do not draw from a shared random stream. Changing creation order changes instance IDs and can therefore change rolls. The version-4 save format preserves job/batch counters and seed; blocked outcomes are serialized without rerolling. The current random algorithm is part of that version contract; presentation snapshots remain separate from saves.

Projected capacity at start checks primary outputs only. Possible bonus capacity is checked when publishing the actual outcome; a lucky bonus can leave a completed batch waiting for storage. This preserves the roll rather than discarding a bonus or rerolling it.

## Try it

Run `npm run examples`, or just `npm run build && node examples/production-effects.mjs`. The example asserts slot aggregation and failure/resume, produces reinforced weapons with a specialist, applies wear/repair, and runs 500 coal batches at a genuine seeded 1% diamond chance.

In the browser, settlement workshops have efficiency and occupied-slot sliders. Specialist and factory-failure toggles affect active work. The coal mine includes the diamond bonus; build a worker residence to provide its 20 workers. In the ship scenario the weapon fabricator exposes reinforcement selection, and storage shows each weapon's attributes. These controls are example host commands, not game rules baked into production.

Local attendance is independent of efficiency slots and pool allocation. Report it with `setFacilityAttendance()`. Partial staffing is supported by default; `minimumWorkforce` sets stricter thresholds. A missing attendance minimum blocks starts, progress and pending publication regardless of modifiers. See [staffing rules and examples](TIMED-CONSTRUCTION.md#local-workforce-capacity-and-minimums).
