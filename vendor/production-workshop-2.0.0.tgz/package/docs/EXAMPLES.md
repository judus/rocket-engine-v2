# Runnable examples and integration

From the project root:

```sh
npm ci
npm run examples
```

This compiles the framework and runs fourteen examples against emitted JavaScript:

- `examples/settlement.mjs`: build a residence and warehouse, advance ten seconds, inspect materials and assigned workers.
- `examples/ship.mjs`: advance onboard production without workers and subscribe to completed-batch events.
- `src/minimal-example.ts` + `examples/minimal.mjs`: typed custom configuration, compiled and asserted to produce three alloys.
- `examples/production-effects.mjs`: slots, modifiers, quality, optional ingredients and bonuses.
- `examples/transport.mjs`: local buffers and host-timed deliveries.
- `examples/item-transport.mjs`: manufactured weapons shipped with bulk cargo, preserving identity, quality and wear.

- `examples/persistence.mjs`: JSON checkpoint/restore with an individual weapon in transit.
- `examples/accounting.mjs`: fractional clock and fair partial input allocation.
- `examples/diagnostics.mjs`: held inputs, blockers, item ownership, bounded trace and invariant validation.

- `examples/scoped-reads.mjs`: clock/count summaries, selected factory views, detached inventory totals and equipment windows.

- `examples/item-selection.mjs`: salvage one explicitly chosen damaged weapon, preserving another weapon through checkpoint/restore.
- `examples/factory-removal.mjs`: drain an active factory, remove it, and transport its manufactured equipment after restore.
- `examples/networks.mjs`: separate planet/faction stock and workforce under one clock, with explicit host-controlled links.

- `examples/web-worker.mjs`: run 6,000 factories in an actual Node worker, compare against direct execution, and checkpoint/restore. Browser rendering is measured separately in [worker.html](../worker.html); see [the worker integration guide](WORKER.md).

## JavaScript client

This API works in a plain ES-module host without a TypeScript rewrite:

```js
import { Simulation } from "./dist/index.js";

const simulation = new Simulation({
  resources: [
    { id: "ore", label: "Ore", kind: "material" },
    { id: "alloy", label: "Alloy", kind: "material" },
  ],
  recipes: [
    {
      id: "smelt",
      label: "Smelt alloy",
      durationSeconds: 1,
      inputs: { ore: 2 },
      outputs: { alloy: 1 },
    },
  ],
  facilities: [
    {
      id: "smelter",
      label: "Smelter",
      category: "production",
      recipes: ["smelt"],
      constructionCost: {},
    },
  ],
});
simulation.createInventory({
  id: "cargo",
  capacityPerMaterial: 20,
  initial: { ore: 6 },
});
const built = simulation.addFacility("smelter", "cargo");
if (!built.ok) throw new Error(built.reason);
simulation.advance(3.05);
console.log(simulation.inventory("cargo").snapshot().quantities);
// { ore: 0, alloy: 3 }
```

## Staffed planetary version

Use the same recipe and inventory code. On the facility definition, add:

```ts
workersRequired: { smiths: 1 },
operatingConditions: ['operator-present']
```

Register a residence or other facility with `workersProvided: { smiths: 1 }`, construct it first, then build the smelter. Conditions start false:

```js
simulation.setFacilityCondition(built.facilityId, "operator-present", true);
simulation.advance(0.3);
// A host mission/relationship system withdraws the operator:
simulation.setFacilityCondition(built.facilityId, "operator-present", false);
simulation.advance(10); // world time passes; this job preserves its progress
simulation.setFacilityCondition(built.facilityId, "operator-present", true);
```

This contract is exercised in `tests/framework.test.mjs`. The production engine knows the condition value, not how a character, relationship or mission determined it.

## Host loop

```js
import { Clock } from "./dist/index.js";
const clock = new Clock((seconds) => simulation.advance(seconds));
function frame(timestampMilliseconds) {
  clock.sample(timestampMilliseconds);
  render(simulation.snapshot());
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
```

Supply `render` from your UI. If your host already owns an authoritative elapsed-time loop, call `simulation.advance(deltaTime)` there instead: do NOT also create a second clock. Keep a single mutation owner and clock; integration with other projects is outside this demo.

## Instant movement between owned inventories

Create both inventories on the same simulation and use:

```js
const moved = simulation.transfer("planet", "cargo", { alloy: 2 });
```

Returns false atomically if the source lacks available goods or the destination is full. This is immediate transfer, not a transport scheduler. For delayed cargo ownership, use the delivery handoff API and the timed transport example described below.

## Production effects

`node examples/production-effects.mjs` (after build) exercises slots, live failure/resume, individual quality, reinforcement, wear/repair and seeded 1% diamond bonuses. See [the effects API and timing contract](PRODUCTION-EFFECTS.md).

## Timed transport

`node examples/transport.mjs` (after build) checks inbound travel, local production, outbound collection, full-output backpressure and manual recovery. The browser example is [logistics.html](../logistics.html). Read [the delivery contract](LOGISTICS.md).

## Hardening examples

- `node examples/persistence.mjs`: serialize a ship while a worn weapon is travelling, restore through JSON, finish its journey, and assert continued production matches the original world. Host travel state is saved separately.
- `node examples/accounting.mjs`: verify 100x work accounting, fractional-clock partitioning, and larger input bundles accumulating stock alongside small consumers.

See [API](API.md) for the simulation mutation commands and persistence contract.

For a longer workload, run `npm run soak`. This accelerated Node-worker check records collected heap with retained versus consumed equipment, then verifies exact checkpoint/restore continuation. See [limits and reproduction](WORKER.md#longer-production-and-lifecycle-checks).

- `examples/identity-lifecycle.mjs`: consume an externally spawned item, save/restore, verify that it remains retired and the next item receives a fresh ID without a historical ledger.

- `examples/inventory-retirement.mjs`: explicitly evacuate a weapon, observe goods/cargo blockers, retire its empty source, and reload with identity and quality preserved.

- `examples/timed-construction.mjs`: deliver site materials, construct over shared ticks, reload midway, report local attendance, pause/resume production, and cancel an unfinished order without destroying cargo or goods.
