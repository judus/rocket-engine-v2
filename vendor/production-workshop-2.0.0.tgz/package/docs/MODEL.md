# Models and execution contract

## Definitions versus state

Register one complete `Configuration` when creating a `Simulation`. Definitions have stable IDs, human labels and named fields; IDs are never inferred from labels or class names. A `Registry` validates references, resolves worker-slot defaults once, and copies/freezes content. Recipe data is copied/frozen once, including nested attributes and bonus definitions. Runtime JSON still requires this validation despite TypeScript types.

- Resource: a material or currency. Currency is uncapped, though quantities must remain safe integers.
- Recipe: input quantities, output quantities and duration in seconds (at least one microsecond). Empty inputs are valid extraction/generation. Several outputs form one atomic batch.
- Facility definition: category, recipe IDs, construction costs, optional worker provision/requirements, optional added capacity and optional named operating conditions.
- Facility instance: stable instance ID, inventory ID, enabled flag, condition values and jobs.
- Job: one production process per configured recipe. Multiple recipes run concurrently; recipe selection and multiple lanes are not implicit.
- Inventory: stock, reservations, per-material capacity and a workforce pool. Ship and settlement inventories are independent; stock is not global across all locations.

A per-material capacity of 20 means up to 20 ore AND 20 alloy, not a total-volume cargo limit. Currency never uses this capacity. Weight/volume policies are future extensions.

## Single simulation clock and work accounting

`advance(seconds)` accumulates elapsed time with fractional microseconds and compensated addition. It processes whole fixed ticks (default 50 ms) and retains the remainder. `advanceTicks(count)` provides exact host-driven ticks independently of that remainder. All jobs share this clock; there are no per-building timers. Floating-point arithmetic has a tiny boundary tolerance (0.1 picoseconds), not a frame-sized time cap. Submit commands at intended tick boundaries: a pending partial tick is not split around a command.

Recipe duration is exact nominal work, no longer rounded up to a tick. A first batch starts at the first boundary and earns no work from the interval before it started. Existing active jobs earn one interval scaled by current productivity. Short recipes and boosts may complete several batches in one tick; unused work can advance the next immediately available batch. Thus a one-second recipe at 100x earns 100 batches per working second, not a maximum of one batch per tick.

Each tick runs bounded rounds:

1. Spend earned work on active eligible jobs; resolve quality and bonuses once at work completion.
2. Publish resolved outcomes atomically, oldest completion/request first. Full storage leaves the outcome owned by its job.
3. Create persistent requests for idle eligible jobs.
4. Reserve available inputs incrementally in request order; consume the complete held bundle and start work only when all inputs are present.

Further rounds spend remaining work from that same tick, never award a second interval. Jobs newly activated from another producer's outputs have no earlier elapsed work to spend. A maximum of 1,000 rounds per tick bounds extreme configurations; surplus work on active jobs is deferred and saved. At that limit throughput can lag, but earned work is retained. Normal input waits and output blockage do not bank idle time. Disabling/gating a facility preserves active work, including deferred work. A zero rate pauses spending deferred work.

## Input allocation and reservations

The oldest request reserves any available part of its bundle. Held inputs remain physically in the inventory and occupy storage, but cannot be spent/transferred elsewhere. A successful producer rejoins the back for its next batch. One ore arriving per tick therefore allows a two-ore recipe to accumulate inputs instead of losing them to a one-ore consumer forever.

This policy deliberately trades utilization for protection of older requests. An old request missing a second resource may hold the first indefinitely; it is not a universal deadlock solver for arbitrary cyclic production graphs. Hosts can use separate buffers or disable/reconfigure an idle facility to release holdings. An input bundle larger than its inventory's per-material capacity is never partially reserved, because it cannot fit. An output-blocked idle job also releases its holdings.

Draining or disabling a facility, losing a condition, setting productivity to zero, or changing an idle optional/item selection releases its holdings and request age. Active batches retain already consumed inputs and their locked selections. Reservations are internal; hosts use delivery commands rather than raw tokens.

Start checks primary-output capacity after consumption of its own inputs, allowing same-resource transformations. Capacity is not reserved: other completions can fill storage. Actual primary/bonus output is checked atomically on publication. Blocked outcomes retain identity, quality and bonus rolls.

## Workforce and operating requirements

Construction checks costs and available workforce before mutation. Residences provide workers; workshops reserve workers; warehouses add capacity. Each inventory has its own worker pool. Suspending a facility does not unassign workers or refund construction costs.

Named operating conditions are explicit booleans supplied by the host. Conditions default to false. A facility requiring `operator-present` and `powered` runs only when both are true. Losing a condition pauses production and publication, retaining consumed inputs and partial/completed batches. Re-enabling resumes; it does not restart or charge inputs again. Resuming an idle job creates a new demand position on the next tick.

The engine does not invent worker AI, power consumption, relationship consequences or a research system. Host systems translate those mechanics into conditions and inventory commands.

## Events and ownership

The simulation is the sole mutation authority. Managed inventories expose frozen read-only handles and detached snapshots. Bulk commands, explicit item spawn/consume/repair/movement and delivery commands all pass through the same reentry guard. Item identities are global within one simulation: physical owners are an inventory, an active delivery, or a resolved job outcome. Reserved items remain at the source; terminal delivery item data is history, not a second owner. Issuance remains provable after consumption/pruning without per-item tombstones: external IDs use a monotonic counter and production IDs use deterministic per-job batch provenance. Item churn is bounded for a fixed producer population and bounded live stock. Removed-producer provenance still scales with factory churn.

Events report committed facts and are delivered after each whole command. Each completion includes a detached batch number and outcome; listeners each receive their own copy. Listener errors are collected into `AggregateError` after commit, without skipping other listeners. Commands and saves cannot run during notification. Observers should enqueue commands for the host's next phase instead of retrying a command that may already have succeeded.

All operations are synchronous and single-threaded. Snapshots/definitions do not expose mutation authority. No worker AI, routing or game balance is inferred by the core.

## Persistence and lifecycle boundaries

`save()` is a versioned complete checkpoint, separate from `snapshot()`. `Simulation.restore(unknown)` returns a fresh isolated world only after validation. It preserves pending time, work, request ordering, input reservations, identity/counter/RNG state, frozen configuration, completed outcomes and all delivery states. No inputs are recharged and no saved outcome is rerolled. Host timers/characters/listeners/UI remain outside the checkpoint. See [API](API.md) and the runnable persistence example.

Active inbound cargo is indexed by destination; reserved totals are indexed by resource. `deliverySnapshot(id)` avoids full-world cloning for transport queries. `pruneDeliveries()` removes terminal history without changing cargo ownership, IDs or demand promises. Snapshots and save generation still scale with total world size. This remains a synchronous prototype, not a large-world benchmark or an offline catch-up approximation.

Safe demolition drains existing work before removal, reverses population/capacity effects only when dependencies allow it, and preserves goods/provenance. Restore accepts only save version 4; incompatible versions are rejected without conversion. Active-batch refund/cancellation, inventory removal, route finding, shipment splitting and host content migrations remain undefined. This hardening pass does not change other game projects.

## Production effects

[Workers, quality, optional ingredients and bonuses](PRODUCTION-EFFECTS.md) specifies rate changes during batches, slots versus population pools, individual inventory, host repair commands and seeded one-time outcomes.

## Production buffers and delivery ownership

Facilities optionally bind distinct input/output inventories. The construction inventory still owns workforce/cost effects. Delivery commands reserve bulk stock and selected equipment identities, move goods into tracked transit ownership on pickup, then unload atomically when the host reports arrival. [Logistics](LOGISTICS.md) specifies demands, inbound promises, cancellation/return, example clock phases and limits.

## Explainability and shared validation

`explainJob` exposes simultaneous blockers and a breakdown of slot efficiency and named multipliers. Reservations, physical available stock and incoming promises remain distinct. `locateItem` reports the current physical owner or a retired issued identity; reservation inspection names the owning job or delivery without granting access to internal tokens.

Restore and `validateState` share the structural validator. Population pools must agree with facility construction effects, generated worker IDs must match their own slots, and issued production identities must agree with batch counters and seeded output manifests. Pending bonus quantities and item identity manifests are verified exactly. Saved quality values remain authoritative because modifiers may have changed after outcome resolution. Counter exhaustion is checked before mutation, including conservative headroom for bounded tick rounds.

`validateState` additionally reconstructs derived indexes and compares snapshots/demands. It reports the first issue, rather than collecting every cascading error. It is an explicit whole-world debug operation. Opt-in bounded trace history records production/allocation/delivery changes and commands; normal frame updates do not flood it, and checkpoints exclude it. No diagnostics are an event-sourcing or replay contract.

## Scoped presentation and checkpoint copies

The live simulation retains a derived facility index for direct selected-factory reads. Construction, removal and restore maintain it; no new index or presentation field is persisted. `summary()` reads clock/count metadata, inventory summaries omit equipment records, and bounded item pages clone only their returned window. Offset pages are live views whose membership may change after stock movement. Whole-world `snapshot()` remains available.

Each checkpoint field owns its detached copy: immutable configuration is copied once, each inventory emits fresh stock/items/workforce/reservations, factory fields copy their nested worker/modifier/job state, and delivery records copy their manifests. The completed checkpoint is returned directly. Restore still validates an isolated copy of untrusted checkpoint data. This optimization preserves its ownership boundary and save version.

Without event subscribers, production keeps trace metadata but skips queued notification records and detached completion payloads. With subscribers, completion payloads remain historical facts and each listener receives its own copy. Subscribe/unsubscribe during notification retains the existing ordering contract.


## Individual inputs and removal provenance

Individual inputs require one-shot host selection. Tick allocation holds exact identities alongside bulk inputs; another reservation owner cannot lose its goods. Batch start consumes the entire bundle and captures latest item attributes as historical batch metadata. These records grant no ownership. Missing selection does not hold bulk inputs; stale selection waits without substitution. Outputs receive new identities, with no implicit attribute inheritance. See [selection contract](API.md#selecting-individual-recipe-inputs).

Drain prevents new batches while existing work finishes normally. Safe removal refuses active work, workforce shortage and capacity loss below physical stock. It releases idle holdings and reverses construction effects, retaining inventories and all deliveries. Removed-factory provenance validates lifetime manufactured identities without keeping removed jobs active. See [removal contract](API.md#draining-and-safe-removal).

Planet/faction networks are separate sets of inventories/endpoints in one simulation, with one authoritative clock. The host owns network membership and permission to trade. Separate simulations have separate identity domains and clocks; cross-simulation cargo handoff remains outside this API. See [context boundaries](API.md#planets-factions-and-simulation-contexts).


## Validation boundaries and trusted execution

Definitions and public commands validate external values. Restore accepts only the current format and validates complete ownership/accounting before returning a new world. Unsupported headers fail before copying the payload. Reserved record-key names are rejected at registration instead of producing inherited-property arithmetic later.

Advance preflights the full clock/counter budget before its first tick. Private ticks do not repeat that budget scan. Production inputs come from immutable registered recipes and validated optional selections; capacity/allocation helpers consume that trusted data directly. Inventory transfers preflight both endpoints once, then commit once. Construction checks stock, workforce and safe-integer effects before payment; its private commit does not revalidate after charging. Removal follows the same preflight/commit separation.

Internal ownership assertions, observer error aggregation, detached public views and strict restore validation are deliberate contracts. Configuration defaults, production phases, bulk versus individual goods, and the two explicit host-clock entry points are current supported behaviors. They are not compatibility fallback paths. There is no migration adapter, alternate legacy engine, silent repair of malformed saves, or swallowed production error.

Timed construction uses explicit owned orders and site reservation tokens; costs are consumed only at atomic activation. The tick loop indexes unfinished orders separately from terminal history. Local attendance, configured minimums, pool allocation and efficiency slots are distinct. Pause and drain remain independent. See [construction and attendance contracts](TIMED-CONSTRUCTION.md).
