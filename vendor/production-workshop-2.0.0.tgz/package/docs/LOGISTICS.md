# Local buffers and delivery handoffs

Production owns input consumption, outcomes and inventory handoffs. The host owns transport agents, route choice, dispatch policy, travel time and deciding when a pickup/arrival occurs. The core never advances a delivery automatically.

## Connect production endpoints

```js
sim.createInventory({
  id: "warehouse",
  capacityPerMaterial: 100,
  initial: { ore: 60 },
});
sim.createInventory({ id: "smelter-input", capacityPerMaterial: 4 });
sim.createInventory({ id: "smelter-output", capacityPerMaterial: 2 });
const built = sim.addFacility("smelter", "warehouse", {
  inputInventoryId: "smelter-input",
  outputInventoryId: "smelter-output",
});
```

The original `inventoryId` remains the construction/workforce/capacity account. Separate `inputInventoryId` and `outputInventoryId` bind production endpoints. Omitting either option uses the original inventory, preserving direct ship and settlement behavior. All endpoints must already exist in the simulation. Binding does not copy or automatically move stock, and these bindings cannot currently be changed after construction.

Production reserves and consumes mandatory/selected optional ingredients from the input inventory only. It delivers complete, atomic outcomes to the output inventory only. For separate inventories, consuming inputs does not free output space. For one shared inventory, capacity prediction still accounts for input consumption. Output capacity is checked at batch start for primary goods; actual primary/bonus/item output is checked again at publication. Completed outcomes remain owned by the job when output storage is full.

## Observe material demands

```js
const demands = sim.materialDemands();
// [{ facilityId, jobId, inventoryId: 'smelter-input', quantities: { ore: 2 } }]
```

This read-only query reports uncovered input quantities for the next batch of each idle, enabled, operating facility with positive productivity. Inputs already held for each job are subtracted first. Shared-buffer unreserved stock is provisionally assigned in persistent demand order. Reserved/in-transit/arrival-blocked inbound deliveries also count as promised supply, preventing a host from dispatching the same missing bundle every frame. It does not reserve anything itself and is not a transport job queue.

Demands omit draining facilities and already active jobs: this version does not forecast future consumption or maintain target buffer stock. Idle jobs can demand inputs even if output space is currently full, allowing a host to stage their next ingredients. `JobSnapshot.missingInputs` continues showing physical input deficits; a delivery promise cannot start production. Neither query chooses suppliers, priorities, vehicles or routes. Multiple hosts must coordinate dispatch in a single command phase; arbitrary extra shipments are permitted and may overfill a destination.

## Delivery lifecycle and ownership

```js
const result = sim.reserveDelivery("warehouse", "smelter-input", { ore: 2 });
if (result.ok) {
  // A vehicle reaches the warehouse:
  sim.pickupDelivery(result.deliveryId);
  // The host runs movement/travel. No deposit occurs during transit.
  // When the vehicle reaches the factory:
  const unloaded = sim.arriveDelivery(result.deliveryId);
  // false means the vehicle still owns its cargo; retry after storage clears.
}
```

| State             | Where goods are owned                                | Operations              |
| ----------------- | ---------------------------------------------------- | ----------------------- |
| `reserved`        | Source inventory; held against other spending        | Pickup or cancel        |
| `in-transit`      | Delivery cargo; neither source nor destination stock | Arrive or return        |
| `arrival-blocked` | Delivery cargo, awaiting storage                     | Retry arrival or return |
| `delivered`       | Destination inventory                                | Terminal                |
| `cancelled`       | Source stock (released or returned)                  | Terminal                |

`reserveDelivery(sourceId, destinationId, quantities)` returns `{ok:true, deliveryId}` or `{ok:false, reason}` if source goods or selected items cannot be reserved. Invalid IDs/quantities or empty cargo throw. Endpoints must differ. Reserving does not require destination capacity and does not deduct owned source quantities yet. Pickup commits the reservation exactly once; arrival deposits the entire cargo atomically. Repeated pickup/arrival after success throws, preventing duplicate goods.

`cancelDelivery(id)` releases an unpicked reservation. Picked-up cargo cannot simply be cancelled away. The host instead schedules a return journey and calls `returnDelivery(id)` **after it reaches the source**. This returns true and marks cancelled if all cargo can unload, or false while retaining the cargo if the source has become full. These handoff methods do not simulate travel themselves.

Delivery snapshots are included in `sim.snapshot().deliveries` and contain `{id, sourceInventoryId, destinationInventoryId, quantities, itemIds, items, state}`. Quantities describe the original manifest even after a delivery becomes terminal; only `in-transit`/`arrival-blocked` cargo contributes to transit stock in conservation accounting. At reservation, goods remain counted at the source. Terminal records are retained for inspection and can be explicitly pruned; save/restore preserves active ownership. Do not use an ever-growing inspection ledger as a long-running game's persistence design.

Inventory primitives remain available to host trade/logistics. Reservations with `logistics:` tokens belong to delivery commands; hosts must not directly release/commit those tokens. Commands are synchronous and cannot be invoked from simulation event observers; enqueue transport actions for the next host command phase instead. Delivery commands do not emit production lifecycle events; inspect snapshots for their state.

## Automatic versus manual is host policy

Automatic feeding means a logistics system dispatches uncovered demands. It does not mean instant material access. Automatic collection similarly picks output up and carries it to a destination. Both settings live in `TransportExample`, not in recipe definitions or production rules. Disabling either stops new automatic dispatches; it does not erase or freeze existing deliveries.

`src/transport-example.ts` is an example host with travel timers, not a pathfinder shipped as core machinery. Its `advance(seconds)` retains fractional time and uses the configured fixed tick. On each shared boundary it handles arrivals, advances production, then dispatches new supply and collection. Calling production separately as well would double-advance it. In a real game, integrate these phases into the engine's existing fixed update; render snapshots independently.

Travel changes affect newly dispatched trips. In-flight trips retain their original duration. Failed arrivals retry each tick in the example; a real host might queue unloading space, park vehicles or choose another destination. The example has unlimited carriers and no transport costs or picking/loading delay. Production needs only real materials and output space, so distance and backpressure already affect throughput without inventing those game rules.

## Run and explore

- Open `http://127.0.0.1:8088/logistics.html` after `npm start`.
- `npm run build && node examples/transport.mjs` checks the first alloy takes 3 seconds inbound, 1 second work and 3 seconds collection, after the first dispatch boundary.
- Increase travel time to reduce throughput.
- Disable collection: two alloys fill the local output buffer and production blocks. Collect one to resume.
- Disable feeding: no new input deliveries are scheduled. Existing cargo still arrives. Dispatch supplies manually.

## Transport individual equipment

```js
const weapon = sim.inventory("ship").snapshot().items[0];
// Third argument contains bulk only. Individual counts are derived from selected IDs.
const delivery = sim.reserveDelivery("ship", "outpost", { sensor: 1 }, [
  weapon.id,
]);
if (delivery.ok) {
  sim.pickupDelivery(delivery.deliveryId);
  // Host owns travel; at arrival, unload bulk and items as one atomic cargo:
  sim.arriveDelivery(delivery.deliveryId);
}
```

`reserveDelivery(sourceId, destinationId, bulkQuantities = {}, itemIds = [])` supports bulk-only, item-only and mixed cargo. Pick exact item IDs rather than a count such as `{weapon: 1}`; the framework never chooses an arbitrary quality variant. Duplicate/invalid ID lists throw. Missing or already-reserved items return `{ok:false}` without reserving any part of the bulk/item bundle.

Reserved equipment remains physically at its source, but cannot be reserved again or moved by `sim.transferItem`. `InventorySnapshot.reservedItemIds` identifies these goods; `reserved(resourceId)`/`available(resourceId)` include their counts. The host can still apply source wear/repair before pickup. **Pickup captures the latest attributes**, removes the selected items from source inventory and places them in delivery ownership. `DeliverySnapshot.itemIds` identifies selected goods; `items` is empty before pickup and contains detached `{id, resourceId, attributes}` views afterward. Delivery `quantities` includes bulk plus selected item counts.

During transit, blocked unloading and return, the same identities and attributes are retained without quality sampling or reconstruction. The entire mixed cargo must fit before anything unloads. Destination identity conflicts throw before depositing any part; they indicate an invalid external import rather than a capacity delay. Pre-pickup cancellation releases every item and bulk reservation. After pickup, a host return journey and `returnDelivery` restore the same goods atomically. Terminal snapshots retain original cargo data for inspection and do not count as extra owned items.

Read-only inventory handles expose `item(itemId)` as a detached view or undefined if physically absent. All mutation, reservation and handoff authority stays inside the simulation. Use `sim.updateItemAttributes(inventoryId, itemId, patch)` for wear/repair at source and `sim.spawnItem` only for genuinely new equipment. Global identity checks prevent duplicating an existing item at a destination.

For polling an individual journey use `sim.deliverySnapshot(id)`. Active inbound promises are indexed by destination; terminal history does not slow material-demand scans. `sim.pruneDeliveries()` removes terminal records, retaining active cargo and identity counters. `sim.save()`/`Simulation.restore()` persist all cargo states/reservations/attributes; external vehicle travel timers must be saved separately by the host.

`npm run build && node examples/item-transport.mjs` manufactures a ship weapon, applies wear, transports it with a sensor, exercises blocked unloading and asserts exact identity/attribute equality at arrival. The browser transport page has **Send one weapon to outpost** and shows item attributes at source, in transit and destination. It seeds two equipment items specifically for transport inspection; manufacturing remains demonstrated in the ship scenario.

## Current limits

Delivery manifests carry bulk goods (including currency if a game wants to transport it) and selected individual equipment. Individual recipe inputs use explicit `setInputItems` selection; construction costs remain bulk-only. Demands for individual inputs include `itemSelection` metadata, and arbitrary inbound equipment quantities do not satisfy an identity choice. Routing, carrier capacity, carrier assignment, transport losses, rerouting, shipment splitting, stock forecasts, and host content migration are not implemented. Restore accepts only save version 4, with no compatibility conversion. Source/destination reservations protect stock, not storage space at arrival. The example validates behavior and frame partitioning, not large-world performance.
