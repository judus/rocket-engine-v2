import { Clock } from "./dist/index.js";
import { TransportExample } from "./dist/transport-example.js";
const $ = (id) => document.getElementById(id);
let world,
  clock,
  lastPaint = 0,
  hiddenPause = false;
const stock = (id) => {
  const i = world.simulation.inventory(id);
  return `Ore: ${i.quantity("ore")} · Alloy: ${i.quantity("alloy")}`;
};
function itemText(item) {
  return `${item.id} · ${Object.entries(item.attributes)
    .map(([key, n]) => `${key}: ${n.toFixed(2)}`)
    .join(" · ")}`;
}
function paintItems(nodeId, inventoryId) {
  const page = world.simulation.inventory(inventoryId).itemPage({limit:50});
  const items = page.items;
  const rows = items.map((item) => {
    const row = document.createElement("p");
    row.className = "hint";
    row.textContent = itemText(item);
    return row;
  });
  if (!rows.length) {
    const row = document.createElement("p");
    row.className = "hint";
    row.textContent = "No equipment here.";
    rows.push(row);
  }
  if (page.total > items.length) {
    const note = document.createElement("p"); note.className = "hint"; note.textContent = `${items.length} of ${page.total} items shown.`; rows.push(note);
  }
  $(nodeId).replaceChildren(...rows);
}
function paint(force = false) {
  const now = performance.now();
  if (!force && now - lastPaint < 100) return;
  lastPaint = now;
  const s = world.simulation.summary(),
    job = world.simulation.facilitySnapshot(world.simulation.facilityIds()[0]).jobs[0];
  $("clock").textContent = `${s.timeSeconds.toFixed(1)}s`;
  $("pause").textContent = clock.paused ? "Resume" : "Pause";
  $("warehouse").textContent = stock("warehouse");
  paintItems("source-items", "warehouse");
  paintItems("destination-items", "outpost");
  $("input").textContent = stock("smelter-input");
  $("output").textContent = stock("smelter-output");
  $("status").textContent = job.state.replaceAll("-", " ");
  $("progress").value = job.progress;
  $("batches").textContent =
    `${job.batchesCompleted} batches delivered into output buffer`;
  $("demand").textContent = world.simulation.materialDemands().length
    ? "Needs ore delivery"
    : "No uncovered input demand";
  const rows = world.journeys().map((d) => {
    const row = document.createElement("div");
    row.className = "production-controls";
    const text = document.createElement("span");
    text.textContent = `${d.id}: ${Object.entries(d.quantities)
      .map(([id, n]) => `${n} ${id}`)
      .join(
        " + ",
      )} · ${d.sourceInventoryId} → ${d.destinationInventoryId} · ${d.state === "arrival-blocked" ? "Waiting for storage" : `${d.remainingSeconds.toFixed(1)}s remaining`}`;
    const progress = document.createElement("progress");
    progress.max = 1;
    progress.value = d.progress;
    progress.setAttribute("aria-label", `${d.id} travel progress`);
    row.append(text, progress);
    for (const item of d.items) {
      const detail = document.createElement("small");
      detail.textContent = itemText(item);
      row.append(detail);
    }
    return row;
  });
  if (!rows.length) {
    const empty = document.createElement("p");
    empty.textContent = "No cargo in transit.";
    rows.push(empty);
  }
  $("deliveries").replaceChildren(...rows);
  $("delivered").textContent =
    `${world.completedDeliveries} deliveries completed`;
}
function reset() {
  world = new TransportExample();
  clock = new Clock((dt) => world.advance(dt));
  hiddenPause = false;
  world.travelSeconds = Number($("travel").value);
  world.automaticFeeding = $("feeding").checked;
  world.automaticCollection = $("collection").checked;
  paint(true);
}
$("feeding").addEventListener(
  "change",
  () => (world.automaticFeeding = $("feeding").checked),
);
$("collection").addEventListener(
  "change",
  () => (world.automaticCollection = $("collection").checked),
);
$("travel").addEventListener(
  "change",
  () => (world.travelSeconds = Number($("travel").value)),
);
$("dispatch").addEventListener("click", () => {
  $("notice").textContent = world.dispatchSupply()
    ? "Supply dispatched."
    : "No uncovered demand or available source goods.";
  paint(true);
});
$("collect").addEventListener("click", () => {
  $("notice").textContent = world.collectOutput()
    ? "Alloy picked up for collection."
    : "No alloy ready for collection.";
  paint(true);
});
$("send-weapon").addEventListener("click", () => {
  $("notice").textContent = world.dispatchWeapon()
    ? "Weapon picked up for transport, with its identity and attributes."
    : "No unreserved weapon available.";
  paint(true);
});
$("pause").addEventListener("click", () => {
  clock.setPaused(!clock.paused);
  paint(true);
});
$("reset").addEventListener("click", reset);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    hiddenPause = !clock.paused;
    clock.setPaused(true);
  } else if (hiddenPause) {
    clock.setPaused(false);
    hiddenPause = false;
  }
  paint(true);
});
reset();
function frame(now) {
  clock.sample(now);
  paint();
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
