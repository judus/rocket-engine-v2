import { invariant } from "./registry.js";
/** Host adapter: measured wall time in milliseconds → simulation seconds. No browser dependency. */
export class Clock {
  #last: number | null = null;
  #speed = 1;
  #paused = false;
  constructor(private readonly advance: (seconds: number) => unknown) {}
  get speed(): number {
    return this.#speed;
  }
  set speed(value: number) {
    invariant(
      Number.isFinite(value) && value > 0,
      "clock speed must be positive",
    );
    this.#speed = value;
  }
  get paused(): boolean {
    return this.#paused;
  }
  setPaused(value: boolean): void {
    this.#paused = value;
    this.#last = null;
  }
  resetBaseline(): void {
    this.#last = null;
  }
  sample(nowMilliseconds: number): void {
    invariant(
      Number.isFinite(nowMilliseconds),
      "clock timestamp must be finite",
    );
    if (this.#paused) return;
    if (this.#last === null) {
      this.#last = nowMilliseconds;
      return;
    }
    invariant(
      nowMilliseconds >= this.#last,
      "clock timestamps must be monotonic",
    );
    const elapsed = (nowMilliseconds - this.#last) / 1000;
    this.#last = nowMilliseconds;
    this.advance(elapsed * this.#speed);
  }
}
