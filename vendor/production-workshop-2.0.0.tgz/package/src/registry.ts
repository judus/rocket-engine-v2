import type {
  Configuration,
  FacilityDefinition,
  Quantities,
  RecipeDefinition,
  ResourceDefinition,
} from "./models.js";
type RegisteredFacilityDefinition = FacilityDefinition & { readonly workerSlots: number; readonly minimumWorkforce: Quantities };

const reservedRecordKeys = new Set(["__proto__", "constructor", "prototype"]);

export class DefinitionError extends Error {
  override name = "DefinitionError";
}
export function invariant(
  condition: unknown,
  message: string,
): asserts condition {
  if (!condition) throw new DefinitionError(message);
}
export function validateQuantities(
  values: Quantities,
  path: string,
  resources?: ReadonlyMap<string, ResourceDefinition>,
): void {
  invariant(
    values !== null && typeof values === "object" && !Array.isArray(values),
    `${path}: expected a quantity object`,
  );
  for (const [id, amount] of Object.entries(values)) {
    invariant(
      id.length > 0 && !reservedRecordKeys.has(id) && (!resources || resources.has(id)),
      `${path}: unknown resource '${id}'`,
    );
    invariant(
      Number.isSafeInteger(amount) && amount >= 0,
      `${path}.${id}: expected a non-negative safe integer`,
    );
  }
}
/** Validates and owns copies of registered content. No renderer or service container dependency. */
export class Registry {
  readonly #resources = new Map<string, ResourceDefinition>();
  readonly #recipes = new Map<string, RecipeDefinition>();
  readonly #facilities = new Map<string, RegisteredFacilityDefinition>();
  readonly tickMicroseconds: number;
  constructor(config: Configuration) {
    const tickMs = config.tickMilliseconds ?? 50;
    invariant(
      Number.isSafeInteger(tickMs) && tickMs > 0 && tickMs <= 1000,
      "tickMilliseconds: expected an integer from 1 to 1000",
    );
    this.tickMicroseconds = tickMs * 1000;
    invariant(
      Number.isSafeInteger(config.seed ?? 1),
      "seed must be a safe integer",
    );
    const isArray = (value: unknown): boolean => Array.isArray(value);
    invariant(isArray(config.resources) && isArray(config.recipes) && isArray(config.facilities), "configuration requires definition arrays");
    for (const r of config.resources) {
      this.validateIdentity(r, this.#resources, "resource");
      invariant(
        r.kind === "material" || r.kind === "currency",
        `resource ${r.id}: invalid kind`,
      );
      invariant(
        r.storage === undefined ||
          r.storage === "bulk" ||
          (r.storage === "individual" && r.kind === "material"),
        "invalid resource storage",
      );
      this.#resources.set(r.id, Object.freeze({ ...r }));
    }
    for (const r of config.recipes) {
      this.validateIdentity(r, this.#recipes, "recipe");
      invariant(
        Number.isFinite(r.durationSeconds) &&
          r.durationSeconds >= 1e-6 &&
          Number.isSafeInteger(Math.round(r.durationSeconds * 1e6)),
        `recipe ${r.id}: invalid duration`,
      );
      validateQuantities(r.inputs, `recipe ${r.id}.inputs`, this.#resources);
      const combinedInputs: Record<string, number> = Object.assign(
        Object.create(null),
        r.inputs,
      );
      for (const [id, n] of Object.entries(r.optionalInputs ?? {}))
        combinedInputs[id] = (combinedInputs[id] ?? 0) + n;
      validateQuantities(combinedInputs, "combined inputs", this.#resources);
      validateQuantities(r.outputs, `recipe ${r.id}.outputs`, this.#resources);
      invariant(
        Object.values(r.outputs).some((n) => n > 0),
        `recipe ${r.id}: needs positive output`,
      );
      this.validateRecipeExtensions(r);
      this.#recipes.set(
        r.id,
        freezeData(r),
      );
    }
    for (const f of config.facilities) {
      this.validateIdentity(f, this.#facilities, "facility");
      invariant(
        typeof f.category === "string" && f.category.length > 0,
        `facility ${f.id}: missing category`,
      );
      invariant(
        Array.isArray(f.recipes as unknown) &&
          new Set(f.recipes).size === f.recipes.length,
        `facility ${f.id}: invalid or duplicate recipes`,
      );
      for (const id of f.recipes)
        invariant(
          this.#recipes.has(id),
          `facility ${f.id}: unknown recipe '${id}'`,
        );
      invariant(
        Array.isArray(f.operatingConditions ?? []) &&
          new Set(f.operatingConditions ?? []).size ===
            (f.operatingConditions ?? []).length &&
          (f.operatingConditions ?? []).every(
            (id) => typeof id === "string" && id.length > 0,
          ),
        `facility ${f.id}: invalid operating conditions`,
      );
      validateQuantities(
        f.constructionCost,
        `facility ${f.id}.constructionCost`,
        this.#resources,
      );
      for (const [id, n] of Object.entries(f.constructionCost))
        invariant(
          n === 0 || this.resource(id).storage !== "individual",
          "construction requires bulk goods",
        );
      validateQuantities(
        f.workersRequired ?? {},
        `facility ${f.id}.workersRequired`,
      );
      const minimum=f.minimumWorkforce ?? Object.fromEntries(Object.entries(f.workersRequired ?? {}).filter(([,n])=>n>0).map(([type])=>[type,1]));
      validateQuantities(minimum,`facility ${f.id}.minimumWorkforce`);
      for(const [type,n] of Object.entries(minimum))invariant(Object.hasOwn(f.workersRequired ?? {},type) && n<=(f.workersRequired?.[type] ?? 0),"minimum workforce exceeds assigned capacity or uses unknown type");
      validateQuantities(
        f.workersProvided ?? {},
        `facility ${f.id}.workersProvided`,
      );
      invariant(
        Number.isSafeInteger(f.capacityProvided ?? 0) &&
          (f.capacityProvided ?? 0) >= 0,
        `facility ${f.id}: invalid capacity`,
      );
      const slots =
        f.workerSlots ??
        Object.values(f.workersRequired ?? {}).reduce((a, b) => a + b, 0);
      invariant(
        Number.isSafeInteger(slots) && slots >= 0 && slots <= 10000,
        "invalid workerSlots",
      );
      this.#facilities.set(
        f.id,
        Object.freeze({
          ...f,
          workerSlots: slots,
          minimumWorkforce:Object.freeze({...minimum}),
          recipes: Object.freeze([...f.recipes]),
          operatingConditions: Object.freeze([
            ...(f.operatingConditions ?? []),
          ]),
          constructionCost: Object.freeze({ ...f.constructionCost }),
          workersRequired: Object.freeze({ ...f.workersRequired }),
          workersProvided: Object.freeze({ ...f.workersProvided }),
        }),
      );
    }
    Object.freeze(this);
  }
  private validateRecipeExtensions(r: RecipeDefinition): void {
    this.validate(r.optionalInputs ?? {}, "optional inputs");
    for (const [id, attrs] of Object.entries(r.itemAttributes ?? {})) {
      invariant(
        this.resource(id).storage === "individual" &&
          ((r.outputs[id] ?? 0) > 0 ||
            (r.bonusOutputs ?? []).some((b) => (b.outputs[id] ?? 0) > 0)),
        "item attributes require a individual output",
      );
      invariant(attrs !== null && typeof attrs === "object" && !Array.isArray(attrs), "invalid item attributes");
      for (const range of Object.values(attrs))
        invariant(
          range !== null && typeof range === "object" && Number.isFinite(range.min) &&
            Number.isFinite(range.max) &&
            range.min <= range.max &&
            Math.abs(range.min) <= 1e12 &&
            Math.abs(range.max) <= 1e12,
          "invalid attribute range",
        );
    }
    for (const [id, attrs] of Object.entries(
      r.optionalAttributeBonuses ?? {},
    )) {
      invariant(
        (r.optionalInputs?.[id] ?? 0) > 0,
        "attribute bonus requires an optional ingredient",
      );
      validateAttributes(attrs, 1e12);
    }
    for (const bonus of r.bonusOutputs ?? []) {
      invariant(
        Number.isFinite(bonus.chance) && bonus.chance >= 0 && bonus.chance <= 1,
        "invalid bonus chance",
      );
      this.validate(bonus.outputs, "bonus output");
      invariant(
        Object.values(bonus.outputs).some((n) => n > 0),
        "empty bonus output",
      );
    }
    const maximum: Record<string, number> = Object.assign(
      Object.create(null),
      r.outputs,
    );
    for (const bonus of r.bonusOutputs ?? [])
      for (const [id, n] of Object.entries(bonus.outputs))
        maximum[id] = (maximum[id] ?? 0) + n;
    this.validate(maximum, "maximum batch output");
    invariant(
      Object.entries(maximum)
        .filter(([id]) => this.resource(id).storage === "individual")
        .reduce((n, [, count]) => n + count, 0) <= 10000,
      "too many individual items per batch",
    );
  }
  private validateIdentity(
    value: { id: string; label: string },
    map: ReadonlyMap<string, unknown>,
    kind: string,
  ): void {
    invariant(
      typeof value.id === "string" && !reservedRecordKeys.has(value.id) &&
        /^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(value.id),
      `${kind}: invalid id`,
    );
    invariant(!map.has(value.id), `${kind}: duplicate id '${value.id}'`);
    invariant(
      typeof value.label === "string" && value.label.length > 0,
      `${kind} ${value.id}: missing label`,
    );
  }
  resource(id: string): ResourceDefinition {
    const d = this.#resources.get(id);
    invariant(d, `unknown resource '${id}'`);
    return d;
  }
  recipe(id: string): RecipeDefinition {
    const d = this.#recipes.get(id);
    invariant(d, `unknown recipe '${id}'`);
    return d;
  }
  facility(id: string): RegisteredFacilityDefinition {
    const d = this.#facilities.get(id);
    invariant(d, `unknown facility '${id}'`);
    return d;
  }
  get resources(): readonly ResourceDefinition[] {
    return [...this.#resources.values()];
  }
  get recipes(): readonly RecipeDefinition[] {
    return [...this.#recipes.values()];
  }
  get facilities(): readonly RegisteredFacilityDefinition[] {
    return [...this.#facilities.values()];
  }
  validate(values: Quantities, path: string): void {
    validateQuantities(values, path, this.#resources);
  }
}

export function validateAttributes(
  values: Readonly<Record<string, number>>,
  limit = Infinity,
): void {
  invariant(
    values !== null && typeof values === "object" && !Array.isArray(values),
    "invalid attributes",
  );
  for (const [id, n] of Object.entries(values))
    invariant(
      id.length > 0 && Number.isFinite(n) && Math.abs(n) <= limit,
      "invalid numeric attribute",
    );
}
export function cloneData<T>(value: T): T {
  if (value && typeof value === "object")
    return (
      Array.isArray(value)
        ? value.map(cloneData)
        : Object.fromEntries(
            Object.entries(value).map(([k, v]) => [k, cloneData(v)]),
          )
    ) as T;
  return value;
}
function freezeData<T>(value: T): T {
  if (value && typeof value === "object") {
    const copy = (
      Array.isArray(value)
        ? value.map(freezeData)
        : Object.fromEntries(
            Object.entries(value).map(([k, v]) => [k, freezeData(v)]),
          )
    ) as T;
    return Object.freeze(copy);
  }
  return value;
}
