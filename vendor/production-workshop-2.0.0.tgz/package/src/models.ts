/** Authorable configuration. IDs are stable references, never inferred from labels. */
export type Quantities = Readonly<Record<string, number>>;
export interface ResourceDefinition {
  id: string;
  label: string;
  kind: "material" | "currency";
  /** Individual goods carry identity and numeric attributes. */
  storage?: "bulk" | "individual";
}
export interface RecipeDefinition {
  id: string;
  label: string;
  durationSeconds: number;
  inputs: Quantities;
  outputs: Quantities;
  itemAttributes?: Readonly<
    Record<string, Readonly<Record<string, AttributeRange>>>
  >;
  bonusOutputs?: readonly { chance: number; outputs: Quantities }[];
  optionalInputs?: Quantities;
  /** Selected optional inputs add these values to each item's attribute ranges. */
  optionalAttributeBonuses?: Readonly<
    Record<string, Readonly<Record<string, number>>>
  >;
}
export interface FacilityDefinition {
  id: string;
  label: string;
  category: string;
  recipes: readonly string[];
  constructionCost: Quantities;
  /** Optional worker types, scoped to the facility's inventory. */
  workersRequired?: Quantities;
  /** Attendance threshold per worker type; defaults to one per required type. */
  minimumWorkforce?: Quantities;
  workersProvided?: Quantities;
  capacityProvided?: number;
  /** Defaults to the sum of workersRequired; zero means autonomous production. */
  workerSlots?: number;
  /** Named gates supplied by the host, e.g. operator-present or powered. Initially false. */
  operatingConditions?: readonly string[];
}
export interface Configuration {
  resources: readonly ResourceDefinition[];
  recipes: readonly RecipeDefinition[];
  facilities: readonly FacilityDefinition[];
  /** Tick length in milliseconds; defaults to 50. */
  tickMilliseconds?: number;
  seed?: number;
}
export interface InventoryOptions {
  id: string;
  capacityPerMaterial: number;
  initial?: Quantities;
}
export type JobState =
  | "drained"
  | "waiting-inputs"
  | "producing"
  | "output-blocked"
  | "paused"
  | "waiting-condition"
  | "waiting-workers";
export interface JobSnapshot {
  id: string;
  recipeId: string;
  state: JobState;
  progress: number;
  batchesCompleted: number;
  missingInputs: Record<string, number>;
  demandSinceTick: number | null;
  selectedOptionalInputs: Record<string, number>;
  selectedInputItemIds: string[];
  batchInputItems: ProducedItem[];
  pendingOutcome: BatchOutcome | null;
  reservedInputs: Record<string, number>;
}
export interface FacilitySnapshot {
  id: string;
  definitionId: string;
  inventoryId: string;
  inputInventoryId: string;
  outputInventoryId: string;
  enabled: boolean;
  draining: boolean;
  conditions: Record<string, boolean>;
  attendance: Record<string, number>;
  missingWorkforce: Record<string,number>;
  jobs: JobSnapshot[];
  workerSlots: (WorkerAssignment | null)[];
  modifiers: Record<string, ProductionModifier>;
  productivity: number;
}
export interface InventorySnapshot {
  id: string;
  capacityPerMaterial: number;
  quantities: Record<string, number>;
  reserved: Record<string, number>;
  workforce: Record<string, { total: number; assigned: number }>;
  items: ProducedItem[];
  reservedItemIds: string[];
}
/** Inventory totals without item records or reserved-item identity lists. */
export interface InventorySummary extends Omit<InventorySnapshot, "items" | "reservedItemIds"> {
  itemCount: number;
  reservedItemCount: number;
}
export interface ItemPageOptions { offset?: number; limit?: number; resourceId?: string; }
export interface ItemPage { items: ProducedItem[]; total: number; offset: number; limit: number; }
export interface SimulationSummary {
  tick: number; timeSeconds: number; pendingSeconds: number;
  facilityCount: number; inventoryCount: number; deliveryCount: number;
}
export interface SimulationSnapshot {
  tick: number;
  timeSeconds: number;
  pendingSeconds: number;
  inventories: InventorySnapshot[];
  facilities: FacilitySnapshot[];
  deliveries: DeliverySnapshot[];
  constructionOrders: ConstructionOrderSnapshot[];
}
export type CommandResult =
  { ok: true; facilityId: string } | { ok: false; reason: string };
export type SimulationEvent =
  | {type: "facility-built" | "facility-enabled" | "facility-condition" | "facility-draining" | "facility-removed"; tick: number; facilityId: string}
  | {type: "construction-created" | "construction-cancelled" | "construction-completed"; tick: number; orderId: string; facilityId: string | null}
  | {type: "batch-started"; tick: number; facilityId: string; jobId: string; batchNumber: number; inputs: BatchOutcome}
  | {type: "batch-completed"; tick: number; facilityId: string; jobId: string; batchNumber: number; outcome: BatchOutcome};

export interface AttributeRange {
  min: number;
  max: number;
}
export interface WorkerAssignment {
  id: string;
  efficiency: number;
}
export interface ProductionModifier {
  /** Named sources multiply: specialist 1.2, damage 0.5, failure 0. */
  productivityMultiplier?: number;
  /** Additive shifts to manufactured attribute ranges. */
  attributeBonuses?: Readonly<Record<string, number>>;
}
export interface ProducedItem {
  id: string;
  resourceId: string;
  attributes: Record<string, number>;
}
export interface BatchOutcome {
  quantities: Record<string, number>;
  items: ProducedItem[];
}

/** Construction uses the original inventory; production endpoints may be local buffers. */
export interface FacilityInventoryOptions {
  inputInventoryId?: string;
  outputInventoryId?: string;
}
export interface MaterialDemand {
  /** Present for individual inputs: delivery quantities alone cannot choose identities. */
  itemSelection?: {required: Quantities; selectedIds: string[]};
  facilityId: string;
  jobId: string;
  inventoryId: string;
  quantities: Record<string, number>;
}
export interface DeliverySnapshot {
  id: string;
  /** Specific selected identities; quantity counts include these items. */
  itemIds: string[];
  /** Populated at pickup, retaining the item's latest source attributes. */
  items: ProducedItem[];
  sourceInventoryId: string;
  destinationInventoryId: string;
  quantities: Record<string, number>;
  state:
    "reserved" | "in-transit" | "arrival-blocked" | "delivered" | "cancelled";
}
export type DeliveryResult =
  { ok: true; deliveryId: string } | { ok: false; reason: string };

/** A live, read-only handle; returned snapshots/items are detached. */
export interface InventoryView {
  readonly id: string;
  readonly capacityPerMaterial: number;
  quantity(id: string): number;
  reserved(id: string): number;
  available(id: string): number;
  missing(values: Quantities): Record<string, number>;
  canWithdraw(values: Quantities): boolean;
  canDeposit(values: Quantities): boolean;
  item(id: string): ProducedItem | undefined;
  snapshot(): InventorySnapshot;
  summary(): InventorySummary;
  itemPage(options?: ItemPageOptions): ItemPage;
}
export interface InventorySave {
  id: string;
  capacityPerMaterial: number;
  quantities: Record<string, number>;
  items: ProducedItem[];
  workforce: Record<string, { total: number; assigned: number }>;
  reservations: { token: string; quantities: Quantities; itemIds: string[] }[];
}
export interface JobSave {
  id: string;
  recipeId: string;
  elapsedTicks: number;
  deferredWork: number;
  optionalInputs: Record<string, number>;
  batchOptionalInputs: Record<string, number>;
  inputItemIds: string[];
  inputItemResources: Record<string,string>;
  batchInputItems: ProducedItem[];
  outcome: BatchOutcome | null;
  active: boolean;
  readySince: number | null;
  demandSince: number | null;
  demandOrder: number;
  completed: number;
  state: JobState;
}
export interface FacilitySave {
  id: string;
  definitionId: string;
  inventoryId: string;
  inputInventoryId: string;
  outputInventoryId: string;
  enabled: boolean;
  draining: boolean;
  conditions: Record<string, boolean>;
  attendance: Record<string, number>;
  workerSlots: (WorkerAssignment | null)[];
  modifiers: Record<string, ProductionModifier>;
  jobs: JobSave[];
}
/** Versioned persistence, distinct from the presentation snapshot. */
export interface SimulationSave {
  format: "production-workshop";
  version: 4;
  configuration: Configuration;
  tick: number;
  pendingMicroseconds: number;
  timeCompensation: number;
  nextId: number;
  nextDelivery: number;
  nextItem: number;
  nextConstruction: number;
  constructionOrders: ConstructionOrderSave[];
  demandOrder: number;
  inventories: InventorySave[];
  facilities: FacilitySave[];
  retiredFacilities: RetiredFacilitySave[];
  deliveries: DeliverySnapshot[];
}

export type ItemLocation =
  | { kind: "inventory"; inventoryId: string; reservationOwner: string | null }
  | { kind: "delivery"; deliveryId: string }
  | { kind: "job"; jobId: string; facilityId: string }
  | { kind: "retired" };
export interface ReservationInspection {
  owner: { kind: "job" | "delivery" | "construction"; id: string };
  quantities: Quantities;
  itemIds: string[];
}
/** Provenance only; removed factories own no stock, work or reservations. */
export interface RetiredFacilitySave {
  id: string;
  definitionId: string;
  jobs: {id: string; recipeId: string; completed: number}[];
}
export type RemovalBlocker =
  | {code: "active-batch"; jobId: string}
  | {code: "workforce"; workerId: string; shortage: number}
  | {code: "capacity"; resourceId: string; excess: number};
export type RemovalResult = {ok: true; facilityId: string} | {ok: false; blockers: RemovalBlocker[]};
export type InventoryRemovalBlocker =
  | {code: "construction-reference"; orderId: string; roles: ("site" | "input" | "output")[]}
  | {code: "unknown-inventory"}
  | {code: "goods"; resourceId: string; quantity: number}
  | {code: "reservation"; token: string}
  | {code: "workforce"; workerId: string; total: number; assigned: number}
  | {code: "facility-reference"; facilityId: string; roles: ("construction" | "input" | "output")[]}
  | {code: "active-delivery"; deliveryId: string; state: "reserved" | "in-transit" | "arrival-blocked"; role: "source" | "destination"};
export type InventoryRemovalResult =
  | {ok: true; inventoryId: string; prunedDeliveryIds: string[]}
  | {ok: false; blockers: InventoryRemovalBlocker[]};
export interface JobExplanation {
  jobId: string;
  facilityId: string;
  phase: "idle" | "working" | "awaiting-output";
  blockers: ({code: "disabled" | "zero-productivity" | "draining"} |
    {code: "missing-item-selection"; quantities: Quantities} |
    {code: "selected-items-unavailable"; itemIds: string[]} |
    {code:"missing-workforce"; quantities:Record<string,number>} |
    {code: "condition"; conditionId: string} |
    {code: "missing-inputs" | "input-capacity" | "output-capacity"; quantities: Quantities})[];
  requiredInputs: Quantities;
  reservedInputs: Quantities;
  availableInputs: Quantities;
  inboundInputs: Quantities;
  productivity: {base: number; modifiers: Record<string, number>; effective: number};
  remainingWorkSeconds: number;
  estimatedCompletionSeconds: number | null;
  deferredWorkSeconds: number;
}
export interface DiagnosticEntry {
  sequence: number;
  tick: number;
  kind: "command" | "event" | "allocation" | "delivery";
  subject: string;
  details: Record<string, unknown>;
}
export type ValidationResult = {ok: true} | {ok: false; issues: {code: "invalid-state"; message: string}[]};

export type ConstructionState = "waiting-materials" | "building" | "awaiting-activation" | "completed" | "cancelled";
export interface ConstructionOptions extends FacilityInventoryOptions { durationSeconds: number; }
export type ConstructionBlocker =
  | {code:"materials"; quantities: Record<string,number>}
  | {code:"material-capacity"; resourceId:string; required:number; capacity:number}
  | {code:"workforce"; quantities:Record<string,number>}
  | {code:"capacity-overflow" | "workforce-overflow" | "facility-id-exhausted"};
export interface ConstructionOrderSave {
  id:string; definitionId:string; inventoryId:string; inputInventoryId:string; outputInventoryId:string;
  durationMicroseconds:number; elapsedMicroseconds:number; state:ConstructionState; facilityId:string|null;
  consumedMaterials:Record<string,number>;
}
export interface ConstructionOrderSnapshot extends ConstructionOrderSave {
  progress:number; reservedMaterials:Record<string,number>; missingMaterials:Record<string,number>;
  incomingMaterials:Record<string,number>; blockers:ConstructionBlocker[];
}
export type ConstructionCancellationResult =
  | {ok:true; orderId:string; releasedMaterials:Record<string,number>; consumedMaterials:Record<string,number>}
  | {ok:false; reason:"terminal-order"};
