import { Simulation } from "./simulation.js";
import type { Configuration, DeliverySnapshot } from "./models.js";
import { invariant } from "./registry.js";

export const transportConfiguration = {
  tickMilliseconds: 50,
  resources: [
    { id: "ore", label: "Ore", kind: "material" },
    { id: "alloy", label: "Alloy", kind: "material" },
    { id: "weapon", label: "Weapon", kind: "material", storage: "individual" },
  ],
  recipes: [
    {
      id: "smelt",
      label: "Smelt alloy",
      durationSeconds: 1,
      inputs: { ore: 2 },
      outputs: { alloy: 1 },
    },
  ],
  facilities: [
    {
      id: "smelter",
      label: "Planet smelter",
      category: "industry",
      recipes: ["smelt"],
      constructionCost: {},
    },
  ],
} satisfies Configuration;

/** Example HOST policy, not a scheduler/pathfinder in the production framework. */
export class TransportExample {
  readonly simulation = new Simulation(transportConfiguration);
  readonly facilityId: string;
  automaticFeeding = true;
  automaticCollection = true;
  #completedDeliveries = 0;
  get completedDeliveries(): number { return this.#completedDeliveries; }
  #travelSeconds = 3;
  #pendingMicroseconds = 0;
  readonly #journeys = new Map<string, { remaining: number; total: number }>();
  constructor() {
    this.simulation.createInventory({
      id: "warehouse",
      capacityPerMaterial: 100,
      initial: { ore: 60 },
    });
    this.simulation.createInventory({
      id: "smelter-input",
      capacityPerMaterial: 4,
    });
    this.simulation.createInventory({
      id: "smelter-output",
      capacityPerMaterial: 2,
    });
    this.simulation.createInventory({ id: "outpost", capacityPerMaterial: 3 });
    // Seed equipment for the transport-only UI. The ship example manufactures equipment.
    this.simulation.spawnItem("warehouse", "weapon", { maxHealth: 87, currentHealth: 62, precision: 0.86 });
    this.simulation.spawnItem("warehouse", "weapon", { maxHealth: 98, currentHealth: 98, precision: 0.97 });
    const result = this.simulation.addFacility("smelter", "warehouse", {
      inputInventoryId: "smelter-input",
      outputInventoryId: "smelter-output",
    });
    if (!result.ok) throw new Error(result.reason);
    this.facilityId = result.facilityId;
  }
  get travelSeconds(): number {
    return this.#travelSeconds;
  }
  set travelSeconds(value: number) {
    invariant(
      Number.isFinite(value) && value >= 0 && value <= 3600,
      "invalid travel duration",
    );
    this.#travelSeconds = value;
  }
  private dispatch(
    source: string,
    destination: string,
    quantities: Record<string, number>,
    itemIds: readonly string[] = [],
  ): boolean {
    const result = this.simulation.reserveDelivery(
      source,
      destination,
      quantities,
      itemIds,
    );
    if (!result.ok) return false;
    this.simulation.pickupDelivery(result.deliveryId);
    this.#journeys.set(result.deliveryId, {
      remaining: this.#travelSeconds,
      total: this.#travelSeconds,
    });
    return true;
  }
  dispatchSupply(): boolean {
    const demand = this.simulation
      .materialDemands()
      .find((d) => d.inventoryId === "smelter-input");
    return demand
      ? this.dispatch("warehouse", demand.inventoryId, demand.quantities)
      : false;
  }
  collectOutput(): boolean {
    const output = this.simulation.inventory("smelter-output");
    return output.available("alloy") > 0
      ? this.dispatch("smelter-output", "warehouse", { alloy: 1 })
      : false;
  }
  dispatchWeapon(): boolean {
    const source = this.simulation.inventory("warehouse").snapshot();
    const item = source.items.find(
      (i) =>
        i.resourceId === "weapon" && !source.reservedItemIds.includes(i.id),
    );
    return item ? this.dispatch("warehouse", "outpost", {}, [item.id]) : false;
  }
  /** The host processes arrivals, production, then dispatch at each shared tick boundary. */
  advance(seconds: number): void {
    invariant(Number.isFinite(seconds) && seconds >= 0, "invalid elapsed time");
    const micros = seconds * 1e6;
    invariant(
      Number.isFinite(micros) && micros >= 0 && micros + this.#pendingMicroseconds <= Number.MAX_SAFE_INTEGER,
      "elapsed time too large",
    );
    this.#pendingMicroseconds += micros;
    const tick = this.simulation.registry.tickMicroseconds;
    while (this.#pendingMicroseconds >= tick - 1e-7) {
      this.#pendingMicroseconds -= tick;
      if (Math.abs(this.#pendingMicroseconds) < 1e-7) this.#pendingMicroseconds = 0;

      for (const [id, journey] of this.#journeys) {
        const delivery = this.simulation.deliverySnapshot(id);
        if (delivery.state === "cancelled" || delivery.state === "delivered") {
          if (delivery.state === "delivered") this.#completedDeliveries++;
          this.#journeys.delete(id);
          continue;
        }
        journey.remaining = Math.max(0, journey.remaining - tick / 1e6);
        if (journey.remaining < 1e-9 && this.simulation.arriveDelivery(id)) {
          this.#completedDeliveries++;
          this.#journeys.delete(id);
        }
      }
      this.simulation.advanceTicks(1);
      if (this.automaticFeeding) this.dispatchSupply();
      if (this.automaticCollection) this.collectOutput();
    }
  }
  journeys(): (DeliverySnapshot & {
    remainingSeconds: number;
    progress: number;
  })[] {
    const deliveries = [...this.#journeys.keys()].map(id => this.simulation.deliverySnapshot(id));
    return deliveries.map((d) => {
        const j = this.#journeys.get(d.id)!;
        return {
          ...d,
          remainingSeconds: j.remaining,
          progress: j.total ? 1 - j.remaining / j.total : 1,
        };
      });
  }
}
