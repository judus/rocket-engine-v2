import type {
  InventorySummary,
  ItemPage,
  ItemPageOptions,
  BatchOutcome,
  InventoryView,
  InventorySave,
  ProducedItem,
  InventoryOptions,
  InventorySnapshot,
  Quantities,
} from "./models.js";
import {
  invariant,
  Registry,
  validateAttributes,
  cloneData,
} from "./registry.js";
/** All mutations are atomic: failed multi-resource operations change nothing. */
export class Inventory {
  readonly id: string;
  readonly #stock = new Map<string, number>();
  readonly #reservations = new Map<
    string,
    { quantities: Quantities; itemIds: readonly string[] }
  >();
  readonly #reservedItems = new Map<string, string>();
  readonly #people = new Map<string, { total: number; assigned: number }>();
  readonly #items = new Map<string, ProducedItem>();
  readonly #reservedTotals = new Map<string, number>();
  #capacity: number;
  view(): InventoryView {
    const self = this;
    return Object.freeze({
      id: this.id,
      get capacityPerMaterial() { return self.capacityPerMaterial; },
      quantity: (id: string) => self.quantity(id),
      reserved: (id: string) => self.reserved(id),
      available: (id: string) => self.available(id),
      missing: (q: Quantities) => self.missing(q),
      canWithdraw: (q: Quantities) => self.canWithdraw(q),
      canDeposit: (q: Quantities) => self.canDeposit(q),
      item: (id: string) => self.item(id),
      snapshot: () => self.snapshot(),
      summary: () => self.summary(),
      itemPage: (options?: ItemPageOptions) => self.itemPage(options),
    });
  }
  constructor(
    readonly registry: Registry,
    options: InventoryOptions,
  ) {
    invariant(
      typeof options.id === "string" && options.id.length > 0,
      "inventory: missing id",
    );
    invariant(
      Number.isSafeInteger(options.capacityPerMaterial) &&
        options.capacityPerMaterial >= 0,
      "inventory: invalid capacity",
    );
    this.id = options.id;
    this.#capacity = options.capacityPerMaterial;
    invariant(
      this.deposit(options.initial ?? {}),
      `inventory ${this.id}: initial stock exceeds capacity`,
    );
  }
  get capacityPerMaterial(): number {
    return this.#capacity;
  }
  quantity(id: string): number {
    this.registry.resource(id);
    return this.#stock.get(id) ?? 0;
  }
  reserved(id: string): number {
    this.registry.resource(id);
    return this.#reservedTotals.get(id) ?? 0;
  }
  available(id: string): number {
    return this.quantity(id) - this.reserved(id);
  }
  missing(values: Quantities): Record<string, number> {
    this.registry.validate(values, "inventory request");
    return Object.fromEntries(
      Object.entries(values)
        .filter(([id, n]) => this.available(id) < n)
        .map(([id, n]) => [id, n - this.available(id)]),
    );
  }
  canWithdraw(values: Quantities): boolean {
    return (
      Object.keys(this.missing(values)).length === 0 &&
      Object.entries(values).every(
        ([id, n]) =>
          n === 0 || this.registry.resource(id).storage !== "individual",
      )
    );
  }
  withdraw(values: Quantities): boolean {
    if (!this.canWithdraw(values)) return false;
    for (const [id, n] of Object.entries(values))
      this.#stock.set(id, this.quantity(id) - n);
    return true;
  }
  private canAcceptQuantities(values: Quantities): boolean {
    return Object.entries(values).every(
      ([id, n]) =>
        Number.isSafeInteger(this.quantity(id) + n) &&
        (this.registry.resource(id).kind === "currency" ||
          this.quantity(id) + n <= this.#capacity),
    );
  }
  canDeposit(values: Quantities): boolean {
    this.registry.validate(values, "inventory deposit");
    return (
      Object.entries(values).every(
        ([id, n]) =>
          n === 0 || this.registry.resource(id).storage !== "individual",
      ) && this.canAcceptQuantities(values)
    );
  }
  /** Capacity-only prediction, including individual outputs. Does not reserve space. */
  canDepositBatch(values: Quantities): boolean {
    return this.canAcceptQuantities(values);
  }
  /** Capacity prediction for a batch whose inputs will be consumed immediately. */
  canStartBatch(inputs: Quantities, outputs: Quantities): boolean {
    return Object.entries(outputs).every(([id, n]) => {
      const projected = this.quantity(id) - (inputs[id] ?? 0) + n;
      return (
        Number.isSafeInteger(projected) &&
        (this.registry.resource(id).kind === "currency" ||
          projected <= this.#capacity)
      );
    });
  }
  deposit(values: Quantities): boolean {
    if (!this.canDeposit(values)) return false;
    for (const [id, n] of Object.entries(values))
      this.#stock.set(id, this.quantity(id) + n);
    return true;
  }
  /** A resolved batch is validated and published atomically, including item identities. */
  depositOutcome(outcome: BatchOutcome): boolean {
    this.registry.validate(outcome.quantities, "outcome");
    const counts: Record<string, number> = Object.create(null);
    const ids = new Set<string>();
    for (const item of outcome.items) {
      invariant(
        this.registry.resource(item.resourceId).storage === "individual",
        "item needs individual resource",
      );
      invariant(
        typeof item.id === "string" &&
          item.id.length > 0 &&
          !ids.has(item.id) &&
          !this.#items.has(item.id),
        "duplicate item identity",
      );
      validateAttributes(item.attributes);
      ids.add(item.id);
      counts[item.resourceId] = (counts[item.resourceId] ?? 0) + 1;
    }
    for (const r of this.registry.resources)
      if (r.storage === "individual")
        invariant(
          (counts[r.id] ?? 0) === (outcome.quantities[r.id] ?? 0),
          "item count does not match outcome",
        );
    if (!this.canAcceptQuantities(outcome.quantities)) return false;
    for (const [id, n] of Object.entries(outcome.quantities))
      this.#stock.set(id, this.quantity(id) + n);
    for (const item of outcome.items) this.#items.set(item.id, cloneData(item));
    return true;
  }
  /** Host applies wear/repair rules; core only checks finite numeric attributes. */
  updateItemAttributes(
    id: string,
    patch: Readonly<Record<string, number>>,
  ): void {
    const item = this.#items.get(id);
    invariant(item, `unknown item '${id}'`);
    validateAttributes(patch);
    item.attributes = { ...item.attributes, ...patch };
  }
  /** Read a detached item view; undefined means not physically in this inventory. */
  item(id: string): ProducedItem | undefined {
    const item = this.#items.get(id);
    return item ? cloneData(item) : undefined;
  }
  transferItemTo(destination: Inventory, id: string): boolean {
    const item = this.#items.get(id);
    invariant(item, `unknown item '${id}'`);
    if (this.#reservedItems.has(id)) return false;
    if (destination === this) return true;
    if (
      !destination.depositOutcome({
        quantities: { [item.resourceId]: 1 },
        items: [item],
      })
    )
      return false;
    this.#items.delete(id);
    this.#stock.set(item.resourceId, this.quantity(item.resourceId) - 1);
    return true;
  }
  /** Reserve a mixed cargo atomically: bulk quantities plus explicitly selected items. */
  reserveCargo(
    token: string,
    bulk: Quantities,
    itemIds: readonly string[] = [],
  ): boolean {
    invariant(
      typeof token === "string" &&
        token.length > 0 &&
        !this.#reservations.has(token),
      `reservation '${token}' already exists or is empty`,
    );
    invariant(
      Array.isArray(itemIds as unknown) &&
        itemIds.every((id) => typeof id === "string" && id.length > 0) &&
        new Set(itemIds).size === itemIds.length,
      "invalid or duplicate cargo item IDs",
    );
    if (
      !this.canWithdraw(bulk) ||
      itemIds.some((id) => !this.#items.has(id) || this.#reservedItems.has(id))
    )
      return false;
    const quantities: Record<string, number> = Object.assign(
      Object.create(null),
      bulk,
    );
    for (const id of itemIds) {
      const item = this.#items.get(id)!;
      quantities[item.resourceId] = (quantities[item.resourceId] ?? 0) + 1;
    }
    this.registry.validate(quantities, "combined cargo");
    this.#reservations.set(token, {
      quantities: Object.freeze(quantities),
      itemIds: Object.freeze([...itemIds]),
    });
    for (const [id, n] of Object.entries(quantities))
      this.#reservedTotals.set(id, this.reserved(id) + n);
    for (const id of itemIds) this.#reservedItems.set(id, token);
    return true;
  }
  /** Detach source cargo exactly once. Item attributes are captured at pickup. */
  commit(token: string): BatchOutcome {
    const reservation = this.#reservations.get(token);
    invariant(reservation, `unknown reservation '${token}'`);
    const items = reservation.itemIds.map((id) =>
      cloneData(this.#items.get(id)!),
    );
    for (const [id, n] of Object.entries(reservation.quantities))
      this.#stock.set(id, this.quantity(id) - n);
    for (const id of reservation.itemIds) {
      this.#items.delete(id);
      this.#reservedItems.delete(id);
    }
    for (const [id, n] of Object.entries(reservation.quantities))
      this.#reservedTotals.set(id, this.reserved(id) - n);
    this.#reservations.delete(token);
    return { quantities: { ...reservation.quantities }, items };
  }
  release(token: string): void {
    const reservation = this.#reservations.get(token);
    invariant(reservation, `unknown reservation '${token}'`);
    for (const id of reservation.itemIds) this.#reservedItems.delete(id);
    for (const [id, n] of Object.entries(reservation.quantities))
      this.#reservedTotals.set(id, this.reserved(id) - n);
    this.#reservations.delete(token);
  }
  /** Transfers are immediate in this version. Reserved stock cannot be transferred. */
  transferTo(destination: Inventory, values: Quantities): boolean {
    if (destination === this) {
      return this.canWithdraw(values);
    }
    if (!this.canWithdraw(values) || !destination.canDeposit(values))
      return false;
    // Both endpoints are preflighted; commit once without repeating command validation.
    for (const [id,n] of Object.entries(values)) {
      this.#stock.set(id, this.quantity(id) - n);
      destination.#stock.set(id, destination.quantity(id) + n);
    }
    return true;
  }
  workforceMissing(
    required: Quantities,
    provided: Quantities = {},
  ): Record<string, number> {
    return Object.fromEntries(
      Object.entries(required).flatMap(([id, n]) => {
        const people = this.#people.get(id) ?? { total: 0, assigned: 0 };
        const short =
          n - (people.total - people.assigned + (provided[id] ?? 0));
        return short > 0 ? [[id, short]] : [];
      }),
    );
  }
  /** Internal construction effect, exposed independently of production batch behavior. */
  applyFacility(
    provided: Quantities,
    required: Quantities,
    capacity: number,
  ): void {
    // Simulation preflights registered construction effects before any payment.
    for (const id of new Set([
      ...Object.keys(provided),
      ...Object.keys(required),
    ])) {
      const p = this.#people.get(id) ?? { total: 0, assigned: 0 };
      this.#people.set(id, {
        total: p.total + (provided[id] ?? 0),
        assigned: p.assigned + (required[id] ?? 0),
      });
    }
    this.#capacity += capacity;
  }
  reservation(token: string): Quantities {
    return { ...(this.#reservations.get(token)?.quantities ?? {}) };
  }
  reservationTokens(): string[] { return [...this.#reservations.keys()]; }
  hasReservation(token: string): boolean { return this.#reservations.has(token); }
  /** Incrementally hold bulk inputs without consuming them. */
  allocate(token: string, required: Quantities, itemIds: readonly string[] = []): void {
    const held = this.reservation(token);
    const bulk: Record<string, number> = {};
    for (const [id,n] of Object.entries(required)) if (this.registry.resource(id).storage !== "individual")
      bulk[id] = (held[id] ?? 0) + Math.min(Math.max(0,n - (held[id] ?? 0)),this.available(id));
    const selected = itemIds.filter(id => this.#items.has(id) &&
      (!this.#reservedItems.has(id) || this.#reservedItems.get(id) === token));
    if (this.hasReservation(token)) this.release(token);
    invariant(this.reserveCargo(token, bulk, selected), "allocation failed");
  }
  availableSelectedItemIds(itemIds: readonly string[], token: string): string[] {
    return itemIds.filter(id => this.#items.has(id) && (!this.#reservedItems.has(id) || this.#reservedItems.get(id) === token));
  }
  availableSelectedItems(itemIds: readonly string[], token: string): Record<string, number> {
    const counts: Record<string, number> = Object.create(null);
    for (const id of itemIds) {
      const item = this.#items.get(id);
      if (item && (!this.#reservedItems.has(id) || this.#reservedItems.get(id) === token))
        counts[item.resourceId] = (counts[item.resourceId] ?? 0) + 1;
    }
    return counts;
  }
  /** Reverse construction effects only after the simulation's removal preflight. */
  removeFacility(provided: Quantities, required: Quantities, capacity: number, retainedWorkerTypes: ReadonlySet<string>): void {
    for (const id of new Set([...Object.keys(provided), ...Object.keys(required)])) {
      const p = this.#people.get(id)!;
      const next = {total: p.total - (provided[id] ?? 0), assigned: p.assigned - (required[id] ?? 0)};
      if (retainedWorkerTypes.has(id)) this.#people.set(id, next);
      else this.#people.delete(id);
    }
    this.#capacity -= capacity;
  }
  increaseCapacity(amount: number): void {
    invariant(Number.isSafeInteger(amount) && amount >= 0 && Number.isSafeInteger(this.#capacity + amount), "invalid capacity increment");
    this.#capacity += amount;
  }
  save(): InventorySave {
    const view = this.summary();
    return { id: this.id, capacityPerMaterial: this.#capacity,
      quantities: view.quantities, items: [...this.#items.values()].map(item => cloneData(item)), workforce: view.workforce,
      reservations: [...this.#reservations].map(([token, r]) => ({token, quantities: {...r.quantities}, itemIds: [...r.itemIds]})) };
  }
  static restore(registry: Registry, state: InventorySave): Inventory {
    const i = new Inventory(registry, {id: state.id, capacityPerMaterial: state.capacityPerMaterial});
    invariant(i.depositOutcome({quantities: state.quantities, items: state.items}), "saved stock exceeds capacity");
    for (const [id, people] of Object.entries(state.workforce)) {
      invariant(id.length > 0 && Number.isSafeInteger(people.total) && people.total >= 0 &&
        Number.isSafeInteger(people.assigned) && people.assigned >= 0 && people.assigned <= people.total,
        "invalid saved workforce");
      i.#people.set(id, {...people});
    }
    for (const r of state.reservations) {
      const bulk = {...r.quantities};
      for (const id of r.itemIds) {
        const item = i.item(id);
        invariant(item, "saved reservation item missing");
        bulk[item.resourceId] = (bulk[item.resourceId] ?? 0) - 1;
      }
      invariant(i.reserveCargo(r.token, bulk, r.itemIds), "invalid saved reservation");
    }
    return i;
  }
  summary(): InventorySummary {
    return {
      id: this.id, capacityPerMaterial: this.#capacity,
      quantities: Object.fromEntries(this.registry.resources.map(r => [r.id,this.quantity(r.id)])),
      reserved: Object.fromEntries(this.registry.resources.map(r => [r.id,this.reserved(r.id)])),
      workforce: Object.fromEntries([...this.#people].map(([id,p]) => [id,{...p}])),
      itemCount: this.#items.size, reservedItemCount: this.#reservedItems.size,
    };
  }
  /** Offset windows over current insertion order, not stable cursors. */
  itemPage({offset = 0, limit = 50, resourceId}: ItemPageOptions = {}): ItemPage {
    invariant(Number.isSafeInteger(offset) && offset >= 0 && Number.isSafeInteger(limit) && limit >= 1 && limit <= 500, "invalid item page bounds");
    if (resourceId !== undefined) invariant(this.registry.resource(resourceId).storage === "individual", "item page requires an individual resource");
    const total = resourceId === undefined ? this.#items.size : this.quantity(resourceId);
    const items: ProducedItem[] = [];
    if (offset < total) {
      let seen = 0;
      for (const item of this.#items.values()) {
        if (resourceId !== undefined && item.resourceId !== resourceId) continue;
        if (seen++ < offset) continue;
        items.push(cloneData(item));
        if (items.length === limit) break;
      }
    }
    return {items,total,offset,limit};
  }
  snapshot(): InventorySnapshot {
    return {
      id: this.id,
      capacityPerMaterial: this.#capacity,
      quantities: Object.fromEntries(
        this.registry.resources.map((r) => [r.id, this.quantity(r.id)]),
      ),
      reserved: Object.fromEntries(
        this.registry.resources.map((r) => [r.id, this.reserved(r.id)]),
      ),
      items: [...this.#items.values()].map((item) => cloneData(item)),
      reservedItemIds: [...this.#reservedItems.keys()],
      workforce: Object.fromEntries(
        [...this.#people].map(([id, p]) => [id, { ...p }]),
      ),
    };
  }
}
