import test from 'node:test';
import assert from 'node:assert/strict';
import {Simulation, DefinitionError} from '../dist/index.js';
import {createShip} from '../dist/examples.js';
const config = (duration = 1, inputs = {ore: 1}) => ({
  resources: [{id:'ore', label:'Ore', kind:'material'}, {id:'alloy',label:'Alloy',kind:'material'},
    {id:'weapon',label:'Weapon',kind:'material',storage:'individual'}],
  recipes:[{id:'make',label:'Make',durationSeconds:duration,inputs,outputs:{alloy:1}}],
  facilities:[{id:'factory',label:'Factory',category:'test',recipes:['make'],constructionCost:{}}],
});
function world(c = config(), ore = 100) {
  const s = new Simulation(c);
  s.createInventory({id:'store',capacityPerMaterial:10000,initial:{ore}});
  s.createInventory({id:'other',capacityPerMaterial:10000});
  s.addFacility('factory','store');
  return s;
}
const roundTrip = s => Simulation.restore(JSON.parse(JSON.stringify(s.save())));
test('managed inventories expose no mutation escape hatch, including from observers', () => {
  const s = world(), i = s.inventory('store');
  for (const method of ['deposit','withdraw','depositOutcome','reserve','reserveCargo','commit','release','applyFacility','transferTo','transferItemTo','updateItemAttributes'])
    assert.equal(i[method], undefined, method);
  assert.ok(Object.isFrozen(i));
  for (const helper of ['ownedInventory','facility','delivery','mutate','step','restoreChecked']) assert.equal(s[helper], undefined);
  assert.throws(() => { s.registry = null; }, TypeError);
  assert.throws(() => { s.registry.tickMicroseconds = 1; }, TypeError);
  const before = i.quantity('ore');
  let blocked = 0;
  s.onEvent(() => {
    assert.throws(() => s.deposit('store',{ore:1}), /observer/);
    assert.throws(() => s.spawnItem('store','weapon',{}), /observer/);
    assert.throws(() => s.save(), /notification/);
    blocked++;
  });
  s.advance(1.05);
  assert.ok(blocked > 0);
  assert.equal(i.quantity('ore'), before - 2);
});
test('identities remain unique through spawn, transit, consumption and historical pruning', () => {
  const s = world();
  const id = s.spawnItem('store','weapon',{health:87});
  assert.throws(() => s.spawnItem('other','weapon',{},id), /framework-owned/);
  assert.throws(() => s.spawnItem('other','weapon',{},'facility-1.job-0.batch-0.weapon-0'), /framework-owned/);
  const d = s.reserveDelivery('store','other',{},[id]);
  assert.equal(s.consumeItem('store',id), false);
  s.pickupDelivery(d.deliveryId);
  assert.throws(() => s.spawnItem('other','weapon',{},id), /framework-owned/);
  s.arriveDelivery(d.deliveryId);
  assert.equal(s.pruneDeliveries(),1);
  assert.deepEqual(s.inventory('other').item(id).attributes,{health:87});
  assert.equal(s.consumeItem('other',id),true);
  assert.throws(() => s.spawnItem('store','weapon',{},id), /framework-owned/);
  const restored = roundTrip(s);
  assert.throws(() => restored.spawnItem('store','weapon',{},id), /framework-owned/);
});
test('60Hz deltas retain fractional microseconds without frame rounding drift', () => {
  const a = world(), b = world();
  a.advance(60);
  for(let i=0;i<3600;i++) b.advance(1/60);
  assert.deepEqual(a.snapshot(),b.snapshot());
  assert.ok(Math.abs(b.snapshot().pendingSeconds) < 1e-9);
  const c = world();
  for(let i=0;i<1000;i++) c.advance(0.0000001);
  assert.ok(Math.abs(c.snapshot().pendingSeconds - .0001) < 1e-12);
  const d = roundTrip(c);
  c.advance(.0499); d.advance(.0499);
  assert.deepEqual(c.save(),d.save());
});
test('exact ticks preserve pending fractional host time', () => {
  const s = world();
  s.advance(.012345678);
  s.advanceTicks(20);
  assert.equal(s.snapshot().timeSeconds,1);
  assert.equal(s.snapshot().pendingSeconds,.012345678);
  assert.throws(() => s.advanceTicks(1.5), DefinitionError);
});
test('100x productivity completes 100 one-second batches in one working second', () => {
  const s = world(config(1,{}),0);
  s.setProductionModifier('facility-1','boost',{productivityMultiplier:100});
  s.advance(.05); // Starting boundary earns no work.
  s.advance(1);
  assert.equal(s.inventory('store').quantity('alloy'),100);
  assert.equal(s.snapshot().facilities[0].jobs[0].batchesCompleted,100);
});
test('recipe work is not rounded to the tick duration and low rates conserve fractional work', () => {
  const s = world(config(.015,{}),0);
  s.advance(.05);
  s.advance(.15);
  assert.equal(s.inventory('store').quantity('alloy'),10);
  const slow = world(config(1,{}),0);
  slow.setProductionModifier('facility-1','slow',{productivityMultiplier:.2});
  slow.advance(.05); slow.advance(5);
  assert.equal(slow.inventory('store').quantity('alloy'),1);
});
test('bounded completion processing defers excess earned work and persists it', () => {
  const s = world(config(.00001,{}),0);
  s.advanceTicks(2);
  assert.equal(s.inventory('store').quantity('alloy'),1000);
  assert.ok(s.save().facilities[0].jobs[0].deferredWork > 0);
  const restored = roundTrip(s);
  s.advanceTicks(1); restored.advanceTicks(1);
  assert.deepEqual(s.save(), restored.save());
  assert.equal(s.inventory('store').quantity('alloy'),2000);
});
test('older large bundles accumulate reservations instead of starving behind small consumers', () => {
  const c = config(.05,{ore:2});
  c.recipes.push({id:'small',label:'Small',durationSeconds:.05,inputs:{ore:1},outputs:{weapon:1}});
  c.facilities.push({id:'small-factory',label:'Small',category:'test',recipes:['small'],constructionCost:{}});
  const s = world(c,0);
  s.addFacility('small-factory','store');
  for(let i=0;i<100;i++) {s.deposit('store',{ore:1}); s.advanceTicks(1);}
  const batches = s.snapshot().facilities.map(f=>f.jobs[0].batchesCompleted);
  assert.ok(batches.every(n=>n>20), JSON.stringify(batches));
  assert.ok(Math.abs(batches[0]-batches[1])<=1);
});
test('partial allocations release on disabled conditions, zero productivity and changed optional inputs', () => {
  const c = config(1,{ore:2});
  c.recipes[0].optionalInputs = {alloy:1};
  c.facilities[0].operatingConditions=['power'];
  const s = world(c,1);
  s.setFacilityCondition('facility-1','power',true);
  s.advanceTicks(1);
  assert.deepEqual(s.snapshot().facilities[0].jobs[0].reservedInputs,{ore:1});
  assert.equal(s.withdraw('store',{ore:1}),false);
  s.setFacilityEnabled('facility-1',false);
  assert.equal(s.inventory('store').reserved('ore'),0);
  s.setFacilityEnabled('facility-1',true); s.advanceTicks(1);
  s.setFacilityCondition('facility-1','power',false);
  assert.equal(s.inventory('store').reserved('ore'),0);
  s.setFacilityCondition('facility-1','power',true); s.advanceTicks(1);
  s.setProductionModifier('facility-1','failure',{productivityMultiplier:0});
  assert.equal(s.inventory('store').reserved('ore'),0);
  s.setProductionModifier('facility-1','failure',null); s.advanceTicks(1);
  s.setOptionalInputs('facility-1','make',{alloy:1});
  assert.equal(s.inventory('store').reserved('ore'),0);
});
test('save restores partial allocations, clock remainder and request ordering', () => {
  const s = world(config(1,{ore:2}),1);
  s.advance(.061234567);
  const restored = roundTrip(s);
  assert.deepEqual(s.snapshot(), restored.snapshot());
  for(const w of [s,restored]) { w.deposit('store',{ore:1}); w.advance(3); }
  assert.deepEqual(s.save(), restored.save());
});
test('save restores quality, live modifiers, optional inputs and active/resolved batches', () => {
  const s = createShip();
  s.advance(1.23456789);
  let restored = roundTrip(s);
  assert.deepEqual(s.snapshot(),restored.snapshot());
  for(const w of [s,restored]) w.advance(30);
  assert.deepEqual(s.save(),restored.save());
  const c = config(.1,{ore:1});
  c.recipes[0].outputs={weapon:1};
  c.recipes[0].itemAttributes={weapon:{health:{min:80,max:90}}};
  c.recipes[0].bonusOutputs=[{chance:.5,outputs:{alloy:1}}];
  const b = world(c,2);
  b.advanceTicks(1);
  const filler=b.spawnItem('store','weapon',{health:100});
  // Fill individual output storage after starting work.
  const limited = b.save(); limited.inventories[0].capacityPerMaterial=2;
  const blocked = Simulation.restore(limited);
  blocked.spawnItem('store','weapon',{});
  blocked.advance(.1);
  assert.equal(blocked.snapshot().facilities[0].jobs[0].state,'output-blocked');
  const copy = roundTrip(blocked);
  for(const w of [blocked,copy]) { w.consumeItem('store',filler); w.advance(.05); }
  assert.deepEqual(blocked.save(),copy.save());
});
test('save restores reserved, travelling and blocked individual deliveries with exact attributes', () => {
  for (const phase of ['reserved','in-transit','arrival-blocked']) {
    const s = world();
    s.createInventory({id:'tiny',capacityPerMaterial:0});
    const item = s.spawnItem('store','weapon',{health:42,precision:.9});
    const d = s.reserveDelivery('store','tiny',{ore:1},[item]);
    if(phase !== 'reserved') s.pickupDelivery(d.deliveryId);
    if(phase === 'arrival-blocked') s.arriveDelivery(d.deliveryId);
    const copy = roundTrip(s);
    assert.deepEqual(s.save(),copy.save());
    for(const w of [s,copy]) {
      if(phase === 'reserved') w.pickupDelivery(d.deliveryId);
      w.increaseCapacity('tiny',10);
      assert.equal(w.arriveDelivery(d.deliveryId),true);
    }
    assert.deepEqual(s.save(),copy.save());
    assert.deepEqual(copy.inventory('tiny').item(item).attributes,{health:42,precision:.9});
  }
});
test('restored ID and RNG counters continue without collisions and listeners are not restored', () => {
  const s = createShip();
  s.advance(20);
  const item = s.spawnItem('ship','weapon',{});
  const saved = s.save();
  const copy = roundTrip(s);
  assert.notEqual(copy.spawnItem('ship','weapon',{}), item);
  assert.equal(copy.addFacility('fabricator','ship').ok, true);
  assert.ok(copy.snapshot().facilities.every((f,index,all)=>all.findIndex(g=>g.id===f.id)===index));
  assert.equal(saved.version,4);
});
test('invalid save data rejects consistently without touching a running world', () => {
  const s = world(config(1,{ore:2}),1); s.advance(.05);
  const before = s.save();
  const corruptions = [
    x=>x.version=999,
    x=>x.pendingMicroseconds=50000,
    x=>x.nextId=1,
    x=>x.inventories[0].quantities.ore=-1,
    x=>x.inventories[0].reservations[0].quantities.ore=2,
    x=>x.inventories[0].reservations[0].token='orphan',
    x=>x.facilities[0].jobs[0].active=true,
    x=>x.facilities[0].jobs[0].elapsedTicks=Infinity,
    x=>x.facilities[0].jobs[0].optionalInputs={ore:999},
    x=>x.facilities[0].jobs[0].recipeId='missing',
    x=>x.facilities[0].workerSlots=[{id:'fake',efficiency:1}],
  ];
  for(const change of corruptions) { const data=structuredClone(before); change(data); assert.throws(()=>Simulation.restore(data),DefinitionError); }
  for(const data of [null,{},[],{version:1,format:'production-workshop',configuration:null}])
    assert.throws(()=>Simulation.restore(data),DefinitionError);
  assert.deepEqual(s.save(), before);
});
test('restore rejects duplicate physical identity between inventory and transit cargo', () => {
  const s = world();
  const id=s.spawnItem('store','weapon',{});
  const d=s.reserveDelivery('store','other',{},[id]); s.pickupDelivery(d.deliveryId);
  const data=s.save();
  data.inventories[1].items=data.deliveries[0].items;
  data.inventories[1].quantities.weapon=1;
  assert.throws(()=>Simulation.restore(data), /duplicate/);
});
test('completion events contain detached outcomes even when an advance completes many batches', () => {
  const s=world(config(.1,{}),0), facts=[];
  s.onEvent(e=>{ if(e.type==='batch-completed') {facts.push(e); e.outcome.quantities.alloy=999;} });
  const observed=[];
  s.onEvent(e=>{if(e.type==='batch-completed') observed.push(e.outcome.quantities.alloy);});
  s.advance(1.05);
  assert.equal(facts.length,10);
  assert.deepEqual(observed,Array(10).fill(1));
  assert.deepEqual(facts.map(e=>e.batchNumber),Array.from({length:10},(_,i)=>i+1));
  assert.equal(s.inventory('store').quantity('alloy'),10);
});
test('pruning terminal deliveries preserves active cargo, inbound accounting and counters', () => {
  const s=world();
  for(let i=0;i<100;i++) {const d=s.reserveDelivery('store','other',{ore:1}); s.cancelDelivery(d.deliveryId);}
  const active=s.reserveDelivery('store','other',{ore:2});
  assert.equal(s.pruneDeliveries(),100);
  assert.equal(s.snapshot().deliveries.length,1);
  assert.equal(s.inventory('store').reserved('ore'),2);
  const copy=roundTrip(s); copy.pickupDelivery(active.deliveryId); copy.arriveDelivery(active.deliveryId);
  assert.equal(copy.inventory('other').quantity('ore'),2);
  assert.ok(copy.reserveDelivery('store','other',{ore:1}).deliveryId.endsWith('102'));
});

test('deferred earned work pauses at zero productivity and resumes after JSON restore', () => {
  const s=world(config(.00001,{}),0); s.advanceTicks(2);
  s.setProductionModifier('facility-1','failure',{productivityMultiplier:0});
  const before=s.save().facilities[0].jobs[0].deferredWork;
  s.advanceTicks(10);
  assert.equal(s.inventory('store').quantity('alloy'),1000);
  assert.equal(s.save().facilities[0].jobs[0].deferredWork,before);
  const restored=roundTrip(s);
  restored.setProductionModifier('facility-1','failure',null); restored.advanceTicks(1);
  assert.equal(restored.inventory('store').quantity('alloy'),2000);
});
test('impossible input bundles do not hoard partial stock', () => {
  const s=world(config(1,{ore:10001}),1); s.advanceTicks(1);
  assert.equal(s.inventory('store').reserved('ore'),0);
  assert.equal(s.withdraw('store',{ore:1}),true);
});
test('null quality ranges report a definition error', () => {
  const c=config(); c.recipes[0].outputs={weapon:1}; c.recipes[0].itemAttributes={weapon:{health:null}};
  assert.throws(()=>new Simulation(c), DefinitionError);
});

test('definition defaults are resolved once and recipes retain deep immutable ownership',()=>{
  const config={resources:[{id:'ore',label:'Ore',kind:'material'}],recipes:[{id:'mine',label:'Mine',durationSeconds:1,inputs:{},outputs:{ore:1},bonusOutputs:[{chance:.1,outputs:{ore:1}}]}],
    facilities:[{id:'home',label:'Home',category:'population',recipes:[],constructionCost:{},workersProvided:{farmer:2}},
      {id:'mine',label:'Mine',category:'production',recipes:['mine'],constructionCost:{},workersRequired:{farmer:2}}]};
  const sim=new Simulation(config);assert.equal(sim.registry.facility('home').workerSlots,0);assert.equal(sim.registry.facility('mine').workerSlots,2);
  config.recipes[0].outputs.ore=100;config.recipes[0].bonusOutputs[0].outputs.ore=100;
  assert.equal(sim.registry.recipe('mine').outputs.ore,1);assert.equal(sim.registry.recipe('mine').bonusOutputs[0].outputs.ore,1);
  assert.ok(Object.isFrozen(sim.registry.recipe('mine').outputs));assert.ok(Object.isFrozen(sim.registry.recipe('mine').bonusOutputs[0].outputs));
});
test('prototype property names fail at definition and workforce boundaries',()=>{
  for(const id of ['constructor','prototype','__proto__']) {
    assert.throws(()=>new Simulation({resources:[{id,label:id,kind:'material'}],recipes:[],facilities:[]}),DefinitionError);
    const required=JSON.parse(`{"${id}":1}`);
    assert.throws(()=>new Simulation({resources:[],recipes:[],facilities:[{id:'factory',label:'Factory',category:'population',recipes:[],constructionCost:{},workersRequired:required}]}),DefinitionError);
  }
});
