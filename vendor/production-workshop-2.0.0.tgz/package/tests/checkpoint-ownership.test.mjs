import test from 'node:test';
import assert from 'node:assert/strict';
import {Simulation} from '../dist/index.js';
function fixture(){
 const sim=new Simulation({resources:[{id:'ore',label:'Ore',kind:'material'},{id:'weapon',label:'Weapon',kind:'material',storage:'individual'}],
 recipes:[{id:'forge',label:'Forge',durationSeconds:.1,inputs:{ore:1},optionalInputs:{ore:1},outputs:{weapon:1},itemAttributes:{weapon:{health:{min:80,max:90}}},optionalAttributeBonuses:{ore:{health:2}}}],
 facilities:[{id:'factory',label:'Factory',category:'production',recipes:['forge'],constructionCost:{},workersRequired:{worker:1},workersProvided:{worker:1},operatingConditions:['powered']}]});
 sim.createInventory({id:'store',capacityPerMaterial:2,initial:{ore:2}});sim.createInventory({id:'outpost',capacityPerMaterial:2});sim.addFacility('factory','store');sim.setFacilityAttendance('facility-1',{worker:1});
 sim.setFacilityCondition('facility-1','powered',true);sim.setOptionalInputs('facility-1','forge',{ore:1});sim.setProductionModifier('facility-1','specialist',{productivityMultiplier:1.2,attributeBonuses:{health:4}});
 sim.advanceTicks(1);const id=sim.spawnItem('store','weapon',{health:87});sim.spawnItem('store','weapon',{health:84});
 sim.advance(.1);assert.ok(sim.save().facilities[0].jobs[0].outcome);sim.reserveDelivery('store','outpost',{},[id]);return sim;
}
function corrupt(value){
 for(const key of Object.keys(value)){
  const x=value[key];
  if(x&&typeof x==='object')corrupt(x);
  else if(typeof x==='number')value[key]=x+1;
  else if(typeof x==='string')value[key]=x+'-changed';
  else if(typeof x==='boolean')value[key]=!x;
 }
}
test('checkpoint detaches every nested value including pending outcomes, configuration, workforce and reservations',()=>{
 const sim=fixture(),checkpoint=sim.save(),expected=sim.save();corrupt(checkpoint);
 assert.deepEqual(sim.save(),expected);
 const restored=Simulation.restore(expected);corrupt(expected);assert.deepEqual(restored.save(),sim.save());
});
test('later mutations and delivery transitions leave existing checkpoints unchanged',()=>{
 const sim=fixture(),checkpoint=sim.save(),expected=JSON.parse(JSON.stringify(checkpoint));
 sim.setWorkerSlot('facility-1',0,{id:'specialist',efficiency:.5});sim.setProductionModifier('facility-1','specialist',null);
 sim.updateItemAttributes('store',checkpoint.deliveries[0].itemIds[0],{health:20});sim.pickupDelivery(checkpoint.deliveries[0].id);sim.arriveDelivery(checkpoint.deliveries[0].id);sim.advance(.2);
 assert.deepEqual(checkpoint,expected);assert.deepEqual(Simulation.restore(checkpoint).save(),expected);
});
