import test from 'node:test';
import assert from 'node:assert/strict';
import {Simulation} from '../dist/index.js';
function fixture(){
 const sim=new Simulation({seed:42,resources:[{id:'ore',label:'Ore',kind:'material'},{id:'weapon',label:'Weapon',kind:'material',storage:'individual'}],
 recipes:[{id:'forge',label:'Forge',durationSeconds:.1,inputs:{ore:1},outputs:{weapon:1},itemAttributes:{weapon:{health:{min:80,max:90}}}}],
 facilities:[{id:'factory',label:'Factory',category:'production',recipes:['forge'],constructionCost:{}}]});
 sim.createInventory({id:'store',capacityPerMaterial:100,initial:{ore:100}});sim.addFacility('factory','store');return sim;
}
test('unused production events change neither state nor trace; late subscriptions receive only future committed events',()=>{
 const silent=fixture(),observed=Simulation.restore(silent.save()),events=[];
 silent.enableDiagnostics(200);observed.enableDiagnostics(200);observed.onEvent(e=>events.push(e));
 silent.advance(.4);observed.advance(.4);assert.deepEqual(silent.save(),observed.save());assert.deepEqual(silent.diagnosticTrace(),observed.diagnosticTrace());
 assert.ok(events.some(e=>e.type==='batch-completed'&&e.outcome.items.length));
 const future=[],offset=events.length,unsubscribe=silent.onEvent(e=>future.push(e));
 silent.advance(.2);observed.advance(.2);assert.deepEqual(future,events.slice(offset));
 unsubscribe();const count=future.length;silent.advance(.2);observed.advance(.2);
 assert.equal(future.length,count);assert.deepEqual(silent.save(),observed.save());assert.deepEqual(silent.diagnosticTrace(),observed.diagnosticTrace());
});
test('subscriptions added during notification retain delivery of later queued events and separate outcome copies',()=>{
 const sim=fixture(),first=[],late=[];let subscribed=false;
 sim.onEvent(e=>{
  first.push(e.type);
  if(e.type==='batch-completed'&&!subscribed){subscribed=true;sim.onEvent(other=>late.push(other));e.outcome.items[0].attributes.health=-1;}
 });
 sim.advance(.4);assert.ok(late.some(e=>e.type==='batch-completed'));
 assert.ok(late.filter(e=>e.type==='batch-completed').every(e=>e.outcome.items[0].attributes.health>=80));
 assert.ok(sim.inventory('store').itemPage().items.every(i=>i.attributes.health>=80));
 assert.ok(first.filter(type=>type==='batch-completed').length>=3);
});
