import test from 'node:test';
import assert from 'node:assert/strict';
import {Simulation, DefinitionError} from '../dist/index.js';
import {createShip, createSettlement} from '../dist/examples.js';
function world({quality=false, staffed=false, bonus=false}={}) {
  const s=new Simulation({seed:42, resources:[{id:'ore',label:'Ore',kind:'material'},{id:'alloy',label:'Alloy',kind:'material'},{id:'weapon',label:'Weapon',kind:'material',storage:'individual'}],
    recipes:[{id:'make',label:'Make',durationSeconds:.1,inputs:{ore:2},outputs:quality?{weapon:2}:{alloy:1},optionalInputs:{alloy:1},
      ...(quality?{itemAttributes:{weapon:{health:{min:80,max:90}}}}:{}), ...(bonus?{bonusOutputs:[{chance:0,outputs:{weapon:2}}]}:{})}],
    facilities:[{id:'factory',label:'Factory',category:'test',recipes:['make'],constructionCost:{},
      ...(staffed?{workersProvided:{workers:2},workersRequired:{workers:2}}:{})}]});
  s.createInventory({id:'store',capacityPerMaterial:20,initial:{ore:10}});
  s.createInventory({id:'other',capacityPerMaterial:20});s.addFacility('factory','store');if(staffed)s.setFacilityAttendance('facility-1',{workers:2});return s;
}
const jsonRestore=s=>Simulation.restore(JSON.parse(JSON.stringify(s.save())));
test('generated workers cannot collide with a future facility and can return to their own emptied slot',()=>{
  const s=world({staffed:true});const before=s.save();
  assert.throws(()=>s.setWorkerSlot('facility-1',0,{id:'facility-2.worker-0',efficiency:1}),/generated worker/);
  assert.deepEqual(s.save(),before);
  s.setWorkerSlot('facility-1',0,null);s.setWorkerSlot('facility-1',0,{id:'facility-1.worker-0',efficiency:.8});
  s.addFacility('factory','store');assert.deepEqual(jsonRestore(s).save(),s.save());
});
test('restore rejects batch rollback, future production references and workforce contradictions',()=>{
  const s=world({quality:true,staffed:true});s.advance(.15);
  for(const change of [d=>d.facilities[0].jobs[0].completed=0,
    d=>d.inventories[0].items[0].id='facility-1.job-0.batch-999.weapon-0',
    d=>d.inventories[0].workforce.workers.assigned=0]) {
    const data=s.save();change(data);assert.throws(()=>Simulation.restore(data),DefinitionError);
  }
  assert.deepEqual(s.validateState(),{ok:true});
});
test('pending outcome validator rejects impossible quantities and altered produced identities',()=>{
  const s=world({quality:true,bonus:true});s.advanceTicks(1);
  // Fill output after the batch starts, then keep its resolved outcome blocked.
  for(let i=0;i<19;i++)s.spawnItem('store','weapon',{});
  s.advance(.1);assert.ok(s.save().facilities[0].jobs[0].outcome);
  const d=s.save(),j=d.facilities[0].jobs[0];
  j.outcome.quantities.weapon=3;j.outcome.items.push({id:j.id+'.batch-0.weapon-2',resourceId:'weapon',attributes:{health:85}});
  assert.throws(()=>Simulation.restore(d),/deterministic batch manifest/);
  const changed=s.save();changed.facilities[0].jobs[0].outcome.items[0].id+='-changed';
  assert.throws(()=>Simulation.restore(changed),/produced identity/);
  s.setProductionModifier('facility-1','specialist',{attributeBonuses:{health:100}});
  assert.deepEqual(jsonRestore(s).save(),s.save());
  assert.deepEqual(s.validateState(),{ok:true});
});
test('exhausted counters fail before any stock, jobs or clock state is changed',()=>{
  for(const [field,command] of [
    ['nextItem',s=>s.spawnItem('store','weapon',{})],
    ['nextDelivery',s=>s.reserveDelivery('store','other',{ore:1})],
    ['nextId',s=>s.addFacility('factory','store')],
    ['demandOrder',s=>s.advance(.05)]]) {
    const data=world().save();data[field]=Number.MAX_SAFE_INTEGER;
    const s=Simulation.restore(data),before=s.save();assert.throws(()=>command(s),/exhausted/);assert.deepEqual(s.save(),before);
  }
});
test('identical optional selection preserves partial holdings and FIFO request age',()=>{
  const s=world();s.withdraw('store',{ore:9});s.advanceTicks(1);
  const before=s.save();s.setOptionalInputs('facility-1','make',{});s.setOptionalInputs('facility-1','make',{alloy:0});
  assert.deepEqual(s.save(),before);assert.equal(s.inventory('store').reserved('ore'),1);
});
test('job explanation separates held stock, inbound promises, missing inputs and productivity sources',()=>{
  const s=world({staffed:true});s.withdraw('store',{ore:9});s.setWorkerSlot('facility-1',0,{id:'alice',efficiency:.5});
  s.setProductionModifier('facility-1','specialist',{productivityMultiplier:1.2});s.advanceTicks(1);
  s.deposit('other',{ore:1});const d=s.reserveDelivery('other','store',{ore:1});
  const e=s.explainJob('facility-1.job-0');assert.equal(e.phase,'idle');assert.deepEqual(e.reservedInputs,{ore:1});assert.equal(e.inboundInputs.ore,1);
  assert.deepEqual(e.blockers.find(b=>b.code==='missing-inputs').quantities,{ore:1});assert.equal(e.productivity.base,.75);assert.ok(Math.abs(e.productivity.effective-.9)<1e-12);
  assert.equal(e.estimatedCompletionSeconds,null);
  e.reservedInputs.ore=99;assert.equal(s.inventory('store').reserved('ore'),1);
  s.pickupDelivery(d.deliveryId);s.arriveDelivery(d.deliveryId);s.advanceTicks(1);
  const active=s.explainJob(e.jobId);assert.equal(active.phase,'working');assert.ok(active.estimatedCompletionSeconds>0);
});
test('explanations identify disabled, zero productivity and exact output deficits',()=>{
  const s=world();s.setFacilityEnabled('facility-1',false);assert.ok(s.explainJob('facility-1.job-0').blockers.some(b=>b.code==='disabled'));
  s.setFacilityEnabled('facility-1',true);s.advanceTicks(1);s.deposit('store',{alloy:20});s.advance(.1);
  assert.deepEqual(s.explainJob('facility-1.job-0').blockers.find(b=>b.code==='output-capacity').quantities,{alloy:1});
  assert.equal(s.explainJob('facility-1.job-0').phase,'awaiting-output');
  const ship=createShip();const f=ship.snapshot().facilities[0];ship.setProductionModifier(f.id,'failure',{productivityMultiplier:0});
  assert.ok(ship.explainJob(f.jobs[0].id).blockers.some(b=>b.code==='zero-productivity'));
  assert.throws(()=>s.explainJob('missing'),DefinitionError);
});
test('ownership queries distinguish reservations, transit, destination, retired and unknown items',()=>{
  const s=world();const id=s.spawnItem('store','weapon',{health:87});
  assert.deepEqual(s.locateItem(id),{kind:'inventory',inventoryId:'store',reservationOwner:null});
  const d=s.reserveDelivery('store','other',{ore:1},[id]);
  assert.equal(s.locateItem(id).reservationOwner,d.deliveryId);assert.equal(s.inspectReservations('store')[0].owner.kind,'delivery');
  const inspected=s.inspectReservations('store');inspected[0].quantities.ore=999;assert.equal(s.inventory('store').reserved('ore'),1);
  s.pickupDelivery(d.deliveryId);assert.deepEqual(s.locateItem(id),{kind:'delivery',deliveryId:d.deliveryId});
  s.arriveDelivery(d.deliveryId);s.pruneDeliveries();assert.equal(s.locateItem(id).inventoryId,'other');
  s.consumeItem('other',id);assert.deepEqual(s.locateItem(id),{kind:'retired'});assert.equal(s.locateItem('never-issued'),undefined);
});
test('blocked production owns its issued equipment and is visible in the inspector',()=>{
  const s=world({quality:true});s.advanceTicks(1);for(let i=0;i<19;i++)s.spawnItem('store','weapon',{});s.advance(.1);
  const id=s.save().facilities[0].jobs[0].outcome.items[0].id;assert.deepEqual(s.locateItem(id),{kind:'job',jobId:'facility-1.job-0',facilityId:'facility-1'});
});
test('trace is bounded, detached, opt-in and excluded from saves',()=>{
  const s=world(),copy=jsonRestore(s);assert.deepEqual(s.diagnosticTrace(),[]);s.enableDiagnostics(8);
  for(let i=0;i<20;i++){s.advance(.05);copy.advance(.05);}
  const entries=s.diagnosticTrace();assert.equal(entries.length,8);assert.ok(entries.every((e,i)=>i===0||e.sequence>entries[i-1].sequence));
  assert.ok(entries.some(e=>e.kind==='event'));entries[0].details.changed=true;assert.equal(s.diagnosticTrace()[0].details.changed,undefined);
  assert.deepEqual(s.save(),copy.save());assert.deepEqual(jsonRestore(s).diagnosticTrace(),[]);
  s.enableDiagnostics(0);s.advanceTicks(1);assert.deepEqual(s.diagnosticTrace(),[]);
});
test('shared validation is safe in event observers and diagnoses both demo worlds across JSON resumes',()=>{
  for(const factory of [createShip,createSettlement]){let s=factory();
    for(let i=0;i<15;i++){s.advance(.173456);assert.deepEqual(s.validateState(),{ok:true});s=jsonRestore(s);}
    s.onEvent(()=>assert.deepEqual(s.validateState(),{ok:true}));s.advance(1);
  }
});

test('tolerance-rounded clock ticks preflight exhaustion before changing the remainder',()=>{
  const data=world().save();data.tick=Number.MAX_SAFE_INTEGER;
  const s=Simulation.restore(data),before=s.save();
  assert.throws(()=>s.advance(.05-5e-14),/tick overflow/);
  assert.deepEqual(s.save(),before);
});

test('restore keeps workforce scoped to construction inventories with separate production endpoints',()=>{
  const sim=new Simulation({resources:[],recipes:[],facilities:[
    {id:'home',label:'Home',category:'housing',recipes:[],constructionCost:{},workersProvided:{farmers:4,engineers:0}},
    {id:'workshop',label:'Workshop',category:'production',recipes:[],constructionCost:{},workersRequired:{farmers:2}},
  ]});
  for(const id of ['town-a','town-b','empty'])sim.createInventory({id,capacityPerMaterial:10});
  for(const id of ['town-a','town-b'])assert.ok(sim.addFacility('home',id).ok);
  assert.ok(sim.addFacility('workshop','town-a',{inputInventoryId:'town-b',outputInventoryId:'empty'}).ok);
  const restored=jsonRestore(sim);
  assert.deepEqual(restored.save(),sim.save());
  assert.deepEqual(restored.inventory('town-a').snapshot().workforce,{farmers:{total:4,assigned:2},engineers:{total:0,assigned:0}});
  assert.deepEqual(restored.inventory('town-b').snapshot().workforce,{farmers:{total:4,assigned:0},engineers:{total:0,assigned:0}});
  assert.deepEqual(restored.inventory('empty').snapshot().workforce,{});
  const corrupted=sim.save();
  corrupted.inventories.find(i=>i.id==='town-a').workforce.farmers.assigned=0;
  corrupted.inventories.find(i=>i.id==='town-b').workforce.farmers.assigned=2;
  assert.throws(()=>Simulation.restore(corrupted),/workforce conflicts/);
  const phantom=sim.save();phantom.inventories.find(i=>i.id==='empty').workforce.farmers={total:1,assigned:0};
  assert.throws(()=>Simulation.restore(phantom),/workforce conflicts/);
});
