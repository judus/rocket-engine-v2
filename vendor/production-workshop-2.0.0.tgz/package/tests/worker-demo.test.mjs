import test from 'node:test';
import assert from 'node:assert/strict';
import {NodeWorkerTransport} from '../examples/node-worker-transport.mjs';
import {WorkerDemoClient} from '../worker/client.js';
import {WorkerDemoHost} from '../dist/worker-demo.js';

test('worker workload preserves ordered deterministic commands, bounded views and checkpoint continuation',async()=>{
  const transport=new NodeWorkerTransport(new URL('../examples/worker-node-entry.mjs',import.meta.url));
  const client=new WorkerDemoClient(()=>{},transport);
  const request=command=>client.request(command);
  try {
    await assert.rejects(request({type:'restore'}),/not initialized/);
    const reference=new WorkerDemoHost();
    assert.deepEqual((await request({type:'init'})).result,reference.handle({type:'init'}));
    await assert.rejects(request({type:'init'}),/already initialized/);
    await assert.rejects(request({type:'restore'}),/checkpoint first/);
    const commands=[{type:'advance',seconds:.017},{type:'advance',seconds:.033},{type:'advance',seconds:.375},{type:'advance',seconds:.825}];
    const replies=await Promise.all(commands.map(request));
    for(let n=0;n<commands.length;n++)assert.deepEqual(replies[n].result,reference.handle(commands[n]));
    const bulk=await request({type:'burst',ticks:200});assert.deepEqual(bulk.result,reference.handle({type:'burst',ticks:200}));
    assert.equal(bulk.result.view.counts.producing,6000);assert.equal(bulk.result.view.counts.blocked,0);
    assert.equal(bulk.result.view.jobs.length,12);assert.ok(JSON.stringify(bulk.result.view).length<5000);
    const before=(await request({type:'read'})).result;assert.deepEqual(before,reference.handle({type:'read'}));
    const saved=await request({type:'checkpoint'});assert.ok(saved.result.checkpointBytes>1000000);
    assert.deepEqual(saved.result,reference.handle({type:'checkpoint'}));assert.equal(saved.result.view,null);assert.equal('checkpoint' in saved.result,false);
    assert.deepEqual((await request({type:'export-checkpoint'})).result,reference.handle({type:'export-checkpoint'}));
    for(const invalid of [{type:'advance',seconds:-1},{type:'burst',ticks:0},{type:'burst',ticks:2001},{type:'unknown'}]) await assert.rejects(request(invalid));
    assert.deepEqual((await request({type:'read'})).result,before);
    await request({type:'advance',seconds:3.173456789});reference.handle({type:'advance',seconds:3.173456789});
    assert.deepEqual((await request({type:'restore'})).result,reference.handle({type:'restore'}));
    assert.deepEqual((await request({type:'read'})).result,before);
    for(let n=0;n<20;n++){
      const command={type:'advance',seconds:.173456789};
      assert.deepEqual((await request(command)).result,reference.handle(command));
    }
    assert.deepEqual((await request({type:'read'})).result,reference.handle({type:'read'}));
    await request({type:'checkpoint'});reference.handle({type:'checkpoint'});
    assert.deepEqual((await request({type:'export-checkpoint'})).result,reference.handle({type:'export-checkpoint'}));
  } finally {client.close();}
});

test('elapsed barrier behind a busy actual owner checkpoints earlier time and preserves later time',async()=>{
  const {WorkerAdvanceQueue}=await import('../worker/advance-queue.js');
  const client=new WorkerDemoClient(()=>{},new NodeWorkerTransport(new URL('../examples/worker-node-entry.mjs',import.meta.url)));
  const reference=new WorkerDemoHost();
  const queue=new WorkerAdvanceQueue(seconds=>client.request({type:'advance',seconds}));
  try {
    await client.request({type:'init'});reference.handle({type:'init'});
    const burst=client.request({type:'burst',ticks:200});
    queue.add(.1);const earlier=queue.advance();queue.add(.23);
    const boundary=queue.flush();queue.add(.17);
    assert.equal(queue.advance(),null);
    await burst;await earlier;await boundary;
    reference.handle({type:'burst',ticks:200});reference.handle({type:'advance',seconds:.1});reference.handle({type:'advance',seconds:.23});
    await client.request({type:'checkpoint'});reference.handle({type:'checkpoint'});
    assert.deepEqual((await client.request({type:'export-checkpoint'})).result,reference.handle({type:'export-checkpoint'}));
    assert.equal(queue.pendingSeconds,.17);
    await queue.advance();reference.handle({type:'advance',seconds:.17});
    await client.request({type:'checkpoint'});reference.handle({type:'checkpoint'});
    assert.deepEqual((await client.request({type:'export-checkpoint'})).result,reference.handle({type:'export-checkpoint'}));
  } finally {queue.close();client.close();}
});
