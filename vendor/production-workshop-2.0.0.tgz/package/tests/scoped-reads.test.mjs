import test from 'node:test';
import assert from 'node:assert/strict';
import {Simulation,DefinitionError} from '../dist/index.js';
import {TransportExample} from '../dist/transport-example.js';
function fixture(){
 const sim=new Simulation({resources:[{id:'ore',label:'Ore',kind:'material'},...['weapon','tool'].map(id=>({id,label:id,kind:'material',storage:'individual'}))],
 recipes:[{id:'forge',label:'Forge',durationSeconds:.1,inputs:{ore:1},outputs:{weapon:1}}],
 facilities:[{id:'factory',label:'Factory',category:'production',recipes:['forge'],constructionCost:{},workersProvided:{worker:1},workersRequired:{worker:1}}]});
 sim.createInventory({id:'store',capacityPerMaterial:200,initial:{ore:5}});sim.createInventory({id:'outpost',capacityPerMaterial:200});
 sim.addFacility('factory','store');sim.setFacilityAttendance('facility-1',{worker:1});return sim;
}
test('scoped summaries and indexed facility reads match full snapshots and remain detached through restore',()=>{
 const sim=fixture();sim.advance(.08);const full=sim.snapshot(),summary=sim.summary();
 assert.equal(summary.facilityCount,1);assert.equal(summary.inventoryCount,2);assert.equal(summary.deliveryCount,0);
 assert.equal(summary.pendingSeconds,full.pendingSeconds);assert.equal(summary.timeSeconds,full.timeSeconds);
 const f=sim.facilitySnapshot('facility-1');assert.deepEqual(f,full.facilities[0]);
 f.workerSlots[0].efficiency=0;f.jobs[0].selectedOptionalInputs.ore=999;
 assert.deepEqual(sim.facilitySnapshot('facility-1'),full.facilities[0]);
 const ids=sim.facilityIds();ids.length=0;assert.deepEqual(sim.facilityIds(),['facility-1']);
 const inventory=sim.inventory('store').summary();assert.equal('items' in inventory,false);inventory.quantities.ore=999;inventory.workforce.worker.total=999;
 assert.equal(sim.inventory('store').quantity('ore'),4);assert.equal(sim.inventory('store').summary().workforce.worker.total,1);
 const restored=Simulation.restore(JSON.parse(JSON.stringify(sim.save())));assert.deepEqual(restored.facilitySnapshot('facility-1'),sim.facilitySnapshot('facility-1'));
 assert.ok(restored.addFacility('factory','store').ok);assert.equal(restored.facilitySnapshot('facility-2').id,'facility-2');
 assert.throws(()=>sim.facilitySnapshot('missing'),DefinitionError);
});
test('item windows preserve insertion order, support resource filtering, and expose detached equipment',()=>{
 const sim=fixture(),view=sim.inventory('store');const ids=[];
 for(let n=0;n<74;n++)ids.push(sim.spawnItem('store',n%20===0?'tool':'weapon',{health:n}));
 const d=sim.reserveDelivery('store','outpost',{},ids.slice(0,2));assert.ok(d.ok);
 assert.equal(view.summary().itemCount,74);assert.equal(view.summary().reservedItemCount,2);
 const first=view.itemPage(),last=view.itemPage({offset:50});assert.equal(first.items.length,50);assert.equal(last.items.length,24);
 assert.deepEqual([...first.items,...last.items],view.snapshot().items);
 assert.equal(view.itemPage({offset:10000}).items.length,0);
 const tools=view.itemPage({resourceId:'tool',offset:1,limit:2});assert.equal(tools.total,4);assert.deepEqual(tools.items.map(i=>i.id),[ids[20],ids[40]]);
 first.items[0].attributes.health=999;assert.equal(view.item(ids[0]).attributes.health,0);
 sim.pickupDelivery(d.deliveryId);assert.equal(view.summary().itemCount,72);assert.equal(view.summary().reservedItemCount,0);
 assert.equal(view.itemPage({resourceId:'tool'}).total,3);
 for(const options of [{offset:-1},{offset:.5},{limit:0},{limit:501},{resourceId:'ore'},{resourceId:'missing'}])assert.throws(()=>view.itemPage(options),DefinitionError);
});

test('transport host reports completed arrivals exactly once without world snapshots',()=>{
 const world=new TransportExample();world.automaticFeeding=false;world.automaticCollection=false;world.travelSeconds=1;
 assert.ok(world.dispatchWeapon());world.advance(.5);assert.equal(world.completedDeliveries,0);
 world.advance(.5);assert.equal(world.completedDeliveries,1);assert.equal(world.journeys().length,0);
 world.advance(2);assert.equal(world.completedDeliveries,1);
 assert.ok(world.dispatchSupply());world.advance(1.1);assert.equal(world.completedDeliveries,2);
 assert.equal(world.completedDeliveries,world.simulation.snapshot().deliveries.filter(d=>d.state==='delivered').length);
});
