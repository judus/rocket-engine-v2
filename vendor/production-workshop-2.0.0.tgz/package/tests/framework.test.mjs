import test from "node:test";
import assert from "node:assert/strict";
import { Simulation, Clock, DefinitionError } from "../dist/index.js";
import {
  createSettlement,
  createShip,
  settlementConfiguration,
} from "../dist/examples.js";
const config = (
  recipes = [
    {
      id: "make",
      label: "Make",
      durationSeconds: 0.75,
      inputs: { ore: 1 },
      outputs: { alloy: 1 },
    },
  ],
) => ({
  resources: [
    { id: "ore", label: "Ore", kind: "material" },
    { id: "alloy", label: "Alloy", kind: "material" },
    { id: "credits", label: "Credits", kind: "currency" },
  ],
  recipes,
  facilities: recipes.map((r) => ({
    id: r.id,
    label: r.label,
    category: "module",
    recipes: [r.id],
    constructionCost: {},
  })),
});
const seeded = () => {
  const s = new Simulation(config());
  s.createInventory({
    id: "cargo",
    capacityPerMaterial: 100,
    initial: { ore: 30 },
  });
  s.addFacility("make", "cargo");
  return s;
};
test("same elapsed simulation time gives identical complete state for large and partitioned updates", () => {
  const a = seeded(),
    b = seeded(),
    c = seeded();
  a.advance(10);
  for (let i = 0; i < 200; i++) b.advance(0.05);
  for (let i = 0; i < 100; i++) {
    c.advance(0.017);
    c.advance(0.083);
  }
  assert.deepEqual(a.snapshot(), b.snapshot());
  assert.deepEqual(a.snapshot(), c.snapshot());
});
test("one clock, pause/resume, speeds, no long-frame time loss", () => {
  const s = seeded(),
    clock = new Clock((t) => s.advance(t));
  clock.sample(1000);
  clock.sample(3000);
  assert.equal(s.snapshot().timeSeconds, 2);
  clock.setPaused(true);
  clock.sample(20000);
  clock.setPaused(false);
  clock.sample(30000);
  clock.speed = 2;
  clock.sample(31000);
  assert.equal(s.snapshot().timeSeconds, 4);
  assert.throws(() => clock.sample(30000), DefinitionError);
});
test("fractional tick remainder is retained", () => {
  const s = seeded();
  assert.equal(s.advance(0.02), 0);
  assert.equal(s.advance(0.03), 1);
  assert.equal(s.snapshot().pendingSeconds, 0);
  assert.throws(() => s.advance(-1), DefinitionError);
});
test("registration rejects unknown resources and recipes, duplicate IDs, invalid quantities and durations", () => {
  const bad = config();
  bad.recipes[0].inputs = { unknown: 2 };
  assert.throws(() => new Simulation(bad), /unknown resource/);
  for (const value of [-1, NaN, Infinity, 0.5]) {
    const c = config();
    c.recipes[0].inputs = { ore: value };
    assert.throws(() => new Simulation(c), /safe integer/);
  }
  const duplicate = config();
  duplicate.resources.push({ ...duplicate.resources[0] });
  assert.throws(() => new Simulation(duplicate), /duplicate/);
  const missing = config();
  missing.facilities[0].recipes = ["missing"];
  assert.throws(() => new Simulation(missing), /unknown recipe/);
  const duration = config();
  duration.recipes[0].durationSeconds = 0;
  assert.throws(() => new Simulation(duration), /duration/);
});
test("registry owns immutable definitions; snapshots cannot mutate live state", () => {
  const c = config(),
    s = new Simulation(c);
  c.recipes[0].inputs.ore = 100;
  assert.equal(s.registry.recipe("make").inputs.ore, 1);
  assert.throws(() => (s.registry.recipe("make").inputs.ore = 2), TypeError);
  const i = s.createInventory({
    id: "cargo",
    capacityPerMaterial: 10,
    initial: { ore: 5 },
  });
  const view = i.snapshot();
  view.quantities.ore = 999;
  assert.equal(i.quantity("ore"), 5);
});
test("atomic inventory operations and uncapped currency", () => {
  const s = new Simulation(config()),
    i = s.createInventory({
      id: "cargo",
      capacityPerMaterial: 5,
      initial: { ore: 4, credits: 10000 },
    });
  assert.equal(s.withdraw(i.id, { ore: 2, alloy: 1 }), false);
  assert.equal(i.quantity("ore"), 4);
  assert.equal(s.deposit(i.id, { ore: 2, alloy: 1 }), false);
  assert.equal(i.quantity("alloy"), 0);
  assert.equal(s.deposit(i.id, { credits: 10000 }), true);
  assert.equal(i.quantity("credits"), 20000);
  assert.throws(() => s.deposit(i.id, { unknown: 1 }), /unknown resource/);
});
test("reservations prevent double spending and support cancellation and pickup", () => {
  const s = seeded(), i = s.inventory("cargo");
  s.createInventory({id: "destination", capacityPerMaterial: 100});
  const d = s.reserveDelivery("cargo", "destination", {ore: 29});
  assert.ok(d.ok);
  assert.equal(s.withdraw("cargo", {ore: 2}), false);
  assert.equal(s.reserveDelivery("cargo", "destination", {ore: 2}).ok, false);
  s.cancelDelivery(d.deliveryId);
  const next = s.reserveDelivery("cargo", "destination", {ore: 2});
  s.pickupDelivery(next.deliveryId);
  assert.equal(i.quantity("ore"), 28);
  assert.equal(i.reserved("ore"), 0);
  assert.throws(() => s.pickupDelivery(next.deliveryId), /awaiting pickup/);
});
test("transfer is atomic and cannot move reserved goods", () => {
  const s = seeded(),
    from = s.inventory("cargo"),
    to = s.createInventory({ id: "planet", capacityPerMaterial: 1 });
  assert.equal(s.transfer(from.id, to.id, { ore: 2 }), false);
  assert.equal(from.quantity("ore"), 30);
  assert.equal(s.transfer(from.id, to.id, { ore: 1 }), true);
  assert.equal(to.quantity("ore"), 1);
  assert.equal(from.quantity("ore"), 29);
});
test("construction charges materials and credits and checks workforce without partial mutations", () => {
  const s = createSettlement(),
    before = s.snapshot();
  assert.equal(s.addFacility("small-warehouse", "settlement").ok, false);
  assert.deepEqual(s.snapshot(), before);
  assert.equal(s.addFacility("farmer-residence", "settlement").ok, true);
  assert.equal(s.addFacility("small-warehouse", "settlement").ok, true);
  const i = s.inventory("settlement").snapshot();
  assert.equal(i.capacityPerMaterial, 40);
  assert.equal(i.quantities.timber, 4);
  assert.equal(i.quantities.credits, 700);
  assert.deepEqual(i.workforce.farmers, { total: 20, assigned: 12 });
});
test("persistent demand gives competing sawmills fair access", () => {
  const s = createSettlement();
  s.addFacility("farmer-residence", "settlement");
  s.addFacility("small-warehouse", "settlement");
  const extraMill=s.addFacility("sawmill", "settlement");
  s.setFacilityAttendance(extraMill.facilityId,{farmers:5});
  s.advance(15);
  const mills = s
    .snapshot()
    .facilities.filter((f) => f.definitionId === "sawmill")
    .map((f) => f.jobs[0].batchesCompleted);
  assert.ok(mills.every((n) => n > 0));
  assert.ok(Math.abs(mills[0] - mills[1]) <= 1, JSON.stringify(mills));
});
test("all inputs are consumed once, multiple output quantities respected", () => {
  const c = config([
    {
      id: "make",
      label: "Make",
      durationSeconds: 1,
      inputs: { ore: 2, credits: 3 },
      outputs: { alloy: 4 },
    },
  ]);
  const s = new Simulation(c);
  s.createInventory({
    id: "cargo",
    capacityPerMaterial: 20,
    initial: { ore: 2, credits: 10 },
  });
  s.addFacility("make", "cargo");
  s.advance(0.05);
  assert.equal(s.inventory("cargo").quantity("ore"), 0);
  assert.equal(s.inventory("cargo").quantity("credits"), 7);
  s.advance(1);
  assert.equal(s.inventory("cargo").quantity("alloy"), 4);
  s.advance(4);
  assert.equal(s.inventory("cargo").quantity("credits"), 7);
});
test("blocked completed output retains batch and publishes later without consuming again", () => {
  const s = seeded(),
    i = s.inventory("cargo");
  s.advance(0.05);
  s.deposit(i.id, { alloy: 100 });
  s.advance(0.75);
  assert.equal(s.snapshot().facilities[0].jobs[0].state, "output-blocked");
  assert.equal(i.quantity("ore"), 29);
  s.withdraw(i.id, { alloy: 1 });
  s.advance(0.05);
  assert.equal(i.quantity("alloy"), 100);
  assert.equal(s.snapshot().facilities[0].jobs[0].batchesCompleted, 1);
  assert.equal(i.quantity("ore"), 29);
});
test("multi-output completion is atomic when one output is full", () => {
  const c = config([
    {
      id: "make",
      label: "Make",
      durationSeconds: 0.1,
      inputs: { ore: 1 },
      outputs: { alloy: 2, credits: 4 },
    },
  ]);
  const s = new Simulation(c),
    i = s.createInventory({
      id: "cargo",
      capacityPerMaterial: 5,
      initial: { ore: 1 },
    });
  s.addFacility("make", "cargo");
  s.advance(0.05);
  s.deposit(i.id, { alloy: 4 });
  s.advance(0.1);
  assert.equal(i.quantity("credits"), 0);
  assert.equal(i.quantity("alloy"), 4);
  s.withdraw(i.id, { alloy: 1 });
  s.advance(0.05);
  assert.equal(i.quantity("alloy"), 5);
  assert.equal(i.quantity("credits"), 4);
});
test("a recipe can transform a material into itself when capacity is full", () => {
  const s = new Simulation(
    config([
      {
        id: "make",
        label: "Make",
        durationSeconds: 0.1,
        inputs: { ore: 2 },
        outputs: { ore: 1 },
      },
    ]),
  );
  s.createInventory({
    id: "cargo",
    capacityPerMaterial: 5,
    initial: { ore: 5 },
  });
  s.addFacility("make", "cargo");
  s.advance(0.15);
  assert.equal(s.snapshot().facilities[0].jobs[0].batchesCompleted, 1);
});
test("suspending a facility preserves batch progress and its assigned workers", () => {
  const s = seeded(),
    f = s.snapshot().facilities[0];
  s.advance(0.3);
  const before = s.snapshot().facilities[0].jobs[0].progress;
  s.setFacilityEnabled(f.id, false);
  s.advance(5);
  assert.equal(s.snapshot().facilities[0].jobs[0].progress, before);
  assert.equal(s.snapshot().facilities[0].jobs[0].state, "paused");
  s.setFacilityEnabled(f.id, true);
  s.advance(0.5);
  assert.equal(s.snapshot().facilities[0].jobs[0].batchesCompleted, 1);
});
test("ship example works without workforce and stops safely at finite inputs", () => {
  const s = createShip();
  s.advance(100);
  const i = s.inventory("ship").snapshot();
  assert.deepEqual(i.workforce, {});
  assert.ok(i.quantities.sensor > 0);
  assert.ok(i.items.some((item) => item.resourceId === "weapon"));
  assert.ok(
    Object.values(i.quantities).every((n) => Number.isSafeInteger(n) && n >= 0),
  );
  assert.ok(
    s
      .snapshot()
      .facilities.some((f) => f.jobs.some((j) => j.state === "waiting-inputs")),
  );
});
test("observers see committed facts and cannot reenter simulation commands", () => {
  const s = seeded(),
    events = [];
  s.onEvent((e) => events.push(e));
  s.advance(1);
  assert.ok(events.some((e) => e.type === "batch-completed"));
  const stop = s.onEvent(() => s.advance(0.05));
  assert.throws(() => s.advance(1), AggregateError);
  stop();
  s.advance(0.05);
});
test("settlement content contains all 43 original facility definitions", () =>
  assert.equal(settlementConfiguration.facilities.length, 43));
test("optional operating condition blocks and resumes a batch without changing the engine", () => {
  const c = config();
  c.facilities[0].operatingConditions = ["operator-present"];
  const s = new Simulation(c);
  s.createInventory({
    id: "cargo",
    capacityPerMaterial: 10,
    initial: { ore: 3 },
  });
  const f = s.addFacility("make", "cargo");
  assert.ok(f.ok);
  s.advance(1);
  assert.equal(s.inventory("cargo").quantity("ore"), 3);
  assert.equal(s.snapshot().facilities[0].jobs[0].state, "waiting-condition");
  s.setFacilityCondition(f.facilityId, "operator-present", true);
  s.advance(0.3);
  const progress = s.snapshot().facilities[0].jobs[0].progress;
  s.setFacilityCondition(f.facilityId, "operator-present", false);
  s.advance(1);
  assert.equal(s.snapshot().facilities[0].jobs[0].progress, progress);
  s.setFacilityCondition(f.facilityId, "operator-present", true);
  s.advance(0.5);
  assert.equal(s.snapshot().facilities[0].jobs[0].batchesCompleted, 1);
  assert.throws(
    () => s.setFacilityCondition(f.facilityId, "unknown", true),
    /unknown operating condition/,
  );
});
test("overflowing construction effects fail before any payment", () => {
  const c = config();
  c.facilities[0].capacityProvided = Number.MAX_SAFE_INTEGER;
  c.facilities[0].constructionCost = { credits: 1 };
  const s = new Simulation(c);
  s.createInventory({
    id: "cargo",
    capacityPerMaterial: 20,
    initial: { credits: 5 },
  });
  const before = s.snapshot();
  assert.throws(() => s.addFacility("make", "cargo"), /safe integer/);
  assert.deepEqual(s.snapshot(), before);
});

function qualityWorld({ chance = 1, slots = 0, capacity = 20 } = {}) {
  const c = {
    seed: 42,
    resources: [
      { id: "ore", label: "Ore", kind: "material" },
      { id: "reinforcement", label: "Reinforcement", kind: "material" },
      { id: "diamond", label: "Diamond", kind: "material" },
      {
        id: "weapon",
        label: "Weapon",
        kind: "material",
        storage: "individual",
      },
    ],
    recipes: [
      {
        id: "weapons",
        label: "Weapons",
        durationSeconds: 1,
        inputs: { ore: 1 },
        outputs: { weapon: 1 },
        itemAttributes: {
          weapon: {
            maxHealth: { min: 80, max: 90 },
            precision: { min: 0.8, max: 0.9 },
          },
        },
        optionalInputs: { reinforcement: 1 },
        optionalAttributeBonuses: { reinforcement: { maxHealth: 10 } },
        bonusOutputs: [{ chance, outputs: { diamond: 1 } }],
      },
    ],
    facilities: [
      {
        id: "factory",
        label: "Factory",
        category: "module",
        recipes: ["weapons"],
        constructionCost: {},
        workerSlots: slots,
      },
    ],
  };
  const s = new Simulation(c);
  s.createInventory({
    id: "cargo",
    capacityPerMaterial: capacity,
    initial: { ore: capacity, reinforcement: capacity },
  });
  const f = s.addFacility("factory", "cargo").facilityId;
  return { s, f, c };
}
test("slot occupancy and productivity differ; specialists multiply aggregate efficiency", () => {
  const { s, f } = qualityWorld({ slots: 3 });
  s.setWorkerSlot(f, 0, { id: "alice", efficiency: 0.8 });
  s.setWorkerSlot(f, 1, { id: "bob", efficiency: 0.2 });
  assert.equal(s.snapshot().facilities[0].productivity, 1 / 3);
  s.setProductionModifier(f, "specialist", { productivityMultiplier: 1.2 });
  assert.ok(Math.abs(s.snapshot().facilities[0].productivity - 0.4) < 1e-12);
  assert.equal(
    s.snapshot().facilities[0].workerSlots.filter(Boolean).length,
    2,
  );
  assert.throws(
    () => s.setWorkerSlot(f, 2, { id: "alice", efficiency: 1 }),
    /already assigned/,
  );
  assert.throws(() => s.setWorkerSlot(f, 3, null), /slot/);
  assert.throws(
    () => s.setProductionModifier(f, "bad", { productivityMultiplier: NaN }),
    /multiplier/,
  );
});
test("live modifiers change future work of the active batch; failure retains inputs and progress", () => {
  const { s, f } = qualityWorld();
  s.advance(0.55);
  assert.equal(s.snapshot().facilities[0].jobs[0].progress, 0.5);
  assert.equal(s.inventory("cargo").quantity("ore"), 19);
  s.setProductionModifier(f, "damage", { productivityMultiplier: 0 });
  s.advance(1);
  assert.equal(s.snapshot().facilities[0].jobs[0].progress, 0.5);
  assert.equal(s.snapshot().facilities[0].jobs[0].state, "paused");
  s.setProductionModifier(f, "damage", { productivityMultiplier: 2 });
  s.advance(0.25);
  assert.equal(s.inventory("cargo").quantity("weapon"), 1);
  assert.equal(s.snapshot().facilities[0].jobs[0].batchesCompleted, 1);
});
test("optional inputs lock at start; completion-time specialist controls same-product attributes", () => {
  const { s, f } = qualityWorld();
  s.setOptionalInputs(f, "weapons", { reinforcement: 1 });
  s.advance(0.55);
  assert.equal(s.inventory("cargo").quantity("reinforcement"), 19);
  s.setOptionalInputs(f, "weapons", {});
  s.setProductionModifier(f, "specialist", {
    attributeBonuses: { maxHealth: 10, precision: 0.1 },
  });
  s.advance(0.5);
  const first = s.inventory("cargo").snapshot().items[0];
  assert.ok(
    first.attributes.maxHealth >= 100 && first.attributes.maxHealth < 110,
  );
  assert.ok(
    first.attributes.precision >= 0.9 && first.attributes.precision < 1,
  );
  assert.equal(s.inventory("cargo").quantity("reinforcement"), 19);
  s.setProductionModifier(f, "specialist", null);
  s.advance(1);
  const second = s.inventory("cargo").snapshot().items[1];
  assert.equal(first.resourceId, second.resourceId);
  assert.notEqual(first.id, second.id);
  assert.ok(
    second.attributes.maxHealth >= 80 && second.attributes.maxHealth < 90,
  );
  assert.throws(
    () => s.setOptionalInputs(f, "weapons", { ore: 1 }),
    /declared/,
  );
});
test("bonus and individual outcomes publish atomically and never reroll while blocked", () => {
  const { s, f } = qualityWorld({ capacity: 2 });
  s.advance(0.05);
  s.deposit("cargo", { diamond: 2 });
  s.advance(1);
  const pending = s.snapshot().facilities[0].jobs[0].pendingOutcome;
  assert.equal(s.inventory("cargo").quantity("weapon"), 0);
  assert.equal(s.snapshot().facilities[0].jobs[0].state, "output-blocked");
  s.setProductionModifier(f, "specialist", {
    attributeBonuses: { maxHealth: 100 },
  });
  s.advance(10);
  assert.deepEqual(s.snapshot().facilities[0].jobs[0].pendingOutcome, pending);
  pending.items[0].attributes.maxHealth = -100;
  assert.notEqual(
    s.snapshot().facilities[0].jobs[0].pendingOutcome.items[0].attributes
      .maxHealth,
    -100,
  );
  s.withdraw("cargo", { diamond: 1 });
  s.advance(0.05);
  assert.equal(s.inventory("cargo").quantity("weapon"), 1);
  assert.equal(s.inventory("cargo").quantity("diamond"), 2);
  assert.ok(s.inventory("cargo").snapshot().items[0].attributes.maxHealth < 90);
});
test("seeded quality and bonus rolls are invariant to frame partition and unrelated facilities", () => {
  const a = qualityWorld({ chance: 0.01, capacity: 1000 });
  const b = qualityWorld({ chance: 0.01, capacity: 1000 });
  a.s.advance(500.05);
  for (let i = 0; i < 10001; i++) b.s.advance(0.05);
  assert.deepEqual(a.s.snapshot(), b.s.snapshot());
  const diamonds = a.s.inventory("cargo").quantity("diamond");
  assert.ok(diamonds > 0 && diamonds < 25, `seeded 1% bonus: ${diamonds}`);
  const noBonus = qualityWorld({ chance: 0 });
  noBonus.s.advance(5);
  assert.equal(noBonus.s.inventory("cargo").quantity("diamond"), 0);
  const extra = qualityWorld();
  const normal = qualityWorld();
  const other = extra.s.createInventory({
    id: "other",
    capacityPerMaterial: 20,
    initial: { ore: 20 },
  });
  extra.s.addFacility("factory", other.id);
  extra.s.advance(5);
  normal.s.advance(5);
  assert.deepEqual(
    extra.s.inventory("cargo").snapshot(),
    normal.s.inventory("cargo").snapshot(),
  );
});
test("individual goods retain identity on transfer; repair and wear belong to host", () => {
  const { s } = qualityWorld();
  s.advance(1.05);
  const cargo = s.inventory("cargo"),
    item = cargo.snapshot().items[0];
  assert.equal(s.withdraw(cargo.id, { weapon: 1 }), false);
  assert.equal(s.deposit(cargo.id, { weapon: 1 }), false);
  s.updateItemAttributes(cargo.id, item.id, { currentHealth: 40 });
  const tiny = s.createInventory({ id: "tiny", capacityPerMaterial: 0 });
  assert.equal(s.transferItem(cargo.id, tiny.id, item.id), false);
  assert.equal(cargo.quantity("weapon"), 1);
  const planet = s.createInventory({ id: "planet", capacityPerMaterial: 2 });
  assert.equal(s.transferItem(cargo.id, planet.id, item.id), true);
  assert.equal(cargo.quantity("weapon"), 0);
  assert.equal(planet.snapshot().items[0].attributes.currentHealth, 40);
  s.updateItemAttributes(planet.id, item.id, {
    currentHealth: item.attributes.maxHealth,
  });
  assert.equal(
    planet.snapshot().items[0].attributes.currentHealth,
    item.attributes.maxHealth,
  );
  assert.throws(
    () => s.updateItemAttributes(planet.id, item.id, { maxHealth: Infinity }),
    /attribute/,
  );
  assert.throws(
    () => s.spawnItem(planet.id, "ore", {}),
    /individual/,
  );
});
test("extended definitions own deep copies and reject malformed authoring", () => {
  const { s, c } = qualityWorld();
  c.recipes[0].itemAttributes.weapon.maxHealth.min = -5;
  assert.equal(
    s.registry.recipe("weapons").itemAttributes.weapon.maxHealth.min,
    80,
  );
  assert.throws(
    () => (s.registry.recipe("weapons").bonusOutputs[0].chance = 0),
    TypeError,
  );
  for (const change of [
    (c) => (c.recipes[0].bonusOutputs[0].chance = 1.1),
    (c) =>
      (c.recipes[0].itemAttributes.weapon.maxHealth = { min: 100, max: 80 }),
    (c) => (c.recipes[0].optionalAttributeBonuses.ore = { maxHealth: 5 }),
    (c) => (c.facilities[0].workerSlots = -1),
  ]) {
    const bad = qualityWorld().c;
    change(bad);
    assert.throws(() => new Simulation(bad), DefinitionError);
  }
});
test("ten half-experienced/full-experienced workers with 20% specialist give 90% rate", () => {
  const { s, f } = qualityWorld({ slots: 10 });
  for (let slot = 0; slot < 10; slot++)
    s.setWorkerSlot(f, slot, {
      id: `person-${slot}`,
      efficiency: slot < 5 ? 0.5 : 1,
    });
  s.setProductionModifier(f, "specialist", { productivityMultiplier: 1.2 });
  assert.ok(Math.abs(s.snapshot().facilities[0].productivity - 0.9) < 1e-12);
});
test("construction worker counts do not fill more slots than reserved", () => {
  const c = config();
  c.facilities[0].workersProvided = { workers: 2 };
  c.facilities[0].workersRequired = { workers: 2 };
  c.facilities[0].workerSlots = 3;
  const s = new Simulation(c);
  s.createInventory({ id: "cargo", capacityPerMaterial: 10 });
  s.addFacility("make", "cargo");
  s.setFacilityAttendance("facility-1",{workers:2});
  assert.equal(
    s.snapshot().facilities[0].workerSlots.filter(Boolean).length,
    2,
  );
  assert.equal(s.snapshot().facilities[0].productivity, 2 / 3);
});

const buffered = (capacity = 2) => {
  const s = new Simulation(config());
  s.createInventory({
    id: "warehouse",
    capacityPerMaterial: 10,
    initial: { ore: 10 },
  });
  s.createInventory({ id: "input", capacityPerMaterial: capacity });
  s.createInventory({ id: "output", capacityPerMaterial: capacity });
  const f = s.addFacility("make", "warehouse", {
    inputInventoryId: "input",
    outputInventoryId: "output",
  }).facilityId;
  return { s, f };
};
test("separate production endpoints use local inputs and outputs, never construction warehouse stock", () => {
  const { s } = buffered();
  s.advance(1);
  assert.equal(s.inventory("warehouse").quantity("ore"), 10);
  assert.equal(s.snapshot().facilities[0].jobs[0].state, "waiting-inputs");
  s.transfer("warehouse", "input", { ore: 2 });
  s.advance(0.8);
  assert.equal(s.inventory("output").quantity("alloy"), 1);
  assert.equal(s.inventory("warehouse").quantity("alloy"), 0);
  assert.equal(s.snapshot().facilities[0].inputInventoryId, "input");
  assert.equal(s.snapshot().facilities[0].outputInventoryId, "output");
});
test("invalid buffer endpoints cannot charge construction costs", () => {
  const s = seeded(),
    before = s.snapshot();
  assert.throws(
    () => s.addFacility("make", "cargo", { inputInventoryId: "missing" }),
    /unknown inventory/,
  );
  assert.deepEqual(s.snapshot(), before);
});
test("reserve, pickup and arrival preserve ownership and prevent double spending or double delivery", () => {
  const { s } = buffered();
  const first = s.reserveDelivery("warehouse", "input", { ore: 6 });
  assert.ok(first.ok);
  assert.equal(s.inventory("warehouse").quantity("ore"), 10);
  assert.equal(s.inventory("warehouse").available("ore"), 4);
  assert.equal(s.reserveDelivery("warehouse", "input", { ore: 5 }).ok, false);
  assert.equal(s.withdraw("warehouse", { ore: 5 }), false);
  s.pickupDelivery(first.deliveryId);
  assert.equal(s.inventory("warehouse").quantity("ore"), 4);
  assert.equal(s.inventory("input").quantity("ore"), 0);
  assert.throws(() => s.pickupDelivery(first.deliveryId), /awaiting pickup/);
  assert.equal(s.arriveDelivery(first.deliveryId), false); // Too large for input buffer.
  assert.equal(s.snapshot().deliveries[0].state, "arrival-blocked");
  s.increaseCapacity("input", 10);
  assert.equal(s.arriveDelivery(first.deliveryId), true);
  assert.equal(s.inventory("input").quantity("ore"), 6);
  assert.throws(() => s.arriveDelivery(first.deliveryId), /carrying cargo/);
});
test("cancellation releases reserved goods; returned cargo waits if source is full", () => {
  const { s } = buffered();
  let d = s.reserveDelivery("warehouse", "input", { ore: 2 });
  s.cancelDelivery(d.deliveryId);
  assert.equal(s.inventory("warehouse").available("ore"), 10);
  assert.equal(s.snapshot().deliveries[0].state, "cancelled");
  assert.throws(() => s.pickupDelivery(d.deliveryId), /awaiting pickup/);
  d = s.reserveDelivery("warehouse", "input", { ore: 2 });
  s.pickupDelivery(d.deliveryId);
  assert.throws(() => s.cancelDelivery(d.deliveryId), /must be returned/);
  s.deposit("warehouse", { ore: 2 });
  assert.equal(s.returnDelivery(d.deliveryId), false);
  assert.equal(s.snapshot().deliveries[1].state, "in-transit");
  s.withdraw("warehouse", { ore: 2 });
  assert.equal(s.returnDelivery(d.deliveryId), true);
  assert.equal(s.inventory("warehouse").quantity("ore"), 10);
  assert.throws(() => s.returnDelivery(d.deliveryId), /carrying cargo/);
});
test("demands account for inbound promises and shared buffers without duplicating available stock", () => {
  const { s } = buffered();
  s.addFacility("make", "warehouse", {
    inputInventoryId: "input",
    outputInventoryId: "output",
  });
  assert.equal(
    s.materialDemands().reduce((n, d) => n + d.quantities.ore, 0),
    2,
  );
  const d = s.reserveDelivery("warehouse", "input", { ore: 2 });
  assert.equal(s.materialDemands().length, 0);
  s.pickupDelivery(d.deliveryId);
  assert.equal(s.materialDemands().length, 0);
  s.arriveDelivery(d.deliveryId);
  assert.equal(s.materialDemands().length, 0);
  s.advance(0.05);
  assert.equal(s.inventory("input").quantity("ore"), 0);
  assert.equal(s.materialDemands().length, 0); // Both batches active; no forecast.
});
test("separate full output blocks start even though input consumption frees input space", () => {
  const { s } = buffered(1);
  s.deposit("input", { ore: 1 });
  s.deposit("output", { alloy: 1 });
  s.advance(0.05);
  assert.equal(s.snapshot().facilities[0].jobs[0].state, "output-blocked");
  assert.equal(s.inventory("input").quantity("ore"), 1);
  s.withdraw("output", { alloy: 1 });
  s.advance(0.8);
  assert.equal(s.inventory("output").quantity("alloy"), 1);
});
test("individual-quality output can publish to a separate buffer", () => {
  const { c } = qualityWorld();
  const independent = new Simulation(c);
  independent.createInventory({ id: "costs", capacityPerMaterial: 20 });
  independent.createInventory({
    id: "input",
    capacityPerMaterial: 20,
    initial: { ore: 2 },
  });
  independent.createInventory({ id: "output", capacityPerMaterial: 1 });
  independent.addFacility("factory", "costs", {
    inputInventoryId: "input",
    outputInventoryId: "output",
  });
  independent.advance(1.05);
  assert.equal(independent.inventory("output").snapshot().items.length, 1);
  assert.equal(independent.inventory("output").quantity("diamond"), 1);
  assert.equal(independent.inventory("costs").snapshot().items.length, 0);
});
test("timed host example uses the same ticks and is independent of frame cadence", async () => {
  const { TransportExample } = await import("../dist/transport-example.js");
  const a = new TransportExample(),
    b = new TransportExample();
  a.advance(20);
  for (let i = 0; i < 200; i++) {
    b.advance(0.017);
    b.advance(0.083);
  }
  assert.deepEqual(a.simulation.snapshot(), b.simulation.snapshot());
  assert.deepEqual(a.journeys(), b.journeys());
  assert.ok(a.simulation.inventory("warehouse").quantity("alloy") > 0);
});
test("slow transport delays output; manual feeding and collection are host policies", async () => {
  const { TransportExample } = await import("../dist/transport-example.js");
  const fast = new TransportExample(),
    slow = new TransportExample();
  fast.travelSeconds = 1;
  slow.travelSeconds = 8;
  fast.advance(15);
  slow.advance(15);
  assert.ok(
    fast.simulation.inventory("warehouse").quantity("alloy") >
      slow.simulation.inventory("warehouse").quantity("alloy"),
  );
  const manual = new TransportExample();
  manual.automaticFeeding = false;
  manual.automaticCollection = false;
  manual.advance(10);
  assert.equal(manual.simulation.inventory("warehouse").quantity("ore"), 60);
  assert.ok(manual.dispatchSupply());
  assert.equal(manual.dispatchSupply(), false);
  manual.advance(4);
  assert.equal(
    manual.simulation.inventory("smelter-output").quantity("alloy"),
    1,
  );
  assert.ok(manual.collectOutput());
  manual.advance(3);
  assert.equal(manual.simulation.inventory("warehouse").quantity("alloy"), 1);
});
test("delivery authoring rejects invalid cargo and snapshots cannot mutate shipment ownership", () => {
  const { s } = buffered();
  assert.throws(() => s.reserveDelivery("warehouse", "input", {}), /empty/);
  assert.throws(
    () => s.reserveDelivery("warehouse", "warehouse", { ore: 1 }),
    /differ/,
  );
  assert.throws(
    () => s.reserveDelivery("warehouse", "input", { unknown: 1 }),
    /unknown resource/,
  );
  assert.throws(
    () => s.reserveDelivery("warehouse", "input", { ore: -1 }),
    /safe integer/,
  );
  const d = s.reserveDelivery("warehouse", "input", { ore: 2 });
  const view = s.snapshot();
  view.deliveries[0].quantities.ore = 999;
  view.deliveries[0].state = "delivered";
  assert.equal(s.snapshot().deliveries[0].state, "reserved");
  assert.equal(s.snapshot().deliveries[0].quantities.ore, 2);
  s.cancelDelivery(d.deliveryId);
  assert.equal(s.materialDemands()[0].quantities.ore, 1);
});

function itemDeliveryWorld() {
  const { s, f } = qualityWorld();
  s.advance(2.05);
  s.setFacilityEnabled(f, false);
  const source = s.inventory("cargo");
  const destination = s.createInventory({
    id: "destination",
    capacityPerMaterial: 20,
  });
  return { s, source, destination, items: source.snapshot().items };
}
test("specific items reserve atomically with bulk cargo and cannot be promised or moved twice", () => {
  const { s, source, destination, items } = itemDeliveryWorld();
  const item = items[0];
  const d = s.reserveDelivery(source.id, destination.id, { ore: 2 }, [item.id]);
  assert.ok(d.ok);
  assert.equal(source.reserved("weapon"), 1);
  assert.equal(source.available("weapon"), 1);
  assert.deepEqual(source.snapshot().reservedItemIds, [item.id]);
  assert.equal(s.transferItem(source.id, destination.id, item.id), false);
  const before = s.snapshot();
  assert.equal(
    s.reserveDelivery(source.id, destination.id, { ore: 1 }, [item.id]).ok,
    false,
  );
  assert.deepEqual(s.snapshot(), before);
  assert.equal(
    s.reserveDelivery(source.id, destination.id, { ore: 999 }, [items[1].id])
      .ok,
    false,
  );
  assert.equal(source.reserved("weapon"), 1);
  assert.throws(
    () =>
      s.reserveDelivery(source.id, destination.id, {}, [
        items[1].id,
        items[1].id,
      ]),
    /duplicate/,
  );
  assert.equal(
    s.reserveDelivery(source.id, destination.id, {}, ["missing-item"]).ok,
    false,
  );
  assert.equal(
    s.reserveDelivery(source.id, destination.id, { weapon: 1 }).ok,
    false,
  );
});
test("pickup captures latest item attributes; arrival retains identity, wear and quality exactly", () => {
  const { s, source, destination, items } = itemDeliveryWorld();
  const id = items[0].id;
  const d = s.reserveDelivery(source.id, destination.id, {}, [id]);
  assert.deepEqual(s.snapshot().deliveries[0].itemIds, [id]);
  assert.deepEqual(s.snapshot().deliveries[0].items, []); // Still physically at source.
  s.updateItemAttributes(source.id, id, { currentHealth: 41 });
  const original = source.item(id);
  s.pickupDelivery(d.deliveryId);
  assert.equal(source.item(id), undefined);
  assert.equal(source.reserved("weapon"), 0);
  assert.deepEqual(s.snapshot().deliveries[0].items, [original]);
  assert.throws(
    () => s.updateItemAttributes(source.id, id, { currentHealth: 99 }),
    /unknown item/,
  );
  const copy = s.snapshot();
  copy.deliveries[0].items[0].attributes.precision = -5;
  assert.deepEqual(s.snapshot().deliveries[0].items, [original]);
  assert.equal(s.arriveDelivery(d.deliveryId), true);
  assert.deepEqual(destination.item(id), original);
  assert.throws(() => s.arriveDelivery(d.deliveryId), /carrying cargo/);
  assert.equal(destination.quantity("weapon"), 1);
});
test("blocked mixed unloading retains all cargo and attributes until whole delivery fits", () => {
  const { s, source, items } = itemDeliveryWorld();
  const tiny = s.createInventory({
    id: "tiny-item-store",
    capacityPerMaterial: 1,
    initial: { ore: 1 },
  });
  const item = items[0];
  const d = s.reserveDelivery(source.id, tiny.id, { ore: 1 }, [item.id]);
  s.pickupDelivery(d.deliveryId);
  const pending = s.snapshot().deliveries[0];
  for (let i = 0; i < 3; i++)
    assert.equal(s.arriveDelivery(d.deliveryId), false);
  assert.equal(tiny.quantity("weapon"), 0);
  assert.equal(tiny.quantity("ore"), 1);
  assert.deepEqual(s.snapshot().deliveries[0].items, pending.items);
  s.withdraw(tiny.id, { ore: 1 });
  assert.equal(s.arriveDelivery(d.deliveryId), true);
  assert.equal(tiny.quantity("ore"), 1);
  assert.deepEqual(tiny.item(item.id), item);
});
test("cancel releases item reservation and return restores exact cargo after host return travel", () => {
  const { s, source, destination, items } = itemDeliveryWorld();
  const item = items[0];
  let d = s.reserveDelivery(source.id, destination.id, {}, [item.id]);
  s.cancelDelivery(d.deliveryId);
  assert.equal(source.reserved("weapon"), 0);
  assert.deepEqual(source.item(item.id), item);
  d = s.reserveDelivery(source.id, destination.id, {}, [item.id]);
  s.pickupDelivery(d.deliveryId);
  assert.equal(s.returnDelivery(d.deliveryId), true);
  assert.deepEqual(source.item(item.id), item);
  assert.equal(source.quantity("weapon"), 2);
  assert.equal(destination.quantity("weapon"), 0);
});
test("full source retains returned individual cargo without partial bulk deposit", () => {
  const { s, source, destination, items } = itemDeliveryWorld();
  const item = items[0];
  const d = s.reserveDelivery(source.id, destination.id, { ore: 1 }, [item.id]);
  s.pickupDelivery(d.deliveryId);
  s.deposit(source.id, { ore: 20 - source.quantity("ore") });
  assert.equal(s.returnDelivery(d.deliveryId), false);
  assert.equal(source.item(item.id), undefined);
  assert.deepEqual(s.snapshot().deliveries[0].items, [item]);
  s.withdraw(source.id, { ore: 1 });
  assert.equal(s.returnDelivery(d.deliveryId), true);
  assert.deepEqual(source.item(item.id), item);
});
test("external spawning cannot duplicate a transit identity", () => {
  const { s, source, destination, items } = itemDeliveryWorld();
  const item = items[0];
  const d = s.reserveDelivery(source.id, destination.id, { ore: 1 }, [item.id]);
  s.pickupDelivery(d.deliveryId);
  // An invalid external import has injected the same identity into the destination.
  assert.throws(() => s.spawnItem(destination.id, "weapon", item.attributes, item.id), /framework-owned/);
  assert.equal(destination.quantity("ore"), 0);
  assert.equal(s.snapshot().deliveries[0].state, "in-transit");
  assert.deepEqual(s.snapshot().deliveries[0].items, [item]);
});
test("timed weapon example preserves item through the same clock as production", async () => {
  const { TransportExample } = await import("../dist/transport-example.js");
  const a = new TransportExample(),
    b = new TransportExample();
  const item = a.simulation.inventory("warehouse").item("external-1");
  assert.ok(a.dispatchWeapon());
  assert.ok(b.dispatchWeapon());
  a.advance(2);
  assert.deepEqual(a.journeys().find((d) => d.itemIds.length).items, [item]);
  a.advance(1);
  for (let i = 0; i < 60; i++) b.advance(0.05);
  assert.deepEqual(a.simulation.snapshot(), b.simulation.snapshot());
  assert.deepEqual(a.simulation.inventory("outpost").item(item.id), item);
});
