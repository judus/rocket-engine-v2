import test from 'node:test';
import assert from 'node:assert/strict';
import {Simulation} from '../dist/index.js';
function world() {
 return new Simulation({seed:7,resources:[{id:'ore',label:'Ore',kind:'material'},{id:'weapon',label:'Weapon',kind:'material',storage:'individual'},{id:'credits',label:'Credits',kind:'currency'}],
 recipes:[{id:'make',label:'Make',durationSeconds:.1,inputs:{ore:2},outputs:{ore:1}},{id:'weapon',label:'Weapon',durationSeconds:.05,inputs:{},outputs:{weapon:1},itemAttributes:{weapon:{health:{min:80,max:100}}}}],
 facilities:[{id:'factory',label:'Factory',category:'test',recipes:['make'],constructionCost:{}},{id:'forge',label:'Forge',category:'test',recipes:['weapon'],constructionCost:{}},{id:'home',label:'Home',category:'test',recipes:[],constructionCost:{},workersProvided:{workers:10}}]});
}
const roundtrip=s=>Simulation.restore(JSON.parse(JSON.stringify(s.save())));
function refuse(s,id,code) {
 s.enableDiagnostics(100);
 assert.throws(()=>s.increaseCapacity('missing-trace-probe',0),/unknown inventory/);
 const before={save:s.save(),trace:s.diagnosticTrace(),snapshot:s.snapshot(),demands:s.materialDemands()};
 const result=s.removeInventory(id);assert.equal(result.ok,false);assert.ok(result.blockers.some(b=>b.code===code));
 assert.deepEqual({save:s.save(),trace:s.diagnosticTrace(),snapshot:s.snapshot(),demands:s.materialDemands()},before);
 assert.deepEqual(roundtrip(s).save(),s.save());return result.blockers;
}
test('empty inventory retirement is typed, reloadable and permits a fresh same-named inventory',()=>{
 const s=world();const old=s.createInventory({id:'empty',capacityPerMaterial:10});s.createInventory({id:'other',capacityPerMaterial:10});
 const counters=s.save();assert.deepEqual(s.inventoryRemovalBlockers('empty'),[]);
 assert.deepEqual(s.removeInventory('empty'),{ok:true,inventoryId:'empty',prunedDeliveryIds:[]});
 assert.throws(()=>s.inventory('empty'),/unknown inventory/);assert.equal(s.summary().inventoryCount,1);
 const copy=roundtrip(s);assert.deepEqual(copy.save(),s.save());assert.throws(()=>copy.deposit('empty',{ore:1}),/unknown inventory/);
 for(const name of ['nextItem','nextId','nextDelivery'])assert.equal(copy.save()[name],counters[name]);
 const fresh=s.createInventory({id:'empty',capacityPerMaterial:10});assert.notEqual(fresh,old);s.deposit('empty',{ore:1});assert.equal(old.quantity('ore'),0);assert.equal(fresh.quantity('ore'),1);
});
test('unknown inventory refusal changes no state or trace',()=>{const s=world();assert.deepEqual(refuse(s,'missing','unknown-inventory'),[{code:'unknown-inventory'}]);});
for(const resource of ['ore','credits','weapon'])test(`${resource} stock blocks retirement, including currency and individual goods`,()=>{
 const s=world();s.createInventory({id:'store',capacityPerMaterial:10});
 if(resource==='weapon')s.spawnItem('store',resource,{health:87});else s.deposit('store',{[resource]:1});
 assert.deepEqual(refuse(s,'store','goods'),[{code:'goods',resourceId:resource,quantity:1}]);
});
test('partial production allocations block retirement without releasing their reservations',()=>{
 const s=world();s.createInventory({id:'store',capacityPerMaterial:10,initial:{ore:1}});const f=s.addFacility('factory','store').facilityId;s.advanceTicks(1);
 const b=refuse(s,'store','reservation');assert.ok(b.some(b=>b.code==='reservation'&&b.token===`${f}.job-0`));assert.equal(s.inventory('store').reserved('ore'),1);
 b.find(b=>b.code==='facility-reference').roles.length=0;assert.equal(s.inventoryRemovalBlockers('store').find(b=>b.code==='facility-reference').roles.length,3);
});
test('unassigned workforce blocks retirement and removal of its provider clears it',()=>{
 const s=world();s.createInventory({id:'store',capacityPerMaterial:10});const f=s.addFacility('home','store').facilityId;
 const b=refuse(s,'store','workforce');assert.ok(b.some(b=>b.code==='workforce'&&b.total===10&&b.assigned===0));
 assert.ok(s.removeFacility(f).ok);assert.ok(s.removeInventory('store').ok);assert.deepEqual(roundtrip(s).save(),s.save());
});
for(const role of ['construction','input','output'])test(`live ${role} endpoint blocks retirement even when disabled and draining`,()=>{
 const s=world();for(const id of ['construction','input','output'])s.createInventory({id,capacityPerMaterial:10});
 const f=s.addFacility('factory','construction',{inputInventoryId:'input',outputInventoryId:'output'}).facilityId;
 s.setFacilityEnabled(f,false);s.setFacilityDraining(f,true);
 assert.deepEqual(refuse(s,role,'facility-reference'),[{code:'facility-reference',facilityId:f,roles:[role]}]);
});
for(const state of ['reserved','in-transit','arrival-blocked'])for(const endpoint of ['source','destination'])test(`${state} delivery blocks ${endpoint} retirement`,()=>{
 const s=world();s.createInventory({id:'source',capacityPerMaterial:10,initial:{ore:1}});s.createInventory({id:'destination',capacityPerMaterial:0});
 const d=s.reserveDelivery('source','destination',{ore:1});
 if(state!=='reserved')s.pickupDelivery(d.deliveryId);if(state==='arrival-blocked')assert.equal(s.arriveDelivery(d.deliveryId),false);
 const b=refuse(s,endpoint,'active-delivery');assert.ok(b.some(b=>b.code==='active-delivery'&&b.deliveryId===d.deliveryId&&b.state===state&&b.role===endpoint));
});
test('successful retirement prunes only referencing terminal history and preserves manufactured identities',()=>{
 const s=world();for(const id of ['source','destination','a','b'])s.createInventory({id,capacityPerMaterial:10});
 const f=s.addFacility('forge','source').facilityId;s.advanceTicks(1);s.setFacilityDraining(f,true);s.advanceTicks(1);assert.ok(s.removeFacility(f).ok);
 const items=s.inventory('source').itemPage({limit:10}).items;assert.equal(items.length,1);
 const d=s.reserveDelivery('source','destination',{},items.map(i=>i.id));s.pickupDelivery(d.deliveryId);s.arriveDelivery(d.deliveryId);
 s.deposit('a',{ore:1});const other=s.reserveDelivery('a','b',{ore:1});s.pickupDelivery(other.deliveryId);s.arriveDelivery(other.deliveryId);
 const before=s.save();assert.deepEqual(s.removeInventory('source'),{ok:true,inventoryId:'source',prunedDeliveryIds:[d.deliveryId]});
 assert.equal(s.summary().deliveryCount,1);assert.equal(s.deliverySnapshot(other.deliveryId).state,'delivered');assert.throws(()=>s.deliverySnapshot(d.deliveryId),/unknown delivery/);
 assert.deepEqual(s.inventory('destination').item(items[0].id),items[0]);assert.deepEqual(s.save().retiredFacilities,before.retiredFacilities);
 const copy=roundtrip(s);assert.deepEqual(copy.save(),s.save());assert.equal(copy.locateItem(items[0].id).inventoryId,'destination');copy.consumeItem('destination',items[0].id);
 assert.deepEqual(roundtrip(copy).locateItem(items[0].id),{kind:'retired'});assert.ok(copy.removeInventory('destination').ok);
 const fresh=copy.spawnItem('a','weapon',{});assert.equal(fresh,`external-${before.nextItem}`);
 copy.deposit('a',{ore:1});const next=copy.reserveDelivery('a','b',{ore:1});assert.equal(next.deliveryId,`delivery-${before.nextDelivery}`);
});
for(const returned of [false,true])test(`cancelled ${returned?'returned':'unpicked'} history is pruned at successful endpoint retirement`,()=>{
 const s=world();s.createInventory({id:'source',capacityPerMaterial:10,initial:{ore:1}});s.createInventory({id:'destination',capacityPerMaterial:10});
 const d=s.reserveDelivery('source','destination',{ore:1});if(returned){s.pickupDelivery(d.deliveryId);assert.ok(s.returnDelivery(d.deliveryId));}else s.cancelDelivery(d.deliveryId);
 assert.deepEqual(s.removeInventory('destination'),{ok:true,inventoryId:'destination',prunedDeliveryIds:[d.deliveryId]});
 assert.equal(s.inventory('source').quantity('ore'),1);assert.deepEqual(roundtrip(s).save(),s.save());
});
test('refusal never prunes terminal history and cannot run inside an observer',()=>{
 const s=world();s.createInventory({id:'store',capacityPerMaterial:10,initial:{ore:3}});s.createInventory({id:'other',capacityPerMaterial:10});
 const d=s.reserveDelivery('store','other',{ore:1});s.cancelDelivery(d.deliveryId);refuse(s,'store','goods');assert.equal(s.deliverySnapshot(d.deliveryId).state,'cancelled');
 s.addFacility('factory','store');let observed=0;s.onEvent(()=>{assert.throws(()=>s.removeInventory('other'),/observer/);observed++;});s.advanceTicks(4);assert.ok(observed>0);assert.ok(s.inventory('other'));
});

test('assigned workforce also blocks retirement without changing its allocation',()=>{
 const configuration=world().save().configuration;configuration.facilities.find(f=>f.id==='factory').workersRequired={workers:2};
 const s=new Simulation(configuration);s.createInventory({id:'store',capacityPerMaterial:10});s.addFacility('home','store');s.addFacility('factory','store');
 const blockers=refuse(s,'store','workforce');assert.ok(blockers.some(b=>b.code==='workforce'&&b.total===10&&b.assigned===2));
 assert.equal(s.inventory('store').summary().workforce.workers.assigned,2);
});
test('reserved equipment refuses cleanup without changing identity, attributes or shipment',()=>{
 const s=world();s.createInventory({id:'store',capacityPerMaterial:10});s.createInventory({id:'other',capacityPerMaterial:10});
 const id=s.spawnItem('store','weapon',{health:87});const d=s.reserveDelivery('store','other',{},[id]);
 const blockers=refuse(s,'store','reservation');assert.ok(blockers.some(b=>b.code==='reservation'&&b.token===`logistics:${d.deliveryId}`));
 assert.equal(s.inventory('store').item(id).attributes.health,87);assert.equal(s.deliverySnapshot(d.deliveryId).state,'reserved');
});
