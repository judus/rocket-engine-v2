import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { WebStandardStreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  McpError,
  ErrorCode,
  isInitializeRequest,
  SUPPORTED_PROTOCOL_VERSIONS,
} from '@modelcontextprotocol/sdk/types.js';
import { createHash, timingSafeEqual } from 'node:crypto';
import type { CharacterHandle, CharacterRuntime } from '../Runtime.js';
import { isJson } from '../json.js';
import type { Capability } from '../types.js';
import { record, text } from '../narrative/validation.js';
import { CfwMcpProvider } from './CfwMcpProvider.js';
import type { CfwMcpBinding, McpReceiptSave } from './CfwMcpProvider.js';
export type { EffectReceipt, McpReceiptSave } from './CfwMcpProvider.js';

interface Connection {
  readonly controller: AbortController;
  readonly binding: CfwMcpBinding;
  readonly transport: WebStandardStreamableHTTPServerTransport;
  // Low-level SDK API preserves the complete JSON Schemas without Zod projection.
  // eslint-disable-next-line @typescript-eslint/no-deprecated
  readonly server: Server;
  initialized: boolean;
  lastUsed: number;
}
export interface McpGatewayOptions {
  readonly runtime: CharacterRuntime;
  readonly credential: string;
  /** Exact HTTP authorities and Origin values. Missing Origin is allowed for server clients. */
  readonly allowedHosts: readonly string[];
  readonly allowedOrigins?: readonly string[];
  readonly path?: string;
  /** Trusted deployment body budget, default128KiB; at most1MiB. Capability budgets still apply. */
  readonly maxRequestBytes?: number;
  readonly maxConnections?: number;
  readonly idleTimeoutMs?: number;
}

/** One HTTP endpoint, immutable per-character connections, host-driven tool effects. */
export class McpGateway {
  readonly #options: McpGatewayOptions;
  readonly #credentialDigest: Buffer;
  readonly #connections = new Map<string, Connection>();
  readonly #provider: CfwMcpProvider;
  #closed = false;
  constructor(options: McpGatewayOptions) {
    if (
      !text(options.credential, 4096) ||
      !options.allowedHosts.length ||
      options.allowedHosts.some((host) => !text(host))
    )
      throw new TypeError('Credential and allowedHosts are required');
    if (
      options.maxRequestBytes !== undefined &&
      (!Number.isSafeInteger(options.maxRequestBytes) ||
        options.maxRequestBytes < 131072 ||
        options.maxRequestBytes > 1024 * 1024)
    )
      throw new TypeError('Invalid maxRequestBytes');
    if (
      options.maxConnections !== undefined &&
      (!Number.isSafeInteger(options.maxConnections) ||
        options.maxConnections < 1)
    )
      throw new TypeError('Invalid maxConnections');
    if (
      options.idleTimeoutMs !== undefined &&
      (!Number.isFinite(options.idleTimeoutMs) || options.idleTimeoutMs < 1)
    )
      throw new TypeError('Invalid idleTimeoutMs');
    this.#options = Object.freeze({
      ...options,
      allowedHosts: Object.freeze([...options.allowedHosts]),
      allowedOrigins: Object.freeze([...(options.allowedOrigins ?? [])]),
    });
    this.#credentialDigest = digestSecret(options.credential);
    this.#provider = new CfwMcpProvider({ runtime: options.runtime });
  }
  /** Trusted host provisioning, never exposed as a model tool or public route. */
  bind(
    key: string,
    handle: CharacterHandle,
    capabilities: readonly Capability[] = [],
  ): Readonly<Record<string, string>> {
    const headers = this.#provider.bind(key, handle, capabilities);
    for (const connection of this.#connections.values())
      if (connection.binding.metadata?.['X-CF-Binding-Key'] === key)
        this.#invalidate(connection.binding);
    return headers;
  }
  unbind(key: string): void {
    this.#provider.unbind(key);
    for (const connection of this.#connections.values())
      if (connection.binding.metadata?.['X-CF-Binding-Key'] === key)
        this.#invalidate(connection.binding);
  }
  advance(seconds: number): void {
    this.#provider.advance(seconds);
  }
  get stats() {
    return Object.freeze({
      connections: this.#connections.size,
      ...this.#provider.stats,
    });
  }
  async handle(request: Request): Promise<Response> {
    if (this.#closed) return failure(503, 'gateway_closed');
    const url = new URL(request.url);
    if (url.pathname !== (this.#options.path ?? '/mcp'))
      return failure(404, 'not_found');
    if (
      !this.#options.allowedHosts.includes(url.host) ||
      (request.headers.has('host') && request.headers.get('host') !== url.host)
    )
      return failure(403, 'host_denied');
    const origin = request.headers.get('origin');
    if (
      origin !== null &&
      !(this.#options.allowedOrigins ?? []).includes(origin)
    )
      return failure(403, 'origin_denied');
    const authorization = request.headers.get('authorization') ?? '';
    if (
      !timingSafeEqual(
        digestSecret(
          authorization.startsWith('Bearer ') ? authorization.slice(7) : '',
        ),
        this.#credentialDigest,
      )
    )
      return failure(401, 'unauthorized');
    const binding = this.#provider.resolveBinding(request);
    if (!binding) return failure(403, 'binding_denied');
    await this.#expire();
    let body: unknown;
    if (request.method === 'POST') {
      try {
        body = JSON.parse(
          await limitedBody(request, this.#options.maxRequestBytes ?? 131072),
        );
      } catch (error) {
        return failure(
          error instanceof RangeError ? 413 : 400,
          error instanceof RangeError ? 'body_too_large' : 'invalid_json',
        );
      }
      if (!isJson(body)) return failure(400, 'invalid_message');
    }
    const sessionId = request.headers.get('mcp-session-id');
    let connection: Connection | undefined;
    if (sessionId !== null) {
      connection = this.#connections.get(sessionId);
      if (!connection) return failure(404, 'session_unavailable');
      if (connection.binding !== binding)
        return failure(403, 'session_binding_denied');
      const protocol = request.headers.get('mcp-protocol-version');
      if (protocol !== null && !SUPPORTED_PROTOCOL_VERSIONS.includes(protocol))
        return failure(400, 'unsupported_protocol');
      if (
        !connection.initialized &&
        record(body) &&
        body['method'] !== 'notifications/initialized' &&
        body['method'] !== 'ping'
      )
        return failure(400, 'not_initialized');
    } else {
      if (request.method !== 'POST' || !isInitializeRequest(body))
        return failure(400, 'initialization_required');
      if (this.#connections.size >= (this.#options.maxConnections ?? 64))
        return failure(503, 'connection_limit');
      connection = await this.#connect(binding);
    }
    connection.lastUsed = Date.now();
    if (request.method === 'GET')
      return new Response(null, {
        status: 405,
        headers: { Allow: 'POST, DELETE' },
      });
    if (request.method === 'DELETE')
      return connection.transport.handleRequest(request);
    let cancelled: (() => void) | undefined;
    const invalidated = new Promise<Response>((resolve) => {
      cancelled = () => {
        resolve(failure(409, 'binding_invalidated'));
      };
      connection.controller.signal.addEventListener('abort', cancelled, {
        once: true,
      });
    });
    const response = await Promise.race([
      connection.transport.handleRequest(request, { parsedBody: body }),
      invalidated,
    ]).finally(() => {
      if (cancelled)
        connection.controller.signal.removeEventListener('abort', cancelled);
    });
    if (!connection.transport.sessionId) await connection.server.close();
    return response;
  }
  saveReceipts(): McpReceiptSave {
    return this.#provider.saveReceipts();
  }
  restoreReceipts(value: unknown): void {
    if (this.#connections.size)
      throw new Error('Restore before connecting clients');
    this.#provider.restoreReceipts(value);
  }
  async dispose(): Promise<void> {
    if (this.#closed) return;
    this.#closed = true;
    this.#provider.dispose();
    await Promise.all(
      [...this.#connections.values()].map((connection) =>
        connection.server.close(),
      ),
    );
    this.#connections.clear();
  }
  async #connect(binding: CfwMcpBinding): Promise<Connection> {
    // This is the SDK's advanced JSON Schema handler path, rather than Zod registration.
    // eslint-disable-next-line @typescript-eslint/no-deprecated
    const server = new Server(
      { name: 'character-framework', version: '0.1.0' },
      { capabilities: { tools: {} } },
    );
    const reservation = crypto.randomUUID();
    const transport = new WebStandardStreamableHTTPServerTransport({
      sessionIdGenerator: () => crypto.randomUUID(),
      enableJsonResponse: true,
      maxRequestBodySize: this.#options.maxRequestBytes ?? 131072,
      onsessioninitialized: (sessionId) => {
        this.#connections.delete(reservation);
        this.#connections.set(sessionId, connection);
      },
    });
    const connection: Connection = {
      binding,
      server,
      transport,
      controller: new AbortController(),
      initialized: false,
      lastUsed: Date.now(),
    };
    server.oninitialized = () => {
      connection.initialized = true;
    };
    server.onclose = () => {
      connection.controller.abort();
      this.#connections.delete(reservation);
      if (transport.sessionId) this.#connections.delete(transport.sessionId);
    };
    server.setRequestHandler(ListToolsRequestSchema, (request) => {
      if (!binding.isCurrent())
        throw new McpError(
          ErrorCode.InvalidRequest,
          'Character binding is no longer current.',
        );
      if (request.params?.cursor)
        throw new McpError(
          ErrorCode.InvalidParams,
          'This bounded catalogue has no pagination cursor.',
        );
      return {
        tools: this.#provider.tools(binding),
      };
    });
    server.setRequestHandler(CallToolRequestSchema, async (request, extra) => {
      if (!binding.isCurrent())
        throw new McpError(
          ErrorCode.InvalidRequest,
          'Character binding is no longer current.',
        );
      const headers = new Headers();
      for (const [key, value] of Object.entries(
        extra.requestInfo?.headers ?? {},
      ))
        if (typeof value === 'string') headers.set(key, value);
      return this.#provider.call(
        request.params.name,
        request.params.arguments ?? {},
        { binding, headers, signal: connection.controller.signal },
      );
    });
    // Reserve capacity before initialization awaits or concurrent connects can exceed the limit.
    this.#connections.set(reservation, connection);
    await server.connect(transport);
    return connection;
  }
  #invalidate(binding: CfwMcpBinding): void {
    for (const connection of this.#connections.values())
      if (connection.binding === binding) {
        connection.controller.abort();
        void connection.server.close().catch(() => undefined);
      }
  }
  async #expire(): Promise<void> {
    const now = Date.now();
    await Promise.all(
      [...this.#connections.values()]
        .filter(
          (connection) =>
            !connection.binding.isCurrent() ||
            now - connection.lastUsed >
              (this.#options.idleTimeoutMs ?? 1800000),
        )
        .map((connection) => connection.server.close()),
    );
  }
}
function digestSecret(value: string): Buffer {
  return createHash('sha256').update(value).digest();
}
function failure(status: number, code: string): Response {
  return Response.json({ error: code }, { status });
}
async function limitedBody(request: Request, limit: number): Promise<string> {
  const reader = request.body?.getReader();
  if (!reader) return '';
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    for (;;) {
      const chunk = await reader.read();
      if (chunk.done) break;
      size += chunk.value.byteLength;
      if (size > limit) {
        await reader.cancel();
        throw new RangeError('Body too large');
      }
      chunks.push(chunk.value);
    }
  } finally {
    reader.releaseLock();
  }
  return new TextDecoder('utf-8', { fatal: true }).decode(
    Buffer.concat(chunks),
  );
}
