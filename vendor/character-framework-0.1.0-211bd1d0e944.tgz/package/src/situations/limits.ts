/** Shared publication/checkpoint contract; model and per-tool budgets are separate. */
export const MAX_QUEST_STAGES = 128;
export const MAX_QUEST_DEFINITION_BYTES = 256 * 1024;
export const MAX_AUTHORING_RECEIPTS = 8192;
export const MAX_AUTHORING_STORE_BYTES = 64 * 1024 * 1024;
export const MAX_QUEST_EVIDENCE_CURSORS = 2048;
