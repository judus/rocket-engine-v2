# Quest-agent tutorial: rebuild the watchtower quest with tools

This is an exact, successfully executed MCP call sequence for `cfw-authoring-prototype-1`. It reconstructs Rocket's corrected twelve-situation blue/red watchtower graph in a new SQLite draft, saves an incomplete checkpoint, reviews/repairs it, publishes it, and reads the publication back **through tools**. No backend model or gameplay action was invoked.

Comparison baseline: `32aabc76aaf1c3f0a8cc57bb6a9287ac3f55eb46334c78a3ba6086be8d0c9f9d`. The resulting `proposalVersion`, `start` and entire `situations` array match the baseline exactly. The publication's `id` is freshly assigned by CFW.

## How an agent should use this tutorial

The concrete `draftId` below came from this recorded run. **For a new run, substitute the ID returned by your own create call and revisions returned by your own edits.** Never invent IDs, assume another author's draft is accessible or submit these example IDs literally. The connector may expose aliases for MCP names; use the actual discovered callable name while retaining the same parameter schema.

The prose and graph illustrate a known fixed game. Ground any new quest in the host's actual description, world-summary result and permitted catalogue. On the combined Rocket endpoint, the game-owned context read is `game_world_summary({})`; CAI normally performs it before generation, alongside the catalogue read. It returns normal completed structured data containing description, player, locations, entities and interactionRules. That separate preflight is not one of the eleven calls in this recorded rebuild. If the context is not supplied, discover and call the available world read; do not invent executable references or mechanics.

Do not call game consequences during authoring. The graph declares what gameplay will execute later. Reference existence and schema validity do not prove narrative quality, causal attainability or every branch's completion.

## Required meaning of this example

- Courtyard entry and sentry defeats must be new events after their declared boundaries.
- The encounter activates existing sentries; its completion reveals the Watchkeeper and opens the gate.
- Dialogue choices require current proximity to the revealed Watchkeeper. Choices select the branch; scene code does not.
- A collected seal can skip pickup. Otherwise pickup must occur after its pickup stage reveals the seal.
- **A prior matching delivery counts.** Blue means blue-seal delivered to beacon-a; Red means red-seal delivered to beacon-b. Arrival or the other seal is insufficient.
- Only the selected matching beacon lights. Terminal closure waits for the consequence commit.

This prior-delivery policy avoids the original ordering softlock. It must not be substituted for a brief that requires a genuinely new delivery after acceptance.

## Exact executed calls

Parameters below are complete JSON objects, including the entire implementation in step6. Results are summarized to avoid repeating the graph and catalogue.

### 1. `read_quest_draft`

Discover the permitted capability schemas, evidence streams and references. This read needs no draft ID. Catalogue declarations are not direct game execution grants.

```json
{
  "section": "catalogue"
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "capabilityNames": [
    "game_location",
    "game_encounter",
    "game_entity",
    "game_activate_group",
    "game_reveal",
    "game_open_gate",
    "game_light_beacon",
    "game_delivery"
  ]
}
```

### 2. `create_quest_draft`

Create a fresh persistent draft. Save the returned draftId and recordRevision=1. The prototype supplies the single beat main.

```json
{
  "intent": {
    "title": "Rebuilt watchtower recovery",
    "premise": "Choose a seal and complete its matching delivery."
  }
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 1,
  "contentRevision": 1,
  "published": false,
  "commandId": "3bc4e5d54542b0d3a8124d1570e688be0a22916e9f961ba2b6f7e7b8624612c7"
}
```

### 3. `edit_quest_draft`

Save the initial three stages. This deliberately leaves the offer destination absent. The edit succeeds as a saved incomplete fragment and returns recordRevision=2.

```json
{
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "expectedRecordRevision": 1,
  "operations": [
    {
      "kind": "replace_beat_implementation",
      "beatId": "main",
      "implementation": {
        "entrySituation": "approach",
        "situations": [
          {
            "id": "approach",
            "dialogue": {
              "text": "Enter the courtyard to investigate the ruined watchtower."
            },
            "routes": [
              {
                "id": "new-arrival",
                "priority": 10,
                "when": {
                  "tool": "game_location",
                  "arguments": {
                    "locationRef": "courtyard"
                  },
                  "expect": {
                    "path": ["count"],
                    "operator": "at_least",
                    "value": 1
                  },
                  "evidence": {
                    "mode": "events",
                    "after": {
                      "kind": "run-start"
                    }
                  }
                },
                "next": "encounter"
              }
            ]
          },
          {
            "id": "encounter",
            "dialogue": {
              "text": "The sentries awaken. Move close to each and press E or click to defeat it."
            },
            "routes": [
              {
                "id": "three-new-defeats",
                "priority": 10,
                "when": {
                  "tool": "game_encounter",
                  "arguments": {
                    "groupRef": "sentries"
                  },
                  "expect": {
                    "path": ["count"],
                    "operator": "at_least",
                    "value": 3
                  },
                  "evidence": {
                    "mode": "events",
                    "after": {
                      "kind": "situation-entry",
                      "situationRef": "encounter"
                    }
                  }
                },
                "next": "watchkeeper"
              }
            ],
            "onEnter": [
              {
                "id": "wake-sentries",
                "tool": "game_activate_group",
                "arguments": {
                  "groupRef": "sentries"
                }
              }
            ]
          },
          {
            "id": "watchkeeper",
            "dialogue": {
              "text": "The watchkeeper appears. Approach to learn the route to the beacon."
            },
            "routes": [
              {
                "id": "approach-guide",
                "priority": 10,
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "guide"
                  },
                  "expect": {
                    "path": ["near"],
                    "operator": "equals",
                    "value": true
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "offer"
              }
            ],
            "onEnter": [
              {
                "id": "show-guide",
                "tool": "game_reveal",
                "arguments": {
                  "entityRef": "guide"
                }
              },
              {
                "id": "open-ridge-gate",
                "tool": "game_open_gate",
                "arguments": {
                  "entityRef": "gate"
                }
              }
            ]
          }
        ],
        "outcomeBindings": []
      }
    }
  ]
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 2,
  "contentRevision": 2,
  "published": false,
  "commandId": "49b4f28b048f9b265d2f2d4b594654a319f1973f8ccb94f64fa1b08b0a008157",
  "assessment": {
    "technicalReady": false,
    "planCoverage": "complete",
    "narrativeReview": {
      "status": "not_reviewed"
    },
    "findings": [
      {
        "code": "draft_issue",
        "path": "/implementation",
        "message": "Unknown destination offer"
      }
    ]
  }
}
```

### 4. `review_quest_draft`

Review the saved fragment. technicalReady=false is expected: missing destinations prevent publication. A saved draft is not a published quest.

```json
{
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 2
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 2,
  "contentRevision": 2,
  "published": false,
  "technicalReady": false,
  "findings": [
    {
      "code": "draft_issue",
      "path": "/implementation",
      "message": "Unknown destination offer"
    }
  ]
}
```

### 5. `publish_quest_draft`

Deliberate negative control: this publication must be rejected with draft_not_ready. In normal generation, review findings should be repaired before attempting publication. This rejection does not increment the draft revision.

```json
{
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "expectedRecordRevision": 2
}
```

Expected result from the recorded run:

```json
{
  "status": "rejected",
  "code": "draft_not_ready",
  "message": "[{\"code\":\"draft_issue\",\"path\":\"/implementation\",\"message\":\"Unknown destination offer\"}]"
}
```

### 6. `edit_quest_draft`

Complete both branches using the same main beat. This is the full executable twelve-situation implementation. Return recordRevision=3. No new tool, attached beat or arc operation is involved.

```json
{
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "expectedRecordRevision": 2,
  "operations": [
    {
      "kind": "replace_beat_implementation",
      "beatId": "main",
      "implementation": {
        "entrySituation": "approach",
        "situations": [
          {
            "id": "approach",
            "dialogue": {
              "text": "Enter the courtyard to investigate the ruined watchtower."
            },
            "routes": [
              {
                "id": "new-arrival",
                "priority": 10,
                "when": {
                  "tool": "game_location",
                  "arguments": {
                    "locationRef": "courtyard"
                  },
                  "expect": {
                    "path": ["count"],
                    "operator": "at_least",
                    "value": 1
                  },
                  "evidence": {
                    "mode": "events",
                    "after": {
                      "kind": "run-start"
                    }
                  }
                },
                "next": "encounter"
              }
            ]
          },
          {
            "id": "encounter",
            "dialogue": {
              "text": "The sentries awaken. Move close to each and press E or click to defeat it."
            },
            "routes": [
              {
                "id": "three-new-defeats",
                "priority": 10,
                "when": {
                  "tool": "game_encounter",
                  "arguments": {
                    "groupRef": "sentries"
                  },
                  "expect": {
                    "path": ["count"],
                    "operator": "at_least",
                    "value": 3
                  },
                  "evidence": {
                    "mode": "events",
                    "after": {
                      "kind": "situation-entry",
                      "situationRef": "encounter"
                    }
                  }
                },
                "next": "watchkeeper"
              }
            ],
            "onEnter": [
              {
                "id": "wake-sentries",
                "tool": "game_activate_group",
                "arguments": {
                  "groupRef": "sentries"
                }
              }
            ]
          },
          {
            "id": "watchkeeper",
            "dialogue": {
              "text": "The watchkeeper appears. Approach to learn the route to the beacon."
            },
            "routes": [
              {
                "id": "approach-guide",
                "priority": 10,
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "guide"
                  },
                  "expect": {
                    "path": ["near"],
                    "operator": "equals",
                    "value": true
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "offer"
              }
            ],
            "onEnter": [
              {
                "id": "show-guide",
                "tool": "game_reveal",
                "arguments": {
                  "entityRef": "guide"
                }
              },
              {
                "id": "open-ridge-gate",
                "tool": "game_open_gate",
                "arguments": {
                  "entityRef": "gate"
                }
              }
            ]
          },
          {
            "id": "offer",
            "dialogue": {
              "text": "Watchkeeper: The tower has two paths. Do you want the blue seal or the red seal? Blue belongs at Beacon Ridge A; red belongs at Beacon Ridge B.",
              "requires": {
                "tool": "game_entity",
                "arguments": {
                  "entityRef": "guide"
                },
                "expect": {
                  "path": ["near"],
                  "operator": "equals",
                  "value": true
                },
                "evidence": {
                  "mode": "fact"
                }
              }
            },
            "choices": [
              {
                "id": "blue",
                "label": "Blue seal — Beacon Ridge A",
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "guide"
                  },
                  "expect": {
                    "path": ["near"],
                    "operator": "equals",
                    "value": true
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "blue-router"
              },
              {
                "id": "red",
                "label": "Red seal — Beacon Ridge B",
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "guide"
                  },
                  "expect": {
                    "path": ["near"],
                    "operator": "equals",
                    "value": true
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "red-router"
              }
            ]
          },
          {
            "id": "blue-router",
            "routes": [
              {
                "id": "prior-carried-seal",
                "priority": 10,
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "blue-seal"
                  },
                  "expect": {
                    "path": ["collected"],
                    "operator": "equals",
                    "value": true
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "blue-delivery"
              },
              {
                "id": "recover-seal",
                "priority": 20,
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "blue-seal"
                  },
                  "expect": {
                    "path": ["collected"],
                    "operator": "equals",
                    "value": false
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "blue-pickup"
              }
            ]
          },
          {
            "id": "blue-pickup",
            "dialogue": {
              "text": "Watchkeeper: You chose blue. Recover the blue seal, then carry it to Beacon Ridge A."
            },
            "onEnter": [
              {
                "id": "show-selected-seal",
                "tool": "game_reveal",
                "arguments": {
                  "entityRef": "blue-seal"
                }
              }
            ],
            "routes": [
              {
                "id": "new-pickup",
                "priority": 10,
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "blue-seal"
                  },
                  "expect": {
                    "path": ["count"],
                    "operator": "at_least",
                    "value": 1
                  },
                  "evidence": {
                    "mode": "events",
                    "after": {
                      "kind": "situation-entry",
                      "situationRef": "blue-pickup"
                    }
                  }
                },
                "next": "blue-delivery"
              }
            ]
          },
          {
            "id": "blue-delivery",
            "dialogue": {
              "text": "Watchkeeper: Deliver the blue seal to Beacon Ridge A. Stand by Beacon A and press E or click it. The other beacon cannot accept this seal."
            },
            "routes": [
              {
                "id": "matching-delivery",
                "priority": 10,
                "when": {
                  "tool": "game_delivery",
                  "arguments": {
                    "itemRef": "blue-seal",
                    "destinationRef": "beacon-a"
                  },
                  "expect": {
                    "path": ["delivered"],
                    "operator": "equals",
                    "value": true
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "blue-complete"
              }
            ]
          },
          {
            "id": "blue-complete",
            "dialogue": {
              "text": "The blue seal reached Beacon Ridge A. Beacon A is lit. Your chosen mission is complete."
            },
            "onEnter": [
              {
                "id": "light-matching-beacon",
                "tool": "game_light_beacon",
                "arguments": {
                  "entityRef": "beacon-a"
                }
              }
            ]
          },
          {
            "id": "red-router",
            "routes": [
              {
                "id": "prior-carried-seal",
                "priority": 10,
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "red-seal"
                  },
                  "expect": {
                    "path": ["collected"],
                    "operator": "equals",
                    "value": true
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "red-delivery"
              },
              {
                "id": "recover-seal",
                "priority": 20,
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "red-seal"
                  },
                  "expect": {
                    "path": ["collected"],
                    "operator": "equals",
                    "value": false
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "red-pickup"
              }
            ]
          },
          {
            "id": "red-pickup",
            "dialogue": {
              "text": "Watchkeeper: You chose red. Recover the red seal, then carry it to Beacon Ridge B."
            },
            "onEnter": [
              {
                "id": "show-selected-seal",
                "tool": "game_reveal",
                "arguments": {
                  "entityRef": "red-seal"
                }
              }
            ],
            "routes": [
              {
                "id": "new-pickup",
                "priority": 10,
                "when": {
                  "tool": "game_entity",
                  "arguments": {
                    "entityRef": "red-seal"
                  },
                  "expect": {
                    "path": ["count"],
                    "operator": "at_least",
                    "value": 1
                  },
                  "evidence": {
                    "mode": "events",
                    "after": {
                      "kind": "situation-entry",
                      "situationRef": "red-pickup"
                    }
                  }
                },
                "next": "red-delivery"
              }
            ]
          },
          {
            "id": "red-delivery",
            "dialogue": {
              "text": "Watchkeeper: Deliver the red seal to Beacon Ridge B. Stand by Beacon B and press E or click it. The other beacon cannot accept this seal."
            },
            "routes": [
              {
                "id": "matching-delivery",
                "priority": 10,
                "when": {
                  "tool": "game_delivery",
                  "arguments": {
                    "itemRef": "red-seal",
                    "destinationRef": "beacon-b"
                  },
                  "expect": {
                    "path": ["delivered"],
                    "operator": "equals",
                    "value": true
                  },
                  "evidence": {
                    "mode": "fact"
                  }
                },
                "next": "red-complete"
              }
            ]
          },
          {
            "id": "red-complete",
            "dialogue": {
              "text": "The red seal reached Beacon Ridge B. Beacon B is lit. Your chosen mission is complete."
            },
            "onEnter": [
              {
                "id": "light-matching-beacon",
                "tool": "game_light_beacon",
                "arguments": {
                  "entityRef": "beacon-b"
                }
              }
            ]
          }
        ],
        "outcomeBindings": []
      }
    }
  ]
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 3,
  "contentRevision": 3,
  "published": false,
  "commandId": "1961f4d70f6149e69a4e1b77dcc80c3769f9660cd9ea4754ee375b1227f36bb5",
  "assessment": {
    "technicalReady": true,
    "planCoverage": "complete",
    "narrativeReview": {
      "status": "not_reviewed"
    },
    "findings": []
  }
}
```

### 7. `review_quest_draft`

Review the completed saved implementation. Expect technicalReady=true and no findings. Independently check brief compliance and attainability; technical readiness alone does not prove them.

```json
{
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 3
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 3,
  "contentRevision": 3,
  "published": false,
  "technicalReady": true,
  "findings": []
}
```

### 8. `read_quest_draft`

Read the exact saved graph at revision3 before publication. The verified run compared its implementation with the complete authored graph, not the model report.

```json
{
  "section": "beat",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 3
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 3,
  "contentRevision": 3,
  "published": false,
  "implementationVerified": "Deep-equal to complete implementation in step6"
}
```

### 9. `publish_quest_draft`

Publish using the current record revision3. Preserve the returned definitionId, definitionDigest, sourceRevision=3 and commandId; publication advances recordRevision to4 and makes this draft immutable. It does not start gameplay.

```json
{
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "expectedRecordRevision": 3
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 4,
  "contentRevision": 3,
  "published": true,
  "definitionId": "definition-509901dd-4e09-4b82-b4dd-8608c44a5870",
  "definitionDigest": "d02d3b4964e4c8619f24e162c7fb866a5c189c5ad25c2615935747ffc897a7e4",
  "sourceRevision": 3,
  "commandId": "7bb4e25284bc204a0331a84b1f2bd4d820195a4f3fb01c8c7328a1b1d12ee613"
}
```

### 10. `publish_quest_draft`

Optional transport-retry proof: resend the identical publication arguments with the ORIGINAL connector effect identity. This run returned exactly the same result as step9, including definition ID, digest, command ID and revision4. Do not use a fresh mutation identity or change expectedRecordRevision to4 for an exact retry. The agent should not intentionally repeat publication as a new action.

```json
{
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "expectedRecordRevision": 3
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 4,
  "contentRevision": 3,
  "published": true,
  "definitionId": "definition-509901dd-4e09-4b82-b4dd-8608c44a5870",
  "definitionDigest": "d02d3b4964e4c8619f24e162c7fb866a5c189c5ad25c2615935747ffc897a7e4",
  "sourceRevision": 3,
  "commandId": "7bb4e25284bc204a0331a84b1f2bd4d820195a4f3fb01c8c7328a1b1d12ee613"
}
```

### 11. `read_quest_draft`

Retrieve the authoritative stored definition through the read tool. data.publication.definition is the actual publication. The verified run checked its identity and canonical digest against step9 and compared the full graph with the current Rocket baseline.

```json
{
  "section": "publications",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209"
}
```

Expected result from the recorded run:

```json
{
  "status": "completed",
  "draftId": "draft-465e9157-ab1f-4f71-9929-33ab979ac209",
  "recordRevision": 4,
  "contentRevision": 3,
  "published": true,
  "publicationVerified": "Stored definition ID/digest matches step9; graph equals Rocket baseline"
}
```

## Connector identity and retries

Tool arguments contain no bearer credentials, binding headers, call IDs, turn IDs or effect keys. The host/connector supplies them. In this run the connector used `rebuild-turn`, distinct logical call IDs `rebuild-call-1` through `rebuild-call-11`, and these mutation effect keys:

| Step                    | Effect key          |
| ----------------------- | ------------------- |
| 2                       | create              |
| 3                       | initial-stages      |
| 5                       | blocked-publication |
| 6                       | complete-branches   |
| 9 and its exact retry10 | publish             |

These are explanatory test identities, **not parameters the agent should add to a tool call**. The connector provisions its own trusted identities. A new logical delivery may have a different call ID while exact effect replay retains the original effect key and arguments. On uncertain outcomes, retain the original command and reconcile its outcome; do not create a replacement mutation to guess success.

## Publication is the handoff, not gameplay

The host selects the exact stored definition using the publication receipt and verified digest, then separately imports/starts it in a reset consumer. Each offered branch must complete through ordinary game interactions with AI disconnected. Keep the original publication, every invalid draft/correction and the resulting gameplay traces. Do not add candidate-specific scene logic or handlers to rescue a failed quest.

The current prototype offers one `main` beat with up to128 situations, a256KiB implementation fragment and empty `outcomeBindings`. Supported edits are `set_intent`, `replace_beat_implementation` and `record_narrative_review`. It has no attach-beat, arc or Mermaid tool. Use the live discovered schemas for the binding you actually have.

## Reproduce and inspect this run

Runnable script: [authoring-watchtower-rebuild.js](../examples/authoring-watchtower-rebuild.js). From the Character Framework root:

```sh
npm run build
node examples/authoring-watchtower-rebuild.js /home/maduser/workspace/rocket-engine-v2/examples/character-encounter/quest.json
```

The baseline argument is optional; without it the script compares against the checked-in fixed example. Each run creates a fresh temporary SQLite namespace and retains `tool-calls.json` and `published-definition.json`. It uses the actual MCP SDK client/gateway; no provider calls or Rocket writes.

This tutorial was generated from `/tmp/cfw-watchtower-rebuild-dMujzb/tool-calls.json`, with publication `definition-509901dd-4e09-4b82-b4dd-8608c44a5870`. The successful run verified incomplete-publication rejection, full graph equality, exact publication replay and the returned canonical digest. This proves the tools can reconstruct this graph; it does not prove an LLM will independently design it.
