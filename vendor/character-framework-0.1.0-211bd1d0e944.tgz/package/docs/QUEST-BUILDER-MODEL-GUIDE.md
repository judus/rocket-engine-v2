# Quest builder guide

Author a coherent quest through tools. CFW constructs runtime JSON. You receive permitted game/world context and a capability catalogue before authoring. Use only those actual functions, arguments and references; do not invent executable game mechanics. Premise/motivation/dialogue are your creative responsibility.

## Workflow

1. Plan the premise, motives, meaningful choices and payoffs. Create intent with `create_quest_draft({title,premise})`; no stage is created implicitly. Revise the overall idea with `update_quest_intent` when needed.
2. Add stages with purposes and optional dialogue; keep returned IDs. Create typed fact/event conditions separately. Add routes, choices, ordered entry consequences and optional progress objectives. Explicitly set the start stage and declare intended endings.
3. Inspect at meaningful branch checkpoints. `inspect_quest_draft({draftId})` returns exact saved logic, semantic Mermaid, condition users, unresolved findings and revision for small drafts. Large drafts return summary/counts: read the advertised stages/conditions/records sections with offset/limit and expectedRevision; concatenate Mermaid text pages before reviewing the whole graph. Compare whole-story purpose/dialogue against every path, rather than count boxes alone.
4. Repair the saved records. Review structure. Publish the exact ready revision; publication freezes the draft. It is not gameplay activation or evidence that effects occurred.

## Responses and revisions

Native success is `{"status":"completed","data":{...}}`. Mutations put draft ID, current revision, created/changed IDs, progress/findings and trusted commandId inside `data`. Inspection puts its authoring view directly in `data`. Follow returned revisions, never assume two dependent edits can use the same expected revision.

Every edit, review, publication and result-reference lookup takes `draft:{id,revision}`. Inspection takes `draftId`. On a revision conflict inspect again. On other errors use code/message and available argument paths/referencing IDs/current revision to correct a NEW edit. Connector-owned effect identity is not a model parameter: exact retries retain original identity/arguments. Use list/recovery tools after interruption, rather than blindly duplicate effects.

```json
{
  "draft": { "id": "returned-draft-id", "revision": 2 },
  "title": "Ask the watchkeeper",
  "purpose": "Learn why the two routes conflict",
  "dialogue": "What happened here?"
}
```

This is `add_stage` input. Its response returns `data.created.stageId`, then the latest `data.revision` for your next edit.

## Conditions and routing

- `create_fact_condition`: something true now. Arguments are checked against the selected inspection capability. `comparison:{path:["field"],operator:"equals",value:true}` or `at_least` for numeric outputs. Nested paths are allowed when declared. Legacy `field:"field"` is accepted instead of `path`; don't supply both.
- `create_event_condition`: same predicate arguments plus `since:"quest_start"` or `since:{stageId}`. A named stage can be the current or an earlier boundary. Every path to the consumer must include that stage; review/publication will reject bypasses. Missing evidence blocks execution; it is not a false observation.
- `add_transition`: `{draft,from,to,conditionId,priority}` connects existing stages automatically. Priorities are explicit, unique and ascending within a stage. Add destinations before connecting; partial work remains saveable.
- `add_choice`: `{draft,from,to,label,conditionId?}` records a player decision. A stage's interaction requirement also gates its dialogue and ALL choices. An individual choice condition is additional; both must pass.
- `set_interaction_requirement`: `{draft,stageId,conditionId}` (or null to remove). It can be a fact or event condition. A dialogue-bearing stage is required.

Facts and new events differ. “Item collected” may remain true after delivery; do not translate it into “still carried.” Counting a new pickup after stage entry cannot be satisfied by a pickup from before that boundary. Choose temporal meaning explicitly from the brief/game contracts.

## Ordinary actions before dialogue

Players can perform supported ordinary interactions before a choice, or before reaching its stage. For every irreversible choice outcome (consumption, transfer, delivery, opening), inspect the game's actual resulting state. Add an automatic outcome transition with `create_fact_condition` and `add_transition` wherever the player can reach that outcome while this stage is waiting. Keep that route independent of the dialogue/choice possession guard. Give observed outcomes precedence over ordinary onward routes when both can match.

For example, if the stone can be given to the mage or dropped in the well, the decision stage needs two observed-outcome routes: actual mage custody → a mage acknowledgement stage, and actual placement in the well → a well acknowledgement stage. Those acknowledgement stages must have no action that transfers/consumes the stone again. The two choices may lead to separate action stages that perform the still-pending operation. Do not route an already-completed outcome into those action stages. Use only predicates and fields actually declared by the game's catalogue; absence of player custody alone does not identify which outcome happened.

Use current facts when an earlier ordinary action should count. An event condition since the decision stage's entry misses an outcome from before entry; an earlier boundary is suitable only when the brief requires that temporal distinction and every path includes it. Check earlier waiting stages too: an early consumed item can invalidate a later pickup or possession gate. If the game exposes no authoritative outcome predicate, report that contract gap instead of inferring success from dialogue or silently disabling ordinary gameplay.

Before publication, walk both alternatives with ordinary action before arrival, ordinary action while the choice is displayed, and choice first. Check repeat interactions, inventory guards becoming false, and routes entering action stages. CFW review/`technicalReady` validates declared structure and capability contracts; it does not simulate all legal player orders or prove playability. Effect identity prevents replay of the same command, not a new command repeating an ordinary action.

A selected quest branch is not an exclusive world outcome. If the game permits refilling a bucket, the player may water the garden, refill, and deliver water to another recipient. Do not invent “only one bucketful” or claim the unselected recipient still waits merely because one ending was selected. Ground resource limits and endings in authoritative game state. If both outcomes are legal, acknowledge both or keep ending prose conditional on observed facts. Enforcing a one-use resource, target restriction or quest-controlled interaction requires an actual game-owned capability/availability contract; dialogue, a choice, an objective or structural review cannot create that restriction.

## Consequences, results and objectives

`add_entry_consequence({draft,stageId,capability,arguments})` appends a granted action in stage-entry order. This authors a consequence; it does not execute it now. Entry actions complete before later dialogue/routes/choices are evaluated.

`from_action_result({draft,recordId,path})` is a read. It returns `data.argument`, an authoring reference to a producing consequence output, without changing revision. Put that returned argument value into a later action or inspection argument. CFW builds the runtime reference internally. The producer/path must exist; final validation requires compatible declared types, earlier same-stage order or a producer on every path, and availability before any event capture that depends on it. Do not supply raw runtime result JSON, expressions or guessed returned values.

`add_objective({draft,stageId,description,conditionId})` adds progress text/condition and returns a record ID. Objectives display progress; they do not implicitly gate routes or keep an ending open. Add an explicit transition if completion must wait.

## Local repair and ending intent

`edit_record({draft,recordId,change})` removes or replaces a transition, choice, consequence or objective. `change:{operation:"remove"}` removes it. Replacement is `{operation:"replace",kind,value}` using that record type's complete fields from discovery. The record keeps its ID/order; the old behavior is replaced.

`update_condition` requires `affectedRecordIds` from inspection so shared edits are intentional. Changing a common interaction requirement affects every choice, even individually guarded ones. To change one branch only, create another condition and rebind that record. `remove_condition` rejects if still referenced. `remove_stage` rejects referenced stages rather than silently cascading.

`declare_ending({draft,stageId,ending:true})` records an intentional terminal; no outgoing connections can remain. Incomplete nonterminals are saveable but block publication. A declared ending is author intent, not proof its actions succeeded. `review_quest_draft({draft})` returns readiness/findings. `publish_quest_draft({draft})` returns immutable definition ID/digest/source revision and freezes further edits; use a new draft for another version.

## Discovery and recovery

`read_quest_draft({section:"catalogue"})` provides permitted capability/reference contracts only. Raw graph sections are unavailable. Discover the granted game provider's context tools: for example, `game_author_briefing` and its entity, inventory, navigation and journal/status readers when available. Use their actual schemas and descriptions; there is no mandatory game-context tool name across providers. If context required by the assignment is unavailable, report the gap rather than assume an empty world.

`list_quest_drafts({})` returns `data.items` and recent command IDs. `get_authoring_command_outcome({commandId})` returns a retained original receipt/result without dispatch. Job completion prose is not authoritative publication evidence: use actual publication markers and a separate consumer assessment. Model/step/call/token limits are host policy; if interrupted, retain the draft/plan and report unfinished work rather than claim completion.

## Capacity

CFW accepts up to128 stages and256KiB per executable definition. These are ceilings, not story targets. They do not permit graph cycles. Individual builder responses stay bounded: follow inspection nextOffset and use expectedRevision to avoid mixing pages from different revisions. Stage/condition/record pages contain items; Mermaid/text pages contain exact text chunks. Authoring workspace storage/receipt capacity is separate from the host generation-step/call budget.
