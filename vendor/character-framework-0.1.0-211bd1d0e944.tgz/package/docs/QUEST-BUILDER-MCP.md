# Registered quest builder domain

`QuestBuilderAuthoring` is exported from `character-framework/authoring-prototype`. It exposes **24 native MCP-compatible capabilities**: the22 documented builder tools, restricted catalogue discovery and durable command-outcome recovery. The same existing `CfwMcpProvider` registers them in the engine-owned host. No separate CFW HTTP server, PHP compiler or browser editor is required.

```js
import { CharacterRuntime } from 'character-framework';
import { CfwMcpProvider } from 'character-framework/mcp';
import { QuestBuilderAuthoring } from 'character-framework/authoring-prototype';

const author = new QuestBuilderAuthoring({
  path: '/application-owned/quest-authoring.sqlite',
  authorId: trustedAuthorNamespace,
  authorize: (context) => authorSessionIsAuthorized(context),
  capabilities: game.capabilities,
  references: permittedWorldReferences,
  referenceBindings: gameReferenceBindings,
});
const runtime = new CharacterRuntime({ gameId, capabilities: author.tools });
const actor = runtime.register({
  id: authorCharacterId,
  name: 'Quest author',
  binding: { id: stableBindingId, generation: hostGeneration },
  cai: { characterId: authorCharacterId, sessionId: caiSessionId },
  capabilities: author.tools.map((tool) => tool.name),
});
const provider = new CfwMcpProvider({ runtime });
const headers = provider.bind(bindingKey, actor, author.tools, [
  'cfw',
  worldProvider.id,
]);
// Existing Rocket host: configure credentials/access/lifecycle as usual;
// resolver returns provider.resolveBinding(request)'s exact object.
host.register(provider);
host.register(worldProvider);
```

Application identifiers/paths above are placeholders chosen by the trusted host. Use the actual returned binding headers, including generation; do not guess or clone the authority-bearing binding object. Advance the runtime/provider through the existing host lane, and dispose host sessions/provider/runtime before `await author.close()`. Host transport/security ownership remains unchanged.

The combined discovery contains25 tools when Rocket's `game_world_summary` is included. Tool descriptions, closed input schemas and read/write annotations are generated from this domain, not copied into CAI by hand. See [native discovery snapshot](contracts/quest-builder-mcp-tools.json), [builder parameters and local walkthrough](QUEST-BUILDER-TOOLS-WALKTHROUGH.md), and the compact [model guide](QUEST-BUILDER-MODEL-GUIDE.md).

## Result and recovery contract

The registered capabilities use CFW's ordinary structured result envelope. Successful edits return:

```json
{
  "status": "completed",
  "data": {
    "draftId": "returned-id",
    "revision": 2,
    "created": { "stageId": "s1" },
    "change": "add_stage",
    "changedId": "s1",
    "savedMeaning": null,
    "progress": { "stages": 1, "conditions": 0, "records": 0 },
    "findings": [],
    "commandId": "trusted-original-command"
  }
}
```

`inspect_quest_draft` puts its exact authoring view directly in `data`; there is no second `data` nesting. Read results do not invent command identities. Rejections retain `status:"rejected"`, code/message and available revision/reference/findings details; MCP sets `isError:true`. Schema admission may reject before dispatch. The local walkthrough's direct-call responses remain evidence for the authoring engine; the registered envelope is described here and retained in the MCP proof transcript.

Review readiness is structural validation, not a gameplay simulator. In particular, it cannot establish that every legal ordinary interaction order leaves a route available. Authors must observe already-applied irreversible outcomes through explicit fact/event transitions and avoid reapplying them in destination entry actions. See [ordinary actions before dialogue](QUEST-BUILDER-MODEL-GUIDE.md#ordinary-actions-before-dialogue) for the authoring pattern and required playability probes.

Mutations require the existing trusted call/turn/effect headers. The connector owns them, not model arguments. The domain stores the authoring state, immutable definitions, frozen publication marker and original terminal command response in **one SQLite transaction** (`WAL`, `synchronous=FULL`). Exact original command+arguments replay returns the stored response even after process restart; different arguments with that identity reject. Rejected admitted edits are also retained. Stable host namespace/binding scope and valid fresh registration remain required; storage persistence is not permission to bypass binding checks.

`list_quest_drafts({})` returns `data.items` plus `data.recentCommands`. Use `get_authoring_command_outcome({commandId})` to inspect a retained original result without executing it again. Publication freezes a draft and returns identity/digest/source revision. The host alone retrieves the runtime definition with `author.readPublishedDefinition(definitionId)` and hands it to a separate consumer. Publication does not import/start gameplay.

The catalogue reader keeps its existing name but accepts **only** `read_quest_draft({section:"catalogue"})`. Discovery and dispatch enforce that restriction; overview/beat/publications/raw replacement are absent. It returns game-supplied capability schemas, evidence/reference contracts and granted references. CAI can retain its existing catalogue/world-summary preflight. A result-based world reference requires a receiver enum bounded to granted references; runtime validates the resolved argument, rather than assuming any produced string is authorized.

## Verified scope and limits

- Official SDK discovers all24 domain tools; combined real compiled Rocket host discovers25.
- Complete63-step builder reconstruction runs through the registered interface, produces the mapped12-stage baseline, checks digest/replay, denies raw graph reads and leaves game events at zero.
- Focused tests verify authorization, conflicting/exact retry, catalogue restriction, publication privacy/freeze and durable original receipts/definitions from a new process. Existing extended runtime tests cover conditions, results, objectives and independent guards.

The combined proof uses real Request/Response MCP transport in process; it is not a new TCP deployment, CAI worker/model run or Rocket browser proof. No provider calls occur.

Current CFW capacity:128 stages and256KiB per runtime definition,16 drafts,8192 retained mutation receipts per author namespace,64MiB namespace state. Receipts are never silently evicted. Storage capacity and per-generation call limits are separate. The runtime checkpoint accepts128-stage paths and2048 evidence cursors; the existing64MiB runtime journal bound remains. Ordinary builder arguments/results remain bounded to64KiB each. The legacy raw-fragment authoring adapter has a trusted, clamped512KiB input/result allowance to carry a256KiB fragment plus envelope; unrelated capabilities keep their64KiB default. Hosts exposing that legacy large-fragment adapter must opt into `McpGateway({maxRequestBytes: 1024 * 1024, ...})` for the HTTP envelope; its default128KiB body limit remains unchanged, and capability-level admission still applies.

`inspect_quest_draft({draftId})` preserves the original complete view when it fits48KiB. Larger views return an explicit summary with counts and `availableSections`. Read `section:"stages"`, `"conditions"` or `"records"` using `offset` and `limit` (1–8); responses contain `items`, `total` and `nextOffset`. Pass the returned `revision` as `expectedRevision` on subsequent pages; changed revisions reject rather than mix snapshots. `section:"mermaid"` returns consecutive text chunks, with `offset`/`nextOffset` measured in UTF-16 code units. Concatenate them before rendering the full diagram. `section:"text"` similarly exposes exact serialized authoring-view chunks for a single record too large for an item page. This never exposes runtime definition JSON. Responses may return fewer items to stay within the wire budget; follow `nextOffset`.

Transport/model step/call/token/deadline budgets and automatic multi-job continuation remain CAI/application policy. CFW does not invoke providers or change the acyclic graph, entry-failure or terminal-dialogue semantics when raising capacity. Previously pinned archives retain their original limits until owners explicitly adopt the new package.

Run the examples after building:

```sh
node examples/quest-builder-watchtower.js
node examples/quest-builder-mcp-proof.js /tmp/returned-local-proof-directory
# Optional read-only real Rocket provider-composition proof:
node examples/quest-builder-mcp-proof.js /tmp/returned-local-proof-directory /path/to/rocket-engine-v2
```

The proof returns its retained artifact directory with discovery, every structured call result, exact publication and assessment. The application-owned combined fixture must adopt this exported domain on its own side before CAI uses that endpoint. Preserve the previous playable baseline/pin while doing so.
