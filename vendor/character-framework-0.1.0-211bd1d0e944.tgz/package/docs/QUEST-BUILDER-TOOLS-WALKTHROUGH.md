# Quest builder tools: working contract and exact watchtower walkthrough

Status: **working authoring engine with registered MCP integration**, 14 October 2026. This document answers Julien's request to move from LLM theory to tool inputs, responses and a practical reconstruction. The author calls small tools; CFW constructs the executable graph internally. This prototype exposes authoring state and Mermaid, never runtime JSON through its author-facing calls.

Capacity update (15 October): CFW now accepts128 stages/256KiB definitions. Large `inspect_quest_draft` views use paged sections; see [current MCP contract](QUEST-BUILDER-MCP.md). The63-call historical transcript below remains an unchanged small-example calibration. Existing archives keep their original limits.

## What actually ran

Run from the repository root after `npm run build`:

```sh
node examples/quest-builder-watchtower.js
node --test --test-isolation=none tests/quest-builder-workspace.test.js
```

The runner made **63 builder calls**, including inspection, blocked publication, reopen and repair controls. Its host adapter made **9 actual MCP calls** through the existing official-client/gateway fixture for catalogue, compilation storage, review, publication, exact publication replay and host-only artifact retrieval. The new builder calls themselves run through `QuestBuilderWorkspace.call(toolName, parameters)` locally: the local transcript remains a direct-engine calibration. The same operations are now registered through the exported SQLite-backed MCP domain; see [registered domain and native envelopes](QUEST-BUILDER-MCP.md). CAI endpoint adoption remains application-owned. No model/provider was invoked.

Result: twelve stages published; the executable graph matches corrected Watchtower baseline SHA256 `32aabc76aaf1c3f0a8cc57bb6a9287ac3f55eb46334c78a3ba6086be8d0c9f9d` after explicit stage/route/choice/consequence ID mapping. Predicate fields, timing, priorities, choice labels, dialogue and ordered entry consequences compare exactly. The runner reopened the saved workspace, replaced a wrong route and a wrong beacon effect, rejected referenced-stage deletion and an unacknowledged shared-condition edit, and verified the publication digest/replay. Authoring never executes game capabilities.

The experiment compiles into the unchanged existing situation format. Explicit ending declarations, titles, purposes and named reusable conditions are authoring data; ending annotations do not add a new runtime field. The host privately retrieves published JSON for execution/evidence. Earlier baseline gameplay proofs remain the comparison evidence; this run does not claim a new browser playthrough or independent LLM storytelling success.

Source: [workspace engine](../src/authoring/QuestBuilderWorkspace.js), [registered domain](../src/authoring/QuestBuilderAuthoring.ts), [executable walkthrough](../examples/quest-builder-watchtower.js), [focused tests](../tests/quest-builder-workspace.test.js). Full machine-readable inputs: [tool schemas](contracts/quest-builder-tools.prototype.json).

## Start and shared parameters

The host supplies permitted world context and capability definitions before authoring. Here those are the frozen [watchtower fixture](contracts/watchtower-authoring-example.json); a real application must use its current granted catalogue. `game_*` names below are game-owned predicates/consequences to AUTHOR, not immediate calls to execute them.

Start with `create_quest_draft({title, premise})`. It creates no stage. Every mutation, review, publish and result-reference lookup takes `draft: {id, revision}`. Use the latest successful response's revision. Inspection uses `draftId`; it returns the exact current revision. Stage/condition/record IDs are assigned, opaque to authors and stable across reopen/replacement. The transcript below contains actual IDs from one run; a new run substitutes its returned draft ID.

Types: ID = nonempty bounded string; prose = nonempty string up to 2000 characters; Arguments = object checked against the selected granted capability. Comparison = `{path: ["outer", "field"], operator, value}` (or the backward-compatible single-field `{field, operator, value}`) with `operator` equal to `equals` or `at_least`; output field and value type are checked. Event boundary = `"quest_start"` or `{stageId}`. A condition checks one scalar output at a path of one to eight field names; `field` and `path` cannot both be supplied. It does not ask the author to write runtime nesting or evidence-stream IDs.

## Tool surface

Parameters below are exhaustive for this prototype. `draft` is required wherever shown. `?` means optional; null has explicit meaning only where specified. All tool schemas reject unknown top-level fields. The linked JSON schemas give exact requiredness/types, including each replacement form.

| Tool                          | Parameters beyond the common draft                | Result / purpose                                                                                                                          |
| ----------------------------- | ------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| `update_quest_intent`         | `draft`, `title`, `premise`                       | Revise overall intent before publication; keeps draft identity and increments revision.                                                   |
| `create_quest_draft`          | No draft; `title`, `premise`                      | Created draft ID, revision 1, empty progress.                                                                                             |
| `list_quest_drafts`           | No draft; `{}`                                    | IDs, revisions and titles for recovery.                                                                                                   |
| `inspect_quest_draft`         | No draft; `draftId`                               | Exact saved authoring state, condition users, findings and Mermaid.                                                                       |
| `add_stage`                   | `title`, `purpose`, `dialogue?`                   | `created.stageId`; no implicit route or ending.                                                                                           |
| `update_stage`                | `stageId`, `title`, `purpose`, `dialogue`         | Replaces presentation, preserves identity/links. Null dialogue removes it.                                                                |
| `remove_stage`                | `stageId`                                         | Removes only an unreferenced stage; otherwise returns referencing IDs.                                                                    |
| `set_start_stage`             | `stageId`                                         | Explicit entry stage.                                                                                                                     |
| `create_fact_condition`       | `capability`, `arguments`, `comparison`           | `created.conditionId`; predicate means true now, including historical matching delivery fact.                                             |
| `create_event_condition`      | Same plus `since`                                 | `created.conditionId`; event evidence after explicit boundary.                                                                            |
| `remove_condition`            | `conditionId`                                     | Removes only an unused condition; otherwise returns `condition_referenced` with user IDs.                                                 |
| `update_condition`            | `conditionId`, `replacement`, `affectedRecordIds` | Replacement has `mode: fact/events`, capability/arguments/comparison, plus `since` for events. Exact affected users must be acknowledged. |
| `add_transition`              | `from`, `to`, `conditionId`, `priority`           | `created.recordId`; automatic route, explicit numeric priority.                                                                           |
| `add_choice`                  | `from`, `to`, `label`, `conditionId?`             | `created.recordId`; player decision with optional guard.                                                                                  |
| `add_entry_consequence`       | `stageId`, `capability`, `arguments`              | `created.recordId`; appends action in entry order, does not execute it.                                                                   |
| `add_objective`               | `stageId`, `description`, `conditionId`           | `created.recordId`; visible progress condition, not an implicit route gate.                                                               |
| `from_action_result`          | `recordId`, `path`                                | Returns `{argument:{fromActionResult:{recordId,path}}}` without changing revision.                                                        |
| `edit_record`                 | `recordId`, `change`                              | Removes/replaces a route, choice, consequence or objective without leaving the old behavior. See below.                                   |
| `set_interaction_requirement` | `stageId`, `conditionId` or null                  | Fact/event guard applies to dialogue AND every choice; a distinct choice guard must also pass. Null removes the shared guard.             |
| `declare_ending`              | `stageId`, `ending: boolean`                      | Explicit terminal intent; true rejects existing outgoing connections.                                                                     |
| `review_quest_draft`          | No extra fields                                   | Readiness/findings; checks saved authoring completeness then existing runtime validator via host.                                         |
| `publish_quest_draft`         | No extra fields                                   | Immutable publication identity/digest/source revision; freezes the draft; blocked while unfinished, never gameplay activation.            |

`edit_record.change` is either `{operation:"remove"}` or `{operation:"replace",kind,value}`. `kind` is the record's existing kind and cannot change. Replacement value is the corresponding complete narrow record:

- transition: `{from,to,conditionId,priority}`;
- choice: `{from,to,label,conditionId?}`;
- consequence: `{stageId,capability,arguments}`;
- objective: `{stageId,description,conditionId}`.

Replacements retain the record's ID and ordered position. To reorder effects in this minimal prototype, remove/re-add the affected records in the desired order; there is no separate reorder tool yet. Transition priority can be replaced explicitly. A stage interaction requirement and an independent choice condition compile separately: both must pass. Stage-relative event conditions may reference the current or an earlier stage; publication validation requires that boundary on every path to each consuming route, choice, objective or interaction. Copy and rebind a condition for a branch-only change; updating a shared condition changes all its users.

## Expected response shapes

A saved edit responds:

```json
{
  "status": "completed",
  "draftId": "returned-id",
  "revision": 2,
  "created": { "stageId": "s1" },
  "change": "add_stage",
  "progress": { "stages": 1, "conditions": 0, "records": 0 },
  "findings": [
    { "code": "start_missing" },
    { "code": "unfinished_stage", "stageId": "s1" }
  ]
}
```

Saved edits also return `changedId`; record/condition replacement returns its exact `savedMeaning` (or removed identity). Input validation errors include a compact field path/message and current draft revision when known.

Stage/condition/record creation uses the corresponding `created` key; other edits return an empty `created` object. Incomplete work is saveable. Common errors:

- `revision_conflict`: returns the current draft ID/revision; inspect before a new edit.
- `stage_referenced`: returns current revision and `referencingIds`; no silent cascade or retarget.
- `condition_users_changed`: returns `affectedRecordIds`; inspect all users before agreeing to the change.
- `invalid_edit`: concise message for bad argument/type/reference/scope; failed edit is not saved. This early prototype does not yet have a full stable diagnostic-code taxonomy.

Review returns `technicalReady` and findings. Publish returns `publication:{definitionId,digest,sourceRevision}` on success, or unfinished findings when blocked. Inspection returns `data:{draftId,revision,intent,publication,startStageId,stages,conditions,records,findings,mermaid}`. That is authoring summary JSON: game semantics, named conditions and connections, not runtime implementation JSON. The LLM can read the Mermaid and corresponding exact details at the same revision.

## Limits of this practical experiment

The direct local fixture serially owns its file workspace. The registered domain instead uses SQLite transactions and durable command receipts; see [MCP storage/recovery contract](QUEST-BUILDER-MCP.md). It saves the authoritative authoring model to a JSON file using same-directory temporary-file replacement. There are no distributed writers, fsync durability guarantee, new builder effect receipts, automatic job continuation or production binding/access-control claims. The existing private host publication path has its existing receipts; that file-only adapter does not claim the registered SQLite domain's durable command replay. Raw replacement stays private to this host bridge and cannot edit the builder's saved source of truth.

This is the smallest demonstrated baseline surface, not full coverage of everything runtime JSON can express: the five identified condition/result/objective gaps are now supported, but multiple beats/long arcs, automatic multi-job continuation and other execution models are outside this experiment. Current sixteen-situation/12-KiB runtime bounds remain. The reconstruction is scripted from the accepted baseline, so it tests tools/compiler fidelity rather than independent model creativity. A many-call CAI experiment must explicitly address its model-step/journal bounds; nothing here raises those limits or invokes paid generation.

## Exact recorded call sequence

The sequence below is generated from a successful run's recorded calls. Every block contains the actual parameters and complete expected response for that call. It includes deliberate negative controls and repairs, not just the shortest happy path. Follow returned IDs/revisions rather than guessing or batching dependent edits. The author never submits a complete quest implementation.

The review pass (#491–492) independently accepted baseline fidelity. The current revision also addresses the three narrow usability findings: Mermaid edges now show predicate capability/arguments/comparison and fact/event boundary, nodes show ordered entry effects and shared interaction requirements; unused conditions can be removed explicitly to discard a branch; and edits/invalid inputs provide affected identity/meaning or missing-field paths. Eight focused tests cover these controls and the new expressiveness, including an actual CFW runtime execution of result chaining, objective progress and independent guards.

Discovery ownership: Rocket/game owns actual vocabulary, references, effects and world facts. The combined host supplies those descriptors to CFW. Its existing CFW `read_quest_draft({section:"catalogue"})` exposes the granted authoring catalogue; Rocket's `game_world_summary({})` exposes game description/world context. CAI preflights both. The local builder receives the catalogue from the host; it has no additional discovery tool yet. Authoring tools do not invent game functions.

The identified gaps are closed: nested output paths, earlier-stage event boundaries, distinct interaction/choice guards, acknowledged result arguments and optional objectives. This is not a blanket claim that every game schema or execution model is supported. General AND/OR/NOT predicates and cycles are not supported by the current runtime either.

Publication lifecycle is now explicit: successful publication saves `{definitionId,digest,sourceRevision}` and freezes that workspace draft. Reopen/inspection exposes this marker. Further edits return `draft_published`; create a new draft for another version in this prototype. Repeated publish of the same saved published revision returns the saved publication without another host dispatch. This is not a general builder mutation-receipt or crash-after-external-publication guarantee; those remain integration work. The fifth focused test verifies editable overall intent, publication/reopen identity and edit rejection.

## Added expressive operations and examples

The surface now has **22 tools**. Existing tool names and single-field comparisons remain compatible. The additions extend authoring data; runtime JSON is still generated privately.

### Nested condition output

```json
{
  "draft": { "id": "d1", "revision": 4 },
  "capability": "game_inventory",
  "arguments": { "playerRef": "player-1" },
  "comparison": {
    "path": ["seal", "collected"],
    "operator": "equals",
    "value": true
  }
}
```

Use this as `create_fact_condition` input only when the granted catalogue declares that capability, arguments and nested output. The result assigns a condition ID and increments revision exactly as before. Unknown output paths and incompatible values reject the edit.

### Earlier-stage events

`create_event_condition` keeps its existing `since:{stageId}` argument. It can now name an earlier stage instead of only the consuming stage. For example, a later delivery-stage condition may count new events since the offer stage's entry. Partial drafts may contain that condition before all links exist. Review/publication rejects any branch that can reach its consumer without entering the boundary. It does not silently switch to quest start or count older history.

### Shared interaction plus individual choice guard

Set `set_interaction_requirement(draft,stageId,conditionId)` for the common predicate, then `add_choice(draft,from,to,label,conditionId)` for a different choice-specific predicate. Both must pass at runtime. A missing choice condition inherits the common requirement. Inspection lists each choice among the shared requirement's affected users, even when that choice also has its own guard. There is no invented general boolean-expression language.

### Action-result arguments

Call `from_action_result` after adding the producing entry consequence:

```json
{
  "draft": { "id": "d1", "revision": 8 },
  "recordId": "r7",
  "path": ["ticket", "id"]
}
```

Expected shape (read-only; same revision):

```json
{
  "status": "completed",
  "draftId": "d1",
  "revision": 8,
  "argument": {
    "fromActionResult": { "recordId": "r7", "path": ["ticket", "id"] }
  }
}
```

Use the returned **argument value** in another granted action or inspection's arguments:

```json
{
  "draft": { "id": "d1", "revision": 8 },
  "stageId": "s1",
  "capability": "game_consume_ticket",
  "arguments": {
    "ticketRef": {
      "fromActionResult": { "recordId": "r7", "path": ["ticket", "id"] }
    }
  }
}
```

These names illustrate the contract; they are not added Watchtower game functions. The catalogue must declare the producing output and receiving input. CFW derives the producer stage and private runtime reference. No interpolation, evaluation, guessed result or author-supplied runtime `$result` object is accepted. Literal sibling arguments retain input-schema validation. A producer cannot be removed while saved arguments reference it.

The reference lookup validates producer/path existence; it does not assert that the producer has executed. Final runtime validation rejects incompatible declared types, same-stage forward/self references, producers bypassed on a branch, and capture scope depending on results unavailable before its event boundary. Incomplete designs can be saved, but those findings block publication. The runtime resolves only authoritative completed results and validates the actual resolved arguments before execution.

### Objectives

Call `add_objective(draft,stageId,description,conditionId)`. It returns `created.recordId`; inspection and Mermaid show the objective's text and exact condition. Replace/remove it through `edit_record`, with `kind:"objective"` and `value:{stageId,description,conditionId}` for replacement. Condition user/deletion checks include objectives.

Objectives display observed progress. They do **not** implicitly choose a route or keep a terminal stage open; use an explicit transition condition when progression must wait. This matches the existing runtime objective semantics.

### Practical checks for these extensions

The focused tests verify an earlier-stage boundary and nested path compile correctly, independent stage/choice guards remain distinct, objectives can be inspected/repaired/removed, and invalid temporal/result provenance blocks publication. A separate actual CFW runtime test executes producer→consumer result chaining, observes objective progress, withholds a choice when either guard fails, and closes the selected path with each action executed once. The Watchtower transcript below remains the unchanged-baseline calibration; these new features are tested separately rather than invented into the game.

### 1. `create_quest_draft`

Input:

```json
{
  "title": "Recover the watchtower beacon",
  "premise": "Choose a seal, recover it if not already collected, and complete matching delivery."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 1,
  "created": {
    "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d"
  },
  "progress": {
    "stages": 0,
    "conditions": 0,
    "records": 0
  }
}
```

### 2. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 1
  },
  "title": "approach",
  "purpose": "Watchtower approach progression",
  "dialogue": "Enter the courtyard to investigate the ruined watchtower."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 2,
  "created": {
    "stageId": "s1"
  },
  "change": "add_stage",
  "changedId": "s1",
  "savedMeaning": null,
  "progress": {
    "stages": 1,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    }
  ]
}
```

### 3. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 2
  },
  "title": "encounter",
  "purpose": "Watchtower encounter progression",
  "dialogue": "The sentries awaken. Move close to each and press E or click to defeat it."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 3,
  "created": {
    "stageId": "s2"
  },
  "change": "add_stage",
  "changedId": "s2",
  "savedMeaning": null,
  "progress": {
    "stages": 2,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    }
  ]
}
```

### 4. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 3
  },
  "title": "watchkeeper",
  "purpose": "Watchtower watchkeeper progression",
  "dialogue": "The watchkeeper appears. Approach to learn the route to the beacon."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 4,
  "created": {
    "stageId": "s3"
  },
  "change": "add_stage",
  "changedId": "s3",
  "savedMeaning": null,
  "progress": {
    "stages": 3,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    }
  ]
}
```

### 5. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 4
  },
  "title": "offer",
  "purpose": "Watchtower offer progression",
  "dialogue": "Watchkeeper: The tower has two paths. Do you want the blue seal or the red seal? Blue belongs at Beacon Ridge A; red belongs at Beacon Ridge B."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 5,
  "created": {
    "stageId": "s4"
  },
  "change": "add_stage",
  "changedId": "s4",
  "savedMeaning": null,
  "progress": {
    "stages": 4,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    }
  ]
}
```

### 6. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 5
  },
  "title": "blue-router",
  "purpose": "Watchtower blue-router progression"
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 6,
  "created": {
    "stageId": "s5"
  },
  "change": "add_stage",
  "changedId": "s5",
  "savedMeaning": null,
  "progress": {
    "stages": 5,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    }
  ]
}
```

### 7. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 6
  },
  "title": "blue-pickup",
  "purpose": "Watchtower blue-pickup progression",
  "dialogue": "Watchkeeper: You chose blue. Recover the blue seal, then carry it to Beacon Ridge A."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 7,
  "created": {
    "stageId": "s6"
  },
  "change": "add_stage",
  "changedId": "s6",
  "savedMeaning": null,
  "progress": {
    "stages": 6,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    }
  ]
}
```

### 8. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 7
  },
  "title": "blue-delivery",
  "purpose": "Watchtower blue-delivery progression",
  "dialogue": "Watchkeeper: Deliver the blue seal to Beacon Ridge A. Stand by Beacon A and press E or click it. The other beacon cannot accept this seal."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 8,
  "created": {
    "stageId": "s7"
  },
  "change": "add_stage",
  "changedId": "s7",
  "savedMeaning": null,
  "progress": {
    "stages": 7,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    }
  ]
}
```

### 9. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 8
  },
  "title": "blue-complete",
  "purpose": "Watchtower blue-complete progression",
  "dialogue": "The blue seal reached Beacon Ridge A. Beacon A is lit. Your chosen mission is complete."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 9,
  "created": {
    "stageId": "s8"
  },
  "change": "add_stage",
  "changedId": "s8",
  "savedMeaning": null,
  "progress": {
    "stages": 8,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    }
  ]
}
```

### 10. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 9
  },
  "title": "red-router",
  "purpose": "Watchtower red-router progression"
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 10,
  "created": {
    "stageId": "s9"
  },
  "change": "add_stage",
  "changedId": "s9",
  "savedMeaning": null,
  "progress": {
    "stages": 9,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    }
  ]
}
```

### 11. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 10
  },
  "title": "red-pickup",
  "purpose": "Watchtower red-pickup progression",
  "dialogue": "Watchkeeper: You chose red. Recover the red seal, then carry it to Beacon Ridge B."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 11,
  "created": {
    "stageId": "s10"
  },
  "change": "add_stage",
  "changedId": "s10",
  "savedMeaning": null,
  "progress": {
    "stages": 10,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    }
  ]
}
```

### 12. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 11
  },
  "title": "red-delivery",
  "purpose": "Watchtower red-delivery progression",
  "dialogue": "Watchkeeper: Deliver the red seal to Beacon Ridge B. Stand by Beacon B and press E or click it. The other beacon cannot accept this seal."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 12,
  "created": {
    "stageId": "s11"
  },
  "change": "add_stage",
  "changedId": "s11",
  "savedMeaning": null,
  "progress": {
    "stages": 11,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    }
  ]
}
```

### 13. `add_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 12
  },
  "title": "red-complete",
  "purpose": "Watchtower red-complete progression",
  "dialogue": "The red seal reached Beacon Ridge B. Beacon B is lit. Your chosen mission is complete."
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 13,
  "created": {
    "stageId": "s12"
  },
  "change": "add_stage",
  "changedId": "s12",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "start_missing"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 14. `set_start_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 13
  },
  "stageId": "s1"
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 14,
  "created": {},
  "change": "set_start_stage",
  "changedId": "s1",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 0,
    "records": 0
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 15. `review_quest_draft`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 14
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 14,
  "technicalReady": false,
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 16. `publish_quest_draft`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 14
  }
}
```

Observed response:

```json
{
  "status": "rejected",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 14,
  "technicalReady": false,
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 17. `create_event_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 14
  },
  "capability": "game_location",
  "arguments": {
    "locationRef": "courtyard"
  },
  "comparison": {
    "field": "count",
    "operator": "at_least",
    "value": 1
  },
  "since": "quest_start"
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 15,
  "created": {
    "conditionId": "c13"
  },
  "change": "create_event_condition",
  "changedId": "c13",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 1,
    "records": 0
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s1"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 18. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 15
  },
  "from": "s1",
  "to": "s2",
  "conditionId": "c13",
  "priority": 10
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 16,
  "created": {
    "recordId": "r14"
  },
  "change": "add_transition",
  "changedId": "r14",
  "savedMeaning": {
    "id": "c13",
    "mode": "events",
    "capability": "game_location",
    "arguments": {
      "locationRef": "courtyard"
    },
    "comparison": {
      "field": "count",
      "operator": "at_least",
      "value": 1
    },
    "since": "quest_start"
  },
  "progress": {
    "stages": 12,
    "conditions": 1,
    "records": 1
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 19. `create_event_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 16
  },
  "capability": "game_encounter",
  "arguments": {
    "groupRef": "sentries"
  },
  "comparison": {
    "field": "count",
    "operator": "at_least",
    "value": 3
  },
  "since": {
    "stageId": "s2"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 17,
  "created": {
    "conditionId": "c15"
  },
  "change": "create_event_condition",
  "changedId": "c15",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 2,
    "records": 1
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s2"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 20. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 17
  },
  "from": "s2",
  "to": "s3",
  "conditionId": "c15",
  "priority": 10
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 18,
  "created": {
    "recordId": "r16"
  },
  "change": "add_transition",
  "changedId": "r16",
  "savedMeaning": {
    "id": "c15",
    "mode": "events",
    "capability": "game_encounter",
    "arguments": {
      "groupRef": "sentries"
    },
    "comparison": {
      "field": "count",
      "operator": "at_least",
      "value": 3
    },
    "since": {
      "stageId": "s2"
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 2,
    "records": 2
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 21. `add_entry_consequence`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 18
  },
  "stageId": "s2",
  "capability": "game_activate_group",
  "arguments": {
    "groupRef": "sentries"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 19,
  "created": {
    "recordId": "r17"
  },
  "change": "add_entry_consequence",
  "changedId": "r17",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 2,
    "records": 3
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 22. `create_fact_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 19
  },
  "capability": "game_entity",
  "arguments": {
    "entityRef": "guide"
  },
  "comparison": {
    "field": "near",
    "operator": "equals",
    "value": true
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 20,
  "created": {
    "conditionId": "c18"
  },
  "change": "create_fact_condition",
  "changedId": "c18",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 3,
    "records": 3
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s3"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 23. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 20
  },
  "from": "s3",
  "to": "s4",
  "conditionId": "c18",
  "priority": 10
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 21,
  "created": {
    "recordId": "r19"
  },
  "change": "add_transition",
  "changedId": "r19",
  "savedMeaning": {
    "id": "c18",
    "mode": "fact",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "guide"
    },
    "comparison": {
      "field": "near",
      "operator": "equals",
      "value": true
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 3,
    "records": 4
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 24. `add_entry_consequence`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 21
  },
  "stageId": "s3",
  "capability": "game_reveal",
  "arguments": {
    "entityRef": "guide"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 22,
  "created": {
    "recordId": "r20"
  },
  "change": "add_entry_consequence",
  "changedId": "r20",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 3,
    "records": 5
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 25. `add_entry_consequence`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 22
  },
  "stageId": "s3",
  "capability": "game_open_gate",
  "arguments": {
    "entityRef": "gate"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 23,
  "created": {
    "recordId": "r21"
  },
  "change": "add_entry_consequence",
  "changedId": "r21",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 3,
    "records": 6
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 26. `set_interaction_requirement`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 23
  },
  "stageId": "s4",
  "conditionId": "c18"
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 24,
  "created": {},
  "change": "set_interaction_requirement",
  "changedId": "s4",
  "savedMeaning": {
    "id": "c18",
    "mode": "fact",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "guide"
    },
    "comparison": {
      "field": "near",
      "operator": "equals",
      "value": true
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 3,
    "records": 6
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s4"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 27. `add_choice`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 24
  },
  "from": "s4",
  "to": "s5",
  "label": "Blue seal — Beacon Ridge A",
  "conditionId": "c18"
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 25,
  "created": {
    "recordId": "r22"
  },
  "change": "add_choice",
  "changedId": "r22",
  "savedMeaning": {
    "id": "c18",
    "mode": "fact",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "guide"
    },
    "comparison": {
      "field": "near",
      "operator": "equals",
      "value": true
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 3,
    "records": 7
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 28. `add_choice`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 25
  },
  "from": "s4",
  "to": "s9",
  "label": "Red seal — Beacon Ridge B",
  "conditionId": "c18"
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 26,
  "created": {
    "recordId": "r23"
  },
  "change": "add_choice",
  "changedId": "r23",
  "savedMeaning": {
    "id": "c18",
    "mode": "fact",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "guide"
    },
    "comparison": {
      "field": "near",
      "operator": "equals",
      "value": true
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 3,
    "records": 8
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 29. `create_fact_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 26
  },
  "capability": "game_entity",
  "arguments": {
    "entityRef": "blue-seal"
  },
  "comparison": {
    "field": "collected",
    "operator": "equals",
    "value": true
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 27,
  "created": {
    "conditionId": "c24"
  },
  "change": "create_fact_condition",
  "changedId": "c24",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 4,
    "records": 8
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s5"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 30. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 27
  },
  "from": "s5",
  "to": "s7",
  "conditionId": "c24",
  "priority": 10
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 28,
  "created": {
    "recordId": "r25"
  },
  "change": "add_transition",
  "changedId": "r25",
  "savedMeaning": {
    "id": "c24",
    "mode": "fact",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "blue-seal"
    },
    "comparison": {
      "field": "collected",
      "operator": "equals",
      "value": true
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 4,
    "records": 9
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 31. `create_fact_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 28
  },
  "capability": "game_entity",
  "arguments": {
    "entityRef": "blue-seal"
  },
  "comparison": {
    "field": "collected",
    "operator": "equals",
    "value": false
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 29,
  "created": {
    "conditionId": "c26"
  },
  "change": "create_fact_condition",
  "changedId": "c26",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 5,
    "records": 9
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 32. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 29
  },
  "from": "s5",
  "to": "s6",
  "conditionId": "c26",
  "priority": 20
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 30,
  "created": {
    "recordId": "r27"
  },
  "change": "add_transition",
  "changedId": "r27",
  "savedMeaning": {
    "id": "c26",
    "mode": "fact",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "blue-seal"
    },
    "comparison": {
      "field": "collected",
      "operator": "equals",
      "value": false
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 5,
    "records": 10
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 33. `create_event_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 30
  },
  "capability": "game_entity",
  "arguments": {
    "entityRef": "blue-seal"
  },
  "comparison": {
    "field": "count",
    "operator": "at_least",
    "value": 1
  },
  "since": {
    "stageId": "s6"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 31,
  "created": {
    "conditionId": "c28"
  },
  "change": "create_event_condition",
  "changedId": "c28",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 6,
    "records": 10
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s6"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 34. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 31
  },
  "from": "s6",
  "to": "s7",
  "conditionId": "c28",
  "priority": 10
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 32,
  "created": {
    "recordId": "r29"
  },
  "change": "add_transition",
  "changedId": "r29",
  "savedMeaning": {
    "id": "c28",
    "mode": "events",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "blue-seal"
    },
    "comparison": {
      "field": "count",
      "operator": "at_least",
      "value": 1
    },
    "since": {
      "stageId": "s6"
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 6,
    "records": 11
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 35. `add_entry_consequence`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 32
  },
  "stageId": "s6",
  "capability": "game_reveal",
  "arguments": {
    "entityRef": "blue-seal"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 33,
  "created": {
    "recordId": "r30"
  },
  "change": "add_entry_consequence",
  "changedId": "r30",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 6,
    "records": 12
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 36. `create_fact_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 33
  },
  "capability": "game_delivery",
  "arguments": {
    "itemRef": "blue-seal",
    "destinationRef": "beacon-a"
  },
  "comparison": {
    "field": "delivered",
    "operator": "equals",
    "value": true
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 34,
  "created": {
    "conditionId": "c31"
  },
  "change": "create_fact_condition",
  "changedId": "c31",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 7,
    "records": 12
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s7"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 37. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 34
  },
  "from": "s7",
  "to": "s8",
  "conditionId": "c31",
  "priority": 10
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 35,
  "created": {
    "recordId": "r32"
  },
  "change": "add_transition",
  "changedId": "r32",
  "savedMeaning": {
    "id": "c31",
    "mode": "fact",
    "capability": "game_delivery",
    "arguments": {
      "itemRef": "blue-seal",
      "destinationRef": "beacon-a"
    },
    "comparison": {
      "field": "delivered",
      "operator": "equals",
      "value": true
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 7,
    "records": 13
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 38. `add_entry_consequence`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 35
  },
  "stageId": "s8",
  "capability": "game_light_beacon",
  "arguments": {
    "entityRef": "beacon-a"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 36,
  "created": {
    "recordId": "r33"
  },
  "change": "add_entry_consequence",
  "changedId": "r33",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 7,
    "records": 14
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s8"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 39. `declare_ending`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 36
  },
  "stageId": "s8",
  "ending": true
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 37,
  "created": {},
  "change": "declare_ending",
  "changedId": "s8",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 7,
    "records": 14
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 40. `create_fact_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 37
  },
  "capability": "game_entity",
  "arguments": {
    "entityRef": "red-seal"
  },
  "comparison": {
    "field": "collected",
    "operator": "equals",
    "value": true
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 38,
  "created": {
    "conditionId": "c34"
  },
  "change": "create_fact_condition",
  "changedId": "c34",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 8,
    "records": 14
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s9"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 41. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 38
  },
  "from": "s9",
  "to": "s11",
  "conditionId": "c34",
  "priority": 10
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 39,
  "created": {
    "recordId": "r35"
  },
  "change": "add_transition",
  "changedId": "r35",
  "savedMeaning": {
    "id": "c34",
    "mode": "fact",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "red-seal"
    },
    "comparison": {
      "field": "collected",
      "operator": "equals",
      "value": true
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 8,
    "records": 15
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 42. `create_fact_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 39
  },
  "capability": "game_entity",
  "arguments": {
    "entityRef": "red-seal"
  },
  "comparison": {
    "field": "collected",
    "operator": "equals",
    "value": false
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 40,
  "created": {
    "conditionId": "c36"
  },
  "change": "create_fact_condition",
  "changedId": "c36",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 9,
    "records": 15
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 43. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 40
  },
  "from": "s9",
  "to": "s10",
  "conditionId": "c36",
  "priority": 20
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 41,
  "created": {
    "recordId": "r37"
  },
  "change": "add_transition",
  "changedId": "r37",
  "savedMeaning": {
    "id": "c36",
    "mode": "fact",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "red-seal"
    },
    "comparison": {
      "field": "collected",
      "operator": "equals",
      "value": false
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 9,
    "records": 16
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 44. `create_event_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 41
  },
  "capability": "game_entity",
  "arguments": {
    "entityRef": "red-seal"
  },
  "comparison": {
    "field": "count",
    "operator": "at_least",
    "value": 1
  },
  "since": {
    "stageId": "s10"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 42,
  "created": {
    "conditionId": "c38"
  },
  "change": "create_event_condition",
  "changedId": "c38",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 10,
    "records": 16
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s10"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 45. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 42
  },
  "from": "s10",
  "to": "s11",
  "conditionId": "c38",
  "priority": 10
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 43,
  "created": {
    "recordId": "r39"
  },
  "change": "add_transition",
  "changedId": "r39",
  "savedMeaning": {
    "id": "c38",
    "mode": "events",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "red-seal"
    },
    "comparison": {
      "field": "count",
      "operator": "at_least",
      "value": 1
    },
    "since": {
      "stageId": "s10"
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 10,
    "records": 17
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 46. `add_entry_consequence`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 43
  },
  "stageId": "s10",
  "capability": "game_reveal",
  "arguments": {
    "entityRef": "red-seal"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 44,
  "created": {
    "recordId": "r40"
  },
  "change": "add_entry_consequence",
  "changedId": "r40",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 10,
    "records": 18
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 47. `create_fact_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 44
  },
  "capability": "game_delivery",
  "arguments": {
    "itemRef": "red-seal",
    "destinationRef": "beacon-b"
  },
  "comparison": {
    "field": "delivered",
    "operator": "equals",
    "value": true
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 45,
  "created": {
    "conditionId": "c41"
  },
  "change": "create_fact_condition",
  "changedId": "c41",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 11,
    "records": 18
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s11"
    },
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 48. `add_transition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 45
  },
  "from": "s11",
  "to": "s12",
  "conditionId": "c41",
  "priority": 10
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 46,
  "created": {
    "recordId": "r42"
  },
  "change": "add_transition",
  "changedId": "r42",
  "savedMeaning": {
    "id": "c41",
    "mode": "fact",
    "capability": "game_delivery",
    "arguments": {
      "itemRef": "red-seal",
      "destinationRef": "beacon-b"
    },
    "comparison": {
      "field": "delivered",
      "operator": "equals",
      "value": true
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 11,
    "records": 19
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 49. `add_entry_consequence`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 46
  },
  "stageId": "s12",
  "capability": "game_light_beacon",
  "arguments": {
    "entityRef": "beacon-b"
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 47,
  "created": {
    "recordId": "r43"
  },
  "change": "add_entry_consequence",
  "changedId": "r43",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 11,
    "records": 20
  },
  "findings": [
    {
      "code": "unfinished_stage",
      "stageId": "s12"
    }
  ]
}
```

### 50. `declare_ending`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 47
  },
  "stageId": "s12",
  "ending": true
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 48,
  "created": {},
  "change": "declare_ending",
  "changedId": "s12",
  "savedMeaning": null,
  "progress": {
    "stages": 12,
    "conditions": 11,
    "records": 20
  },
  "findings": []
}
```

### 51. `inspect_quest_draft`

Input:

```json
{
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d"
}
```

Observed response:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 48,
    "intent": {
      "title": "Recover the watchtower beacon",
      "premise": "Choose a seal, recover it if not already collected, and complete matching delivery."
    },
    "publication": null,
    "startStageId": "s1",
    "stages": [
      {
        "id": "s1",
        "title": "approach",
        "purpose": "Watchtower approach progression",
        "dialogue": "Enter the courtyard to investigate the ruined watchtower.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s2",
        "title": "encounter",
        "purpose": "Watchtower encounter progression",
        "dialogue": "The sentries awaken. Move close to each and press E or click to defeat it.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s3",
        "title": "watchkeeper",
        "purpose": "Watchtower watchkeeper progression",
        "dialogue": "The watchkeeper appears. Approach to learn the route to the beacon.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s4",
        "title": "offer",
        "purpose": "Watchtower offer progression",
        "dialogue": "Watchkeeper: The tower has two paths. Do you want the blue seal or the red seal? Blue belongs at Beacon Ridge A; red belongs at Beacon Ridge B.",
        "ending": false,
        "interaction": "c18"
      },
      {
        "id": "s5",
        "title": "blue-router",
        "purpose": "Watchtower blue-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s6",
        "title": "blue-pickup",
        "purpose": "Watchtower blue-pickup progression",
        "dialogue": "Watchkeeper: You chose blue. Recover the blue seal, then carry it to Beacon Ridge A.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s7",
        "title": "blue-delivery",
        "purpose": "Watchtower blue-delivery progression",
        "dialogue": "Watchkeeper: Deliver the blue seal to Beacon Ridge A. Stand by Beacon A and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s8",
        "title": "blue-complete",
        "purpose": "Watchtower blue-complete progression",
        "dialogue": "The blue seal reached Beacon Ridge A. Beacon A is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      },
      {
        "id": "s9",
        "title": "red-router",
        "purpose": "Watchtower red-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s10",
        "title": "red-pickup",
        "purpose": "Watchtower red-pickup progression",
        "dialogue": "Watchkeeper: You chose red. Recover the red seal, then carry it to Beacon Ridge B.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s11",
        "title": "red-delivery",
        "purpose": "Watchtower red-delivery progression",
        "dialogue": "Watchkeeper: Deliver the red seal to Beacon Ridge B. Stand by Beacon B and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s12",
        "title": "red-complete",
        "purpose": "Watchtower red-complete progression",
        "dialogue": "The red seal reached Beacon Ridge B. Beacon B is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      }
    ],
    "conditions": [
      {
        "id": "c13",
        "mode": "events",
        "capability": "game_location",
        "arguments": {
          "locationRef": "courtyard"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": "quest_start",
        "usedBy": ["r14"]
      },
      {
        "id": "c15",
        "mode": "events",
        "capability": "game_encounter",
        "arguments": {
          "groupRef": "sentries"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 3
        },
        "since": {
          "stageId": "s2"
        },
        "usedBy": ["r16"]
      },
      {
        "id": "c18",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "guide"
        },
        "comparison": {
          "field": "near",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["interaction:s4", "r19", "r22", "r23"]
      },
      {
        "id": "c24",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r25"]
      },
      {
        "id": "c26",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r27"]
      },
      {
        "id": "c28",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s6"
        },
        "usedBy": ["r29"]
      },
      {
        "id": "c31",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "blue-seal",
          "destinationRef": "beacon-a"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r32"]
      },
      {
        "id": "c34",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r35"]
      },
      {
        "id": "c36",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r37"]
      },
      {
        "id": "c38",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s10"
        },
        "usedBy": ["r39"]
      },
      {
        "id": "c41",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "red-seal",
          "destinationRef": "beacon-b"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r42"]
      }
    ],
    "records": [
      {
        "id": "r14",
        "kind": "transition",
        "from": "s1",
        "to": "s2",
        "conditionId": "c13",
        "priority": 10
      },
      {
        "id": "r16",
        "kind": "transition",
        "from": "s2",
        "to": "s3",
        "conditionId": "c15",
        "priority": 10
      },
      {
        "id": "r17",
        "kind": "consequence",
        "stageId": "s2",
        "capability": "game_activate_group",
        "arguments": {
          "groupRef": "sentries"
        }
      },
      {
        "id": "r19",
        "kind": "transition",
        "from": "s3",
        "to": "s4",
        "conditionId": "c18",
        "priority": 10
      },
      {
        "id": "r20",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "guide"
        }
      },
      {
        "id": "r21",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_open_gate",
        "arguments": {
          "entityRef": "gate"
        }
      },
      {
        "id": "r22",
        "kind": "choice",
        "from": "s4",
        "to": "s5",
        "label": "Blue seal — Beacon Ridge A",
        "conditionId": "c18"
      },
      {
        "id": "r23",
        "kind": "choice",
        "from": "s4",
        "to": "s9",
        "label": "Red seal — Beacon Ridge B",
        "conditionId": "c18"
      },
      {
        "id": "r25",
        "kind": "transition",
        "from": "s5",
        "to": "s7",
        "conditionId": "c24",
        "priority": 10
      },
      {
        "id": "r27",
        "kind": "transition",
        "from": "s5",
        "to": "s6",
        "conditionId": "c26",
        "priority": 20
      },
      {
        "id": "r29",
        "kind": "transition",
        "from": "s6",
        "to": "s7",
        "conditionId": "c28",
        "priority": 10
      },
      {
        "id": "r30",
        "kind": "consequence",
        "stageId": "s6",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "blue-seal"
        }
      },
      {
        "id": "r32",
        "kind": "transition",
        "from": "s7",
        "to": "s8",
        "conditionId": "c31",
        "priority": 10
      },
      {
        "id": "r33",
        "kind": "consequence",
        "stageId": "s8",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-a"
        }
      },
      {
        "id": "r35",
        "kind": "transition",
        "from": "s9",
        "to": "s11",
        "conditionId": "c34",
        "priority": 10
      },
      {
        "id": "r37",
        "kind": "transition",
        "from": "s9",
        "to": "s10",
        "conditionId": "c36",
        "priority": 20
      },
      {
        "id": "r39",
        "kind": "transition",
        "from": "s10",
        "to": "s11",
        "conditionId": "c38",
        "priority": 10
      },
      {
        "id": "r40",
        "kind": "consequence",
        "stageId": "s10",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "red-seal"
        }
      },
      {
        "id": "r42",
        "kind": "transition",
        "from": "s11",
        "to": "s12",
        "conditionId": "c41",
        "priority": 10
      },
      {
        "id": "r43",
        "kind": "consequence",
        "stageId": "s12",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-b"
        }
      }
    ],
    "findings": [],
    "mermaid": "flowchart TD\n  s1[\"s1: approach\"]\n  s2[\"s2: encounter; enter r17: game_activate_group {&quot;groupRef&quot;:&quot;sentries&quot;}\"]\n  s3[\"s3: watchkeeper; enter r20: game_reveal {&quot;entityRef&quot;:&quot;guide&quot;}; enter r21: game_open_gate {&quot;entityRef&quot;:&quot;gate&quot;}\"]\n  s4[\"s4: offer; interaction c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"]\n  s5[\"s5: blue-router\"]\n  s6[\"s6: blue-pickup; enter r30: game_reveal {&quot;entityRef&quot;:&quot;blue-seal&quot;}\"]\n  s7[\"s7: blue-delivery\"]\n  s8[\"s8: blue-complete (ending); enter r33: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-a&quot;}\"]\n  s9[\"s9: red-router\"]\n  s10[\"s10: red-pickup; enter r40: game_reveal {&quot;entityRef&quot;:&quot;red-seal&quot;}\"]\n  s11[\"s11: red-delivery\"]\n  s12[\"s12: red-complete (ending); enter r43: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-b&quot;}\"]\n  s1 -->|\"r14: c13: game_location {&quot;locationRef&quot;:&quot;courtyard&quot;} count at_least 1; events since quest start priority 10\"| s2\n  s2 -->|\"r16: c15: game_encounter {&quot;groupRef&quot;:&quot;sentries&quot;} count at_least 3; events since s2 entry priority 10\"| s3\n  s3 -->|\"r19: c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now priority 10\"| s4\n  s4 -->|\"r22: choice Blue seal — Beacon Ridge A; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s5\n  s4 -->|\"r23: choice Red seal — Beacon Ridge B; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s9\n  s5 -->|\"r25: c24: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals true; fact now priority 10\"| s7\n  s5 -->|\"r27: c26: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals false; fact now priority 20\"| s6\n  s6 -->|\"r29: c28: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} count at_least 1; events since s6 entry priority 10\"| s7\n  s7 -->|\"r32: c31: game_delivery {&quot;itemRef&quot;:&quot;blue-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-a&quot;} delivered equals true; fact now priority 10\"| s8\n  s9 -->|\"r35: c34: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals true; fact now priority 10\"| s11\n  s9 -->|\"r37: c36: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals false; fact now priority 20\"| s10\n  s10 -->|\"r39: c38: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} count at_least 1; events since s10 entry priority 10\"| s11\n  s11 -->|\"r42: c41: game_delivery {&quot;itemRef&quot;:&quot;red-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-b&quot;} delivered equals true; fact now priority 10\"| s12"
  }
}
```

### 52. `inspect_quest_draft`

Input:

```json
{
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d"
}
```

Observed response:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 48,
    "intent": {
      "title": "Recover the watchtower beacon",
      "premise": "Choose a seal, recover it if not already collected, and complete matching delivery."
    },
    "publication": null,
    "startStageId": "s1",
    "stages": [
      {
        "id": "s1",
        "title": "approach",
        "purpose": "Watchtower approach progression",
        "dialogue": "Enter the courtyard to investigate the ruined watchtower.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s2",
        "title": "encounter",
        "purpose": "Watchtower encounter progression",
        "dialogue": "The sentries awaken. Move close to each and press E or click to defeat it.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s3",
        "title": "watchkeeper",
        "purpose": "Watchtower watchkeeper progression",
        "dialogue": "The watchkeeper appears. Approach to learn the route to the beacon.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s4",
        "title": "offer",
        "purpose": "Watchtower offer progression",
        "dialogue": "Watchkeeper: The tower has two paths. Do you want the blue seal or the red seal? Blue belongs at Beacon Ridge A; red belongs at Beacon Ridge B.",
        "ending": false,
        "interaction": "c18"
      },
      {
        "id": "s5",
        "title": "blue-router",
        "purpose": "Watchtower blue-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s6",
        "title": "blue-pickup",
        "purpose": "Watchtower blue-pickup progression",
        "dialogue": "Watchkeeper: You chose blue. Recover the blue seal, then carry it to Beacon Ridge A.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s7",
        "title": "blue-delivery",
        "purpose": "Watchtower blue-delivery progression",
        "dialogue": "Watchkeeper: Deliver the blue seal to Beacon Ridge A. Stand by Beacon A and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s8",
        "title": "blue-complete",
        "purpose": "Watchtower blue-complete progression",
        "dialogue": "The blue seal reached Beacon Ridge A. Beacon A is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      },
      {
        "id": "s9",
        "title": "red-router",
        "purpose": "Watchtower red-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s10",
        "title": "red-pickup",
        "purpose": "Watchtower red-pickup progression",
        "dialogue": "Watchkeeper: You chose red. Recover the red seal, then carry it to Beacon Ridge B.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s11",
        "title": "red-delivery",
        "purpose": "Watchtower red-delivery progression",
        "dialogue": "Watchkeeper: Deliver the red seal to Beacon Ridge B. Stand by Beacon B and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s12",
        "title": "red-complete",
        "purpose": "Watchtower red-complete progression",
        "dialogue": "The red seal reached Beacon Ridge B. Beacon B is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      }
    ],
    "conditions": [
      {
        "id": "c13",
        "mode": "events",
        "capability": "game_location",
        "arguments": {
          "locationRef": "courtyard"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": "quest_start",
        "usedBy": ["r14"]
      },
      {
        "id": "c15",
        "mode": "events",
        "capability": "game_encounter",
        "arguments": {
          "groupRef": "sentries"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 3
        },
        "since": {
          "stageId": "s2"
        },
        "usedBy": ["r16"]
      },
      {
        "id": "c18",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "guide"
        },
        "comparison": {
          "field": "near",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["interaction:s4", "r19", "r22", "r23"]
      },
      {
        "id": "c24",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r25"]
      },
      {
        "id": "c26",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r27"]
      },
      {
        "id": "c28",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s6"
        },
        "usedBy": ["r29"]
      },
      {
        "id": "c31",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "blue-seal",
          "destinationRef": "beacon-a"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r32"]
      },
      {
        "id": "c34",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r35"]
      },
      {
        "id": "c36",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r37"]
      },
      {
        "id": "c38",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s10"
        },
        "usedBy": ["r39"]
      },
      {
        "id": "c41",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "red-seal",
          "destinationRef": "beacon-b"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r42"]
      }
    ],
    "records": [
      {
        "id": "r14",
        "kind": "transition",
        "from": "s1",
        "to": "s2",
        "conditionId": "c13",
        "priority": 10
      },
      {
        "id": "r16",
        "kind": "transition",
        "from": "s2",
        "to": "s3",
        "conditionId": "c15",
        "priority": 10
      },
      {
        "id": "r17",
        "kind": "consequence",
        "stageId": "s2",
        "capability": "game_activate_group",
        "arguments": {
          "groupRef": "sentries"
        }
      },
      {
        "id": "r19",
        "kind": "transition",
        "from": "s3",
        "to": "s4",
        "conditionId": "c18",
        "priority": 10
      },
      {
        "id": "r20",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "guide"
        }
      },
      {
        "id": "r21",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_open_gate",
        "arguments": {
          "entityRef": "gate"
        }
      },
      {
        "id": "r22",
        "kind": "choice",
        "from": "s4",
        "to": "s5",
        "label": "Blue seal — Beacon Ridge A",
        "conditionId": "c18"
      },
      {
        "id": "r23",
        "kind": "choice",
        "from": "s4",
        "to": "s9",
        "label": "Red seal — Beacon Ridge B",
        "conditionId": "c18"
      },
      {
        "id": "r25",
        "kind": "transition",
        "from": "s5",
        "to": "s7",
        "conditionId": "c24",
        "priority": 10
      },
      {
        "id": "r27",
        "kind": "transition",
        "from": "s5",
        "to": "s6",
        "conditionId": "c26",
        "priority": 20
      },
      {
        "id": "r29",
        "kind": "transition",
        "from": "s6",
        "to": "s7",
        "conditionId": "c28",
        "priority": 10
      },
      {
        "id": "r30",
        "kind": "consequence",
        "stageId": "s6",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "blue-seal"
        }
      },
      {
        "id": "r32",
        "kind": "transition",
        "from": "s7",
        "to": "s8",
        "conditionId": "c31",
        "priority": 10
      },
      {
        "id": "r33",
        "kind": "consequence",
        "stageId": "s8",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-a"
        }
      },
      {
        "id": "r35",
        "kind": "transition",
        "from": "s9",
        "to": "s11",
        "conditionId": "c34",
        "priority": 10
      },
      {
        "id": "r37",
        "kind": "transition",
        "from": "s9",
        "to": "s10",
        "conditionId": "c36",
        "priority": 20
      },
      {
        "id": "r39",
        "kind": "transition",
        "from": "s10",
        "to": "s11",
        "conditionId": "c38",
        "priority": 10
      },
      {
        "id": "r40",
        "kind": "consequence",
        "stageId": "s10",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "red-seal"
        }
      },
      {
        "id": "r42",
        "kind": "transition",
        "from": "s11",
        "to": "s12",
        "conditionId": "c41",
        "priority": 10
      },
      {
        "id": "r43",
        "kind": "consequence",
        "stageId": "s12",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-b"
        }
      }
    ],
    "findings": [],
    "mermaid": "flowchart TD\n  s1[\"s1: approach\"]\n  s2[\"s2: encounter; enter r17: game_activate_group {&quot;groupRef&quot;:&quot;sentries&quot;}\"]\n  s3[\"s3: watchkeeper; enter r20: game_reveal {&quot;entityRef&quot;:&quot;guide&quot;}; enter r21: game_open_gate {&quot;entityRef&quot;:&quot;gate&quot;}\"]\n  s4[\"s4: offer; interaction c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"]\n  s5[\"s5: blue-router\"]\n  s6[\"s6: blue-pickup; enter r30: game_reveal {&quot;entityRef&quot;:&quot;blue-seal&quot;}\"]\n  s7[\"s7: blue-delivery\"]\n  s8[\"s8: blue-complete (ending); enter r33: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-a&quot;}\"]\n  s9[\"s9: red-router\"]\n  s10[\"s10: red-pickup; enter r40: game_reveal {&quot;entityRef&quot;:&quot;red-seal&quot;}\"]\n  s11[\"s11: red-delivery\"]\n  s12[\"s12: red-complete (ending); enter r43: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-b&quot;}\"]\n  s1 -->|\"r14: c13: game_location {&quot;locationRef&quot;:&quot;courtyard&quot;} count at_least 1; events since quest start priority 10\"| s2\n  s2 -->|\"r16: c15: game_encounter {&quot;groupRef&quot;:&quot;sentries&quot;} count at_least 3; events since s2 entry priority 10\"| s3\n  s3 -->|\"r19: c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now priority 10\"| s4\n  s4 -->|\"r22: choice Blue seal — Beacon Ridge A; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s5\n  s4 -->|\"r23: choice Red seal — Beacon Ridge B; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s9\n  s5 -->|\"r25: c24: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals true; fact now priority 10\"| s7\n  s5 -->|\"r27: c26: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals false; fact now priority 20\"| s6\n  s6 -->|\"r29: c28: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} count at_least 1; events since s6 entry priority 10\"| s7\n  s7 -->|\"r32: c31: game_delivery {&quot;itemRef&quot;:&quot;blue-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-a&quot;} delivered equals true; fact now priority 10\"| s8\n  s9 -->|\"r35: c34: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals true; fact now priority 10\"| s11\n  s9 -->|\"r37: c36: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals false; fact now priority 20\"| s10\n  s10 -->|\"r39: c38: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} count at_least 1; events since s10 entry priority 10\"| s11\n  s11 -->|\"r42: c41: game_delivery {&quot;itemRef&quot;:&quot;red-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-b&quot;} delivered equals true; fact now priority 10\"| s12"
  }
}
```

### 53. `edit_record`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 48
  },
  "recordId": "r32",
  "change": {
    "operation": "replace",
    "kind": "transition",
    "value": {
      "from": "s7",
      "to": "s12",
      "conditionId": "c31",
      "priority": 10
    }
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 49,
  "created": {},
  "change": "edit_record",
  "changedId": "r32",
  "savedMeaning": {
    "id": "r32",
    "kind": "transition",
    "from": "s7",
    "to": "s12",
    "conditionId": "c31",
    "priority": 10
  },
  "progress": {
    "stages": 12,
    "conditions": 11,
    "records": 20
  },
  "findings": []
}
```

### 54. `inspect_quest_draft`

Input:

```json
{
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d"
}
```

Observed response:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 49,
    "intent": {
      "title": "Recover the watchtower beacon",
      "premise": "Choose a seal, recover it if not already collected, and complete matching delivery."
    },
    "publication": null,
    "startStageId": "s1",
    "stages": [
      {
        "id": "s1",
        "title": "approach",
        "purpose": "Watchtower approach progression",
        "dialogue": "Enter the courtyard to investigate the ruined watchtower.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s2",
        "title": "encounter",
        "purpose": "Watchtower encounter progression",
        "dialogue": "The sentries awaken. Move close to each and press E or click to defeat it.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s3",
        "title": "watchkeeper",
        "purpose": "Watchtower watchkeeper progression",
        "dialogue": "The watchkeeper appears. Approach to learn the route to the beacon.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s4",
        "title": "offer",
        "purpose": "Watchtower offer progression",
        "dialogue": "Watchkeeper: The tower has two paths. Do you want the blue seal or the red seal? Blue belongs at Beacon Ridge A; red belongs at Beacon Ridge B.",
        "ending": false,
        "interaction": "c18"
      },
      {
        "id": "s5",
        "title": "blue-router",
        "purpose": "Watchtower blue-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s6",
        "title": "blue-pickup",
        "purpose": "Watchtower blue-pickup progression",
        "dialogue": "Watchkeeper: You chose blue. Recover the blue seal, then carry it to Beacon Ridge A.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s7",
        "title": "blue-delivery",
        "purpose": "Watchtower blue-delivery progression",
        "dialogue": "Watchkeeper: Deliver the blue seal to Beacon Ridge A. Stand by Beacon A and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s8",
        "title": "blue-complete",
        "purpose": "Watchtower blue-complete progression",
        "dialogue": "The blue seal reached Beacon Ridge A. Beacon A is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      },
      {
        "id": "s9",
        "title": "red-router",
        "purpose": "Watchtower red-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s10",
        "title": "red-pickup",
        "purpose": "Watchtower red-pickup progression",
        "dialogue": "Watchkeeper: You chose red. Recover the red seal, then carry it to Beacon Ridge B.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s11",
        "title": "red-delivery",
        "purpose": "Watchtower red-delivery progression",
        "dialogue": "Watchkeeper: Deliver the red seal to Beacon Ridge B. Stand by Beacon B and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s12",
        "title": "red-complete",
        "purpose": "Watchtower red-complete progression",
        "dialogue": "The red seal reached Beacon Ridge B. Beacon B is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      }
    ],
    "conditions": [
      {
        "id": "c13",
        "mode": "events",
        "capability": "game_location",
        "arguments": {
          "locationRef": "courtyard"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": "quest_start",
        "usedBy": ["r14"]
      },
      {
        "id": "c15",
        "mode": "events",
        "capability": "game_encounter",
        "arguments": {
          "groupRef": "sentries"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 3
        },
        "since": {
          "stageId": "s2"
        },
        "usedBy": ["r16"]
      },
      {
        "id": "c18",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "guide"
        },
        "comparison": {
          "field": "near",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["interaction:s4", "r19", "r22", "r23"]
      },
      {
        "id": "c24",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r25"]
      },
      {
        "id": "c26",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r27"]
      },
      {
        "id": "c28",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s6"
        },
        "usedBy": ["r29"]
      },
      {
        "id": "c31",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "blue-seal",
          "destinationRef": "beacon-a"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r32"]
      },
      {
        "id": "c34",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r35"]
      },
      {
        "id": "c36",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r37"]
      },
      {
        "id": "c38",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s10"
        },
        "usedBy": ["r39"]
      },
      {
        "id": "c41",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "red-seal",
          "destinationRef": "beacon-b"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r42"]
      }
    ],
    "records": [
      {
        "id": "r14",
        "kind": "transition",
        "from": "s1",
        "to": "s2",
        "conditionId": "c13",
        "priority": 10
      },
      {
        "id": "r16",
        "kind": "transition",
        "from": "s2",
        "to": "s3",
        "conditionId": "c15",
        "priority": 10
      },
      {
        "id": "r17",
        "kind": "consequence",
        "stageId": "s2",
        "capability": "game_activate_group",
        "arguments": {
          "groupRef": "sentries"
        }
      },
      {
        "id": "r19",
        "kind": "transition",
        "from": "s3",
        "to": "s4",
        "conditionId": "c18",
        "priority": 10
      },
      {
        "id": "r20",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "guide"
        }
      },
      {
        "id": "r21",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_open_gate",
        "arguments": {
          "entityRef": "gate"
        }
      },
      {
        "id": "r22",
        "kind": "choice",
        "from": "s4",
        "to": "s5",
        "label": "Blue seal — Beacon Ridge A",
        "conditionId": "c18"
      },
      {
        "id": "r23",
        "kind": "choice",
        "from": "s4",
        "to": "s9",
        "label": "Red seal — Beacon Ridge B",
        "conditionId": "c18"
      },
      {
        "id": "r25",
        "kind": "transition",
        "from": "s5",
        "to": "s7",
        "conditionId": "c24",
        "priority": 10
      },
      {
        "id": "r27",
        "kind": "transition",
        "from": "s5",
        "to": "s6",
        "conditionId": "c26",
        "priority": 20
      },
      {
        "id": "r29",
        "kind": "transition",
        "from": "s6",
        "to": "s7",
        "conditionId": "c28",
        "priority": 10
      },
      {
        "id": "r30",
        "kind": "consequence",
        "stageId": "s6",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "blue-seal"
        }
      },
      {
        "id": "r32",
        "kind": "transition",
        "from": "s7",
        "to": "s12",
        "conditionId": "c31",
        "priority": 10
      },
      {
        "id": "r33",
        "kind": "consequence",
        "stageId": "s8",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-a"
        }
      },
      {
        "id": "r35",
        "kind": "transition",
        "from": "s9",
        "to": "s11",
        "conditionId": "c34",
        "priority": 10
      },
      {
        "id": "r37",
        "kind": "transition",
        "from": "s9",
        "to": "s10",
        "conditionId": "c36",
        "priority": 20
      },
      {
        "id": "r39",
        "kind": "transition",
        "from": "s10",
        "to": "s11",
        "conditionId": "c38",
        "priority": 10
      },
      {
        "id": "r40",
        "kind": "consequence",
        "stageId": "s10",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "red-seal"
        }
      },
      {
        "id": "r42",
        "kind": "transition",
        "from": "s11",
        "to": "s12",
        "conditionId": "c41",
        "priority": 10
      },
      {
        "id": "r43",
        "kind": "consequence",
        "stageId": "s12",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-b"
        }
      }
    ],
    "findings": [],
    "mermaid": "flowchart TD\n  s1[\"s1: approach\"]\n  s2[\"s2: encounter; enter r17: game_activate_group {&quot;groupRef&quot;:&quot;sentries&quot;}\"]\n  s3[\"s3: watchkeeper; enter r20: game_reveal {&quot;entityRef&quot;:&quot;guide&quot;}; enter r21: game_open_gate {&quot;entityRef&quot;:&quot;gate&quot;}\"]\n  s4[\"s4: offer; interaction c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"]\n  s5[\"s5: blue-router\"]\n  s6[\"s6: blue-pickup; enter r30: game_reveal {&quot;entityRef&quot;:&quot;blue-seal&quot;}\"]\n  s7[\"s7: blue-delivery\"]\n  s8[\"s8: blue-complete (ending); enter r33: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-a&quot;}\"]\n  s9[\"s9: red-router\"]\n  s10[\"s10: red-pickup; enter r40: game_reveal {&quot;entityRef&quot;:&quot;red-seal&quot;}\"]\n  s11[\"s11: red-delivery\"]\n  s12[\"s12: red-complete (ending); enter r43: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-b&quot;}\"]\n  s1 -->|\"r14: c13: game_location {&quot;locationRef&quot;:&quot;courtyard&quot;} count at_least 1; events since quest start priority 10\"| s2\n  s2 -->|\"r16: c15: game_encounter {&quot;groupRef&quot;:&quot;sentries&quot;} count at_least 3; events since s2 entry priority 10\"| s3\n  s3 -->|\"r19: c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now priority 10\"| s4\n  s4 -->|\"r22: choice Blue seal — Beacon Ridge A; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s5\n  s4 -->|\"r23: choice Red seal — Beacon Ridge B; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s9\n  s5 -->|\"r25: c24: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals true; fact now priority 10\"| s7\n  s5 -->|\"r27: c26: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals false; fact now priority 20\"| s6\n  s6 -->|\"r29: c28: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} count at_least 1; events since s6 entry priority 10\"| s7\n  s7 -->|\"r32: c31: game_delivery {&quot;itemRef&quot;:&quot;blue-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-a&quot;} delivered equals true; fact now priority 10\"| s12\n  s9 -->|\"r35: c34: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals true; fact now priority 10\"| s11\n  s9 -->|\"r37: c36: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals false; fact now priority 20\"| s10\n  s10 -->|\"r39: c38: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} count at_least 1; events since s10 entry priority 10\"| s11\n  s11 -->|\"r42: c41: game_delivery {&quot;itemRef&quot;:&quot;red-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-b&quot;} delivered equals true; fact now priority 10\"| s12"
  }
}
```

### 55. `edit_record`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 49
  },
  "recordId": "r32",
  "change": {
    "operation": "replace",
    "kind": "transition",
    "value": {
      "from": "s7",
      "to": "s8",
      "conditionId": "c31",
      "priority": 10
    }
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 50,
  "created": {},
  "change": "edit_record",
  "changedId": "r32",
  "savedMeaning": {
    "id": "r32",
    "kind": "transition",
    "from": "s7",
    "to": "s8",
    "conditionId": "c31",
    "priority": 10
  },
  "progress": {
    "stages": 12,
    "conditions": 11,
    "records": 20
  },
  "findings": []
}
```

### 56. `edit_record`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 50
  },
  "recordId": "r33",
  "change": {
    "operation": "replace",
    "kind": "consequence",
    "value": {
      "stageId": "s8",
      "capability": "game_light_beacon",
      "arguments": {
        "entityRef": "beacon-b"
      }
    }
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 51,
  "created": {},
  "change": "edit_record",
  "changedId": "r33",
  "savedMeaning": {
    "id": "r33",
    "kind": "consequence",
    "stageId": "s8",
    "capability": "game_light_beacon",
    "arguments": {
      "entityRef": "beacon-b"
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 11,
    "records": 20
  },
  "findings": []
}
```

### 57. `inspect_quest_draft`

Input:

```json
{
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d"
}
```

Observed response:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 51,
    "intent": {
      "title": "Recover the watchtower beacon",
      "premise": "Choose a seal, recover it if not already collected, and complete matching delivery."
    },
    "publication": null,
    "startStageId": "s1",
    "stages": [
      {
        "id": "s1",
        "title": "approach",
        "purpose": "Watchtower approach progression",
        "dialogue": "Enter the courtyard to investigate the ruined watchtower.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s2",
        "title": "encounter",
        "purpose": "Watchtower encounter progression",
        "dialogue": "The sentries awaken. Move close to each and press E or click to defeat it.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s3",
        "title": "watchkeeper",
        "purpose": "Watchtower watchkeeper progression",
        "dialogue": "The watchkeeper appears. Approach to learn the route to the beacon.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s4",
        "title": "offer",
        "purpose": "Watchtower offer progression",
        "dialogue": "Watchkeeper: The tower has two paths. Do you want the blue seal or the red seal? Blue belongs at Beacon Ridge A; red belongs at Beacon Ridge B.",
        "ending": false,
        "interaction": "c18"
      },
      {
        "id": "s5",
        "title": "blue-router",
        "purpose": "Watchtower blue-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s6",
        "title": "blue-pickup",
        "purpose": "Watchtower blue-pickup progression",
        "dialogue": "Watchkeeper: You chose blue. Recover the blue seal, then carry it to Beacon Ridge A.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s7",
        "title": "blue-delivery",
        "purpose": "Watchtower blue-delivery progression",
        "dialogue": "Watchkeeper: Deliver the blue seal to Beacon Ridge A. Stand by Beacon A and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s8",
        "title": "blue-complete",
        "purpose": "Watchtower blue-complete progression",
        "dialogue": "The blue seal reached Beacon Ridge A. Beacon A is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      },
      {
        "id": "s9",
        "title": "red-router",
        "purpose": "Watchtower red-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s10",
        "title": "red-pickup",
        "purpose": "Watchtower red-pickup progression",
        "dialogue": "Watchkeeper: You chose red. Recover the red seal, then carry it to Beacon Ridge B.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s11",
        "title": "red-delivery",
        "purpose": "Watchtower red-delivery progression",
        "dialogue": "Watchkeeper: Deliver the red seal to Beacon Ridge B. Stand by Beacon B and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s12",
        "title": "red-complete",
        "purpose": "Watchtower red-complete progression",
        "dialogue": "The red seal reached Beacon Ridge B. Beacon B is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      }
    ],
    "conditions": [
      {
        "id": "c13",
        "mode": "events",
        "capability": "game_location",
        "arguments": {
          "locationRef": "courtyard"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": "quest_start",
        "usedBy": ["r14"]
      },
      {
        "id": "c15",
        "mode": "events",
        "capability": "game_encounter",
        "arguments": {
          "groupRef": "sentries"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 3
        },
        "since": {
          "stageId": "s2"
        },
        "usedBy": ["r16"]
      },
      {
        "id": "c18",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "guide"
        },
        "comparison": {
          "field": "near",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["interaction:s4", "r19", "r22", "r23"]
      },
      {
        "id": "c24",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r25"]
      },
      {
        "id": "c26",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r27"]
      },
      {
        "id": "c28",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s6"
        },
        "usedBy": ["r29"]
      },
      {
        "id": "c31",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "blue-seal",
          "destinationRef": "beacon-a"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r32"]
      },
      {
        "id": "c34",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r35"]
      },
      {
        "id": "c36",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r37"]
      },
      {
        "id": "c38",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s10"
        },
        "usedBy": ["r39"]
      },
      {
        "id": "c41",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "red-seal",
          "destinationRef": "beacon-b"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r42"]
      }
    ],
    "records": [
      {
        "id": "r14",
        "kind": "transition",
        "from": "s1",
        "to": "s2",
        "conditionId": "c13",
        "priority": 10
      },
      {
        "id": "r16",
        "kind": "transition",
        "from": "s2",
        "to": "s3",
        "conditionId": "c15",
        "priority": 10
      },
      {
        "id": "r17",
        "kind": "consequence",
        "stageId": "s2",
        "capability": "game_activate_group",
        "arguments": {
          "groupRef": "sentries"
        }
      },
      {
        "id": "r19",
        "kind": "transition",
        "from": "s3",
        "to": "s4",
        "conditionId": "c18",
        "priority": 10
      },
      {
        "id": "r20",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "guide"
        }
      },
      {
        "id": "r21",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_open_gate",
        "arguments": {
          "entityRef": "gate"
        }
      },
      {
        "id": "r22",
        "kind": "choice",
        "from": "s4",
        "to": "s5",
        "label": "Blue seal — Beacon Ridge A",
        "conditionId": "c18"
      },
      {
        "id": "r23",
        "kind": "choice",
        "from": "s4",
        "to": "s9",
        "label": "Red seal — Beacon Ridge B",
        "conditionId": "c18"
      },
      {
        "id": "r25",
        "kind": "transition",
        "from": "s5",
        "to": "s7",
        "conditionId": "c24",
        "priority": 10
      },
      {
        "id": "r27",
        "kind": "transition",
        "from": "s5",
        "to": "s6",
        "conditionId": "c26",
        "priority": 20
      },
      {
        "id": "r29",
        "kind": "transition",
        "from": "s6",
        "to": "s7",
        "conditionId": "c28",
        "priority": 10
      },
      {
        "id": "r30",
        "kind": "consequence",
        "stageId": "s6",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "blue-seal"
        }
      },
      {
        "id": "r32",
        "kind": "transition",
        "from": "s7",
        "to": "s8",
        "conditionId": "c31",
        "priority": 10
      },
      {
        "id": "r33",
        "kind": "consequence",
        "stageId": "s8",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-b"
        }
      },
      {
        "id": "r35",
        "kind": "transition",
        "from": "s9",
        "to": "s11",
        "conditionId": "c34",
        "priority": 10
      },
      {
        "id": "r37",
        "kind": "transition",
        "from": "s9",
        "to": "s10",
        "conditionId": "c36",
        "priority": 20
      },
      {
        "id": "r39",
        "kind": "transition",
        "from": "s10",
        "to": "s11",
        "conditionId": "c38",
        "priority": 10
      },
      {
        "id": "r40",
        "kind": "consequence",
        "stageId": "s10",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "red-seal"
        }
      },
      {
        "id": "r42",
        "kind": "transition",
        "from": "s11",
        "to": "s12",
        "conditionId": "c41",
        "priority": 10
      },
      {
        "id": "r43",
        "kind": "consequence",
        "stageId": "s12",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-b"
        }
      }
    ],
    "findings": [],
    "mermaid": "flowchart TD\n  s1[\"s1: approach\"]\n  s2[\"s2: encounter; enter r17: game_activate_group {&quot;groupRef&quot;:&quot;sentries&quot;}\"]\n  s3[\"s3: watchkeeper; enter r20: game_reveal {&quot;entityRef&quot;:&quot;guide&quot;}; enter r21: game_open_gate {&quot;entityRef&quot;:&quot;gate&quot;}\"]\n  s4[\"s4: offer; interaction c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"]\n  s5[\"s5: blue-router\"]\n  s6[\"s6: blue-pickup; enter r30: game_reveal {&quot;entityRef&quot;:&quot;blue-seal&quot;}\"]\n  s7[\"s7: blue-delivery\"]\n  s8[\"s8: blue-complete (ending); enter r33: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-b&quot;}\"]\n  s9[\"s9: red-router\"]\n  s10[\"s10: red-pickup; enter r40: game_reveal {&quot;entityRef&quot;:&quot;red-seal&quot;}\"]\n  s11[\"s11: red-delivery\"]\n  s12[\"s12: red-complete (ending); enter r43: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-b&quot;}\"]\n  s1 -->|\"r14: c13: game_location {&quot;locationRef&quot;:&quot;courtyard&quot;} count at_least 1; events since quest start priority 10\"| s2\n  s2 -->|\"r16: c15: game_encounter {&quot;groupRef&quot;:&quot;sentries&quot;} count at_least 3; events since s2 entry priority 10\"| s3\n  s3 -->|\"r19: c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now priority 10\"| s4\n  s4 -->|\"r22: choice Blue seal — Beacon Ridge A; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s5\n  s4 -->|\"r23: choice Red seal — Beacon Ridge B; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s9\n  s5 -->|\"r25: c24: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals true; fact now priority 10\"| s7\n  s5 -->|\"r27: c26: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals false; fact now priority 20\"| s6\n  s6 -->|\"r29: c28: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} count at_least 1; events since s6 entry priority 10\"| s7\n  s7 -->|\"r32: c31: game_delivery {&quot;itemRef&quot;:&quot;blue-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-a&quot;} delivered equals true; fact now priority 10\"| s8\n  s9 -->|\"r35: c34: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals true; fact now priority 10\"| s11\n  s9 -->|\"r37: c36: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals false; fact now priority 20\"| s10\n  s10 -->|\"r39: c38: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} count at_least 1; events since s10 entry priority 10\"| s11\n  s11 -->|\"r42: c41: game_delivery {&quot;itemRef&quot;:&quot;red-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-b&quot;} delivered equals true; fact now priority 10\"| s12"
  }
}
```

### 58. `edit_record`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 51
  },
  "recordId": "r33",
  "change": {
    "operation": "replace",
    "kind": "consequence",
    "value": {
      "stageId": "s8",
      "capability": "game_light_beacon",
      "arguments": {
        "entityRef": "beacon-a"
      }
    }
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 52,
  "created": {},
  "change": "edit_record",
  "changedId": "r33",
  "savedMeaning": {
    "id": "r33",
    "kind": "consequence",
    "stageId": "s8",
    "capability": "game_light_beacon",
    "arguments": {
      "entityRef": "beacon-a"
    }
  },
  "progress": {
    "stages": 12,
    "conditions": 11,
    "records": 20
  },
  "findings": []
}
```

### 59. `remove_stage`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 52
  },
  "stageId": "s8"
}
```

Observed response:

```json
{
  "status": "rejected",
  "code": "stage_referenced",
  "referencingIds": ["r32", "r33"],
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 52
}
```

### 60. `update_condition`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 52
  },
  "conditionId": "c18",
  "replacement": {
    "mode": "fact",
    "capability": "game_entity",
    "arguments": {
      "entityRef": "guide"
    },
    "comparison": {
      "field": "near",
      "operator": "equals",
      "value": true
    }
  },
  "affectedRecordIds": []
}
```

Observed response:

```json
{
  "status": "rejected",
  "code": "condition_users_changed",
  "affectedRecordIds": ["interaction:s4", "r19", "r22", "r23"],
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 52
}
```

### 61. `review_quest_draft`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 52
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "technicalReady": true,
  "findings": [],
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 52
}
```

### 62. `publish_quest_draft`

Input:

```json
{
  "draft": {
    "id": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 52
  }
}
```

Observed response:

```json
{
  "status": "completed",
  "publication": {
    "definitionId": "definition-e980b960-aceb-43d6-a7c9-26d77959225d",
    "digest": "1b750e44d7a3782de73104ea141cb8efe7a85499c733576cafd375a848677744",
    "sourceRevision": 52
  },
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
  "revision": 52
}
```

### 63. `inspect_quest_draft`

Input:

```json
{
  "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d"
}
```

Observed response:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-1444993b-4130-4ec3-857f-7b9c7276b19d",
    "revision": 52,
    "intent": {
      "title": "Recover the watchtower beacon",
      "premise": "Choose a seal, recover it if not already collected, and complete matching delivery."
    },
    "publication": {
      "definitionId": "definition-e980b960-aceb-43d6-a7c9-26d77959225d",
      "digest": "1b750e44d7a3782de73104ea141cb8efe7a85499c733576cafd375a848677744",
      "sourceRevision": 52
    },
    "startStageId": "s1",
    "stages": [
      {
        "id": "s1",
        "title": "approach",
        "purpose": "Watchtower approach progression",
        "dialogue": "Enter the courtyard to investigate the ruined watchtower.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s2",
        "title": "encounter",
        "purpose": "Watchtower encounter progression",
        "dialogue": "The sentries awaken. Move close to each and press E or click to defeat it.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s3",
        "title": "watchkeeper",
        "purpose": "Watchtower watchkeeper progression",
        "dialogue": "The watchkeeper appears. Approach to learn the route to the beacon.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s4",
        "title": "offer",
        "purpose": "Watchtower offer progression",
        "dialogue": "Watchkeeper: The tower has two paths. Do you want the blue seal or the red seal? Blue belongs at Beacon Ridge A; red belongs at Beacon Ridge B.",
        "ending": false,
        "interaction": "c18"
      },
      {
        "id": "s5",
        "title": "blue-router",
        "purpose": "Watchtower blue-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s6",
        "title": "blue-pickup",
        "purpose": "Watchtower blue-pickup progression",
        "dialogue": "Watchkeeper: You chose blue. Recover the blue seal, then carry it to Beacon Ridge A.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s7",
        "title": "blue-delivery",
        "purpose": "Watchtower blue-delivery progression",
        "dialogue": "Watchkeeper: Deliver the blue seal to Beacon Ridge A. Stand by Beacon A and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s8",
        "title": "blue-complete",
        "purpose": "Watchtower blue-complete progression",
        "dialogue": "The blue seal reached Beacon Ridge A. Beacon A is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      },
      {
        "id": "s9",
        "title": "red-router",
        "purpose": "Watchtower red-router progression",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s10",
        "title": "red-pickup",
        "purpose": "Watchtower red-pickup progression",
        "dialogue": "Watchkeeper: You chose red. Recover the red seal, then carry it to Beacon Ridge B.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s11",
        "title": "red-delivery",
        "purpose": "Watchtower red-delivery progression",
        "dialogue": "Watchkeeper: Deliver the red seal to Beacon Ridge B. Stand by Beacon B and press E or click it. The other beacon cannot accept this seal.",
        "ending": false,
        "interaction": null
      },
      {
        "id": "s12",
        "title": "red-complete",
        "purpose": "Watchtower red-complete progression",
        "dialogue": "The red seal reached Beacon Ridge B. Beacon B is lit. Your chosen mission is complete.",
        "ending": true,
        "interaction": null
      }
    ],
    "conditions": [
      {
        "id": "c13",
        "mode": "events",
        "capability": "game_location",
        "arguments": {
          "locationRef": "courtyard"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": "quest_start",
        "usedBy": ["r14"]
      },
      {
        "id": "c15",
        "mode": "events",
        "capability": "game_encounter",
        "arguments": {
          "groupRef": "sentries"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 3
        },
        "since": {
          "stageId": "s2"
        },
        "usedBy": ["r16"]
      },
      {
        "id": "c18",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "guide"
        },
        "comparison": {
          "field": "near",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["interaction:s4", "r19", "r22", "r23"]
      },
      {
        "id": "c24",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r25"]
      },
      {
        "id": "c26",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r27"]
      },
      {
        "id": "c28",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "blue-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s6"
        },
        "usedBy": ["r29"]
      },
      {
        "id": "c31",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "blue-seal",
          "destinationRef": "beacon-a"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r32"]
      },
      {
        "id": "c34",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r35"]
      },
      {
        "id": "c36",
        "mode": "fact",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "collected",
          "operator": "equals",
          "value": false
        },
        "usedBy": ["r37"]
      },
      {
        "id": "c38",
        "mode": "events",
        "capability": "game_entity",
        "arguments": {
          "entityRef": "red-seal"
        },
        "comparison": {
          "field": "count",
          "operator": "at_least",
          "value": 1
        },
        "since": {
          "stageId": "s10"
        },
        "usedBy": ["r39"]
      },
      {
        "id": "c41",
        "mode": "fact",
        "capability": "game_delivery",
        "arguments": {
          "itemRef": "red-seal",
          "destinationRef": "beacon-b"
        },
        "comparison": {
          "field": "delivered",
          "operator": "equals",
          "value": true
        },
        "usedBy": ["r42"]
      }
    ],
    "records": [
      {
        "id": "r14",
        "kind": "transition",
        "from": "s1",
        "to": "s2",
        "conditionId": "c13",
        "priority": 10
      },
      {
        "id": "r16",
        "kind": "transition",
        "from": "s2",
        "to": "s3",
        "conditionId": "c15",
        "priority": 10
      },
      {
        "id": "r17",
        "kind": "consequence",
        "stageId": "s2",
        "capability": "game_activate_group",
        "arguments": {
          "groupRef": "sentries"
        }
      },
      {
        "id": "r19",
        "kind": "transition",
        "from": "s3",
        "to": "s4",
        "conditionId": "c18",
        "priority": 10
      },
      {
        "id": "r20",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "guide"
        }
      },
      {
        "id": "r21",
        "kind": "consequence",
        "stageId": "s3",
        "capability": "game_open_gate",
        "arguments": {
          "entityRef": "gate"
        }
      },
      {
        "id": "r22",
        "kind": "choice",
        "from": "s4",
        "to": "s5",
        "label": "Blue seal — Beacon Ridge A",
        "conditionId": "c18"
      },
      {
        "id": "r23",
        "kind": "choice",
        "from": "s4",
        "to": "s9",
        "label": "Red seal — Beacon Ridge B",
        "conditionId": "c18"
      },
      {
        "id": "r25",
        "kind": "transition",
        "from": "s5",
        "to": "s7",
        "conditionId": "c24",
        "priority": 10
      },
      {
        "id": "r27",
        "kind": "transition",
        "from": "s5",
        "to": "s6",
        "conditionId": "c26",
        "priority": 20
      },
      {
        "id": "r29",
        "kind": "transition",
        "from": "s6",
        "to": "s7",
        "conditionId": "c28",
        "priority": 10
      },
      {
        "id": "r30",
        "kind": "consequence",
        "stageId": "s6",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "blue-seal"
        }
      },
      {
        "id": "r32",
        "kind": "transition",
        "from": "s7",
        "to": "s8",
        "conditionId": "c31",
        "priority": 10
      },
      {
        "id": "r33",
        "kind": "consequence",
        "stageId": "s8",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-a"
        }
      },
      {
        "id": "r35",
        "kind": "transition",
        "from": "s9",
        "to": "s11",
        "conditionId": "c34",
        "priority": 10
      },
      {
        "id": "r37",
        "kind": "transition",
        "from": "s9",
        "to": "s10",
        "conditionId": "c36",
        "priority": 20
      },
      {
        "id": "r39",
        "kind": "transition",
        "from": "s10",
        "to": "s11",
        "conditionId": "c38",
        "priority": 10
      },
      {
        "id": "r40",
        "kind": "consequence",
        "stageId": "s10",
        "capability": "game_reveal",
        "arguments": {
          "entityRef": "red-seal"
        }
      },
      {
        "id": "r42",
        "kind": "transition",
        "from": "s11",
        "to": "s12",
        "conditionId": "c41",
        "priority": 10
      },
      {
        "id": "r43",
        "kind": "consequence",
        "stageId": "s12",
        "capability": "game_light_beacon",
        "arguments": {
          "entityRef": "beacon-b"
        }
      }
    ],
    "findings": [],
    "mermaid": "flowchart TD\n  s1[\"s1: approach\"]\n  s2[\"s2: encounter; enter r17: game_activate_group {&quot;groupRef&quot;:&quot;sentries&quot;}\"]\n  s3[\"s3: watchkeeper; enter r20: game_reveal {&quot;entityRef&quot;:&quot;guide&quot;}; enter r21: game_open_gate {&quot;entityRef&quot;:&quot;gate&quot;}\"]\n  s4[\"s4: offer; interaction c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"]\n  s5[\"s5: blue-router\"]\n  s6[\"s6: blue-pickup; enter r30: game_reveal {&quot;entityRef&quot;:&quot;blue-seal&quot;}\"]\n  s7[\"s7: blue-delivery\"]\n  s8[\"s8: blue-complete (ending); enter r33: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-a&quot;}\"]\n  s9[\"s9: red-router\"]\n  s10[\"s10: red-pickup; enter r40: game_reveal {&quot;entityRef&quot;:&quot;red-seal&quot;}\"]\n  s11[\"s11: red-delivery\"]\n  s12[\"s12: red-complete (ending); enter r43: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-b&quot;}\"]\n  s1 -->|\"r14: c13: game_location {&quot;locationRef&quot;:&quot;courtyard&quot;} count at_least 1; events since quest start priority 10\"| s2\n  s2 -->|\"r16: c15: game_encounter {&quot;groupRef&quot;:&quot;sentries&quot;} count at_least 3; events since s2 entry priority 10\"| s3\n  s3 -->|\"r19: c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now priority 10\"| s4\n  s4 -->|\"r22: choice Blue seal — Beacon Ridge A; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s5\n  s4 -->|\"r23: choice Red seal — Beacon Ridge B; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now\"| s9\n  s5 -->|\"r25: c24: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals true; fact now priority 10\"| s7\n  s5 -->|\"r27: c26: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals false; fact now priority 20\"| s6\n  s6 -->|\"r29: c28: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} count at_least 1; events since s6 entry priority 10\"| s7\n  s7 -->|\"r32: c31: game_delivery {&quot;itemRef&quot;:&quot;blue-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-a&quot;} delivered equals true; fact now priority 10\"| s8\n  s9 -->|\"r35: c34: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals true; fact now priority 10\"| s11\n  s9 -->|\"r37: c36: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals false; fact now priority 20\"| s10\n  s10 -->|\"r39: c38: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} count at_least 1; events since s10 entry priority 10\"| s11\n  s11 -->|\"r42: c41: game_delivery {&quot;itemRef&quot;:&quot;red-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-b&quot;} delivered equals true; fact now priority 10\"| s12"
  }
}
```

## Final saved logic

```mermaid
flowchart TD
  s1["s1: approach"]
  s2["s2: encounter; enter r17: game_activate_group {&quot;groupRef&quot;:&quot;sentries&quot;}"]
  s3["s3: watchkeeper; enter r20: game_reveal {&quot;entityRef&quot;:&quot;guide&quot;}; enter r21: game_open_gate {&quot;entityRef&quot;:&quot;gate&quot;}"]
  s4["s4: offer; interaction c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now"]
  s5["s5: blue-router"]
  s6["s6: blue-pickup; enter r30: game_reveal {&quot;entityRef&quot;:&quot;blue-seal&quot;}"]
  s7["s7: blue-delivery"]
  s8["s8: blue-complete (ending); enter r33: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-a&quot;}"]
  s9["s9: red-router"]
  s10["s10: red-pickup; enter r40: game_reveal {&quot;entityRef&quot;:&quot;red-seal&quot;}"]
  s11["s11: red-delivery"]
  s12["s12: red-complete (ending); enter r43: game_light_beacon {&quot;entityRef&quot;:&quot;beacon-b&quot;}"]
  s1 -->|"r14: c13: game_location {&quot;locationRef&quot;:&quot;courtyard&quot;} count at_least 1; events since quest start priority 10"| s2
  s2 -->|"r16: c15: game_encounter {&quot;groupRef&quot;:&quot;sentries&quot;} count at_least 3; events since s2 entry priority 10"| s3
  s3 -->|"r19: c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now priority 10"| s4
  s4 -->|"r22: choice Blue seal — Beacon Ridge A; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now"| s5
  s4 -->|"r23: choice Red seal — Beacon Ridge B; c18: game_entity {&quot;entityRef&quot;:&quot;guide&quot;} near equals true; fact now"| s9
  s5 -->|"r25: c24: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals true; fact now priority 10"| s7
  s5 -->|"r27: c26: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} collected equals false; fact now priority 20"| s6
  s6 -->|"r29: c28: game_entity {&quot;entityRef&quot;:&quot;blue-seal&quot;} count at_least 1; events since s6 entry priority 10"| s7
  s7 -->|"r32: c31: game_delivery {&quot;itemRef&quot;:&quot;blue-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-a&quot;} delivered equals true; fact now priority 10"| s8
  s9 -->|"r35: c34: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals true; fact now priority 10"| s11
  s9 -->|"r37: c36: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} collected equals false; fact now priority 20"| s10
  s10 -->|"r39: c38: game_entity {&quot;entityRef&quot;:&quot;red-seal&quot;} count at_least 1; events since s10 entry priority 10"| s11
  s11 -->|"r42: c41: game_delivery {&quot;itemRef&quot;:&quot;red-seal&quot;,&quot;destinationRef&quot;:&quot;beacon-b&quot;} delivered equals true; fact now priority 10"| s12
```

Exact condition/action details appear in the inspection responses above. The diagram is generated from saved authoring records at the same revision.
