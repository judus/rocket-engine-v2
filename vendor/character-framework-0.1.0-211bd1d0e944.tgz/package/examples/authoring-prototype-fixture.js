import { CharacterRuntime } from '../dist/src/index.js';
import { QuestAuthoringPrototype } from '../dist/src/authoring/index.js';
import { McpGateway } from '../dist/src/mcp/index.js';
import { FakeCaiClient } from './fake-cai-client.js';
import { setImmediate } from 'node:timers/promises';

/** Offline real MCP transport/service; game adapter is explicitly a volatile fake. */
export async function createAuthoringPrototypeFixture(path) {
  let authorized = true;
  let sequence = 0,
    inside = false,
    visited = false;
  const entries = [],
    captures = new Map();
  const location = {
    name: 'rocket_inspect_grove',
    kind: 'inspection',
    description:
      'Offline adapter matching Rocket grove descriptor; its own volatile world authority.',
    inputSchema: {
      type: 'object',
      properties: { locationRef: { const: 'grove' } },
      required: ['locationRef'],
      additionalProperties: false,
    },
    outputSchema: {
      type: 'object',
      properties: {
        inside: { type: 'boolean' },
        visited: { type: 'boolean' },
        entries: { type: 'integer', minimum: 0 },
      },
      required: ['inside', 'visited', 'entries'],
      additionalProperties: false,
    },
    evidenceStream: { ref: 'grove-entries', captureKeys: ['locationRef'] },
    validate: (args) =>
      args?.locationRef === 'grove' && Object.keys(args).length === 1,
    execute: (context) => ({
      status: 'completed',
      data: {
        inside,
        visited,
        entries: entries.filter(
          (event) => event > (context.narrative?.evidence?.cursor ?? -1),
        ).length,
      },
    }),
  };
  const authoring = new QuestAuthoringPrototype({
    path,
    authorId: 'visit-prototype-author',
    authorize: (context) =>
      authorized && context.character.id === 'author-prototype',
    capabilities: [location],
    references: { location: ['grove'] },
    referenceBindings: {
      rocket_inspect_grove: [{ path: ['locationRef'], category: 'location' }],
    },
  });
  const runtime = new CharacterRuntime({
    gameId: 'cfw-authoring-visit-proof',
    capabilities: [location, ...authoring.tools],
    situationGame: {
      capabilities: () => [location],
      scopeAvailable: (_, scope) =>
        scope.kind === 'player' && scope.ref === 'player',
      capture: (context, stream, args) => {
        if (stream !== 'grove-entries' || args.locationRef !== 'grove')
          throw new Error('Unknown evidence scope');
        const key = context.narrative.effectId;
        if (!key) throw new Error('Capture requires original effect identity');
        if (!captures.has(key)) captures.set(key, sequence);
        return captures.get(key);
      },
      observe: (context, observations) => ({
        revision: String(sequence),
        results: observations.map((observation) =>
          observation.capability.execute(
            {
              ...context,
              narrative: {
                ...context.narrative,
                evidence: observation.evidence,
              },
            },
            observation.arguments,
          ),
        ),
      }),
      observationCurrent: (_, revision) => revision === String(sequence),
      reconcile: () => ({ status: 'not_admitted' }),
      persist: () => {},
      retire: () => {},
    },
  });
  const director = runtime.register({
    id: 'grove-director',
    name: 'Offline grove director',
    capabilities: [location.name],
  });
  const game = {
    runtime,
    system: runtime.situations,
    handle: runtime.situations.bind(director),
    enter() {
      if (!inside) {
        inside = true;
        visited = true;
        entries.push(++sequence);
      }
    },
    leave() {
      if (inside) {
        inside = false;
        sequence++;
      }
    },
    dispose() {
      runtime.dispose();
    },
  };
  const actor = game.runtime.register({
    id: 'author-prototype',
    name: 'Authoring prototype',
    binding: { id: 'prototype-stable-binding', generation: 'host-reopen' },
    cai: { characterId: 'offline-author', sessionId: 'offline-author-session' },
    capabilities: authoring.tools.map((t) => t.name),
  });
  const credential = 'offline-authoring-prototype-only';
  const gateway = new McpGateway({
    maxRequestBytes: 1024 * 1024,
    runtime: game.runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
  });
  const headers = gateway.bind('prototype-author', actor, authoring.tools);
  const client = new FakeCaiClient(
    new URL('http://127.0.0.1:8094/mcp'),
    headers,
    credential,
    (url, init) => gateway.handle(new Request(url, init)),
  );
  await client.connect();
  let delivery = 0;
  async function pump(promise) {
    let settled = false;
    promise.then(
      () => {
        settled = true;
      },
      () => {
        settled = true;
      },
    );
    for (let i = 0; i < 1000 && !settled; i++) {
      game.runtime.advance(0);
      gateway.advance(0);
      await setImmediate();
    }
    if (!settled) throw new Error('Prototype host command did not settle');
    return promise;
  }
  async function call(name, args, effectKey) {
    const result = await pump(
      client.call(name, args, {
        callId: 'delivery-' + ++delivery,
        turnId: 'offline-authoring-turn',
        ...(effectKey ? { effectKey } : {}),
      }),
    );
    return result.structuredContent ?? JSON.parse(result.content[0].text);
  }
  return {
    gateway,
    game,
    authoring,
    client,
    call,
    pump,
    revoke: () => {
      authorized = false;
    },
    async close() {
      await client.close();
      await gateway.dispose();
      game.dispose();
      authoring.close();
    },
  };
}

export const visitFragment = {
  entrySituation: 'watch',
  situations: [
    {
      id: 'watch',
      routes: [
        {
          id: 'entered',
          priority: 10,
          when: {
            tool: 'rocket_inspect_grove',
            arguments: { locationRef: 'grove' },
            expect: { path: ['entries'], operator: 'at_least', value: 1 },
            evidence: { mode: 'events', after: { kind: 'run-start' } },
          },
          next: 'end',
        },
      ],
    },
    { id: 'end' },
  ],
  outcomeBindings: [],
};
