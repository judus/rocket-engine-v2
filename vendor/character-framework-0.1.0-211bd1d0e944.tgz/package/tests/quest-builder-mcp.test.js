import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import {
  CharacterRuntime,
  validateSituationDefinition,
} from '../dist/src/index.js';
import { setImmediate } from 'node:timers/promises';
import { createQuestBuilderMcpFixture } from '../examples/quest-builder-mcp-fixture.js';

const example = JSON.parse(
  await readFile(
    new URL(
      '../docs/contracts/watchtower-authoring-example.json',
      import.meta.url,
    ),
    'utf8',
  ),
);
async function fixture(t, vocabulary = example) {
  const dir = await mkdtemp(join(tmpdir(), 'cfw-builder-mcp-'));
  const path = join(dir, 'author.sqlite');
  const f = await createQuestBuilderMcpFixture(path, vocabulary);
  t.after(async () => {
    await f.close();
    await rm(dir, { recursive: true });
  });
  return { ...f, path };
}
test('registered builder discovers 24 typed tools with restricted catalogue and durable mutation replay', async (t) => {
  const f = await fixture(t);
  const { tools } = await f.client.client.listTools();
  assert.equal(tools.length, 24);
  assert.equal(
    tools.find((t) => t.name === 'add_stage').annotations.readOnlyHint,
    false,
  );
  assert.equal(
    tools.find((t) => t.name === 'from_action_result').annotations.readOnlyHint,
    true,
  );
  assert.deepEqual(
    tools.find((t) => t.name === 'read_quest_draft').inputSchema.properties
      .section,
    { const: 'catalogue' },
  );
  assert.equal(
    (await f.call('read_quest_draft', { section: 'catalogue' })).data
      .capabilities.length,
    example.capabilities.length,
  );
  assert.equal(
    (await f.call('read_quest_draft', { section: 'beat' })).status,
    'rejected',
  );
  const args = { title: 'Recover watchtower', premise: 'A supported quest' };
  const created = await f.call('create_quest_draft', args, 'create');
  assert.equal(created.status, 'completed');
  assert.deepEqual(await f.call('create_quest_draft', args, 'create'), created);
  assert.equal(
    (
      await f.call(
        'create_quest_draft',
        { ...args, title: 'Different' },
        'create',
      )
    ).code,
    'effect_key_conflict',
  );
  const outcome = await f.call('get_authoring_command_outcome', {
    commandId: created.data.commandId,
  });
  assert.deepEqual(outcome.data.result, created);
  assert.equal((await f.call('list_quest_drafts', {})).data.items.length, 1);
  f.revoke();
  assert.equal(
    (await f.call('inspect_quest_draft', { draftId: created.data.draftId }))
      .code,
    'permission_denied',
  );
});

test('registered builder rejects publication outside granted reference categories', async (t) => {
  const f = await fixture(t, {
    ...example,
    references: { ...example.references, location: [] },
  });
  const created = await f.call(
    'create_quest_draft',
    { title: 'Grant proof', premise: 'Restricted vocabulary' },
    'create',
  );
  let draft = { id: created.data.draftId, revision: created.data.revision };
  const edit = async (name, args, key) => {
    const r = await f.call(name, { draft, ...args }, key);
    if (r.status === 'completed' && r.data.revision)
      draft = { id: draft.id, revision: r.data.revision };
    return r;
  };
  const s = (await edit('add_stage', { title: 'End', purpose: 'End' }, 'stage'))
    .data.created.stageId;
  const c = (
    await edit(
      'create_fact_condition',
      {
        capability: 'game_location',
        arguments: { locationRef: 'courtyard' },
        comparison: { path: ['visited'], operator: 'equals', value: true },
      },
      'condition',
    )
  ).data.created.conditionId;
  await edit(
    'add_objective',
    { stageId: s, description: 'Visit', conditionId: c },
    'objective',
  );
  await edit('set_start_stage', { stageId: s }, 'start');
  await edit('declare_ending', { stageId: s, ending: true }, 'ending');
  const review = await edit('review_quest_draft', {});
  assert.equal(review.data.technicalReady, false);
  assert.ok(
    review.data.findings.some((f) =>
      f.message.includes('Unpermitted reference'),
    ),
  );
  const pub = await edit('publish_quest_draft', {}, 'publish');
  assert.equal(pub.status, 'rejected');
  assert.deepEqual(
    await f.call('publish_quest_draft', { draft }, 'publish'),
    pub,
  );
});

test('registered builder accepts publication beyond the old 12KiB fragment budget', async (t) => {
  const f = await fixture(t);
  const created = await f.call(
    'create_quest_draft',
    { title: 'Budget', premise: 'Oversize graph' },
    'create',
  );
  let draft = { id: created.data.draftId, revision: created.data.revision };
  let sequence = 0;
  const edit = async (name, args) => {
    const r = await f.call(name, { draft, ...args }, `edit-${++sequence}`);
    assert.equal(r.status, 'completed');
    if (r.data.revision) draft = { id: draft.id, revision: r.data.revision };
    return r;
  };
  const stages = [];
  for (let i = 0; i < 7; i++)
    stages.push(
      (
        await edit('add_stage', {
          title: `Stage${i}`,
          purpose: 'Progress',
          dialogue: 'x'.repeat(1990),
        })
      ).data.created.stageId,
    );
  const c = (
    await edit('create_fact_condition', {
      capability: 'game_entity',
      arguments: { entityRef: 'guide' },
      comparison: { path: ['near'], operator: 'equals', value: true },
    })
  ).data.created.conditionId;
  for (let i = 0; i < 6; i++)
    await edit('add_transition', {
      from: stages[i],
      to: stages[i + 1],
      conditionId: c,
      priority: 10,
    });
  await edit('set_start_stage', { stageId: stages[0] });
  await edit('declare_ending', { stageId: stages[6], ending: true });
  const review = await edit('review_quest_draft', {});
  assert.equal(review.data.technicalReady, true);
  assert.equal(
    (await f.call('publish_quest_draft', { draft }, 'publish')).status,
    'completed',
  );
});

test('registered builder storage uses namespace capacity rather than the tool-message budget', async (t) => {
  const f = await fixture(t);
  for (let i = 0; i < 16; i++) {
    const r = await f.call(
      'create_quest_draft',
      { title: 't'.repeat(2000), premise: 'p'.repeat(2000) },
      `create-${i}`,
    );
    assert.equal(r.status, 'completed');
  }
  const listed = await f.call('list_quest_drafts', {});
  assert.equal(listed.data.items.length, 16);
  assert.ok(Buffer.byteLength(JSON.stringify(listed)) < 65536);
  const overflow = await f.call(
    'create_quest_draft',
    { title: 'Seventeenth', premise: 'Explicit limit' },
    'overflow',
  );
  assert.equal(overflow.code, 'capacity_exceeded');
  assert.deepEqual(
    await f.call(
      'create_quest_draft',
      { title: 'Seventeenth', premise: 'Explicit limit' },
      'overflow',
    ),
    overflow,
  );
});
test('builder publication and original edit receipts survive a new process and host-only definitions remain private', async (t) => {
  const f = await fixture(t);
  const args = { title: 'Terminal proof', premise: 'One deliberate ending' };
  const created = await f.call('create_quest_draft', args, 'create');
  const s = await f.call(
    'add_stage',
    {
      draft: { id: created.data.draftId, revision: 1 },
      title: 'Ending',
      purpose: 'Resolve',
    },
    'stage',
  );
  const start = await f.call(
    'set_start_stage',
    {
      draft: { id: created.data.draftId, revision: s.data.revision },
      stageId: s.data.created.stageId,
    },
    'start',
  );
  const end = await f.call(
    'declare_ending',
    {
      draft: { id: created.data.draftId, revision: start.data.revision },
      stageId: s.data.created.stageId,
      ending: true,
    },
    'end',
  );
  const pub = await f.call(
    'publish_quest_draft',
    { draft: { id: created.data.draftId, revision: end.data.revision } },
    'publish',
  );
  assert.equal(pub.status, 'completed');
  assert.equal(
    f.author.readPublishedDefinition(pub.data.publication.definitionId)
      .situations.length,
    1,
  );
  const view = await f.call('inspect_quest_draft', {
    draftId: created.data.draftId,
  });
  assert.equal(
    view.data.publication.definitionId,
    pub.data.publication.definitionId,
  );
  assert.equal(Object.hasOwn(view.data, 'situations'), false);
  assert.equal(
    (
      await f.call(
        'update_quest_intent',
        {
          draft: { id: created.data.draftId, revision: end.data.revision },
          title: 'Other',
          premise: 'Other',
        },
        'frozen',
      )
    ).code,
    'draft_published',
  );
  const script = `import {QuestBuilderAuthoring} from ${JSON.stringify(new URL('../dist/src/authoring/index.js', import.meta.url).href)};const a=new QuestBuilderAuthoring({path:${JSON.stringify(f.path)},authorId:'builder-author',authorize:()=>true,capabilities:[],references:{},referenceBindings:{}});const r=await a.tools.find(t=>t.name==='create_quest_draft').execute({character:{},signal:new AbortController().signal,mutation:{id:${JSON.stringify(created.data.commandId)}}},${JSON.stringify(args)});console.log(JSON.stringify({result:r,definition:a.readPublishedDefinition(${JSON.stringify(pub.data.publication.definitionId)}).id}));await a.close();`;
  const child = spawnSync(
    process.execPath,
    ['--input-type=module', '-e', script],
    { encoding: 'utf8' },
  );
  assert.ifError(child.error);
  assert.equal(child.status, 0, child.stderr);
  const recovered = JSON.parse(child.stdout);
  assert.deepEqual(recovered.result, created);
  assert.equal(recovered.definition, pub.data.publication.definitionId);
});

test('128-stage large definition survives native authoring, paged inspection, reopen, runtime playback and checkpoint restore', async (t) => {
  const f = await fixture(t);
  const created = await f.call(
    'create_quest_draft',
    { title: 'Large quest', premise: 'Capacity proof, no provider' },
    'large-create',
  );
  let draft = { id: created.data.draftId, revision: created.data.revision },
    seq = 0;
  const edit = async (name, args) => {
    const r = await f.call(name, { draft, ...args }, `large-${++seq}`);
    assert.equal(r.status, 'completed', JSON.stringify(r));
    draft = { id: draft.id, revision: r.data.revision };
    return r.data;
  };
  const stages = [];
  for (let i = 0; i < 128; i++)
    stages.push(
      (
        await edit('add_stage', {
          title: `Stage ${i}`,
          purpose: 'Observe and continue',
          dialogue: '界'.repeat(500),
        })
      ).created.stageId,
    );
  const rejected = await f.call(
    'add_stage',
    { draft, title: '129th', purpose: 'Must reject' },
    'stage-overflow',
  );
  assert.equal(rejected.status, 'rejected');
  assert.equal(rejected.revision, draft.revision);
  assert.deepEqual(
    await f.call(
      'add_stage',
      { draft, title: '129th', purpose: 'Must reject' },
      'stage-overflow',
    ),
    rejected,
  );
  const conditionId = (
    await edit('create_fact_condition', {
      capability: 'game_entity',
      arguments: { entityRef: 'guide' },
      comparison: { path: ['near'], operator: 'equals', value: true },
    })
  ).created.conditionId;
  for (let i = 0; i < 127; i++)
    await edit('add_transition', {
      from: stages[i],
      to: stages[i + 1],
      conditionId,
      priority: 1,
    });
  await edit('set_start_stage', { stageId: stages[0] });
  await edit('declare_ending', { stageId: stages[127], ending: true });
  const summary = (await f.call('inspect_quest_draft', { draftId: draft.id }))
    .data;
  assert.equal(summary.section, 'summary');
  assert.equal(summary.counts.stages, 128);
  const collected = [];
  let offset = 0;
  do {
    const page = (
      await f.call('inspect_quest_draft', {
        draftId: draft.id,
        section: 'stages',
        expectedRevision: draft.revision,
        offset,
        limit: 8,
      })
    ).data;
    assert.ok(Buffer.byteLength(JSON.stringify(page)) < 65536);
    collected.push(...page.items);
    offset = page.nextOffset;
  } while (offset !== null);
  assert.deepEqual(
    collected.map((s) => s.id),
    stages,
  );
  const stale = await f.call('inspect_quest_draft', {
    draftId: draft.id,
    section: 'records',
    expectedRevision: draft.revision - 1,
  });
  assert.equal(stale.status, 'rejected');
  let diagram = '';
  offset = 0;
  do {
    const page = (
      await f.call('inspect_quest_draft', {
        draftId: draft.id,
        section: 'mermaid',
        expectedRevision: draft.revision,
        offset,
      })
    ).data;
    diagram += page.text;
    offset = page.nextOffset;
  } while (offset !== null);
  assert.match(diagram, /flowchart TD/);
  assert.ok(diagram.includes(stages[127]));
  assert.equal(
    (await f.call('review_quest_draft', { draft })).data.technicalReady,
    true,
  );
  const published = await f.call(
    'publish_quest_draft',
    { draft },
    'large-publish',
  );
  assert.equal(published.status, 'completed');
  const definition = f.author.readPublishedDefinition(
    published.data.publication.definitionId,
  );
  const bytes = Buffer.byteLength(JSON.stringify(definition));
  assert.ok(bytes > 65536 && bytes <= 262144, String(bytes));
  const reopened = await createQuestBuilderMcpFixture(f.path, example);
  try {
    assert.deepEqual(
      reopened.author.readPublishedDefinition(definition.id),
      definition,
    );
    assert.deepEqual(
      await reopened.call('publish_quest_draft', { draft }, 'large-publish'),
      published,
    );
  } finally {
    await reopened.close();
  }
  const caps = example.capabilities.map((c) => ({
    ...c,
    validate: () => true,
    execute: () => ({
      status: 'completed',
      data: { near: true, visible: true, collected: false, count: 0 },
    }),
  }));
  assert.deepEqual(validateSituationDefinition(definition, caps), []);
  const exactBudget = structuredClone(definition);
  for (const stage of exactBudget.situations) {
    const remaining = 262144 - Buffer.byteLength(JSON.stringify(exactBudget));
    stage.dialogue.text += 'x'.repeat(
      Math.min(remaining, 2000 - stage.dialogue.text.length),
    );
    if (remaining === 0) break;
  }
  assert.equal(Buffer.byteLength(JSON.stringify(exactBudget)), 262144);
  assert.deepEqual(validateSituationDefinition(exactBudget, caps), []);
  const overBudget = structuredClone(exactBudget);
  overBudget.situations.find(
    (s) => s.dialogue.text.length < 2000,
  ).dialogue.text += 'x';
  assert.equal(Buffer.byteLength(JSON.stringify(overBudget)), 262145);
  assert.match(
    validateSituationDefinition(overBudget, caps).join(';'),
    /262144-byte/,
  );
  const tooLarge = structuredClone(definition);
  tooLarge.situations[0].dialogue.text = '界'.repeat(100000);
  assert.match(
    validateSituationDefinition(tooLarge, caps).join(';'),
    /262144-byte/,
  );
  const tooMany = structuredClone(definition);
  tooMany.situations.push({ id: 'overflow' });
  assert.notDeepEqual(validateSituationDefinition(tooMany, caps), []);
  const runtime = new CharacterRuntime({
    gameId: 'large-playback',
    capabilities: caps,
    situationGame: {
      capabilities: () => caps,
      scopeAvailable: () => true,
      capture: () => 0,
      observe: async (c, queries) => ({
        revision: '0',
        results: await Promise.all(
          queries.map((q) => q.capability.execute(c, q.arguments)),
        ),
      }),
      observationCurrent: () => true,
      reconcile: () => ({ status: 'not_admitted' }),
      persist: () => {},
      retire: () => {},
    },
  });
  try {
    const actor = runtime.register({
      id: 'reader',
      name: 'Reader',
      capabilities: caps.map((c) => c.name),
    });
    const h = runtime.situations.bind(actor);
    const pump = async (p) => {
      let done = false;
      void p.then(
        () => {
          done = true;
        },
        () => {
          done = true;
        },
      );
      for (let i = 0; i < 1000 && !done; i++) {
        runtime.advance(0);
        await setImmediate();
      }
      assert.ok(done);
      return p;
    };
    await pump(h.publish(definition, 'publish'));
    const { runId } = await pump(
      h.start(definition.id, { kind: 'world' }, 'start'),
    );
    for (let i = 0; i < 1000 && h.read(runId).status !== 'closed'; i++) {
      runtime.advance(0);
      await setImmediate();
    }
    assert.equal(h.read(runId).status, 'closed');
    assert.equal(h.read(runId).situationId, stages[127]);
    const save = runtime.situations.save();
    assert.equal(save.runs[0].path.length, 128);
    runtime.situations.restore(save);
    assert.equal(h.read(runId).status, 'closed');
  } finally {
    runtime.dispose();
  }
});

test('builder retains more than one generation of 512 mutation receipts without evicting original effects', async (t) => {
  const f = await fixture(t);
  const args = { title: 'Original', premise: 'Retain exact first receipt' };
  const created = await f.call('create_quest_draft', args, 'original');
  let draft = { id: created.data.draftId, revision: created.data.revision };
  for (let i = 0; i < 520; i++) {
    const r = await f.call(
      'update_quest_intent',
      { draft, title: `Revision ${i}`, premise: 'Continue across invocations' },
      `retained-${i}`,
    );
    assert.equal(r.status, 'completed');
    draft = { id: draft.id, revision: r.data.revision };
  }
  assert.deepEqual(
    await f.call('create_quest_draft', args, 'original'),
    created,
  );
  const reopened = await createQuestBuilderMcpFixture(f.path, example);
  try {
    assert.deepEqual(
      await reopened.call('create_quest_draft', args, 'original'),
      created,
    );
  } finally {
    await reopened.close();
  }
});
