import test from 'node:test';
import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { createMcpScenario } from '../dist/examples/mcp-scenario.js';
import { McpGateway } from '../dist/src/mcp/index.js';
import { CharacterRuntime } from '../dist/src/index.js';
import { FakeCaiClient } from '../examples/fake-cai-client.js';

const url = 'http://127.0.0.1:8094/mcp';
const credential = 'test-only-association-key';
let sequence = 0;
function fixture(t) {
  const scenario = createMcpScenario(credential);
  t.after(() => scenario.dispose());
  return scenario;
}
async function request(scenario, binding, body, extra = {}, method = 'POST') {
  return scenario.gateway.handle(
    new Request(url, {
      method,
      headers: {
        Authorization: `Bearer ${credential}`,
        Accept: 'application/json, text/event-stream',
        'Content-Type': 'application/json',
        ...binding,
        ...extra,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    }),
  );
}
async function connect(scenario, binding) {
  const response = await request(scenario, binding, {
    jsonrpc: '2.0',
    id: ++sequence,
    method: 'initialize',
    params: {
      protocolVersion: '2025-11-25',
      capabilities: {},
      clientInfo: { name: 'test-cai', version: '1' },
    },
  });
  assert.equal(response.status, 200);
  assert.equal((await response.json()).result.protocolVersion, '2025-11-25');
  const session = response.headers.get('mcp-session-id');
  assert.ok(session);
  const headers = {
    ...binding,
    'Mcp-Session-Id': session,
    'MCP-Protocol-Version': '2025-11-25',
  };
  const ready = await request(scenario, headers, {
    jsonrpc: '2.0',
    method: 'notifications/initialized',
  });
  assert.equal(ready.status, 202);
  return headers;
}
async function pump(scenario, promise) {
  let done = false;
  promise.then(
    () => {
      done = true;
    },
    () => {
      done = true;
    },
  );
  for (let i = 0; i < 1000 && !done; i++) {
    scenario.advance(0);
    await setImmediate();
  }
  assert.ok(done, 'Host-driven tool call must settle');
  return promise;
}
function call(scenario, headers, name, args = {}, key, extra = {}) {
  return request(
    scenario,
    headers,
    {
      jsonrpc: '2.0',
      id: ++sequence,
      method: 'tools/call',
      params: { name, arguments: args },
    },
    {
      'X-CF-Call-Id': `logical-${key ?? sequence}`,
      'X-CF-Turn-Request-Id': 'turn-1',
      ...(key ? { 'X-CF-Effect-Key': key } : {}),
      ...extra,
    },
  );
}
async function result(scenario, promise) {
  const response = await pump(scenario, promise);
  assert.equal(response.status, 200);
  const value = await response.json();
  assert.ok(value.result, JSON.stringify(value));
  assert.deepEqual(
    JSON.parse(value.result.content[0].text),
    value.result.structuredContent,
  );
  return value.result;
}
const quest = (scenario) =>
  scenario.draft('A winter survey', 'grove-1').toInput();

for (const choiceCount of [3, 4]) {
  test(`MCP returns schema-valid ${choiceCount}-choice branches with opaque IDs`, async (t) => {
    const scenario = fixture(t);
    const client = new FakeCaiClient(
      new URL(url),
      scenario.directorHeaders,
      credential,
      (target, init) => scenario.gateway.handle(new Request(target, init)),
    );
    await client.connect();
    t.after(() => client.close());
    const tools = await client.client.listTools();
    assert.ok(
      tools.tools.find((tool) => tool.name === 'create_quest').inputSchema
        .properties.quest.properties.flow,
    );
    const input = structuredClone(quest(scenario));
    const town = scenario.draft('Town', 'river-town').toInput().quest
      .objectives[0];
    input.quest.objectives = [
      { ...input.quest.objectives[0], id: 'survey' },
      { ...town, id: 'town' },
    ];
    input.quest.flow = {
      start: 'survey',
      stages: [
        {
          id: 'survey',
          objectives: ['survey'],
          choices: Array.from({ length: choiceCount }, (_, i) => ({
            id: '森'.repeat(159) + i,
            label: `Route ${i}`,
            next: 'town',
          })),
        },
        { id: 'town', objectives: ['town'] },
      ],
    };
    const headers = await connect(scenario, scenario.directorHeaders);
    const created = await result(
      scenario,
      call(scenario, headers, 'create_quest', input, 'flow-create'),
    );
    assert.equal(created.structuredContent.status, 'completed');
    const questId = created.structuredContent.data.questId;
    const offered = await result(
      scenario,
      call(
        scenario,
        headers,
        'offer_quest',
        { questId, recipientRef: 'player-1', dialogue: 'Help?' },
        'flow-offer',
      ),
    );
    await pump(
      scenario,
      scenario.narrative.choose(
        'player-1',
        offered.structuredContent.data.choices[0].id,
        'flow-accept',
      ),
    );
    scenario.visit('grove-1');
    for (let i = 0; i < 6; i++) {
      scenario.advance(0.1);
      await setImmediate();
    }
    const inspected = await pump(
      scenario,
      client.call(
        'inspect_quest',
        { questId, recipientRef: 'player-1' },
        { callId: 'flow-inspect', turnId: 'flow-turn' },
      ),
    );
    assert.equal(inspected.isError, false);
    assert.equal(inspected.structuredContent.data.flow.currentStage, 'survey');
    assert.equal(inspected.structuredContent.data.choices.length, choiceCount);
    assert.equal(inspected.structuredContent.data.choices[0].label, 'Route 0');
    assert.ok(inspected.structuredContent.data.choices[0].id.length > 160);
  });
}

test('official SDK client negotiates and retains full output schemas with isolated discovery', async (t) => {
  const scenario = fixture(t);
  const fetch_ = (target, init) =>
    scenario.gateway.handle(new Request(target, init));
  const forester = new FakeCaiClient(
    new URL(url),
    scenario.foresterHeaders,
    credential,
    fetch_,
  );
  const director = new FakeCaiClient(
    new URL(url),
    scenario.directorHeaders,
    credential,
    fetch_,
  );
  await Promise.all([forester.connect(), director.connect()]);
  t.after(() => Promise.all([forester.close(), director.close()]));
  const [local, world] = await Promise.all([
    forester.client.listTools(),
    director.client.listTools(),
  ]);
  assert.ok(local.tools.some((tool) => tool.name === 'request_work'));
  assert.ok(!world.tools.some((tool) => tool.name === 'request_work'));
  const schema = local.tools.find((tool) => tool.name === 'create_quest');
  assert.equal(schema.outputSchema.type, 'object');
  assert.equal(
    schema.inputSchema.properties.quest.properties.objectives.items.properties
      .condition.properties.arguments.maxProperties,
    16,
  );
  const outcomes = await pump(
    scenario,
    Promise.all([
      forester.call(
        'inspect_context',
        { scope: 'world' },
        { callId: 'local', turnId: 'chat' },
      ),
      director.call(
        'inspect_context',
        { scope: 'world' },
        { callId: 'world', turnId: 'story' },
      ),
    ]),
  );
  assert.equal(outcomes[0].structuredContent.code, 'scope_denied');
  assert.equal(outcomes[0].isError, true);
  assert.equal(outcomes[1].structuredContent.data.characterRef, 'director');
});

test('credentials, origins, hosts, crossed sessions and stale generations fail before discovery/effects', async (t) => {
  const scenario = fixture(t);
  const forester = await connect(scenario, scenario.foresterHeaders);
  const message = { jsonrpc: '2.0', id: ++sequence, method: 'tools/list' };
  assert.equal(
    (
      await request(scenario, forester, message, {
        Authorization: 'Bearer wrong',
      })
    ).status,
    401,
  );
  assert.equal(
    (
      await request(scenario, forester, message, {
        Origin: 'https://untrusted.example',
      })
    ).status,
    403,
  );
  assert.equal(
    (await request(scenario, forester, message, { Host: 'untrusted.example' }))
      .status,
    403,
  );
  assert.equal(
    (
      await request(
        scenario,
        { ...forester, 'X-CF-CAI-Session-Id': 'demo-session-2' },
        message,
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await request(
        scenario,
        { ...forester, ...scenario.directorHeaders },
        message,
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await request(
        scenario,
        { ...forester, 'X-CF-Binding-Generation': 'old' },
        message,
      )
    ).status,
    403,
  );
  assert.equal(scenario.narrative.stats.quests, 0);
  assert.equal(scenario.gateway.stats.receipts, 0);
});

test('lifecycle, protocol header, body limits and deletion are enforced', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  assert.equal(
    (
      await request(scenario, scenario.foresterHeaders, {
        jsonrpc: '2.0',
        id: ++sequence,
        method: 'tools/list',
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await request(
        scenario,
        headers,
        { jsonrpc: '2.0', id: ++sequence, method: 'tools/list' },
        { 'MCP-Protocol-Version': 'unsupported' },
      )
    ).status,
    400,
  );
  assert.equal(
    (await request(scenario, headers, undefined, {}, 'GET')).status,
    405,
  );
  assert.equal(
    (await request(scenario, headers, { padding: 'x'.repeat(140000) })).status,
    413,
  );
  const malformed = await scenario.gateway.handle(
    new Request(url, {
      method: 'POST',
      headers: { ...headers, Authorization: `Bearer ${credential}` },
      body: '{',
    }),
  );
  assert.equal(malformed.status, 400);
  assert.equal(
    (await request(scenario, headers, undefined, {}, 'DELETE')).status,
    200,
  );
  assert.equal(
    (
      await request(scenario, headers, {
        jsonrpc: '2.0',
        id: ++sequence,
        method: 'tools/list',
      })
    ).status,
    404,
  );
});

test('quest mutation waits for host advance; lost response, concurrent replay and conflict retain one effect', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const first = call(
    scenario,
    headers,
    'create_quest',
    quest(scenario),
    'create-1',
  );
  const duplicate = call(
    scenario,
    headers,
    'create_quest',
    quest(scenario),
    'create-1',
  );
  await setImmediate();
  assert.equal(scenario.narrative.stats.quests, 0);
  const response = await pump(scenario, first);
  // Deliberately discard the response without reading it, as a connector disconnect would.
  await response.body.cancel();
  const concurrent = await result(scenario, duplicate);
  const replayed = await result(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario), 'create-1'),
  );
  assert.deepEqual(replayed, concurrent);
  assert.equal(scenario.narrative.stats.quests, 1);
  const conflict = await result(
    scenario,
    call(
      scenario,
      headers,
      'create_quest',
      { quest: { ...quest(scenario).quest, title: 'Changed' } },
      'create-1',
    ),
  );
  assert.equal(conflict.structuredContent.code, 'effect_key_conflict');
  assert.equal(conflict.isError, true);
});

test('schema rejections are terminal receipts; corrected input needs a new key and capabilities remain scoped', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const bad = await result(
    scenario,
    call(scenario, headers, 'create_quest', { quest: {} }, 'bad'),
  );
  assert.equal(bad.structuredContent.code, 'invalid_arguments');
  assert.equal(
    (
      await result(
        scenario,
        call(scenario, headers, 'create_quest', quest(scenario), 'bad'),
      )
    ).structuredContent.code,
    'effect_key_conflict',
  );
  assert.equal(
    (
      await result(
        scenario,
        call(scenario, headers, 'create_quest', quest(scenario), 'corrected'),
      )
    ).isError,
    false,
  );
  const missingKey = await pump(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario)),
  );
  assert.equal((await missingKey.json()).error.code, -32602);
  const noCorrelation = await request(scenario, headers, {
    jsonrpc: '2.0',
    id: ++sequence,
    method: 'tools/call',
    params: { name: 'inspect_nearby', arguments: {} },
  });
  assert.equal((await noCorrelation.json()).error.code, -32602);
  const unavailable = await pump(
    scenario,
    call(scenario, headers, 'inspect_world'),
  );
  assert.equal((await unavailable.json()).error.code, -32602);
});

test('game tools use separate host lane and actions replay once even while reasoning is pending', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  scenario.forester.requestDecision({ greeting: 'hello' });
  scenario.director.requestDecision({ theme: 'winter' });
  const assigned = await result(
    scenario,
    call(scenario, headers, 'request_work', { jobId: 'forestry' }, 'work-1'),
  );
  assert.equal(assigned.structuredContent.data.assigned, true);
  scenario.assignments.clear();
  const replay = await result(
    scenario,
    call(scenario, headers, 'request_work', { jobId: 'forestry' }, 'work-1'),
  );
  assert.deepEqual(replay, assigned);
  assert.equal(scenario.assignments.size, 0);
  const nearby = await result(
    scenario,
    call(scenario, headers, 'inspect_nearby'),
  );
  assert.equal(nearby.structuredContent.data.location, 'Northern lumber yard');
  const denied = await result(
    scenario,
    call(scenario, headers, 'game_inspect_location', {
      playerRef: 'player-1',
      locationRef: 'river-town',
    }),
  );
  assert.equal(denied.structuredContent.code, 'entity_unavailable');
});

test('persistent receipts survive explicit identity restoration and fresh generation', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const created = await result(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario), 'saved'),
  );
  const saved = JSON.parse(JSON.stringify(scenario.gateway.saveReceipts()));
  const narrative = scenario.narrative.save();
  const prior = scenario.forester.snapshot();
  await scenario.gateway.dispose();
  scenario.forester.unregister();
  const restored = scenario.runtime.register(prior);
  const gateway = new McpGateway({
    runtime: scenario.runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
  });
  t.after(() => gateway.dispose());
  gateway.restoreReceipts(saved);
  scenario.narrative.restore(narrative);
  const newHeaders = gateway.bind('forester/workforce-17', restored);
  assert.notEqual(
    newHeaders['X-CF-Binding-Generation'],
    headers['X-CF-Binding-Generation'],
  );
  const restoredScenario = {
    ...scenario,
    gateway,
    advance: (seconds) => {
      scenario.runtime.advance(seconds);
      gateway.advance(seconds);
    },
  };
  const session = await connect(restoredScenario, newHeaders);
  const replay = await result(
    restoredScenario,
    call(restoredScenario, session, 'create_quest', quest(scenario), 'saved'),
  );
  assert.deepEqual(replay, created);
  assert.equal(scenario.narrative.stats.quests, 1);
  assert.equal(
    (
      await request(restoredScenario, headers, {
        jsonrpc: '2.0',
        id: ++sequence,
        method: 'tools/list',
      })
    ).status,
    403,
  );
  assert.throws(() => gateway.restoreReceipts(saved), /before connecting/);
});

test('replacement invalidates queued calls and cannot replay the retired identity receipts', async (t) => {
  const scenario = fixture(t);
  const old = await connect(scenario, scenario.foresterHeaders);
  await result(
    scenario,
    call(scenario, old, 'create_quest', quest(scenario), 'old-create'),
  );
  const pending = call(
    scenario,
    old,
    'create_quest',
    quest(scenario),
    'pending',
  );
  await setImmediate();
  scenario.forester.unregister();
  const replacement = scenario.registerForester();
  const metadata = scenario.gateway.bind('forester/workforce-17', replacement);
  await pump(scenario, pending);
  const next = await connect(scenario, metadata);
  const created = await result(
    scenario,
    call(scenario, next, 'create_quest', quest(scenario), 'old-create'),
  );
  assert.equal(created.structuredContent.data.questId, 'quest-2');
  assert.equal(scenario.narrative.stats.quests, 2);
  assert.equal(
    (
      await request(scenario, old, {
        jsonrpc: '2.0',
        id: ++sequence,
        method: 'tools/list',
      })
    ).status,
    403,
  );
});

test('bad host action output stays unresolved and retries do not execute again', async (t) => {
  const scenario = fixture(t);
  let executions = 0;
  const broken = {
    name: 'request_work',
    kind: 'action',
    description: 'Broken host fixture',
    inputSchema: { type: 'object' },
    validate: () => true,
    execute: () => {
      executions++;
      return { status: 'invented' };
    },
  };
  const metadata = scenario.gateway.bind(
    'forester/workforce-17',
    scenario.forester,
    [broken],
  );
  const headers = await connect(scenario, metadata);
  const first = await pump(
    scenario,
    call(scenario, headers, 'request_work', {}, 'broken'),
  );
  assert.equal((await first.json()).error.code, -32603);
  const second = await pump(
    scenario,
    call(scenario, headers, 'request_work', {}, 'broken'),
  );
  assert.equal((await second.json()).error.code, -32603);
  assert.equal(executions, 1);
  assert.equal(scenario.gateway.saveReceipts().receipts[0].state, 'unresolved');
});

test('malformed context output cannot reach the client as a successful tool result', async (t) => {
  const runtime = new CharacterRuntime({
    gameId: 'malformed-context',
    reasoning: { decide: () => ({ dialogue: '' }) },
    narrativeGame: {
      capabilities: () => [],
      recipientAvailable: () => true,
      referencesAvailable: () => true,
      inspectContext: () => ({ status: 'completed', data: { invented: true } }),
    },
  });
  const handle = runtime.register({
    id: 'director',
    name: 'Director',
    capabilities: [],
    cai: { characterId: 'profile', sessionId: 'session' },
  });
  const gateway = new McpGateway({
    runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
  });
  t.after(async () => {
    await gateway.dispose();
    runtime.dispose();
  });
  const scenario = {
    gateway,
    advance: (seconds) => {
      runtime.advance(seconds);
      gateway.advance(seconds);
    },
  };
  const headers = await connect(scenario, gateway.bind('director', handle));
  const response = await pump(
    scenario,
    call(scenario, headers, 'inspect_context', { scope: 'world' }),
  );
  assert.equal((await response.json()).error.code, -32603);
});

test('connection capacity counts concurrent initialization and deletion frees it', async (t) => {
  const scenario = fixture(t);
  const gateway = new McpGateway({
    runtime: scenario.runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
    maxConnections: 1,
  });
  t.after(() => gateway.dispose());
  const target = { ...scenario, gateway };
  const metadata = gateway.bind('forester', scenario.forester);
  const message = () => ({
    jsonrpc: '2.0',
    id: ++sequence,
    method: 'initialize',
    params: {
      protocolVersion: '2025-11-25',
      capabilities: {},
      clientInfo: { name: 'test', version: '1' },
    },
  });
  const responses = await Promise.all([
    request(target, metadata, message()),
    request(target, metadata, message()),
  ]);
  assert.deepEqual(
    responses.map((response) => response.status).sort(),
    [200, 503],
  );
  const accepted = responses.find((response) => response.status === 200);
  const session = {
    ...metadata,
    'Mcp-Session-Id': accepted.headers.get('mcp-session-id'),
    'MCP-Protocol-Version': '2025-11-25',
  };
  await request(target, session, undefined, {}, 'DELETE');
  assert.equal(gateway.stats.connections, 0);
  await connect(target, metadata);
});

test('oversized mutations are admission errors, while admitted corrections retain replay and conflict semantics', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const oversized = {
    quest: { ...quest(scenario).quest, summary: 'x'.repeat(66000) },
  };
  for (let attempt = 0; attempt < 2; attempt++) {
    const response = await pump(
      scenario,
      call(scenario, headers, 'create_quest', oversized, 'size-review'),
    );
    const body = await response.json();
    assert.equal(body.result, undefined);
    assert.equal(body.error.code, -32602);
    assert.deepEqual(body.error.data, {
      code: 'argument_limit',
      admitted: false,
    });
    assert.equal(scenario.gateway.stats.receipts, 0);
    assert.equal(scenario.narrative.stats.quests, 0);
  }
  const corrected = await result(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario), 'size-review'),
  );
  assert.equal(corrected.isError, false);
  assert.deepEqual(
    await result(
      scenario,
      call(scenario, headers, 'create_quest', quest(scenario), 'size-review'),
    ),
    corrected,
  );
  const changed = await result(
    scenario,
    call(
      scenario,
      headers,
      'create_quest',
      {
        quest: { ...quest(scenario).quest, title: 'Different admitted input' },
      },
      'size-review',
    ),
  );
  assert.equal(changed.structuredContent.code, 'effect_key_conflict');
  assert.equal(scenario.gateway.stats.receipts, 1);
  assert.equal(scenario.narrative.stats.quests, 1);
});

test('full receipt storage refuses admission but preserves existing replay and read tools', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const committed = await result(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario), 'kept'),
  );
  const saved = scenario.gateway.saveReceipts();
  await request(scenario, headers, undefined, {}, 'DELETE');
  scenario.gateway.restoreReceipts({
    ...saved,
    receipts: [
      saved.receipts[0],
      ...Array.from({ length: 4095 }, (_, index) => ({
        ...saved.receipts[0],
        key: `capacity-${index}`,
      })),
    ],
  });
  const next = await connect(scenario, scenario.foresterHeaders);
  for (let attempt = 0; attempt < 2; attempt++) {
    const response = await pump(
      scenario,
      call(scenario, next, 'create_quest', quest(scenario), 'not-admitted'),
    );
    const body = await response.json();
    assert.equal(body.result, undefined);
    assert.equal(body.error.code, -32603);
    assert.deepEqual(body.error.data, {
      code: 'receipt_limit',
      admitted: false,
    });
  }
  assert.equal(scenario.gateway.saveReceipts().receipts.length, 4096);
  assert.equal(scenario.narrative.stats.quests, 1);
  assert.deepEqual(
    await result(
      scenario,
      call(scenario, next, 'create_quest', quest(scenario), 'kept'),
    ),
    committed,
  );
  assert.equal(
    (
      await result(
        scenario,
        call(scenario, next, 'inspect_context', { scope: 'local' }),
      )
    ).isError,
    false,
  );
});

test('pending effects use the same public conflict code as committed receipts', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const first = call(
    scenario,
    headers,
    'create_quest',
    quest(scenario),
    'pending-conflict',
  );
  await setImmediate();
  const response = await call(
    scenario,
    headers,
    'create_quest',
    { quest: { ...quest(scenario).quest, title: 'Changed while pending' } },
    'pending-conflict',
  );
  const body = await response.json();
  assert.equal(body.result.structuredContent.code, 'effect_key_conflict');
  assert.equal(body.result.isError, true);
  assert.equal(scenario.narrative.stats.quests, 0);
  await result(scenario, first);
  assert.equal(scenario.narrative.stats.quests, 1);
});

test('trusted mutation identity separates logical delivery from scoped effects without replaying admission', async (t) => {
  const seen = [];
  const action = {
    name: 'submit_action',
    kind: 'action',
    description: 'Admit a game operation.',
    inputSchema: {
      type: 'object',
      properties: { target: { type: 'string' } },
      required: ['target'],
      additionalProperties: false,
    },
    validate: () => true,
    execute: (context) => {
      assert.ok(context.mutation);
      assert.ok(Object.isFrozen(context.mutation));
      seen.push(context);
      return { status: 'running', operationId: 'operation-' + seen.length };
    },
  };
  const runtime = new CharacterRuntime({
    gameId: 'identity-test',
    capabilities: [action],
    reasoning: { decide: () => ({ dialogue: '' }) },
  });
  const gateway = new McpGateway({
    runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
  });
  const scenario = {
    gateway,
    advance: () => {
      runtime.advance(0);
      gateway.advance(0);
    },
  };
  t.after(async () => {
    await gateway.dispose();
    runtime.dispose();
  });
  const bind = (id, sessionId) =>
    gateway.bind(
      id,
      runtime.register({
        id,
        name: id,
        cai: { characterId: 'profile', sessionId },
        capabilities: [action.name],
      }),
      [action],
    );
  const first = await connect(scenario, bind('actor-a', 'session-a'));
  const sameCall = { 'X-CF-Call-Id': 'shared-call' };
  const original = await result(
    scenario,
    call(
      scenario,
      first,
      action.name,
      { target: 'gate' },
      'effect-a',
      sameCall,
    ),
  );
  const replay = await result(
    scenario,
    call(scenario, first, action.name, { target: 'gate' }, 'effect-a', {
      'X-CF-Call-Id': 'new-call',
    }),
  );
  assert.deepEqual(replay, original);
  assert.equal(seen.length, 1);
  assert.equal(seen[0].requestId, 'shared-call');
  const conflict = await result(
    scenario,
    call(
      scenario,
      first,
      action.name,
      { target: 'other' },
      'effect-a',
      sameCall,
    ),
  );
  assert.equal(conflict.structuredContent.code, 'effect_key_conflict');
  assert.equal(seen.length, 1);
  await result(
    scenario,
    call(
      scenario,
      first,
      action.name,
      { target: 'gate' },
      'effect-b',
      sameCall,
    ),
  );
  assert.equal(seen.length, 2);
  assert.notEqual(seen[0].mutation.id, seen[1].mutation.id);
  const second = await connect(scenario, bind('actor-b', 'session-b'));
  await result(
    scenario,
    call(
      scenario,
      second,
      action.name,
      { target: 'gate' },
      'effect-a',
      sameCall,
    ),
  );
  assert.equal(seen.length, 3);
  assert.notEqual(seen[0].mutation.id, seen[2].mutation.id);
  assert.match(seen[0].mutation.id, /^[a-f0-9]{64}$/);
  const forged = await result(
    scenario,
    call(
      scenario,
      first,
      action.name,
      { target: 'gate', mutation: { id: 'forged' } },
      'effect-forged',
      sameCall,
    ),
  );
  assert.equal(forged.structuredContent.code, 'invalid_arguments');
  assert.equal(seen.length, 3);
});

test('inspection and local capability contexts do not invent trusted mutation metadata', async (t) => {
  const seen = [];
  const inspection = {
    name: 'inspect_identity',
    kind: 'inspection',
    description: 'Inspect context.',
    inputSchema: { type: 'object', additionalProperties: false },
    validate: () => true,
    execute: (context) => {
      seen.push(context);
      return { status: 'completed', data: {} };
    },
  };
  const runtime = new CharacterRuntime({
    gameId: 'absence-test',
    capabilities: [inspection],
    reasoning: { decide: () => ({ dialogue: '' }) },
  });
  const actor = runtime.register({
    id: 'actor',
    name: 'Actor',
    cai: { characterId: 'profile', sessionId: 'session' },
    capabilities: [inspection.name],
  });
  const gateway = new McpGateway({
    runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
  });
  const scenario = {
    gateway,
    advance: () => {
      runtime.advance(0);
      gateway.advance(0);
    },
  };
  t.after(async () => {
    await gateway.dispose();
    runtime.dispose();
  });
  const headers = await connect(
    scenario,
    gateway.bind('actor', actor, [inspection]),
  );
  await result(
    scenario,
    call(scenario, headers, inspection.name, {}, 'untrusted-inspection-key'),
  );
  actor.dispatch(inspection.name, {});
  scenario.advance();
  await setImmediate();
  scenario.advance();
  assert.equal(seen.length, 2);
  for (const invocation of seen) assert.equal(invocation.mutation, undefined);
});

test('mutation identity isolates session alone and retains effect receipt across generation-only rebind', async (t) => {
  const seen = [];
  const action = {
    name: 'scoped_departure',
    kind: 'action',
    description: 'Admit one journey.',
    inputSchema: { type: 'object', additionalProperties: false },
    validate: () => true,
    execute: (context) => {
      seen.push(context);
      return { status: 'running', operationId: context.mutation.id };
    },
  };
  const runtime = new CharacterRuntime({
    gameId: 'scope-axes',
    capabilities: [action],
    reasoning: { decide: () => ({ dialogue: '' }) },
  });
  const gateway = new McpGateway({
    runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
  });
  const scenario = {
    gateway,
    advance: () => {
      runtime.advance(0);
      gateway.advance(0);
    },
  };
  t.after(async () => {
    await gateway.dispose();
    runtime.dispose();
  });
  const first = runtime.register({
    id: 'same-actor',
    name: 'Actor',
    cai: { characterId: 'same-profile', sessionId: 'session-a' },
    capabilities: [action.name],
  });
  const firstDefinition = first.snapshot();
  const firstHeaders = await connect(
    scenario,
    gateway.bind('same-key', first, [action]),
  );
  const effect = 'same-effect';
  const firstResult = await result(
    scenario,
    call(scenario, firstHeaders, action.name, {}, effect),
  );
  first.unregister();
  const second = runtime.register({
    ...firstDefinition,
    cai: { ...firstDefinition.cai, sessionId: 'session-b' },
  });
  assert.equal(second.snapshot().binding.id, firstDefinition.binding.id);
  assert.equal(second.snapshot().id, firstDefinition.id);
  const secondHeaders = await connect(
    scenario,
    gateway.bind('same-key', second, [action]),
  );
  const secondResult = await result(
    scenario,
    call(scenario, secondHeaders, action.name, {}, effect),
  );
  assert.equal(seen.length, 2);
  assert.notEqual(seen[0].mutation.id, seen[1].mutation.id);
  assert.notDeepEqual(firstResult, secondResult);
  // Same actor, stable binding and session; only the runtime generation changes.
  const secondDefinition = second.snapshot();
  second.unregister();
  const third = runtime.register(secondDefinition);
  assert.equal(third.snapshot().binding.id, secondDefinition.binding.id);
  assert.equal(third.snapshot().cai.sessionId, secondDefinition.cai.sessionId);
  assert.notEqual(
    third.snapshot().binding.generation,
    secondDefinition.binding.generation,
  );
  const thirdHeaders = await connect(
    scenario,
    gateway.bind('same-key', third, [action]),
  );
  const replay = await result(
    scenario,
    call(scenario, thirdHeaders, action.name, {}, effect, {
      'X-CF-Call-Id': 'new-delivery',
    }),
  );
  assert.deepEqual(replay, secondResult);
  assert.equal(replay.structuredContent.operationId, seen[1].mutation.id);
  assert.equal(
    seen.length,
    2,
    'generation rebind must not call capability/move again',
  );
  assert.throws(() => first.snapshot());
  assert.throws(() => second.snapshot());
  const denied = await request(scenario, secondHeaders, {
    jsonrpc: '2.0',
    id: ++sequence,
    method: 'tools/list',
  });
  assert.equal(denied.status, 403);
});

test('departure MCP admission retains one trusted operation through replay, blocked waiting and terminal handoff', async (t) => {
  const { createDepartureScenario } =
    await import('../dist/examples/departure-scenario.js');
  const scenario = createDepartureScenario(credential);
  t.after(() => scenario.dispose());
  const headers = await connect(scenario, scenario.headers);
  const args = { destination_ref: 'gate' };
  const admitted = await result(
    scenario,
    call(scenario, headers, 'game_submit_departure', args, 'departure'),
  );
  assert.equal(admitted.structuredContent.status, 'running');
  const replay = await result(
    scenario,
    call(scenario, headers, 'game_submit_departure', args, 'departure', {
      'X-CF-Call-Id': 'lost-admission-retry',
    }),
  );
  assert.deepEqual(replay, admitted);
  assert.equal(scenario.snapshot().starts, 1);
  scenario.settle('blocked');
  assert.equal(scenario.snapshot().sources.length, 0);
  const busy = await result(
    scenario,
    call(scenario, headers, 'game_submit_departure', args, 'other-departure'),
  );
  assert.equal(busy.structuredContent.code, 'actor_busy');
  const invalid = await result(
    scenario,
    call(
      scenario,
      headers,
      'game_submit_departure',
      { destination_ref: 'unknown' },
      'invalid',
    ),
  );
  assert.equal(invalid.structuredContent.code, 'destination_unavailable');
  assert.equal(scenario.snapshot().status, 'blocked');
  scenario.settle('moving');
  scenario.settle('arrived');
  scenario.settle('arrived');
  assert.equal(scenario.snapshot().sources.length, 1);
  const source = scenario.snapshot().sources[0];
  assert.equal(
    source.references.operation_id,
    admitted.structuredContent.operationId,
  );
  assert.equal(source.type, 'departure_arrived');
  await assert.rejects(
    scenario.handoff(async () => {
      throw new Error('storage');
    }),
    /storage/,
  );
  assert.deepEqual(scenario.snapshot().sources[0], source);
  const waiting = await result(
    scenario,
    call(scenario, headers, 'game_submit_departure', args, 'after-arrival'),
  );
  assert.equal(waiting.structuredContent.code, 'feedback_pending');
  await scenario.handoff(async (feedback) => {
    assert.deepEqual(feedback, source);
  });
  assert.equal(scenario.snapshot().sources.length, 0);
  await result(
    scenario,
    call(scenario, headers, 'game_submit_departure', args, 'departure', {
      'X-CF-Call-Id': 'terminal-replay',
    }),
  );
  assert.equal(scenario.snapshot().starts, 1);
  assert.equal(scenario.snapshot().retainedOperations, 1);
});

test('departure removal preserves cancellation evidence and rejects local provenance or retired feedback delivery', async (t) => {
  const { createDepartureScenario } =
    await import('../dist/examples/departure-scenario.js');
  const scenario = createDepartureScenario(credential);
  t.after(() => scenario.dispose());
  scenario.character.dispatch('game_submit_departure', {
    destination_ref: 'gate',
  });
  scenario.advance();
  await setImmediate();
  scenario.advance();
  assert.equal(
    scenario.character.snapshot().lastCapabilityResult.code,
    'missing_mutation_identity',
  );
  const headers = await connect(scenario, scenario.headers);
  await result(
    scenario,
    call(
      scenario,
      headers,
      'game_submit_departure',
      { destination_ref: 'gate' },
      'departure',
    ),
  );
  scenario.retire();
  scenario.settle('arrived');
  assert.equal(scenario.snapshot().sources.length, 1);
  assert.equal(scenario.snapshot().sources[0].type, 'departure_cancelled');
  assert.equal(scenario.snapshot().reconciliationRequired, true);
  let delivered = false;
  await assert.rejects(
    scenario.handoff(async () => {
      delivered = true;
    }),
    /reconciliation_required/,
  );
  assert.equal(delivered, false);
  assert.equal(
    (
      await call(
        scenario,
        headers,
        'game_submit_departure',
        { destination_ref: 'gate' },
        'late',
      )
    ).status,
    403,
  );
});

test('departure terminal feedback loss retries original event and never restarts admitted movement', async (t) => {
  const { createDepartureScenario } =
    await import('../dist/examples/departure-scenario.js');
  const { CaiConversation } =
    await import('../dist/src/cai/CaiConversation.js');
  const scenario = createDepartureScenario(credential);
  t.after(() => scenario.dispose());
  const headers = await connect(scenario, scenario.headers);
  await result(
    scenario,
    call(
      scenario,
      headers,
      'game_submit_departure',
      { destination_ref: 'gate' },
      'departure',
    ),
  );
  scenario.settle('arrived');
  const events = [];
  let stored, committed;
  const backend = {
    event: async (_, input) => {
      events.push(structuredClone(input));
      if (!committed) {
        committed = { eventId: input.event_id, version: input.version + 1 };
        throw new Error('reply lost');
      }
      return committed;
    },
  };
  const current = () => {
    scenario.character.snapshot();
  };
  const persist = (save) => {
    stored = structuredClone(save);
  };
  const conversation = new CaiConversation(
    backend,
    {
      schemaVersion: 1,
      session: {
        id: 'canned-session',
        characterId: 'canned-profile',
        bindingKey: 'mara',
        version: 0,
        mode: 'game',
        continuityMode: 'session',
        bindingGeneration: scenario.character.snapshot().binding.generation,
      },
      pending: null,
      feedback: [],
      reported: [],
    },
    current,
    persist,
  );
  let release;
  const gate = new Promise((yes) => {
    release = yes;
  });
  const transfer = scenario.handoff(async (feedback) => {
    await gate;
    conversation.enqueueFeedback(feedback);
    persist(conversation.save());
  });
  await assert.rejects(
    scenario.handoff(async () => {}),
    /feedback_handoff_busy/,
  );
  assert.equal(scenario.snapshot().sources.length, 1);
  release();
  await transfer;
  assert.equal(
    scenario.snapshot().sources.length,
    0,
    'ownership transferred after checkpoint storage',
  );
  await assert.rejects(conversation.flushFeedback(), /reply lost/);
  const pending = JSON.parse(JSON.stringify(stored));
  const restored = new CaiConversation(backend, pending, current, persist);
  conversation.dispose();
  await restored.retry();
  assert.deepEqual(events[0], events[1]);
  assert.equal(restored.save().session.version, 1);
  assert.equal(restored.save().reported.length, 1);
  assert.equal(restored.save().pending, null);
  assert.equal(scenario.snapshot().starts, 1);
  assert.equal(scenario.snapshot().sources.length, 0);
  restored.dispose();
});

test('departure operation ledger rejects capacity without eviction or another admission', async (t) => {
  const { createDepartureScenario } =
    await import('../dist/examples/departure-scenario.js');
  const scenario = createDepartureScenario(credential);
  t.after(() => scenario.dispose());
  const headers = await connect(scenario, scenario.headers);
  for (let i = 0; i < 128; i++) {
    await result(
      scenario,
      call(
        scenario,
        headers,
        'game_submit_departure',
        { destination_ref: 'gate' },
        'effect-' + i,
      ),
    );
    scenario.settle('unreachable');
    await scenario.handoff(async () => {});
  }
  const full = await result(
    scenario,
    call(
      scenario,
      headers,
      'game_submit_departure',
      { destination_ref: 'gate' },
      'effect-overflow',
    ),
  );
  assert.equal(full.structuredContent.code, 'operation_capacity');
  assert.equal(scenario.snapshot().starts, 128);
  assert.equal(scenario.snapshot().retainedOperations, 128);
  await result(
    scenario,
    call(
      scenario,
      headers,
      'game_submit_departure',
      { destination_ref: 'gate' },
      'effect-0',
    ),
  );
  assert.equal(scenario.snapshot().starts, 128);
});

test('official MCP client discovers offering policy schemas and replays committed policy without duplicate source', async (t) => {
  const scenario = fixture(t);
  const client = new FakeCaiClient(
    new URL(url),
    scenario.foresterHeaders,
    credential,
    (target, init) => scenario.gateway.handle(new Request(target, init)),
  );
  await client.connect();
  t.after(() => client.close());
  const tools = (await client.client.listTools()).tools;
  assert.equal(
    tools.find((tool) => tool.name === 'inspect_offering_access').annotations
      .readOnlyHint,
    true,
  );
  const mutation = tools.find((tool) => tool.name === 'set_offering_access');
  assert.equal(mutation.annotations.readOnlyHint, false);
  assert.equal(mutation.inputSchema.properties.allowedQuestIds.maxItems, 16);
  const args = {
    recipientRef: 'player-1',
    expectedRevision: 0,
    mode: 'restricted',
    allowedQuestIds: [],
  };
  const identity = {
    callId: 'set-policy',
    turnId: 'policy-turn',
    effectKey: 'policy-effect',
  };
  const committed = await pump(
    scenario,
    client.call('set_offering_access', args, identity),
  );
  assert.equal(committed.structuredContent.data.revision, 1);
  assert.equal(committed.structuredContent.data.mode, 'restricted');
  const replay = await pump(
    scenario,
    client.call('set_offering_access', args, {
      ...identity,
      callId: 'lost-reply',
    }),
  );
  assert.deepEqual(replay, committed);
  assert.equal(scenario.narrative.offeringEvents().length, 1);
  const inspected = await pump(
    scenario,
    client.call(
      'inspect_offering_access',
      { recipientRef: 'player-1' },
      { callId: 'inspect', turnId: 'policy-turn' },
    ),
  );
  assert.deepEqual(
    inspected.structuredContent.data,
    committed.structuredContent.data,
  );
  const stale = await pump(
    scenario,
    client.call('set_offering_access', args, {
      ...identity,
      effectKey: 'new-effect',
    }),
  );
  assert.equal(stale.structuredContent.code, 'stale_policy_revision');
  const headers = await connect(scenario, scenario.foresterHeaders);
  const missing = await pump(
    scenario,
    call(scenario, headers, 'set_offering_access', args),
  );
  assert.equal((await missing.json()).error.code, -32602);
});

test('official MCP client validates authored graph discovery, journal replay and host-only cursor transitions', async (t) => {
  const scenario = fixture(t);
  const client = new FakeCaiClient(
    new URL(url),
    scenario.foresterHeaders,
    credential,
    (target, init) => scenario.gateway.handle(new Request(target, init)),
  );
  await client.connect();
  t.after(() => client.close());
  const tools = (await client.client.listTools()).tools;
  assert.equal(
    tools.find((tool) => tool.name === 'inspect_dialogue_graph').annotations
      .readOnlyHint,
    true,
  );
  for (const name of ['create_dialogue_graph', 'start_dialogue_graph'])
    assert.equal(
      tools.find((tool) => tool.name === name).annotations.readOnlyHint,
      false,
    );
  assert.equal(
    tools.find((tool) => tool.name === 'create_dialogue_graph').inputSchema
      .properties.nodes.maxItems,
    16,
  );
  assert.ok(!tools.some((tool) => tool.name === 'choose_dialogue'));
  const args = {
    recipientRef: 'player-1',
    title: 'Greeting',
    start: 'greet',
    nodes: [
      {
        id: 'greet',
        text: 'Hello.',
        choices: [{ id: 'leave', label: 'Goodbye.', next: 'exit' }],
      },
      { id: 'exit', text: 'Safe travels.', choices: [] },
    ],
  };
  const identity = {
    callId: 'graph-author',
    turnId: 'graph-turn',
    effectKey: 'graph-effect',
  };
  const created = await pump(
    scenario,
    client.call('create_dialogue_graph', args, identity),
  );
  assert.equal(created.structuredContent.status, 'completed');
  assert.deepEqual(
    await pump(
      scenario,
      client.call('create_dialogue_graph', args, {
        ...identity,
        callId: 'graph-replay',
      }),
    ),
    created,
  );
  const startInput = { graphId: created.structuredContent.data.graphId };
  const started = await pump(
    scenario,
    client.call('start_dialogue_graph', startInput, {
      callId: 'start',
      turnId: 'graph-turn',
      effectKey: 'start-effect',
    }),
  );
  const view = started.structuredContent.data;
  assert.equal(view.revision, 0);
  const closed = await pump(
    scenario,
    scenario.narrative.choose('player-1', view.choices[0].id, 'player-effect'),
  );
  assert.equal(closed.data.closed, true);
  const inspected = await pump(
    scenario,
    client.call(
      'inspect_dialogue_graph',
      { instanceId: view.instanceId },
      { callId: 'inspect', turnId: 'graph-turn' },
    ),
  );
  assert.deepEqual(inspected.structuredContent.data, closed.data);
  assert.deepEqual(
    await pump(
      scenario,
      client.call('start_dialogue_graph', startInput, {
        callId: 'start-replay',
        turnId: 'graph-turn',
        effectKey: 'start-effect',
      }),
    ),
    started,
  );
  assert.equal(scenario.narrative.dialogueEvents().length, 2);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const missing = await pump(
    scenario,
    call(scenario, headers, 'start_dialogue_graph', startInput),
  );
  assert.equal((await missing.json()).error.code, -32602);
});

async function combinedFixture(t) {
  const { createCombinedReactionScenario } =
    await import('../dist/examples/combined-reaction-scenario.js');
  const scenario = createCombinedReactionScenario(credential);
  t.after(() => scenario.dispose());
  const headers = await connect(scenario, scenario.headers);
  const invoke = async (name, input, effect, extra) =>
    (
      await result(
        scenario,
        call(scenario, headers, name, input, effect, extra),
      )
    ).structuredContent;
  const ordinary = await invoke(
    'create_quest',
    scenario.quest('Ordinary work'),
    'ordinary',
  );
  const redemption = await invoke(
    'create_quest',
    scenario.quest('Make amends'),
    'redemption',
  );
  assert.equal(ordinary.status, 'completed');
  assert.equal(redemption.status, 'completed');
  const restriction = {
    recipientRef: 'player-1',
    expectedRevision: 0,
    mode: 'restricted',
    allowedQuestIds: [redemption.data.questId],
  };
  assert.equal(
    (await invoke('set_offering_access', restriction, 'restriction')).status,
    'completed',
  );
  return {
    scenario,
    invoke,
    ordinary: ordinary.data.questId,
    redemption: redemption.data.questId,
    restriction,
  };
}

test('one scoped NPC binding combines departure and restricted offers without implying arrival or automatic restoration', async (t) => {
  const { scenario, invoke, ordinary, redemption, restriction } =
    await combinedFixture(t);
  assert.equal(
    (
      await invoke(
        'offer_quest',
        { questId: ordinary, recipientRef: 'player-1', dialogue: 'Work?' },
        'refused',
      )
    ).code,
    'offering_restricted',
  );
  const admitted = await invoke(
    'game_submit_departure',
    { destination_ref: 'gate' },
    'reaction-departure',
  );
  assert.equal(admitted.status, 'running');
  scenario.settle('blocked');
  assert.equal(scenario.snapshot().sources.length, 0);
  assert.equal(
    (await invoke('inspect_offering_access', { recipientRef: 'player-1' })).data
      .mode,
    'restricted',
  );
  assert.deepEqual(
    await invoke(
      'game_submit_departure',
      { destination_ref: 'gate' },
      'reaction-departure',
      { 'X-CF-Call-Id': 'replayed-departure' },
    ),
    admitted,
  );
  await invoke('set_offering_access', restriction, 'restriction', {
    'X-CF-Call-Id': 'replayed-policy',
  });
  assert.equal(scenario.snapshot().starts, 1);
  assert.equal(scenario.narrative.offeringEvents().length, 1);
  const offered = await invoke(
    'offer_quest',
    { questId: redemption, recipientRef: 'player-1', dialogue: 'Make amends.' },
    'redemption-offer',
  );
  assert.equal(offered.status, 'completed');
  const accepted = scenario.narrative.choose(
    'player-1',
    offered.data.choices[0].id,
    'accept-redemption',
  );
  assert.equal((await pump(scenario, accepted)).status, 'completed');
  scenario.settle('arrived');
  scenario.settle('arrived');
  assert.equal(scenario.snapshot().sources.length, 1);
  assert.equal(scenario.snapshot().sources[0].type, 'departure_arrived');
  scenario.redeem();
  for (let i = 0; i < 4; i++) {
    scenario.advance(0);
    await setImmediate();
  }
  assert.equal(
    (
      await invoke('inspect_quest', {
        questId: redemption,
        recipientRef: 'player-1',
      })
    ).data.status,
    'completed',
  );
  assert.equal(
    (await invoke('inspect_offering_access', { recipientRef: 'player-1' })).data
      .mode,
    'restricted',
  );
  await invoke(
    'set_offering_access',
    {
      recipientRef: 'player-1',
      expectedRevision: 1,
      mode: 'open',
      allowedQuestIds: [],
    },
    'restore-offers',
  );
  assert.equal(
    (
      await invoke(
        'offer_quest',
        {
          questId: ordinary,
          recipientRef: 'player-1',
          dialogue: 'Work again?',
        },
        'ordinary-offer',
      )
    ).status,
    'completed',
  );
  assert.equal(scenario.narrative.offeringEvents().length, 2);
  assert.equal(scenario.snapshot().starts, 1);
});

test('combined reaction keeps committed restriction through rejected or unreachable departure', async (t) => {
  const { scenario, invoke, ordinary } = await combinedFixture(t);
  assert.equal(
    (
      await invoke(
        'game_submit_departure',
        { destination_ref: 'unknown' },
        'invalid-departure',
      )
    ).code,
    'destination_unavailable',
  );
  assert.equal(scenario.snapshot().starts, 0);
  assert.equal(scenario.snapshot().sources.length, 0);
  const admitted = await invoke(
    'game_submit_departure',
    { destination_ref: 'gate' },
    'departure',
  );
  assert.equal(admitted.status, 'running');
  scenario.settle('unreachable');
  assert.equal(scenario.snapshot().sources[0].type, 'departure_unreachable');
  assert.deepEqual(
    await invoke(
      'game_submit_departure',
      { destination_ref: 'gate' },
      'departure',
    ),
    admitted,
  );
  assert.equal(scenario.snapshot().starts, 1);
  assert.equal(
    (await invoke('inspect_offering_access', { recipientRef: 'player-1' })).data
      .mode,
    'restricted',
  );
  assert.equal(
    (
      await invoke(
        'offer_quest',
        { questId: ordinary, recipientRef: 'player-1', dialogue: 'Work?' },
        'still-denied',
      )
    ).code,
    'offering_restricted',
  );
  assert.equal(scenario.narrative.offeringEvents().length, 1);
});

test('combined reaction retains both source domains on failed storage and delivers exact events to the same session without another journey', async (t) => {
  const { scenario, invoke } = await combinedFixture(t);
  const { CaiConversation } =
    await import('../dist/src/cai/CaiConversation.js');
  await invoke(
    'game_submit_departure',
    { destination_ref: 'gate' },
    'departure',
  );
  scenario.settle('arrived');
  const policy = scenario.narrative.offeringEvents()[0];
  const generation = scenario.character.snapshot().binding.generation;
  assert.equal(policy.bindingGeneration, generation);
  assert.equal(policy.characterRef, 'mara');
  const feedback = {
    sourceId: policy.id,
    origin: 'framework_narrative',
    type: 'offering_access_changed',
    summary: 'Committed offering policy: restricted',
    references: {
      policy_id: policy.policyId,
      actor_ref: policy.characterRef,
      recipient_ref: policy.recipientRef,
      revision: String(policy.revision),
    },
  };
  let checkpoint;
  let failStorage = true;
  let loseReply = true;
  const events = [];
  const receipts = new Map();
  const backend = {
    event: async (sessionId, input) => {
      assert.equal(sessionId, 'canned-session');
      events.push(structuredClone(input));
      if (!receipts.has(input.event_id))
        receipts.set(input.event_id, {
          eventId: input.event_id,
          version: input.version + 1,
        });
      if (loseReply) {
        loseReply = false;
        throw new Error('reply lost');
      }
      return receipts.get(input.event_id);
    },
  };
  const persist = (save) => {
    if (failStorage) throw new Error('storage unavailable');
    checkpoint = structuredClone(save);
  };
  const current = () => {
    scenario.character.snapshot();
  };
  const conversation = new CaiConversation(
    backend,
    {
      schemaVersion: 1,
      session: {
        id: 'canned-session',
        characterId: 'canned-profile',
        bindingKey: 'mara',
        version: 0,
        mode: 'game',
        continuityMode: 'session',
        bindingGeneration: generation,
      },
      pending: null,
      feedback: [],
      reported: [],
    },
    current,
    persist,
  );
  t.after(() => conversation.dispose());
  const transferPolicy = () => {
    conversation.enqueueFeedback(feedback);
    persist(conversation.save());
    scenario.narrative.acknowledgeOfferingEvent(policy.id);
  };
  assert.throws(transferPolicy, /storage unavailable/);
  await assert.rejects(
    scenario.handoff(async (source) => {
      conversation.enqueueFeedback(source);
      persist(conversation.save());
    }),
    /storage unavailable/,
  );
  assert.equal(scenario.narrative.offeringEvents().length, 1);
  assert.equal(scenario.snapshot().sources.length, 1);
  assert.equal(events.length, 0);
  failStorage = false;
  transferPolicy();
  await scenario.handoff(async (source) => {
    conversation.enqueueFeedback(source);
    persist(conversation.save());
  });
  assert.equal(scenario.narrative.offeringEvents().length, 0);
  assert.equal(scenario.snapshot().sources.length, 0);
  assert.equal(checkpoint.feedback.length, 2);
  await assert.rejects(conversation.flushFeedback(), /reply lost/);
  const restored = new CaiConversation(
    backend,
    structuredClone(checkpoint),
    current,
    persist,
  );
  t.after(() => restored.dispose());
  conversation.dispose();
  await restored.retry();
  await restored.flushFeedback();
  assert.deepEqual(events[0], events[1]);
  assert.deepEqual(
    events.map((event) => event.origin),
    ['framework_narrative', 'framework_narrative', 'game_outcome'],
  );
  assert.equal(restored.save().session.version, 2);
  assert.equal(restored.save().reported.length, 2);
  assert.equal(scenario.snapshot().starts, 1);
});

test('trusted capability byte overrides remain bounded and ordinary tools retain their wire budget', async () => {
  const { validResult, capabilityByteLimit } =
    await import('../dist/src/mcp/HostLane.js');
  const large = { status: 'completed', data: 'x'.repeat(70000) };
  assert.equal(validResult(large), false);
  assert.equal(validResult(large, 512 * 1024), true);
  assert.equal(capabilityByteLimit(Infinity), 65536);
  assert.equal(capabilityByteLimit(1), 65536);
  assert.equal(capabilityByteLimit(10 * 1024 * 1024), 512 * 1024);
  assert.equal(
    validResult(
      { status: 'completed', data: 'x'.repeat(512 * 1024) },
      10 * 1024 * 1024,
    ),
    false,
  );
  assert.equal(
    validResult({ status: 'completed', data: Infinity }, 512 * 1024),
    false,
  );
});
