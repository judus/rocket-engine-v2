import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { McpGateway } from '../dist/src/mcp/index.js';
import {
  createAuthoringPrototypeFixture,
  visitFragment,
} from '../examples/authoring-prototype-fixture.js';

async function path() {
  return join(
    await mkdtemp(join(tmpdir(), 'cfw-authoring-test-')),
    'drafts.sqlite',
  );
}

test('MCP review blocks invalid output comparisons and publication until the visit predicate is corrected', async () => {
  const f = await createAuthoringPrototypeFixture(await path());
  try {
    const created = await f.call(
      'create_quest_draft',
      {
        intent: { title: 'A new visit, not a boolean count' },
      },
      'comparison-create',
    );
    const draftId = created.data.draftId;
    let revision = 1;
    for (const [name, expectation, finding] of [
      [
        'boolean-count',
        { path: ['inside'], operator: 'at_least', value: 1 },
        /at_least.*boolean.*number/,
      ],
      [
        'unknown-output',
        { path: ['invented'], operator: 'equals', value: true },
        /Undeclared.*invented/,
      ],
      [
        'wrong-literal',
        { path: ['entries'], operator: 'equals', value: true },
        /boolean.*integer/,
      ],
    ]) {
      const fragment = structuredClone(visitFragment);
      fragment.situations[0].routes[0].when.expect = expectation;
      const edited = await f.call(
        'edit_quest_draft',
        {
          draftId,
          expectedRecordRevision: revision,
          operations: [
            {
              kind: 'replace_beat_implementation',
              beatId: 'main',
              implementation: fragment,
            },
          ],
        },
        name,
      );
      revision++;
      assert.equal(edited.status, 'completed');
      const review = await f.call('review_quest_draft', {
        draftId,
        recordRevision: revision,
      });
      assert.equal(review.data.technicalReady, false);
      const issue = review.data.findings.find((x) => finding.test(x.message));
      assert.ok(issue, JSON.stringify(review));
      assert.equal(
        issue.path,
        '/implementation/situations/0/routes/0/when/expect',
      );
      const blocked = await f.call(
        'publish_quest_draft',
        { draftId, expectedRecordRevision: revision },
        name + '-publish',
      );
      assert.equal(blocked.code, 'draft_not_ready');
      assert.equal(f.game.system.stats.runs, 0);
    }
    const corrected = await f.call(
      'edit_quest_draft',
      {
        draftId,
        expectedRecordRevision: revision,
        operations: [
          {
            kind: 'replace_beat_implementation',
            beatId: 'main',
            implementation: visitFragment,
          },
        ],
      },
      'comparison-correct',
    );
    assert.equal(corrected.data.assessment.technicalReady, true);
    const published = await f.call(
      'publish_quest_draft',
      { draftId, expectedRecordRevision: revision + 1 },
      'comparison-publish',
    );
    assert.equal(published.status, 'completed');
  } finally {
    await f.close();
  }
});

test('actual MCP authors an incomplete visit, corrects, publishes without activation and resumes in a fresh process', async () => {
  const database = await path();
  const f = await createAuthoringPrototypeFixture(database);
  try {
    const discovery = await f.client.client.listTools();
    assert.equal(discovery.tools.length, 7);
    assert.equal(
      discovery.tools.find((t) => t.name === 'read_quest_draft').annotations
        .readOnlyHint,
      true,
    );
    assert.equal(
      discovery.tools.find((t) => t.name === 'create_quest_draft').annotations
        .readOnlyHint,
      false,
    );
    const catalogue = await f.call('read_quest_draft', {
      section: 'catalogue',
    });
    assert.equal(catalogue.data.capabilities[0].name, 'rocket_inspect_grove');
    assert.equal(
      catalogue.data.capabilities[0].inputSchema.properties.locationRef.const,
      'grove',
    );
    const created = await f.call(
      'create_quest_draft',
      { intent: { title: 'Visit the Old Grove' } },
      'create',
    );
    const draftId = created.data.draftId;
    const incomplete = structuredClone(visitFragment);
    incomplete.situations.pop();
    const edited = await f.call(
      'edit_quest_draft',
      {
        draftId,
        expectedRecordRevision: 1,
        operations: [
          {
            kind: 'replace_beat_implementation',
            beatId: 'main',
            implementation: incomplete,
          },
        ],
      },
      'incomplete',
    );
    assert.equal(edited.data.assessment.technicalReady, false);
    const blocked = await f.call(
      'publish_quest_draft',
      { draftId, expectedRecordRevision: 2 },
      'blocked',
    );
    assert.equal(blocked.code, 'draft_not_ready');
    const fixed = await f.call(
      'edit_quest_draft',
      {
        draftId,
        expectedRecordRevision: 2,
        operations: [
          {
            kind: 'replace_beat_implementation',
            beatId: 'main',
            implementation: visitFragment,
          },
        ],
      },
      'corrected',
    );
    assert.equal(fixed.data.assessment.technicalReady, true);
    const review = await f.call('review_quest_draft', {
      draftId,
      recordRevision: 3,
    });
    assert.equal(review.data.technicalReady, true);
    const published = await f.call(
      'publish_quest_draft',
      { draftId, expectedRecordRevision: 3 },
      'publish',
    );
    assert.equal(published.status, 'completed');
    assert.equal(f.game.system.stats.runs, 0);
    assert.deepEqual(
      await f.call(
        'publish_quest_draft',
        { draftId, expectedRecordRevision: 3 },
        'publish',
      ),
      published,
    );
  } finally {
    await f.close();
  }
  const resumed = spawnSync(
    process.execPath,
    ['examples/authoring-prototype-resume.js', database],
    { encoding: 'utf8' },
  );
  assert.ifError(resumed.error);
  assert.equal(resumed.status, 0, resumed.stderr + resumed.stdout);
  const proof = JSON.parse(resumed.stdout.trim());
  assert.equal(proof.freshProcess, true);
  assert.equal(proof.commandRecoveredFromList, true);
  assert.equal(proof.priorEntryExcluded, true);
  assert.equal(proof.newEntryClosed, true);
});

test('prototype rejects stale edits, rolls back an entire rejected batch and persists original command replay on reopen', async () => {
  const database = await path();
  let f = await createAuthoringPrototypeFixture(database);
  const args = { intent: { title: 'Original intent' } };
  let created;
  try {
    created = await f.call('create_quest_draft', args, 'original-create');
    const draftId = created.data.draftId;
    const oversized = {
      entrySituation: 's0',
      situations: Array.from({ length: 128 }, (_, i) => ({
        id: 's' + i,
        dialogue: { text: '界'.repeat(700) },
        ...(i < 127
          ? { choices: [{ id: 'next', label: 'Next', next: 's' + (i + 1) }] }
          : {}),
      })),
      outcomeBindings: [],
    };
    const rejected = await f.call(
      'edit_quest_draft',
      {
        draftId,
        expectedRecordRevision: 1,
        operations: [
          { kind: 'set_intent', intent: { title: 'Should not commit' } },
          {
            kind: 'replace_beat_implementation',
            beatId: 'main',
            implementation: oversized,
          },
        ],
      },
      'atomic-reject',
    );
    assert.equal(rejected.code, 'fragment_too_large');
    const read = await f.call('read_quest_draft', {
      section: 'overview',
      draftId,
    });
    assert.equal(read.data.intent.title, 'Original intent');
    assert.equal(read.data.recordRevision, 1);
    const stale = await f.call(
      'edit_quest_draft',
      {
        draftId,
        expectedRecordRevision: 2,
        operations: [{ kind: 'set_intent', intent: { title: 'Stale' } }],
      },
      'stale',
    );
    assert.equal(stale.code, 'revision_conflict');
  } finally {
    await f.close();
  }
  f = await createAuthoringPrototypeFixture(database);
  try {
    assert.deepEqual(
      await f.call('create_quest_draft', args, 'original-create'),
      created,
    );
    const listed = await f.call('list_quest_drafts', {});
    assert.equal(listed.data.items.length, 1);
    const outcome = await f.call('get_authoring_command_outcome', {
      commandId: created.data.commandId,
    });
    assert.deepEqual(outcome.data.result, created);
    f.revoke();
    assert.equal(
      (await f.call('read_quest_draft', { section: 'catalogue' })).code,
      'permission_denied',
    );
  } finally {
    await f.close();
  }
});

test('legacy raw authoring transports large valid fragments and restores their exact MCP receipts', async () => {
  const f = await createAuthoringPrototypeFixture(await path());
  let restored;
  try {
    const c = await f.call(
      'create_quest_draft',
      { intent: { title: 'Large legacy fragment' } },
      'large-create',
    );
    const draftId = c.data.draftId;
    const fragment = {
      entrySituation: 's0',
      situations: Array.from({ length: 128 }, (_, i) => ({
        id: `s${i}`,
        dialogue: { text: '界'.repeat(500) },
        ...(i < 127
          ? { choices: [{ id: 'next', label: 'Next', next: `s${i + 1}` }] }
          : {}),
      })),
      outcomeBindings: [],
    };
    assert.ok(Buffer.byteLength(JSON.stringify(fragment)) > 131072);
    const args = {
      draftId,
      expectedRecordRevision: 1,
      operations: [
        {
          kind: 'replace_beat_implementation',
          beatId: 'main',
          implementation: fragment,
        },
      ],
    };
    const result = await f.call('edit_quest_draft', args, 'large-edit');
    assert.equal(result.status, 'completed', JSON.stringify(result));
    const beat = await f.call('read_quest_draft', { section: 'beat', draftId });
    assert.equal(beat.status, 'completed');
    assert.ok(Buffer.byteLength(JSON.stringify(beat)) > 131072);
    const pub = await f.call(
      'publish_quest_draft',
      { draftId, expectedRecordRevision: result.data.recordRevision },
      'large-publish',
    );
    assert.equal(pub.status, 'completed', JSON.stringify(pub));
    const checkpoint = f.gateway.saveReceipts();
    assert.ok(checkpoint.receipts.some((r) => r.digest.length > 65536));
    restored = new McpGateway({
      runtime: f.game.runtime,
      credential: 'restored-only',
      allowedHosts: ['127.0.0.1:8099'],
    });
    restored.restoreReceipts(checkpoint);
    assert.deepEqual(restored.saveReceipts(), checkpoint);
    assert.deepEqual(
      await f.call('edit_quest_draft', args, 'large-edit'),
      result,
    );
  } finally {
    if (restored) await restored.dispose();
    await f.close();
  }
});
