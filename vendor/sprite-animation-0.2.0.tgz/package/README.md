# Sprite Animation

Small independent TypeScript atlas and playback package. The caller supplies elapsed seconds and owns image resources. Core has zero runtime dependencies, no DOM types, no clock, no event listeners and no Rocket dependency.

```ts
import { createAtlas, AnimationPlayer } from "sprite-animation";
const atlas = createAtlas({
  width: 16,
  height: 8,
  frames: {
    idle: { source: { x: 0, y: 0, width: 8, height: 8 } },
    step: { source: { x: 8, y: 0, width: 8, height: 8 } },
  },
  clips: {
    walk: [
      { frame: "idle", duration: 0.25 },
      { frame: "step", duration: 0.5 },
    ],
  },
});
const player = new AnimationPlayer(atlas);
player.play("walk");
player.advance(0.25);
const drawable = player.snapshot; // step, source rectangle and local visual bounds
player.play("walk", { mode: "once" });
const completion = player.advance(10); // once, holds final frame
player.dispose(); // clears player's atlas reference; other players retain their atlas
```

Development: Node.js 24, `npm ci`, then `npm run check`. Run the non-DOM demo with `npm run demo:headless`. `npm run smoke:package` packs a local tarball, installs it into a temporary consumer, compiles against its exported declarations without DOM/ambient types, and executes the emitted consumer. The package is private; no publishing is part of this milestone.

See [API and states](docs/API.md). The workspace also contains PLAN.md and docs/M1-REPORT.md for review tracking. Implemented: atlas validation, immutable snapshots, caller-controlled loop/once playback and an optional borrowed-image Canvas2D adapter. See [Canvas usage and demo](docs/CANVAS.md). Run `npm run demo:canvas` and open `http://127.0.0.1:8095/examples/canvas/`. Rocket integration remains under a separate review gate.
