# Core API — M1

Import `createAtlas`, `AnimationPlayer` and the exported metadata/snapshot types from `sprite-animation`. ES modules and ES2022 are required. Generations are bigint and must be stringified explicitly for JSON. A generation uniquely identifies a play within one player's lifetime, not across players.

## Atlas

`createAtlas({width, height, frames, clips})` copies and deeply freezes its own metadata. Input records remain caller-owned and mutable. Atlas and source dimensions are positive safe integers; source x/y are nonnegative safe integers. Rectangles must lie within the declared atlas. No image is loaded or validated here; dimensions are supplied by the consumer.

Frames have a source rectangle and optional finite pixel pivot. Default pivot is bottom-center. Local bounds are `{x:-pivot.x, y:-pivot.y, width, height}`. Both local endpoints must be finite and distinguishable in floating-point arithmetic. Pivots may lie outside the rectangle if bounds remain nondegenerate. These are visual bounds, not automatically gameplay collision geometry. Different-size frames can keep feet at local origin by specifying a suitable pivot for each.

Frame and clip records are nonempty with nonblank names. Clips contain nonempty dense arrays (missing/sparse steps are rejected) of `{frame, duration}`. Durations are positive finite seconds. References must resolve to an own atlas frame. Cumulative ends must be finite and strictly increasing: a duration rounded away during addition is rejected. Prototype-like names are supported through own entries in null-prototype records. Constructor accepts only atlases produced by createAtlas.

## Commands and states

Player begins idle with no selected clip, generation 0n and rate 1. `status`, `rate`, `generation` are readable diagnostics. `snapshot` is null when idle/disposed, otherwise a fresh frozen plain object containing frame name/source/pivot/bounds, atlasWidth/atlasHeight, clip, frameIndex, phase in seconds, mode, status, rate and generation. Nested objects refer to immutable atlas metadata. Reads do not affect timing.

| Command             | Idle                  | Playing (including rate zero)             | Paused                | Completed             | Disposed  |
| ------------------- | --------------------- | ----------------------------------------- | --------------------- | --------------------- | --------- |
| play(name, options) | Start at zero         | Start at zero, except preserve case below | Same                  | Same                  | Throws    |
| pause()             | No effect             | Become paused                             | No effect             | No effect             | Throws    |
| resume()            | No effect             | No effect                                 | Become playing        | No effect             | Throws    |
| reset()             | No effect             | New generation, phase zero, paused        | Same                  | Same                  | Throws    |
| setRate(rate)       | Set rate              | Set rate                                  | Set rate              | Set rate              | Throws    |
| advance(dt)         | Validate, return null | Advance unless zero rate/time             | Validate, return null | Validate, return null | Throws    |
| dispose()           | Dispose               | Dispose                                   | Dispose               | Dispose               | No effect |

`play` defaults to `{mode:'loop', restart:true}`. Restart increments generation and enters playing, retaining rate. `restart:false` with the same clip AND mode preserves phase, generation AND status, including paused/completed; it does not resume. Changing clip or mode starts a new playing generation even with restart=false. `reset` rewinds the selected clip into a new paused generation, retaining mode/rate. `resume` never restarts a completed animation. Generations use bigint and never wrap/reuse within the player.

Rate must be finite and nonnegative; zero is a playing state with frozen phase, not pause. Negative speed/reverse playback is unsupported. Invalid clip/mode/restart/rate/time is rejected before mutating player state or generation. Time must be finite nonnegative seconds even while idle/paused/completed. Scaled dt overflow is rejected before state mutation, including those states. Disposed commands throw before argument checks.

Disposal is final and idempotent, sets status disposed, clears clip/atlas references and phase, and snapshot becomes null. Rate/generation diagnostics retain their previous values. Already-returned snapshots/completion records remain valid immutable values. Shared atlas data and other players are unaffected. No callbacks/listeners/assets are retained or released.

## Timing, boundaries and completion

Frame intervals are half-open: a cumulative boundary belongs to the next frame. Exact total duration wraps a loop to frame zero; once playback becomes completed and holds the final frame. `advance` returns one frozen `{clip,generation}` completion record on that transition, otherwise null. Resume, repeated advance, pause and advance(0) produce no extra completion. Restart/reset/switch replace the old generation and cancel its completion eligibility. Dispose cancels it too. This record describes presentation completion; it has no authority over inventory, quests or other domain effects.

Loop advancement reduces scaled elapsed time modulo total duration before adding it to phase; crossing the endpoint uses subtraction to avoid overflowing a sum. Once playback compares against remaining duration before addition. Work is O(1) per advance and O(log clip frames) per snapshot, regardless of loop count or crossed frames. No catch-up callbacks, per-crossed-frame loop, elapsed clamp or hidden time source exists. Each advance consumes its supplied time; the caller must choose one update owner and avoid advancing in render or in both fixed/frame lanes. Any number of render/snapshot reads sees the same phase.

JavaScript numbers are binary64. Finite inputs can still lose low-order phase precision at enormous elapsed/duration ratios. Useful operation requires representable strictly increasing metadata ends and elapsed/phase resolution substantially finer than the shortest frame. For ordinary seconds-scale clips and short update steps, partition checks compare phase within 1e-12 seconds away from boundaries; binary-exact test durations/steps agree exactly. That test tolerance is not a universal error bound. Arbitrarily large elapsed times and rounded boundary ambiguities do not have exact partition guarantees. No epsilon advances a frame early; comparisons use the represented numbers. A rounded loop phase equal to duration is normalized to zero; a rounded once phase equal to duration completes immediately. Extremely small scaled time can underflow to zero. Use short caller-provided intervals rather than huge absolute timestamps. Overflowing scaled time rejects; large finite phase updates avoid addition overflow rather than silently dropping time.
