# Optional Canvas2D adapter — M2

Import core from `sprite-animation`; import `drawSprite`, `getSpriteBounds` and `SpriteImage`/`DrawOptions` from `sprite-animation/canvas2d`. Only the Canvas subpath needs DOM declarations. Core exports remain DOM-free, including when the package is installed independently.

```ts
import { AnimationPlayer } from "sprite-animation";
import { drawSprite, getSpriteBounds } from "sprite-animation/canvas2d";
// atlas and ready image are explicitly supplied by this consumer.
const player = new AnimationPlayer(atlas);
player.play("walk");
player.advance(dtSeconds); // exactly one host update owner
const frame = player.snapshot;
if (frame) {
  ctx.save();
  try {
    ctx.translate(100, 120); // caller supplies transforms, camera and scale
    drawSprite(ctx, image, frame, { flipX: true });
    const bounds = getSpriteBounds(frame, { flipX: true });
    ctx.strokeRect(bounds.x, bounds.y, bounds.width, bounds.height);
  } finally {
    ctx.restore();
  }
}
player.dispose(); // never closes the consumer's image
```

Supported ready sources in this slice are same-realm HTMLCanvasElement, HTMLImageElement and ImageBitmap. Canvas/bitmap width and height are intrinsic pixels. HTMLImageElement uses complete plus positive naturalWidth/naturalHeight, never display/CSS width or height. Loading/broken images, closed bitmaps, zero-size canvases, mismatched declared atlas dimensions and unsupported source objects throw. No OffscreenCanvas, video, SVGImageElement or cross-realm support is promised. Browser decode and CORS remain the consumer's responsibility. The adapter never fetches, decodes or caches.

`drawSprite(ctx, image, frame, options={})` validates safe pixel rectangles within declared dimensions, finite/nondegenerate pivots and matching visual bounds, boolean flips and actual source dimensions before saving context. It accepts the frame snapshot returned by the core. Invalid/null geometry or options throws. Snapshot status/phase is not interpreted as timing input; paused/completed frames draw normally. The source is borrowed and must remain alive through drawing; the caller must not release it prematurely.

Destination rectangle is exactly `(-pivot.x, -pivot.y, source.width, source.height)` in local coordinates. Existing caller transforms/styles/clip compose naturally. flipX/flipY mirrors around local origin by scaling -1 on that axis, so bounds become `(pivot.x-width, pivot.y-height)` on flipped axes. `getSpriteBounds` returns the matching frozen local visual rectangle without touching a context/image/player. Off-center/outside pivots are supported subject to the core's nondegenerate numeric bounds validation. These rectangles never update physics geometry.

Context save/restore is protected by finally after a successful save, including drawImage failure. Smoothing, globalAlpha, composition and clipping stay caller-owned and are not changed by the adapter. Draw does not clear/resize the canvas, advance animation, schedule work or release images. Canvas errors propagate after restoration.

## Standalone demo and cleanup

`npm run demo:canvas`, then open `http://127.0.0.1:8095/examples/canvas/`. The original 96×32 atlas is drawn in code into a caller-owned canvas. A and B share this image with independent players; A appears in both canvases. Both players advance once from one host requestAnimationFrame; three draws normally occur per tick. Flip control changes may cause extra paints without consuming time.

A's controls: clip, loop/once, play/restart, pause/resume, reset (new paused generation), rate including zero and both flips. B independently plays blink at rate 0.6. Cyan crosses mark pivots and gold rectangles show visual bounds. Playback counters expose phase/generation/completion and update/draw counts.

Destroy cancels the one pending frame, aborts nine host UI listeners, disposes both players once and displays disposed/null snapshots plus final counters. Recreate first destroys any prior host, then creates fresh players/artwork and one clock/listener scope. Two persistent lifecycle button listeners remain until pagehide, where the page controller removes them and its pagehide handler. The image is a canvas with no close/dispose API; releasing the destroyed host closure permits collection. Native ImageBitmap ownership is consumer-managed, never assumed by adapter/player.

Tests use simulated source/context objects for exact rectangles, validation and restore paths; real browser inspection is required separately. This demo establishes the standalone Canvas slice, not Rocket transforms/picking/leases or population capacity.

Native browser source verification is runnable at `http://127.0.0.1:8095/examples/canvas/verify.html` after the same build/server command. It checks actual canvas/image/bitmap sources, intrinsic dimensions, closed/unready/mismatch rejection, real context restoration after an injected drawing failure, clipping preservation and cleanup. It uses an original locally drawn PNG data URL, owns and closes its bitmap, and needs no external asset.
