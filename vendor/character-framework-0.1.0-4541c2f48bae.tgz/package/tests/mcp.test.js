import test from 'node:test';
import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { createMcpScenario } from '../dist/examples/mcp-scenario.js';
import { McpGateway } from '../dist/src/mcp/index.js';
import { CharacterRuntime } from '../dist/src/index.js';
import { FakeCaiClient } from '../examples/fake-cai-client.js';

const url = 'http://127.0.0.1:8094/mcp';
const credential = 'test-only-association-key';
let sequence = 0;
function fixture(t) {
  const scenario = createMcpScenario(credential);
  t.after(() => scenario.dispose());
  return scenario;
}
async function request(scenario, binding, body, extra = {}, method = 'POST') {
  return scenario.gateway.handle(
    new Request(url, {
      method,
      headers: {
        Authorization: `Bearer ${credential}`,
        Accept: 'application/json, text/event-stream',
        'Content-Type': 'application/json',
        ...binding,
        ...extra,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    }),
  );
}
async function connect(scenario, binding) {
  const response = await request(scenario, binding, {
    jsonrpc: '2.0',
    id: ++sequence,
    method: 'initialize',
    params: {
      protocolVersion: '2025-11-25',
      capabilities: {},
      clientInfo: { name: 'test-cai', version: '1' },
    },
  });
  assert.equal(response.status, 200);
  assert.equal((await response.json()).result.protocolVersion, '2025-11-25');
  const session = response.headers.get('mcp-session-id');
  assert.ok(session);
  const headers = {
    ...binding,
    'Mcp-Session-Id': session,
    'MCP-Protocol-Version': '2025-11-25',
  };
  const ready = await request(scenario, headers, {
    jsonrpc: '2.0',
    method: 'notifications/initialized',
  });
  assert.equal(ready.status, 202);
  return headers;
}
async function pump(scenario, promise) {
  let done = false;
  promise.then(
    () => {
      done = true;
    },
    () => {
      done = true;
    },
  );
  for (let i = 0; i < 1000 && !done; i++) {
    scenario.advance(0);
    await setImmediate();
  }
  assert.ok(done, 'Host-driven tool call must settle');
  return promise;
}
function call(scenario, headers, name, args = {}, key, extra = {}) {
  return request(
    scenario,
    headers,
    {
      jsonrpc: '2.0',
      id: ++sequence,
      method: 'tools/call',
      params: { name, arguments: args },
    },
    {
      'X-CF-Call-Id': `logical-${key ?? sequence}`,
      'X-CF-Turn-Request-Id': 'turn-1',
      ...(key ? { 'X-CF-Effect-Key': key } : {}),
      ...extra,
    },
  );
}
async function result(scenario, promise) {
  const response = await pump(scenario, promise);
  assert.equal(response.status, 200);
  const value = await response.json();
  assert.ok(value.result, JSON.stringify(value));
  assert.deepEqual(
    JSON.parse(value.result.content[0].text),
    value.result.structuredContent,
  );
  return value.result;
}
const quest = (scenario) =>
  scenario.draft('A winter survey', 'grove-1').toInput();

for (const choiceCount of [3, 4]) {
  test(`MCP returns schema-valid ${choiceCount}-choice branches with opaque IDs`, async (t) => {
    const scenario = fixture(t);
    const client = new FakeCaiClient(
      new URL(url),
      scenario.directorHeaders,
      credential,
      (target, init) => scenario.gateway.handle(new Request(target, init)),
    );
    await client.connect();
    t.after(() => client.close());
    const tools = await client.client.listTools();
    assert.ok(
      tools.tools.find((tool) => tool.name === 'create_quest').inputSchema
        .properties.quest.properties.flow,
    );
    const input = structuredClone(quest(scenario));
    const town = scenario.draft('Town', 'river-town').toInput().quest
      .objectives[0];
    input.quest.objectives = [
      { ...input.quest.objectives[0], id: 'survey' },
      { ...town, id: 'town' },
    ];
    input.quest.flow = {
      start: 'survey',
      stages: [
        {
          id: 'survey',
          objectives: ['survey'],
          choices: Array.from({ length: choiceCount }, (_, i) => ({
            id: '森'.repeat(159) + i,
            label: `Route ${i}`,
            next: 'town',
          })),
        },
        { id: 'town', objectives: ['town'] },
      ],
    };
    const headers = await connect(scenario, scenario.directorHeaders);
    const created = await result(
      scenario,
      call(scenario, headers, 'create_quest', input, 'flow-create'),
    );
    assert.equal(created.structuredContent.status, 'completed');
    const questId = created.structuredContent.data.questId;
    const offered = await result(
      scenario,
      call(
        scenario,
        headers,
        'offer_quest',
        { questId, recipientRef: 'player-1', dialogue: 'Help?' },
        'flow-offer',
      ),
    );
    await pump(
      scenario,
      scenario.narrative.choose(
        'player-1',
        offered.structuredContent.data.choices[0].id,
        'flow-accept',
      ),
    );
    scenario.visit('grove-1');
    for (let i = 0; i < 6; i++) {
      scenario.advance(0.1);
      await setImmediate();
    }
    const inspected = await pump(
      scenario,
      client.call(
        'inspect_quest',
        { questId, recipientRef: 'player-1' },
        { callId: 'flow-inspect', turnId: 'flow-turn' },
      ),
    );
    assert.equal(inspected.isError, false);
    assert.equal(inspected.structuredContent.data.flow.currentStage, 'survey');
    assert.equal(inspected.structuredContent.data.choices.length, choiceCount);
    assert.equal(inspected.structuredContent.data.choices[0].label, 'Route 0');
    assert.ok(inspected.structuredContent.data.choices[0].id.length > 160);
  });
}

test('official SDK client negotiates and retains full output schemas with isolated discovery', async (t) => {
  const scenario = fixture(t);
  const fetch_ = (target, init) =>
    scenario.gateway.handle(new Request(target, init));
  const forester = new FakeCaiClient(
    new URL(url),
    scenario.foresterHeaders,
    credential,
    fetch_,
  );
  const director = new FakeCaiClient(
    new URL(url),
    scenario.directorHeaders,
    credential,
    fetch_,
  );
  await Promise.all([forester.connect(), director.connect()]);
  t.after(() => Promise.all([forester.close(), director.close()]));
  const [local, world] = await Promise.all([
    forester.client.listTools(),
    director.client.listTools(),
  ]);
  assert.ok(local.tools.some((tool) => tool.name === 'request_work'));
  assert.ok(!world.tools.some((tool) => tool.name === 'request_work'));
  const schema = local.tools.find((tool) => tool.name === 'create_quest');
  assert.equal(schema.outputSchema.type, 'object');
  assert.equal(
    schema.inputSchema.properties.quest.properties.objectives.items.properties
      .condition.properties.arguments.maxProperties,
    16,
  );
  const outcomes = await pump(
    scenario,
    Promise.all([
      forester.call(
        'inspect_context',
        { scope: 'world' },
        { callId: 'local', turnId: 'chat' },
      ),
      director.call(
        'inspect_context',
        { scope: 'world' },
        { callId: 'world', turnId: 'story' },
      ),
    ]),
  );
  assert.equal(outcomes[0].structuredContent.code, 'scope_denied');
  assert.equal(outcomes[0].isError, true);
  assert.equal(outcomes[1].structuredContent.data.characterRef, 'director');
});

test('credentials, origins, hosts, crossed sessions and stale generations fail before discovery/effects', async (t) => {
  const scenario = fixture(t);
  const forester = await connect(scenario, scenario.foresterHeaders);
  const message = { jsonrpc: '2.0', id: ++sequence, method: 'tools/list' };
  assert.equal(
    (
      await request(scenario, forester, message, {
        Authorization: 'Bearer wrong',
      })
    ).status,
    401,
  );
  assert.equal(
    (
      await request(scenario, forester, message, {
        Origin: 'https://untrusted.example',
      })
    ).status,
    403,
  );
  assert.equal(
    (await request(scenario, forester, message, { Host: 'untrusted.example' }))
      .status,
    403,
  );
  assert.equal(
    (
      await request(
        scenario,
        { ...forester, 'X-CF-CAI-Session-Id': 'demo-session-2' },
        message,
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await request(
        scenario,
        { ...forester, ...scenario.directorHeaders },
        message,
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await request(
        scenario,
        { ...forester, 'X-CF-Binding-Generation': 'old' },
        message,
      )
    ).status,
    403,
  );
  assert.equal(scenario.narrative.stats.quests, 0);
  assert.equal(scenario.gateway.stats.receipts, 0);
});

test('lifecycle, protocol header, body limits and deletion are enforced', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  assert.equal(
    (
      await request(scenario, scenario.foresterHeaders, {
        jsonrpc: '2.0',
        id: ++sequence,
        method: 'tools/list',
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await request(
        scenario,
        headers,
        { jsonrpc: '2.0', id: ++sequence, method: 'tools/list' },
        { 'MCP-Protocol-Version': 'unsupported' },
      )
    ).status,
    400,
  );
  assert.equal(
    (await request(scenario, headers, undefined, {}, 'GET')).status,
    405,
  );
  assert.equal(
    (await request(scenario, headers, { padding: 'x'.repeat(140000) })).status,
    413,
  );
  const malformed = await scenario.gateway.handle(
    new Request(url, {
      method: 'POST',
      headers: { ...headers, Authorization: `Bearer ${credential}` },
      body: '{',
    }),
  );
  assert.equal(malformed.status, 400);
  assert.equal(
    (await request(scenario, headers, undefined, {}, 'DELETE')).status,
    200,
  );
  assert.equal(
    (
      await request(scenario, headers, {
        jsonrpc: '2.0',
        id: ++sequence,
        method: 'tools/list',
      })
    ).status,
    404,
  );
});

test('quest mutation waits for host advance; lost response, concurrent replay and conflict retain one effect', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const first = call(
    scenario,
    headers,
    'create_quest',
    quest(scenario),
    'create-1',
  );
  const duplicate = call(
    scenario,
    headers,
    'create_quest',
    quest(scenario),
    'create-1',
  );
  await setImmediate();
  assert.equal(scenario.narrative.stats.quests, 0);
  const response = await pump(scenario, first);
  // Deliberately discard the response without reading it, as a connector disconnect would.
  await response.body.cancel();
  const concurrent = await result(scenario, duplicate);
  const replayed = await result(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario), 'create-1'),
  );
  assert.deepEqual(replayed, concurrent);
  assert.equal(scenario.narrative.stats.quests, 1);
  const conflict = await result(
    scenario,
    call(
      scenario,
      headers,
      'create_quest',
      { quest: { ...quest(scenario).quest, title: 'Changed' } },
      'create-1',
    ),
  );
  assert.equal(conflict.structuredContent.code, 'effect_key_conflict');
  assert.equal(conflict.isError, true);
});

test('schema rejections are terminal receipts; corrected input needs a new key and capabilities remain scoped', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const bad = await result(
    scenario,
    call(scenario, headers, 'create_quest', { quest: {} }, 'bad'),
  );
  assert.equal(bad.structuredContent.code, 'invalid_arguments');
  assert.equal(
    (
      await result(
        scenario,
        call(scenario, headers, 'create_quest', quest(scenario), 'bad'),
      )
    ).structuredContent.code,
    'effect_key_conflict',
  );
  assert.equal(
    (
      await result(
        scenario,
        call(scenario, headers, 'create_quest', quest(scenario), 'corrected'),
      )
    ).isError,
    false,
  );
  const missingKey = await pump(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario)),
  );
  assert.equal((await missingKey.json()).error.code, -32602);
  const noCorrelation = await request(scenario, headers, {
    jsonrpc: '2.0',
    id: ++sequence,
    method: 'tools/call',
    params: { name: 'inspect_nearby', arguments: {} },
  });
  assert.equal((await noCorrelation.json()).error.code, -32602);
  const unavailable = await pump(
    scenario,
    call(scenario, headers, 'inspect_world'),
  );
  assert.equal((await unavailable.json()).error.code, -32602);
});

test('game tools use separate host lane and actions replay once even while reasoning is pending', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  scenario.forester.requestDecision({ greeting: 'hello' });
  scenario.director.requestDecision({ theme: 'winter' });
  const assigned = await result(
    scenario,
    call(scenario, headers, 'request_work', { jobId: 'forestry' }, 'work-1'),
  );
  assert.equal(assigned.structuredContent.data.assigned, true);
  scenario.assignments.clear();
  const replay = await result(
    scenario,
    call(scenario, headers, 'request_work', { jobId: 'forestry' }, 'work-1'),
  );
  assert.deepEqual(replay, assigned);
  assert.equal(scenario.assignments.size, 0);
  const nearby = await result(
    scenario,
    call(scenario, headers, 'inspect_nearby'),
  );
  assert.equal(nearby.structuredContent.data.location, 'Northern lumber yard');
  const denied = await result(
    scenario,
    call(scenario, headers, 'game_inspect_location', {
      playerRef: 'player-1',
      locationRef: 'river-town',
    }),
  );
  assert.equal(denied.structuredContent.code, 'entity_unavailable');
});

test('persistent receipts survive explicit identity restoration and fresh generation', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const created = await result(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario), 'saved'),
  );
  const saved = JSON.parse(JSON.stringify(scenario.gateway.saveReceipts()));
  const narrative = scenario.narrative.save();
  const prior = scenario.forester.snapshot();
  await scenario.gateway.dispose();
  scenario.forester.unregister();
  const restored = scenario.runtime.register(prior);
  const gateway = new McpGateway({
    runtime: scenario.runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
  });
  t.after(() => gateway.dispose());
  gateway.restoreReceipts(saved);
  scenario.narrative.restore(narrative);
  const newHeaders = gateway.bind('forester/workforce-17', restored);
  assert.notEqual(
    newHeaders['X-CF-Binding-Generation'],
    headers['X-CF-Binding-Generation'],
  );
  const restoredScenario = {
    ...scenario,
    gateway,
    advance: (seconds) => {
      scenario.runtime.advance(seconds);
      gateway.advance(seconds);
    },
  };
  const session = await connect(restoredScenario, newHeaders);
  const replay = await result(
    restoredScenario,
    call(restoredScenario, session, 'create_quest', quest(scenario), 'saved'),
  );
  assert.deepEqual(replay, created);
  assert.equal(scenario.narrative.stats.quests, 1);
  assert.equal(
    (
      await request(restoredScenario, headers, {
        jsonrpc: '2.0',
        id: ++sequence,
        method: 'tools/list',
      })
    ).status,
    403,
  );
  assert.throws(() => gateway.restoreReceipts(saved), /before connecting/);
});

test('replacement invalidates queued calls and cannot replay the retired identity receipts', async (t) => {
  const scenario = fixture(t);
  const old = await connect(scenario, scenario.foresterHeaders);
  await result(
    scenario,
    call(scenario, old, 'create_quest', quest(scenario), 'old-create'),
  );
  const pending = call(
    scenario,
    old,
    'create_quest',
    quest(scenario),
    'pending',
  );
  await setImmediate();
  scenario.forester.unregister();
  const replacement = scenario.registerForester();
  const metadata = scenario.gateway.bind('forester/workforce-17', replacement);
  await pump(scenario, pending);
  const next = await connect(scenario, metadata);
  const created = await result(
    scenario,
    call(scenario, next, 'create_quest', quest(scenario), 'old-create'),
  );
  assert.equal(created.structuredContent.data.questId, 'quest-2');
  assert.equal(scenario.narrative.stats.quests, 2);
  assert.equal(
    (
      await request(scenario, old, {
        jsonrpc: '2.0',
        id: ++sequence,
        method: 'tools/list',
      })
    ).status,
    403,
  );
});

test('bad host action output stays unresolved and retries do not execute again', async (t) => {
  const scenario = fixture(t);
  let executions = 0;
  const broken = {
    name: 'request_work',
    kind: 'action',
    description: 'Broken host fixture',
    inputSchema: { type: 'object' },
    validate: () => true,
    execute: () => {
      executions++;
      return { status: 'invented' };
    },
  };
  const metadata = scenario.gateway.bind(
    'forester/workforce-17',
    scenario.forester,
    [broken],
  );
  const headers = await connect(scenario, metadata);
  const first = await pump(
    scenario,
    call(scenario, headers, 'request_work', {}, 'broken'),
  );
  assert.equal((await first.json()).error.code, -32603);
  const second = await pump(
    scenario,
    call(scenario, headers, 'request_work', {}, 'broken'),
  );
  assert.equal((await second.json()).error.code, -32603);
  assert.equal(executions, 1);
  assert.equal(scenario.gateway.saveReceipts().receipts[0].state, 'unresolved');
});

test('malformed context output cannot reach the client as a successful tool result', async (t) => {
  const runtime = new CharacterRuntime({
    gameId: 'malformed-context',
    reasoning: { decide: () => ({ dialogue: '' }) },
    narrativeGame: {
      capabilities: () => [],
      recipientAvailable: () => true,
      referencesAvailable: () => true,
      inspectContext: () => ({ status: 'completed', data: { invented: true } }),
    },
  });
  const handle = runtime.register({
    id: 'director',
    name: 'Director',
    capabilities: [],
    cai: { characterId: 'profile', sessionId: 'session' },
  });
  const gateway = new McpGateway({
    runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
  });
  t.after(async () => {
    await gateway.dispose();
    runtime.dispose();
  });
  const scenario = {
    gateway,
    advance: (seconds) => {
      runtime.advance(seconds);
      gateway.advance(seconds);
    },
  };
  const headers = await connect(scenario, gateway.bind('director', handle));
  const response = await pump(
    scenario,
    call(scenario, headers, 'inspect_context', { scope: 'world' }),
  );
  assert.equal((await response.json()).error.code, -32603);
});

test('connection capacity counts concurrent initialization and deletion frees it', async (t) => {
  const scenario = fixture(t);
  const gateway = new McpGateway({
    runtime: scenario.runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
    maxConnections: 1,
  });
  t.after(() => gateway.dispose());
  const target = { ...scenario, gateway };
  const metadata = gateway.bind('forester', scenario.forester);
  const message = () => ({
    jsonrpc: '2.0',
    id: ++sequence,
    method: 'initialize',
    params: {
      protocolVersion: '2025-11-25',
      capabilities: {},
      clientInfo: { name: 'test', version: '1' },
    },
  });
  const responses = await Promise.all([
    request(target, metadata, message()),
    request(target, metadata, message()),
  ]);
  assert.deepEqual(
    responses.map((response) => response.status).sort(),
    [200, 503],
  );
  const accepted = responses.find((response) => response.status === 200);
  const session = {
    ...metadata,
    'Mcp-Session-Id': accepted.headers.get('mcp-session-id'),
    'MCP-Protocol-Version': '2025-11-25',
  };
  await request(target, session, undefined, {}, 'DELETE');
  assert.equal(gateway.stats.connections, 0);
  await connect(target, metadata);
});

test('oversized mutations are admission errors, while admitted corrections retain replay and conflict semantics', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const oversized = {
    quest: { ...quest(scenario).quest, summary: 'x'.repeat(66000) },
  };
  for (let attempt = 0; attempt < 2; attempt++) {
    const response = await pump(
      scenario,
      call(scenario, headers, 'create_quest', oversized, 'size-review'),
    );
    const body = await response.json();
    assert.equal(body.result, undefined);
    assert.equal(body.error.code, -32602);
    assert.deepEqual(body.error.data, {
      code: 'argument_limit',
      admitted: false,
    });
    assert.equal(scenario.gateway.stats.receipts, 0);
    assert.equal(scenario.narrative.stats.quests, 0);
  }
  const corrected = await result(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario), 'size-review'),
  );
  assert.equal(corrected.isError, false);
  assert.deepEqual(
    await result(
      scenario,
      call(scenario, headers, 'create_quest', quest(scenario), 'size-review'),
    ),
    corrected,
  );
  const changed = await result(
    scenario,
    call(
      scenario,
      headers,
      'create_quest',
      {
        quest: { ...quest(scenario).quest, title: 'Different admitted input' },
      },
      'size-review',
    ),
  );
  assert.equal(changed.structuredContent.code, 'effect_key_conflict');
  assert.equal(scenario.gateway.stats.receipts, 1);
  assert.equal(scenario.narrative.stats.quests, 1);
});

test('full receipt storage refuses admission but preserves existing replay and read tools', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const committed = await result(
    scenario,
    call(scenario, headers, 'create_quest', quest(scenario), 'kept'),
  );
  const saved = scenario.gateway.saveReceipts();
  await request(scenario, headers, undefined, {}, 'DELETE');
  scenario.gateway.restoreReceipts({
    ...saved,
    receipts: [
      saved.receipts[0],
      ...Array.from({ length: 4095 }, (_, index) => ({
        ...saved.receipts[0],
        key: `capacity-${index}`,
      })),
    ],
  });
  const next = await connect(scenario, scenario.foresterHeaders);
  for (let attempt = 0; attempt < 2; attempt++) {
    const response = await pump(
      scenario,
      call(scenario, next, 'create_quest', quest(scenario), 'not-admitted'),
    );
    const body = await response.json();
    assert.equal(body.result, undefined);
    assert.equal(body.error.code, -32603);
    assert.deepEqual(body.error.data, {
      code: 'receipt_limit',
      admitted: false,
    });
  }
  assert.equal(scenario.gateway.saveReceipts().receipts.length, 4096);
  assert.equal(scenario.narrative.stats.quests, 1);
  assert.deepEqual(
    await result(
      scenario,
      call(scenario, next, 'create_quest', quest(scenario), 'kept'),
    ),
    committed,
  );
  assert.equal(
    (
      await result(
        scenario,
        call(scenario, next, 'inspect_context', { scope: 'local' }),
      )
    ).isError,
    false,
  );
});

test('pending effects use the same public conflict code as committed receipts', async (t) => {
  const scenario = fixture(t);
  const headers = await connect(scenario, scenario.foresterHeaders);
  const first = call(
    scenario,
    headers,
    'create_quest',
    quest(scenario),
    'pending-conflict',
  );
  await setImmediate();
  const response = await call(
    scenario,
    headers,
    'create_quest',
    { quest: { ...quest(scenario).quest, title: 'Changed while pending' } },
    'pending-conflict',
  );
  const body = await response.json();
  assert.equal(body.result.structuredContent.code, 'effect_key_conflict');
  assert.equal(body.result.isError, true);
  assert.equal(scenario.narrative.stats.quests, 0);
  await result(scenario, first);
  assert.equal(scenario.narrative.stats.quests, 1);
});
