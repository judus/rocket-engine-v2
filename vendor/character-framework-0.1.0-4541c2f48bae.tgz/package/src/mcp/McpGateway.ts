import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { WebStandardStreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  McpError,
  ErrorCode,
  isInitializeRequest,
  SUPPORTED_PROTOCOL_VERSIONS,
} from '@modelcontextprotocol/sdk/types.js';
import type { CallToolResult } from '@modelcontextprotocol/sdk/types.js';
import { createHash, timingSafeEqual } from 'node:crypto';
import type { CharacterHandle, CharacterRuntime } from '../Runtime.js';
import { immutable, isJson } from '../json.js';
import type { Capability, CharacterSnapshot, Json } from '../types.js';
import type { NarrativeHandle } from '../narrative/NarrativeSystem.js';
import {
  boundedJson,
  canonical,
  record,
  reject,
  text,
} from '../narrative/validation.js';
import type { ToolName } from '../narrative/types.js';
import { capabilityContract, narrativeContracts } from './catalogue.js';
import type { ToolContract } from './catalogue.js';
import { HostLane, validResult } from './HostLane.js';

interface Binding {
  readonly key: string;
  readonly handle: CharacterHandle;
  readonly snapshot: CharacterSnapshot;
  readonly narrative: NarrativeHandle | undefined;
  readonly tools: ReadonlyMap<
    string,
    { contract: ToolContract; capability?: Capability }
  >;
}
interface Connection {
  readonly controller: AbortController;
  readonly binding: Binding;
  readonly transport: WebStandardStreamableHTTPServerTransport;
  // Low-level SDK API preserves the complete JSON Schemas without Zod projection.
  // eslint-disable-next-line @typescript-eslint/no-deprecated
  readonly server: Server;
  initialized: boolean;
  lastUsed: number;
}
export interface EffectReceipt {
  readonly scope: string;
  readonly key: string;
  readonly digest: string;
  readonly callId: string;
  readonly turnId: string;
  readonly state: 'terminal' | 'unresolved';
  readonly result?: Json;
}
export interface McpReceiptSave {
  readonly schemaVersion: 1;
  readonly associationId: string;
  readonly receipts: readonly EffectReceipt[];
}
interface PendingEffect {
  readonly digest: string;
  readonly promise: Promise<Json>;
}
export interface McpGatewayOptions {
  readonly runtime: CharacterRuntime;
  readonly credential: string;
  /** Exact HTTP authorities and Origin values. Missing Origin is allowed for server clients. */
  readonly allowedHosts: readonly string[];
  readonly allowedOrigins?: readonly string[];
  readonly path?: string;
  readonly maxConnections?: number;
  readonly idleTimeoutMs?: number;
}

/** One HTTP endpoint, immutable per-character connections, host-driven tool effects. */
export class McpGateway {
  readonly #options: McpGatewayOptions;
  readonly #credentialDigest: Buffer;
  readonly #bindings = new Map<string, Binding>();
  readonly #connections = new Map<string, Connection>();
  readonly #receipts = new Map<string, EffectReceipt>();
  readonly #pending = new Map<string, PendingEffect>();
  readonly #lane: HostLane;
  #closed = false;
  constructor(options: McpGatewayOptions) {
    if (
      !text(options.credential, 4096) ||
      !options.allowedHosts.length ||
      options.allowedHosts.some((host) => !text(host))
    )
      throw new TypeError('Credential and allowedHosts are required');
    if (
      options.maxConnections !== undefined &&
      (!Number.isSafeInteger(options.maxConnections) ||
        options.maxConnections < 1)
    )
      throw new TypeError('Invalid maxConnections');
    if (
      options.idleTimeoutMs !== undefined &&
      (!Number.isFinite(options.idleTimeoutMs) || options.idleTimeoutMs < 1)
    )
      throw new TypeError('Invalid idleTimeoutMs');
    this.#options = Object.freeze({
      ...options,
      allowedHosts: Object.freeze([...options.allowedHosts]),
      allowedOrigins: Object.freeze([...(options.allowedOrigins ?? [])]),
    });
    this.#credentialDigest = digestSecret(options.credential);
    this.#lane = new HostLane(options.runtime.stats.gameId);
  }
  /** Trusted host provisioning, never exposed as a model tool or public route. */
  bind(
    key: string,
    handle: CharacterHandle,
    capabilities: readonly Capability[] = [],
  ): Readonly<Record<string, string>> {
    if (this.#closed || !text(key))
      throw new TypeError('Invalid or closed binding');
    const snapshot = handle.snapshot();
    if (
      !snapshot.cai ||
      !this.#options.runtime
        .characters()
        .some(
          (character) =>
            character.binding.generation === snapshot.binding.generation,
        )
    )
      throw new TypeError(
        'Binding must belong to this runtime and have a CAI session',
      );
    for (const binding of this.#bindings.values())
      if (
        binding.key !== key &&
        binding.snapshot.binding.id === snapshot.binding.id
      )
        throw new TypeError('Character is already bound');
    const tools = new Map<
      string,
      { contract: ToolContract; capability?: Capability }
    >();
    const narrative = this.#options.runtime.narrative?.bind(handle);
    if (narrative)
      for (const [name, contract] of narrativeContracts)
        tools.set(name, { contract });
    for (const capability of capabilities) {
      if (
        !snapshot.capabilities.includes(capability.name) ||
        tools.has(capability.name)
      )
        throw new TypeError('Tool must be granted and have a unique name');
      tools.set(capability.name, {
        contract: capabilityContract(capability),
        capability: Object.freeze({
          ...capability,
          inputSchema: immutable(capability.inputSchema),
        }),
      });
    }
    const previous = this.#bindings.get(key);
    this.#bindings.set(key, { key, handle, snapshot, narrative, tools });
    if (previous) this.#invalidate(previous);
    return immutable({
      'X-CF-Binding-Key': key,
      'X-CF-CAI-Session-Id': snapshot.cai.sessionId,
      'X-CF-Binding-Generation': snapshot.binding.generation,
    });
  }
  unbind(key: string): void {
    const binding = this.#bindings.get(key);
    if (binding) {
      this.#bindings.delete(key);
      this.#invalidate(binding);
    }
  }
  /** Host calls this in its update boundary, alongside runtime.advance(). */
  advance(seconds: number): void {
    this.#lane.advance(seconds);
  }
  get stats() {
    return Object.freeze({
      connections: this.#connections.size,
      receipts: this.#receipts.size,
      pendingEffects: this.#pending.size,
      pendingHostTools: this.#lane.pending,
    });
  }
  async handle(request: Request): Promise<Response> {
    if (this.#closed) return failure(503, 'gateway_closed');
    const url = new URL(request.url);
    if (url.pathname !== (this.#options.path ?? '/mcp'))
      return failure(404, 'not_found');
    if (
      !this.#options.allowedHosts.includes(url.host) ||
      (request.headers.has('host') && request.headers.get('host') !== url.host)
    )
      return failure(403, 'host_denied');
    const origin = request.headers.get('origin');
    if (
      origin !== null &&
      !(this.#options.allowedOrigins ?? []).includes(origin)
    )
      return failure(403, 'origin_denied');
    const authorization = request.headers.get('authorization') ?? '';
    if (
      !timingSafeEqual(
        digestSecret(
          authorization.startsWith('Bearer ') ? authorization.slice(7) : '',
        ),
        this.#credentialDigest,
      )
    )
      return failure(401, 'unauthorized');
    const binding = this.#bindings.get(
      request.headers.get('x-cf-binding-key') ?? '',
    );
    if (
      !binding ||
      !this.#current(binding) ||
      request.headers.get('x-cf-cai-session-id') !==
        binding.snapshot.cai?.sessionId ||
      request.headers.get('x-cf-binding-generation') !==
        binding.snapshot.binding.generation
    )
      return failure(403, 'binding_denied');
    await this.#expire();
    let body: unknown;
    if (request.method === 'POST') {
      try {
        body = JSON.parse(await limitedBody(request));
      } catch (error) {
        return failure(
          error instanceof RangeError ? 413 : 400,
          error instanceof RangeError ? 'body_too_large' : 'invalid_json',
        );
      }
      if (!isJson(body)) return failure(400, 'invalid_message');
    }
    const sessionId = request.headers.get('mcp-session-id');
    let connection: Connection | undefined;
    if (sessionId !== null) {
      connection = this.#connections.get(sessionId);
      if (!connection) return failure(404, 'session_unavailable');
      if (connection.binding !== binding)
        return failure(403, 'session_binding_denied');
      const protocol = request.headers.get('mcp-protocol-version');
      if (protocol !== null && !SUPPORTED_PROTOCOL_VERSIONS.includes(protocol))
        return failure(400, 'unsupported_protocol');
      if (
        !connection.initialized &&
        record(body) &&
        body['method'] !== 'notifications/initialized' &&
        body['method'] !== 'ping'
      )
        return failure(400, 'not_initialized');
    } else {
      if (request.method !== 'POST' || !isInitializeRequest(body))
        return failure(400, 'initialization_required');
      if (this.#connections.size >= (this.#options.maxConnections ?? 64))
        return failure(503, 'connection_limit');
      connection = await this.#connect(binding);
    }
    connection.lastUsed = Date.now();
    if (request.method === 'GET')
      return new Response(null, {
        status: 405,
        headers: { Allow: 'POST, DELETE' },
      });
    if (request.method === 'DELETE')
      return connection.transport.handleRequest(request);
    let cancelled: (() => void) | undefined;
    const invalidated = new Promise<Response>((resolve) => {
      cancelled = () => {
        resolve(failure(409, 'binding_invalidated'));
      };
      connection.controller.signal.addEventListener('abort', cancelled, {
        once: true,
      });
    });
    const response = await Promise.race([
      connection.transport.handleRequest(request, { parsedBody: body }),
      invalidated,
    ]).finally(() => {
      if (cancelled)
        connection.controller.signal.removeEventListener('abort', cancelled);
    });
    if (!connection.transport.sessionId) await connection.server.close();
    return response;
  }
  /** Persist with narrative/game state at a quiescent host checkpoint. Sessions are ephemeral. */
  saveReceipts(): McpReceiptSave {
    if (this.#pending.size || this.#lane.pending)
      throw new Error('MCP effects must settle before checkpoint');
    return immutable({
      schemaVersion: 1,
      associationId: this.#options.runtime.stats.gameId,
      receipts: [...this.#receipts.values()],
    });
  }
  restoreReceipts(value: unknown): void {
    if (this.#connections.size || this.#pending.size || this.#lane.pending)
      throw new Error('Restore before connecting clients');
    if (
      !record(value) ||
      value['schemaVersion'] !== 1 ||
      value['associationId'] !== this.#options.runtime.stats.gameId ||
      !Array.isArray(value['receipts']) ||
      value['receipts'].length > 4096
    )
      throw new TypeError('Invalid MCP receipts');
    const receipts = new Map<string, EffectReceipt>();
    for (const raw of value['receipts']) {
      const receipt: unknown = raw;
      if (!validReceipt(receipt))
        throw new TypeError('Invalid MCP effect receipt');
      const key = canonical([receipt.scope, receipt.key]);
      if (receipts.has(key)) throw new TypeError('Duplicate MCP receipt');
      receipts.set(key, immutable(receipt));
    }
    this.#receipts.clear();
    for (const [key, receipt] of receipts) this.#receipts.set(key, receipt);
  }
  async dispose(): Promise<void> {
    if (this.#closed) return;
    this.#closed = true;
    this.#lane.dispose();
    await Promise.all(
      [...this.#connections.values()].map((connection) =>
        connection.server.close(),
      ),
    );
    this.#connections.clear();
  }
  async #connect(binding: Binding): Promise<Connection> {
    // This is the SDK's advanced JSON Schema handler path, rather than Zod registration.
    // eslint-disable-next-line @typescript-eslint/no-deprecated
    const server = new Server(
      { name: 'character-framework', version: '0.1.0' },
      { capabilities: { tools: {} } },
    );
    const reservation = crypto.randomUUID();
    const transport = new WebStandardStreamableHTTPServerTransport({
      sessionIdGenerator: () => crypto.randomUUID(),
      enableJsonResponse: true,
      maxRequestBodySize: 131072,
      onsessioninitialized: (sessionId) => {
        this.#connections.delete(reservation);
        this.#connections.set(sessionId, connection);
      },
    });
    const connection: Connection = {
      binding,
      server,
      transport,
      controller: new AbortController(),
      initialized: false,
      lastUsed: Date.now(),
    };
    server.oninitialized = () => {
      connection.initialized = true;
    };
    server.onclose = () => {
      connection.controller.abort();
      this.#connections.delete(reservation);
      if (transport.sessionId) this.#connections.delete(transport.sessionId);
    };
    server.setRequestHandler(ListToolsRequestSchema, (request) => {
      this.#assertCurrent(binding);
      if (request.params?.cursor)
        throw new McpError(
          ErrorCode.InvalidParams,
          'This bounded catalogue has no pagination cursor.',
        );
      return {
        tools: [...binding.tools.values()].map((entry) => entry.contract.tool),
      };
    });
    server.setRequestHandler(CallToolRequestSchema, async (request, extra) => {
      this.#assertCurrent(binding);
      const headers = new Headers();
      for (const [key, value] of Object.entries(
        extra.requestInfo?.headers ?? {},
      ))
        if (typeof value === 'string') headers.set(key, value);
      const callId = headers.get('x-cf-call-id');
      const turnId = headers.get('x-cf-turn-request-id');
      if (!text(callId) || !text(turnId))
        throw new McpError(
          ErrorCode.InvalidParams,
          'Trusted call and turn headers are required.',
        );
      const name = request.params.name;
      const entry = binding.tools.get(name);
      if (!entry)
        throw new McpError(ErrorCode.InvalidParams, 'Tool is unavailable.');
      const input: unknown = request.params.arguments ?? {};
      if (!boundedJson(input))
        throw new McpError(
          ErrorCode.InvalidParams,
          'Arguments exceed JSON size/depth limits; invocation was not admitted.',
          { code: 'argument_limit', admitted: false },
        );
      const mutation = entry.capability
        ? entry.capability.kind === 'action'
        : name === 'create_quest' || name === 'offer_quest';
      const execute = async (): Promise<Json> => {
        this.#assertCurrent(binding);
        if (!entry.contract.input(input))
          return jsonResult(
            reject(
              'invalid_arguments',
              'Arguments do not conform to the discovered schema.',
            ),
          );
        if (entry.capability) {
          if (!entry.capability.validate(input))
            return jsonResult(
              reject(
                'invalid_arguments',
                'Host argument validation rejected the call.',
              ),
            );
          const result = await this.#lane.call(
            () => {
              this.#assertCurrent(binding);
              return binding.handle.snapshot();
            },
            entry.capability,
            input,
            callId,
          );
          return { ...result };
        }
        if (!binding.narrative || !isNarrativeTool(name))
          throw new McpError(
            ErrorCode.InternalError,
            'Narrative service unavailable.',
          );
        const result = await binding.narrative.call(
          name,
          input,
          headers.get('x-cf-effect-key') ?? undefined,
        );
        return jsonResult(result);
      };
      const result = mutation
        ? await this.#effect(
            binding,
            name,
            input,
            headers.get('x-cf-effect-key'),
            callId,
            turnId,
            execute,
          )
        : await execute();
      if (entry.contract.output && !entry.contract.output(result))
        throw new McpError(
          ErrorCode.InternalError,
          'Host result failed the tool output schema; inspect the effect receipt before continuing.',
        );
      this.#assertCurrent(binding);
      return envelope(result);
    });
    // Reserve capacity before initialization awaits or concurrent connects can exceed the limit.
    this.#connections.set(reservation, connection);
    await server.connect(transport);
    return connection;
  }
  async #effect(
    binding: Binding,
    name: string,
    input: Json,
    effectKey: string | null,
    callId: string,
    turnId: string,
    execute: () => Promise<Json>,
  ): Promise<Json> {
    if (!text(effectKey))
      throw new McpError(
        ErrorCode.InvalidParams,
        'Trusted effect key required for mutations.',
      );
    const scope = canonical([
      this.#options.runtime.stats.gameId,
      binding.snapshot.binding.id,
      binding.snapshot.id,
      binding.snapshot.cai ? { ...binding.snapshot.cai } : null,
    ]);
    const key = canonical([scope, effectKey]);
    const digest = canonical({ name, arguments: input });
    const receipt = this.#receipts.get(key);
    if (receipt) {
      if (receipt.digest !== digest)
        return jsonResult(
          reject(
            'effect_key_conflict',
            'Effect key was already used with different input.',
          ),
        );
      if (receipt.state === 'unresolved' || receipt.result === undefined)
        throw new McpError(
          ErrorCode.InternalError,
          'Effect outcome unresolved; host reconciliation required.',
        );
      return receipt.result;
    }
    const pending = this.#pending.get(key);
    if (pending)
      return pending.digest === digest
        ? pending.promise
        : jsonResult(
            reject(
              'effect_key_conflict',
              'Effect key is in use with different input.',
            ),
          );
    if (this.#receipts.size + this.#pending.size >= 4096)
      throw new McpError(
        ErrorCode.InternalError,
        'Mutation receipt capacity reached; invocation was not admitted.',
        { code: 'receipt_limit', admitted: false },
      );
    const identity = { scope, key: effectKey, digest, callId, turnId };
    const promise = execute()
      .then(
        (result) => {
          this.#receipts.set(
            key,
            immutable({ ...identity, state: 'terminal', result }),
          );
          return result;
        },
        (error: unknown) => {
          this.#receipts.set(
            key,
            immutable({ ...identity, state: 'unresolved' }),
          );
          throw error;
        },
      )
      .finally(() => {
        this.#pending.delete(key);
      });
    this.#pending.set(key, { digest, promise });
    return promise;
  }
  #current(binding: Binding): boolean {
    if (this.#bindings.get(binding.key) !== binding) return false;
    try {
      return (
        binding.handle.snapshot().binding.generation ===
        binding.snapshot.binding.generation
      );
    } catch {
      return false;
    }
  }
  #assertCurrent(binding: Binding): void {
    if (!this.#current(binding))
      throw new McpError(
        ErrorCode.InvalidRequest,
        'Character binding is no longer current.',
      );
  }
  #invalidate(binding: Binding): void {
    for (const connection of this.#connections.values())
      if (connection.binding === binding) {
        connection.controller.abort();
        void connection.server.close().catch(() => undefined);
      }
  }
  async #expire(): Promise<void> {
    const now = Date.now();
    await Promise.all(
      [...this.#connections.values()]
        .filter(
          (connection) =>
            !this.#current(connection.binding) ||
            now - connection.lastUsed >
              (this.#options.idleTimeoutMs ?? 1800000),
        )
        .map((connection) => connection.server.close()),
    );
  }
}
function jsonResult(value: unknown): Json {
  if (!boundedJson(value))
    throw new McpError(ErrorCode.InternalError, 'Invalid JSON result.');
  return value;
}
function digestSecret(value: string): Buffer {
  return createHash('sha256').update(value).digest();
}
function failure(status: number, code: string): Response {
  return Response.json({ error: code }, { status });
}
function envelope(result: Json): CallToolResult {
  if (!record(result))
    throw new McpError(
      ErrorCode.InternalError,
      'Expected structured tool result.',
    );
  return {
    content: [{ type: 'text', text: JSON.stringify(result) }],
    structuredContent: result,
    isError: result['status'] === 'rejected',
  };
}
function isNarrativeTool(name: string): name is ToolName {
  return narrativeContracts.has(name);
}
async function limitedBody(request: Request): Promise<string> {
  const reader = request.body?.getReader();
  if (!reader) return '';
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    for (;;) {
      const chunk = await reader.read();
      if (chunk.done) break;
      size += chunk.value.byteLength;
      if (size > 131072) {
        await reader.cancel();
        throw new RangeError('Body too large');
      }
      chunks.push(chunk.value);
    }
  } finally {
    reader.releaseLock();
  }
  return new TextDecoder('utf-8', { fatal: true }).decode(
    Buffer.concat(chunks),
  );
}
function validReceipt(value: unknown): value is EffectReceipt {
  if (
    !record(value) ||
    !isJson(value) ||
    !text(value['scope'], 2000) ||
    !text(value['key']) ||
    !text(value['digest'], 131072) ||
    !text(value['callId']) ||
    !text(value['turnId'])
  )
    return false;
  return value['state'] === 'unresolved'
    ? value['result'] === undefined
    : value['state'] === 'terminal' && validResult(value['result']);
}
