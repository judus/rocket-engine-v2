import { immutable, isJson } from '../json.js';
import {
  canonical,
  integer,
  record,
  shape,
  text,
} from '../narrative/validation.js';

export type HostIntent =
  | { readonly kind: 'dialogue'; readonly message: string }
  | { readonly kind: 'choice'; readonly choiceId: string };
export type HostCommand =
  | (HostIntent & {
      readonly requestId: string;
      readonly expectedRevision: number;
    })
  | {
      readonly kind: 'retry';
      readonly requestId: string;
      readonly failedRequestId: string;
    }
  | {
      readonly kind: 'stop_waiting';
      readonly requestId: string;
      readonly pendingRequestId: string;
    };
export interface HostMessage {
  readonly id: string;
  readonly speaker: 'player' | 'character';
  readonly kind: 'dialogue';
  readonly text: string;
}
export interface HostChoice {
  readonly id: string;
  readonly label: string;
}
interface Operation {
  readonly id: string;
  readonly effectKey: string;
  readonly intent: HostIntent;
  readonly sent: boolean;
  readonly result: string | null;
  readonly done: boolean;
}
interface Delivery {
  readonly id: string;
  readonly digest: string;
  readonly operationId: string;
}
export interface HostPortSave {
  readonly schemaVersion: 1;
  readonly sessionId: string;
  readonly revision: number;
  readonly operations: readonly Operation[];
  readonly deliveries: readonly Delivery[];
  readonly messages: readonly HostMessage[];
  readonly choices?: readonly HostChoice[];
}
export interface HostSnapshot {
  readonly sessionId: string;
  readonly revision: number;
  readonly messages: readonly HostMessage[];
  readonly choices: readonly HostChoice[];
  readonly operationId: string | null;
  readonly authorityPending: boolean;
  readonly state: 'idle' | 'pending' | 'uncertain' | 'disposed';
  readonly commands: readonly (
    'dialogue' | 'choice' | 'retry' | 'stop_waiting'
  )[];
}
export interface HostDriver {
  /** Host retains this operation/effect identity, its conversation checkpoint and effect receipts. */
  run(
    operationId: string,
    effectKey: string,
    intent: HostIntent,
    retry: boolean,
  ): Promise<string>;
  choices(): readonly HostChoice[];
  current(): void;
}
function validIntent(value: unknown): value is HostIntent {
  return (
    (shape(value, ['kind', 'message']) &&
      value['kind'] === 'dialogue' &&
      text(value['message'], 8000) &&
      value['message'].trim().length > 0) ||
    (shape(value, ['kind', 'choiceId']) &&
      value['kind'] === 'choice' &&
      text(value['choiceId'], 1000))
  );
}
function validChoices(value: unknown): value is readonly HostChoice[] {
  return (
    Array.isArray(value) &&
    value.length <= 32 &&
    value.every(
      (choice: unknown) =>
        shape(choice, ['id', 'label']) &&
        text(choice['id'], 1000) &&
        text(choice['label'], 1000),
    ) &&
    new Set((value as HostChoice[]).map((choice) => choice.id)).size ===
      value.length
  );
}
const choiceKey = (choices: readonly HostChoice[]) =>
  canonical(choices.map((choice) => ({ id: choice.id, label: choice.label })));
function validSave(value: unknown): value is HostPortSave {
  if (
    !isJson(value) ||
    new TextEncoder().encode(JSON.stringify(value)).byteLength >
      64 * 1024 * 1024 ||
    !shape(
      value,
      [
        'schemaVersion',
        'sessionId',
        'revision',
        'operations',
        'deliveries',
        'messages',
        'choices',
      ],
      [
        'schemaVersion',
        'sessionId',
        'revision',
        'operations',
        'deliveries',
        'messages',
      ],
    ) ||
    value['schemaVersion'] !== 1 ||
    !text(value['sessionId']) ||
    !integer(value['revision']) ||
    (value['choices'] !== undefined && !validChoices(value['choices']))
  )
    return false;
  const ops: unknown = value['operations'];
  const deliveries: unknown = value['deliveries'];
  const messages: unknown = value['messages'];
  if (
    !Array.isArray(ops) ||
    ops.length > 128 ||
    !Array.isArray(deliveries) ||
    deliveries.length > 128 ||
    !Array.isArray(messages) ||
    messages.length > 64
  )
    return false;
  if (
    !ops.every(
      (op: unknown) =>
        shape(op, ['id', 'effectKey', 'intent', 'sent', 'result', 'done']) &&
        text(op['id']) &&
        text(op['effectKey']) &&
        validIntent(op['intent']) &&
        typeof op['sent'] === 'boolean' &&
        typeof op['done'] === 'boolean' &&
        (op['result'] === null || text(op['result'], 32000)) &&
        (!op['done'] || (op['sent'] && op['result'] !== null)),
    )
  )
    return false;
  const ids = (ops as Operation[]).map((op: Operation) => op.id);
  return (
    new Set(ids).size === ids.length &&
    (ops as Operation[]).filter((op: Operation) => !op.done).length <= 1 &&
    deliveries.every(
      (d: unknown) =>
        shape(d, ['id', 'digest', 'operationId']) &&
        text(d['id']) &&
        text(d['digest'], 20000) &&
        typeof d['operationId'] === 'string' &&
        ids.includes(d['operationId']),
    ) &&
    new Set((deliveries as Delivery[]).map((d: Delivery) => d.id)).size ===
      deliveries.length &&
    messages.every(
      (m: unknown) =>
        shape(m, ['id', 'speaker', 'kind', 'text']) &&
        text(m['id'], 200) &&
        ['player', 'character'].includes(String(m['speaker'])) &&
        m['kind'] === 'dialogue' &&
        text(m['text'], m['speaker'] === 'player' ? 8000 : 32000),
    )
  );
}

/** One trusted character host, many views. No network endpoint, CAI ID or credential is exposed. */
export class CharacterHostPort {
  readonly #driver: HostDriver;
  readonly #persist: (state: HostPortSave) => void | Promise<void>;
  readonly #listeners = new Set<(state: HostSnapshot) => void>();
  #saved: HostPortSave;
  #active = false;
  #publishing = false;
  #authorityDirty = false;
  #disposed = false;
  constructor(
    driver: HostDriver,
    persist: (state: HostPortSave) => void | Promise<void>,
    saved: unknown = {
      schemaVersion: 1,
      sessionId: crypto.randomUUID(),
      revision: 0,
      operations: [],
      deliveries: [],
      messages: [],
    },
  ) {
    if (!validSave(saved)) throw new TypeError('Invalid host port checkpoint');
    this.#driver = driver;
    this.#persist = persist;
    const choices = saved.choices ?? this.#sampleChoices();
    this.#saved = immutable({ ...saved, choices });
    this.#authorityDirty =
      choiceKey(choices) !== choiceKey(this.#sampleChoices());
  }
  save(): HostPortSave {
    return immutable(this.#saved);
  }
  read(): HostSnapshot {
    const pending = this.#saved.operations.find((op) => !op.done);
    const state = this.#disposed
      ? 'disposed'
      : this.#active
        ? 'pending'
        : pending
          ? 'uncertain'
          : 'idle';
    const choices = this.#disposed ? [] : (this.#saved.choices ?? []);
    return immutable({
      sessionId: this.#saved.sessionId,
      revision: this.#saved.revision,
      messages: this.#saved.messages,
      choices,
      operationId: pending?.id ?? null,
      authorityPending: this.#authorityDirty || this.#publishing,
      state,
      commands:
        state === 'disposed'
          ? []
          : state === 'pending'
            ? ['stop_waiting']
            : state === 'uncertain'
              ? ['retry', 'stop_waiting']
              : this.#authorityDirty ||
                  this.#publishing ||
                  this.#saved.deliveries.length >= 128
                ? []
                : ['dialogue', 'choice'],
    });
  }
  /** Host calls after committed narrative/game changes on its existing update boundary. */
  async publishAuthority(): Promise<HostSnapshot> {
    this.#assertLive();
    const choices = this.#sampleChoices();
    if (choiceKey(choices) === choiceKey(this.#saved.choices ?? [])) {
      if (!this.#publishing) this.#authorityDirty = false;
      return this.read();
    }
    this.#authorityDirty = true;
    if (this.#active || this.#publishing) return this.read(); // Coalesce while another checkpoint writer is active.
    if (this.#saved.revision >= Number.MAX_SAFE_INTEGER - 1)
      throw new Error('Host revision saturated');
    this.#publishing = true;
    try {
      const next = immutable({
        ...this.#saved,
        revision: this.#saved.revision + 1,
        choices,
      });
      await this.#persist(next);
      this.#assertLive();
      this.#saved = next;
      this.#authorityDirty =
        choiceKey(this.#sampleChoices()) !== choiceKey(choices);
    } finally {
      this.#publishing = false;
      this.#emit();
    }
    return this.read();
  }
  subscribe(listener: (state: HostSnapshot) => void): () => void {
    if (this.#disposed) throw new Error('Host port disposed');
    this.#listeners.add(listener);
    try {
      listener(this.read());
    } catch (error) {
      this.#listeners.delete(listener);
      throw error;
    }
    return () => {
      this.#listeners.delete(listener);
    };
  }
  async dispatch(command: HostCommand): Promise<HostSnapshot> {
    if (this.#disposed) throw new Error('Host port disposed');
    this.#driver.current();
    if (!record(command) || !text(command.requestId))
      throw new TypeError('Invalid host command');
    if (command.kind === 'stop_waiting') {
      if (
        !shape(command, ['kind', 'requestId', 'pendingRequestId']) ||
        this.read().operationId !== command.pendingRequestId
      )
        throw new Error('Unknown pending operation');
      return this.read(); // Presentation only; cannot clear uncertainty or cancel world effects.
    }
    const digest = canonical(command);
    const prior = this.#saved.deliveries.find(
      (item) => item.id === command.requestId,
    );
    if (prior && prior.digest !== digest)
      throw new Error('Host request identity conflict');
    const target =
      prior?.operationId ??
      (command.kind === 'retry' ? command.failedRequestId : command.requestId);
    let op = this.#saved.operations.find((item) => item.id === target);
    if (op?.done) {
      if (!prior) {
        if (
          command.kind !== 'retry' ||
          !shape(command, ['kind', 'requestId', 'failedRequestId'])
        )
          throw new Error('Host request identity conflict');
        if (this.#active || this.#publishing)
          throw new Error('Host operation pending');
        if (this.#saved.deliveries.length >= 128)
          throw new Error('Host request ledger saturated');
        this.#saved = immutable({
          ...this.#saved,
          deliveries: [
            ...this.#saved.deliveries,
            { id: command.requestId, digest, operationId: op.id },
          ],
        });
        this.#active = true;
        try {
          await this.#persist(this.save());
          this.#assertLive();
        } finally {
          this.#active = false;
          this.#emit();
        }
      }
      return this.read(); // Retained replay precedes stale revision checks.
    }
    if (this.#active || this.#publishing)
      throw new Error('Host operation pending');
    if (!prior && this.#saved.deliveries.length >= 128)
      throw new Error('Host request ledger saturated');
    if (command.kind === 'retry') {
      if (!shape(command, ['kind', 'requestId', 'failedRequestId']) || !op)
        throw new Error('Unknown retry identity');
    } else {
      const intent =
        command.kind === 'dialogue'
          ? { kind: command.kind, message: command.message }
          : { kind: command.kind, choiceId: command.choiceId };
      if (
        !integer(command.expectedRevision) ||
        !validIntent(intent) ||
        !shape(
          command,
          command.kind === 'dialogue'
            ? ['kind', 'requestId', 'expectedRevision', 'message']
            : ['kind', 'requestId', 'expectedRevision', 'choiceId'],
        )
      )
        throw new TypeError('Invalid host command');
      if (!op) {
        if (
          this.#authorityDirty ||
          choiceKey(this.#sampleChoices()) !==
            choiceKey(this.#saved.choices ?? [])
        ) {
          this.#authorityDirty = true;
          throw new Error(
            'Publish committed host authority before new commands',
          );
        }
        if (command.expectedRevision !== this.#saved.revision)
          throw new Error('Stale host revision');
        if (this.#saved.operations.some((item) => !item.done))
          throw new Error('Resolve retained host operation first');
        if (
          intent.kind === 'choice' &&
          !this.read().choices.some((choice) => choice.id === intent.choiceId)
        )
          throw new Error('Unavailable quest choice');
        op = immutable({
          id: command.requestId,
          effectKey: crypto.randomUUID(),
          intent,
          sent: false,
          done: false,
          result: null,
        });
        this.#saved = immutable({
          ...this.#saved,
          operations: [...this.#saved.operations, op],
        });
      }
    }
    const original = op;
    if (!prior)
      this.#saved = immutable({
        ...this.#saved,
        deliveries: [
          ...this.#saved.deliveries,
          { id: command.requestId, digest, operationId: op.id },
        ],
      });
    this.#active = true;
    try {
      this.#bump();
      // Mark uncertainty durably BEFORE dispatch. Restore never treats an unknown effect as unsent.
      const retry = original.sent;
      this.#replace({ ...original, sent: true });
      await this.#persist(this.save());
      this.#assertLive();
      const result =
        original.result ??
        (await this.#driver.run(
          original.id,
          original.effectKey,
          original.intent,
          retry,
        ));
      this.#assertLive();
      if (!text(result, 32000))
        throw new Error('Invalid host operation result');
      this.#replace({ ...original, sent: true, result, done: false });
      const messages =
        original.intent.kind === 'dialogue'
          ? [
              ...this.#saved.messages,
              {
                id: original.id + '/player',
                speaker: 'player' as const,
                kind: 'dialogue' as const,
                text: original.intent.message,
              },
              {
                id: original.id + '/character',
                speaker: 'character' as const,
                kind: 'dialogue' as const,
                text: result,
              },
            ].slice(-64)
          : this.#saved.messages;
      const acknowledged = immutable({
        ...this.#saved,
        revision: this.#saved.revision + 1,
        choices: this.#sampleChoices(),
        messages,
        operations: this.#saved.operations.map((item) =>
          item.id === original.id ? { ...item, done: true } : item,
        ),
      });
      await this.#persist(acknowledged);
      this.#assertLive();
      this.#saved = acknowledged;
    } finally {
      this.#active = false;
      if (this.#authorityDirty && this.read().state !== 'disposed')
        await this.publishAuthority();
      this.#emit();
    }
    return this.read();
  }
  dispose(): void {
    this.#disposed = true;
    this.#listeners.clear();
  }
  #sampleChoices(): readonly HostChoice[] {
    const choices = this.#driver.choices();
    if (!validChoices(choices))
      throw new Error('Invalid committed host choices');
    return immutable(choices);
  }
  #assertLive(): void {
    if (this.#disposed) throw new Error('Host port disposed');
    this.#driver.current();
  }
  #replace(op: Operation): void {
    this.#saved = immutable({
      ...this.#saved,
      operations: this.#saved.operations.map((item) =>
        item.id === op.id ? op : item,
      ),
    });
  }
  #bump(): void {
    if (this.#saved.revision >= Number.MAX_SAFE_INTEGER - 1)
      throw new Error('Host revision saturated');
    this.#saved = immutable({
      ...this.#saved,
      revision: this.#saved.revision + 1,
    });
    this.#emit();
  }
  #emit(): void {
    if (this.#disposed) return;
    const state = this.read();
    for (const listener of this.#listeners) {
      try {
        listener(state);
      } catch {
        /* A view cannot interrupt host settlement. */
      }
    }
  }
}
