# Production Workshop 1.0.0

A strict TypeScript production simulation with a plain HTML/CSS/JavaScript demo. The framework has no DOM, canvas, engine, service-container, timer-global or runtime-package dependency. It compiles to native ES modules plus `.d.ts` declarations.

## Run

```sh
npm ci
npm start
# Open http://127.0.0.1:8088
```

```sh
npm test          # builds and tests the emitted JavaScript
npm run examples # runs settlement, ship, TypeScript, production-effects, transport, item-transport, persistence, accounting, diagnostics, scoped-read, item-selection, factory-removal and network examples
npm run typecheck # strict TypeScript checks without emission
npm run lint      # correctness-focused Oxlint checks
npm run check     # static analysis, tests and examples
```

Select **Settlement** or **Ship fabricator** in the page header. Scenarios restart when switched. Reloading resets state.

## Framework and examples

- `src/index.ts`: public exports.
- `src/models.ts`: authorable definitions, commands, events and snapshot types.
- `src/registry.ts`: registration validation and immutable content.
- `src/inventory.ts`: atomic inventory operations, reservations and instant transfers.
- `src/simulation.ts`: facility instances, jobs, fair input allocation and fixed ticks.
- `src/outcome.ts`: deterministic per-batch quality and bonus resolution.
- `src/clock.ts`: optional adapter from host timestamps to elapsed simulation time.
- `src/settlement-content.ts`: all 43 original building definitions converted from the archived `game-engine-2/newly/apps/game/Settings.js`; Grand Warehouse arguments corrected, original accelerated recipes retained.
- `src/examples.ts`: independent settlement and ship configurations and factories.
- `src/minimal-example.ts`: runnable TypeScript configuration example.
- `examples/*.mjs`: runnable JavaScript clients of the compiled API.
- `app.js`: demo presentation and commands, importing compiled modules.

Read [API](docs/API.md), [model and lifecycle](docs/MODEL.md), and [examples and integration](docs/EXAMPLES.md). The browser has a [quick guide](docs/guide.html).

## Deliberate scope

The settlement keeps residences, construction, workforce, warehouses and the original recipe chains. Construction now charges configured credits as well as materials. Currency is not capacity-limited. Maintenance, resident consumption and population unlock thresholds remain outside this demo; incomplete original recipes such as input-free concrete remain explicit content, not engine rules.

The ship refines ore, prints circuits and fabricates advanced sensors and individual weapons with no workforce. Cargo is finite; the demo resupply button buys a shipment for credits. That purchase policy lives in the demo, not the framework.

Workforce is a pool scoped to an inventory. Workers are assigned at construction and remain assigned when a facility is suspended. Worker slots aggregate actual efficiencies, and named modifiers change active work immediately at tick boundaries. Named operating conditions allow the host to pause a staffed or powered facility independently. Direct transfers remain instant. Bulk and individual goods can now be reserved, picked up and unloaded by an external logistics host; worker movement and offline progression policies remain external. Safe factory removal is supported after draining work and checking workforce/capacity dependencies. Versioned save/restore is supported, including active batches and deliveries.

The browser explicitly pauses while hidden. The core accepts all elapsed time provided to it without a silent cap. Long advances synchronously process every tick; no claim of large-world performance is made.

This project is independent of Rocket Engine and Zemegagame; both are unchanged.

## Production effects

The demo exposes worker efficiency/occupancy, specialist and failure controls. Ship weapons have per-item health/precision and optional reinforcement; settlement coal mines roll a 1% diamond bonus at completion. See [the complete contract and runnable examples](docs/PRODUCTION-EFFECTS.md). Game systems calculate experience, perks, damage and repair; the framework owns progress, ingredient consumption and stable batch outcomes.

## Local buffers and transport

[The transport demo](logistics.html) connects a warehouse and smelter through local input/output buffers, with travel progress bars and automatic/manual dispatch. Read [the delivery API and ownership contract](docs/LOGISTICS.md). `src/transport-example.ts` supplies the example host timers; the production core owns mixed bulk/item shipments but does not schedule travel. Run `node examples/transport.mjs` after building.

Specific equipment can be shipped by ID alongside bulk cargo, preserving quality and wear through transit, blocked arrival and return. `examples/item-transport.mjs` manufactures and transports a weapon, asserting exact item equality.

## Hardened contracts

Inventories are read-only views. Use simulation commands for stock, item spawn/repair/consume, instant transfers and deliveries. Item identities are unique across the world, including transit and blocked production. FIFO requests hold partial inputs to prevent small consumers starving larger bundles; hosts still own cyclic-chain/buffer policy.

`advance(seconds)` retains fractional microseconds; `advanceTicks(count)` accepts exact ticks. Multiple batches can complete per tick, preserving surplus work. `save()` and `Simulation.restore(data)` round-trip a JSON checkpoint (format 7; legacy formats 4, 5 and 6 remain readable); restore accepts all four; external travel timers and UI are host state. `deliverySnapshot()` and terminal-history pruning avoid scanning history for routine logistics. Read [the API and persistence contract](docs/API.md).

## Production inspector

Expand **Production inspector** in the settlement/ship demo to select a job, see blockers and productivity sources, inspect input reservations, and locate an individual item by ID. **Validate state** checks ownership, batch identities, workforce, reservations and derived indexes through the restore validator. Optional tracing keeps at most 200 entries (the panel displays the newest 20); it stays disabled by default. Run `node examples/diagnostics.mjs` for the same read-only APIs outside the browser.

## Scoped presentation reads

Use `simulation.summary()`, `facilityIds()` and `facilitySnapshot(id)` for selected production views. Managed inventories expose `summary()` and bounded `itemPage({offset, limit, resourceId?})`. The demos use these reads during painting; the production page has previous/next controls for its 50-item windows. Full snapshots remain available for explicit world inspection. `examples/scoped-reads.mjs` demonstrates detached reads and pagination.

## Individual inputs, demolition and networks

Recipes can consume specific equipment using one-shot `setInputItems(factoryId, recipeId, itemIds)` selection. No arbitrary item is chosen; reservations protect identities alongside bulk stock, and consumed attributes remain inspectable during the batch. Outputs are new goods. Run `node examples/item-selection.mjs`.

Use **Drain batches** in the demo to finish current work without starting another batch, then **Remove**. The API refuses active batches and unsafe loss of workforce/capacity. Stored goods, inventories and deliveries survive; construction costs are not refunded. `examples/factory-removal.mjs` checks manufactured identities after removal and restore.

Separate inventories/endpoints support planet/faction networks under one clock; the host owns membership and trade permissions. `examples/networks.mjs` demonstrates local stock/workforce and explicit links. Separate simulations are independent ownership domains; cross-simulation identity transfer is not yet supported. Read [the complete API contracts](docs/API.md#selecting-individual-recipe-inputs).

## Static analysis without runtime ceremony

Strict TypeScript checking and correctness-focused Oxlint analysis run in `npm run check`. Rules are explicit, development-only, and scoped to the typed core plus JavaScript clients. Efficient loops, intentional mutation, caches and ownership boundaries are supported. Prefer a documented narrow exception over introducing slower code just to appease a rule. See [the analysis scope and performance policy](docs/STATIC-ANALYSIS.md).

## Web Worker lab

[worker.html](worker.html) runs 6,000 factories across 2,000 active ore → alloy → equipment chains. A module worker owns production; the main thread receives twelve job summaries and aggregate counts, and animates a responsiveness marker. Compare against direct main-thread execution, measure 10/30/60-second RAF windows, and stress catch-up/checkpoint/restore. Routine messages are bounded; full checkpoint export is explicit. See [the protocol, clock policy and measurement limits](docs/WORKER.md). `examples/web-worker.mjs` verifies the same workload/protocol through a Node worker.

`npm run soak` exercises 300 simulated seconds in real Node workers, with retained versus consumed equipment and exact save/restore continuation checks. The worker guide documents lifecycle failures, elapsed-time barriers and the compact item-issuance model and remaining history memory limits.

Item identities are framework-owned. `spawnItem()` accepts three arguments; custom IDs are rejected. Save format 4 replaces per-item tombstones with counters and deterministic producer provenance; previous formats are rejected without migration. See [identity guarantees and memory limits](docs/IDENTITIES.md).

## Guarded inventory retirement

Version 1.1.0 adds `removeInventory(id)` with typed blockers for goods, reservations, workforce, live factories and active cargo references. Success prunes only referencing terminal delivery history and remains reloadable without changing save format 4. Factory removal is unchanged. See [the contract, host-policy audit and separate proposals](docs/INVENTORY-RETIREMENT.md). Run `node examples/inventory-retirement.mjs` after building.

## Timed construction and worker presence

Version 2.0.0 adds explicit construction orders while preserving immediate `addFacility()` behavior. Costs stay reserved during work and are consumed once at atomic activation; cancellation of unfinished orders is non-destructive. Production now requires host-reported local attendance; workforce allocation and slots do not imply presence. Partial staffing works by default, with configurable `minimumWorkforce` for stricter thresholds. Ten slots and one attendee give 10% base capacity. Save format 4 stores orders and attendance; earlier formats are rejected without migration. Existing callers of staffed facilities must report attendance explicitly, as the demos now do. See [contracts, limits and example](docs/TIMED-CONSTRUCTION.md).

Optional read-only MCP telemetry is available from `production-workshop/mcp`; see [the API and ownership contract](docs/MCP-TELEMETRY.md). Transport remains host-owned. Run `node examples/mcp-telemetry.mjs` after building.

## Object inventories (2.2.0)

Attach inventories to arbitrary object IDs with named storage roles. Shared unit capacity and bulk-stack/item slot capacity are enforced through normal production and transfers. See [the full API and persistence rules](docs/OBJECT-INVENTORIES.md), run `node examples/object-inventories.mjs`, or open [the player/house/lake demo](inventory.html). New saves use format 7; formats 4, 5 and 6 remain readable. Rocket is unchanged.

## Inventory operations (2.3.0)

Atomic mixed exchanges and transformations, explicit resource restrictions, integer weight/volume budgets, and a committed inventory event feed share the existing stock authority. See [the complete operation/event contract](docs/INVENTORY-OPERATIONS.md), run `node examples/inventory-operations.mjs`, or open [the operations demo](operations.html). New checkpoints use format 7 with persisted event position. Rocket is unchanged.

## Inventory context and equipment (2.4.0)

Numeric inventory modifiers expose matching effective item attributes without changing their base values. Separate JSON metadata stays inert. Equipment inventories accept one individual item and use atomic equip/swap/unequip operations. See [the contract](docs/INVENTORY-CONTEXT.md), run `node examples/inventory-context.mjs`, or open [the interactive example](context.html). Save format 7 retains the context; genuine formats 4–6 remain readable. Permissions and nested containers are not implemented.
