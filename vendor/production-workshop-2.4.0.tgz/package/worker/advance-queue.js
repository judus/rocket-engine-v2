/** Host elapsed-time buffer. One advance in flight; barriers capture an exact command boundary. */
export class WorkerAdvanceQueue {
  #send;
  #pending = 0;
  #inFlight = null;
  #barrier = null;
  #failure = null;
  #closed = false;
  #queued = 0;
  #applied = 0;
  constructor(send) {
    this.#send = send;
  }
  get pendingSeconds() {
    return this.#pending;
  }
  get busy() {
    return this.#inFlight !== null || this.#barrier !== null;
  }
  get backlogSeconds() {
    return Math.max(0, this.#queued - this.#applied);
  }
  add(seconds) {
    this.#assertOpen();
    if (!Number.isFinite(seconds) || seconds < 0)
      throw new RangeError('Elapsed seconds must be finite and nonnegative');
    this.#pending += seconds;
    this.#queued += seconds;
  }
  advance() {
    this.#assertOpen();
    if (this.busy || this.#pending === 0) return null;
    const seconds = this.#pending;
    this.#pending = 0;
    return this.#advance(seconds);
  }
  /** Wait for earlier work, then commit only elapsed time captured when this barrier was requested. */
  flush() {
    this.#assertOpen();
    if (this.#barrier)
      throw new Error('An elapsed-time barrier is already active');
    const seconds = this.#pending;
    this.#pending = 0;
    const operation = (async () => {
      await this.#inFlight;
      this.#assertOpen();
      return seconds > 0 ? this.#advance(seconds) : null;
    })();
    this.#barrier = operation.finally(() => {
      this.#barrier = null;
    });
    return this.#barrier;
  }
  close() {
    this.#closed = true;
    this.#pending = 0;
  }
  #assertOpen() {
    if (this.#failure) throw this.#failure;
    if (this.#closed) throw new Error('Elapsed-time queue is closed');
  }
  #advance(seconds) {
    const operation = Promise.resolve().then(() => {
      this.#assertOpen();
      return this.#send(seconds);
    });
    this.#inFlight = operation.then(
      (reply) => {
        this.#applied += seconds;
        this.#inFlight = null;
        return reply;
      },
      (error) => {
        this.#failure = error;
        this.#inFlight = null;
        throw error;
      },
    );
    return this.#inFlight;
  }
}
