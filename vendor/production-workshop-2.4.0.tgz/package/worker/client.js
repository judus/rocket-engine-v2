/** Browser host bridge. One terminal failure rejects every outstanding request. */
export class WorkerDemoClient {
  #worker;
  #onFailure;
  #nextId = 1;
  #pending = new Map();
  #failure = null;
  constructor(
    onFailure = () => {},
    worker = new Worker(new URL('./entry.js', import.meta.url), {
      type: 'module',
    }),
  ) {
    this.#worker = worker;
    this.#onFailure = onFailure;
    worker.onmessage = ({ data }) => {
      if (data === null || typeof data !== 'object') {
        this.#fail(new Error('Malformed worker reply'));
        return;
      }
      const pending = this.#pending.get(data.id);
      if (!pending) {
        this.#fail(new Error(`Unexpected worker reply ID: ${data.id}`));
        return;
      }
      if (data.ok === true) {
        if (
          !data.result ||
          typeof data.result !== 'object' ||
          !Number.isFinite(data.workMilliseconds) ||
          data.workMilliseconds < 0
        ) {
          this.#fail(new Error('Malformed worker success reply'));
          return;
        }
        this.#pending.delete(data.id);
        pending.resolve(data);
      } else if (
        data.ok === false &&
        typeof data.error?.name === 'string' &&
        typeof data.error?.message === 'string'
      ) {
        this.#pending.delete(data.id);
        const error = new Error(data.error.message);
        error.name = data.error.name;
        pending.reject(error); // A rejected command does not kill a healthy owner.
      } else this.#fail(new Error('Malformed worker error reply'));
    };
    worker.onerror = (event) => this.#fail(new Error(event.message));
    worker.onmessageerror = () =>
      this.#fail(new Error('Worker message could not be decoded'));
  }
  request(command) {
    if (this.#failure) return Promise.reject(this.#failure);
    const id = this.#nextId++;
    return new Promise((resolve, reject) => {
      this.#pending.set(id, { resolve, reject });
      try {
        this.#worker.postMessage({ id, command });
      } catch (error) {
        this.#pending.delete(id);
        reject(error);
      }
    });
  }
  close() {
    const error = new Error('Worker client closed');
    error.name = 'AbortError';
    this.#fail(error, false);
  }
  #fail(error, notify = true) {
    if (this.#failure) return;
    this.#failure = error;
    this.#worker.onmessage = null;
    this.#worker.onerror = null;
    this.#worker.onmessageerror = null;
    this.#worker.terminate();
    this.#worker = null;
    for (const pending of this.#pending.values()) pending.reject(error);
    this.#pending.clear();
    if (notify) this.#onFailure(error);
  }
}
