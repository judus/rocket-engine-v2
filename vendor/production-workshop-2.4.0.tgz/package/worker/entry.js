import { WorkerDemoHost } from '../dist/worker-demo.js';
const host = new WorkerDemoHost();
self.onmessage = ({ data }) => {
  const started = performance.now();
  try {
    const result = host.handle(data.command);
    self.postMessage({
      id: data.id,
      ok: true,
      result,
      workMilliseconds: performance.now() - started,
    });
  } catch (error) {
    self.postMessage({
      id: data.id,
      ok: false,
      error: { name: error.name, message: error.message },
    });
  }
};
