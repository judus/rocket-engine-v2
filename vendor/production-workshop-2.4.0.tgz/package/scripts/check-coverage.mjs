import { readdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { stripVTControlCharacters } from 'node:util';
// Check one aggregate report: isolated child reporters can hide a decimal-floor
// miss in the final merged total. Keep the admitted baseline explicit here.
const root = fileURLToPath(new URL('../', import.meta.url));
const files = readdirSync(new URL('../tests/', import.meta.url))
  .filter((name) => name.endsWith('.test.mjs'))
  .sort()
  .map((name) => `tests/${name}`);
const result = spawnSync(
  process.execPath,
  [
    '--test',
    '--experimental-test-coverage',
    '--test-coverage-include=dist/**/*.js',
    ...files,
  ],
  { cwd: root, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 },
);
process.stdout.write(result.stdout ?? '');
process.stderr.write(result.stderr ?? '');
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status ?? 1);
const report = stripVTControlCharacters(result.stdout);
for (const name of ['simulation.js', 'inventory.js', 'mcp.js']) {
  if (!report.includes(name))
    throw new Error(`Missing runtime coverage for ${name}`);
}
const totals = [
  ...report.matchAll(
    /all files\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)/g,
  ),
];
if (totals.length !== 1)
  throw new Error('Expected exactly one aggregate coverage report');
for (const [index, name, minimum] of [
  [1, 'lines', 98.5],
  [2, 'branches', 94.5],
  [3, 'functions', 97.5],
]) {
  const actual = Number(totals[0][index]);
  if (!Number.isFinite(actual) || actual < minimum)
    throw new Error(`${name} coverage ${actual}% is below ${minimum}%`);
}
