import {
  Worker,
  isMainThread,
  parentPort,
  workerData,
} from 'node:worker_threads';
import { performance } from 'node:perf_hooks';
import { createHash } from 'node:crypto';
import { writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { createWorkerWorld } from '../dist/worker-demo.js';
import { Simulation } from '../dist/index.js';

// Accelerated workload/heap experiment, not a real-time browser frame benchmark.
const sample = (sim) => {
  let weapons = 0,
    batches = 0,
    producing = 0;
  for (let chain = 0; chain < 2000; chain++)
    weapons += sim.inventory(`finished-${chain}`).quantity('weapon');
  for (const id of sim.facilityIds())
    for (const job of sim.facilitySnapshot(id).jobs) {
      batches += job.batchesCompleted;
      if (job.state === 'producing') producing++;
    }
  return {
    tick: sim.summary().tick,
    timeSeconds: sim.summary().timeSeconds,
    weapons,
    batches,
    producing,
  };
};
if (isMainThread) {
  const seconds = Number(process.argv[2] ?? 300);
  assert.ok(
    Number.isSafeInteger(seconds) &&
      seconds >= 30 &&
      seconds <= 600 &&
      seconds % 10 === 0,
    'Use 30–600 simulation seconds, in multiples of 10.',
  );
  const results = [];
  for (const mode of ['retain', 'consume']) {
    const result = await new Promise((resolve, reject) => {
      const worker = new Worker(new URL(import.meta.url), {
        workerData: { mode, seconds },
      });
      let completed = false;
      worker.on('message', (message) => {
        if (message.type === 'progress')
          process.stdout.write(
            `${mode}: ${message.sample.timeSeconds}s simulated, ${message.sample.heapMiB.toFixed(1)} MiB worker heap\n`,
          );
        else {
          completed = true;
          resolve(message.result);
        }
      });
      worker.on('error', reject);
      worker.on('exit', (code) => {
        if (!completed) reject(new Error(`Soak worker exited (${code})`));
      });
    });
    results.push(result);
  }
  const output = process.argv[3] ?? '/tmp/production-worker-soak.json';
  writeFileSync(
    output,
    JSON.stringify(
      {
        description:
          '6000 factories, accelerated real Node workers; forced GC at sampling points, outside advance timing. Retained goods versus explicit host consumption. Not a browser frame or hours-long play-session test.',
        node: process.version,
        results,
      },
      null,
      2,
    ),
  );
  console.log(`Saved ${output}`);
} else {
  assert.equal(
    typeof global.gc,
    'function',
    'Run parent Node with --expose-gc to measure collected heap.',
  );
  const { mode, seconds } = workerData;
  let sim = createWorkerWorld();
  let consumed = 0;
  const samples = [];
  const started = performance.now();
  let advanceMilliseconds = 0;
  function collect() {
    for (let chain = 0; chain < 2000; chain++) {
      const id = `finished-${chain}`,
        inventory = sim.inventory(id);
      while (inventory.quantity('weapon') > 0) {
        for (const item of inventory.itemPage({
          resourceId: 'weapon',
          limit: 500,
        }).items) {
          assert.ok(sim.consumeItem(id, item.id));
          consumed++;
        }
      }
    }
  }
  function record() {
    const value = { ...sample(sim), consumed };
    global.gc();
    value.heapMiB = process.memoryUsage().heapUsed / 2 ** 20;
    samples.push(value);
    parentPort.postMessage({ type: 'progress', sample: value });
  }
  record();
  for (let elapsed = 0; elapsed < seconds; elapsed += 10) {
    const t = performance.now();
    sim.advanceTicks(200);
    advanceMilliseconds += performance.now() - t;
    if (mode === 'consume') collect();
    if ((elapsed + 10) % 60 === 0 || elapsed + 10 === seconds) record();
  }
  assert.equal(sample(sim).producing, 6000);
  function verifyRoundTrip(sim) {
    let checkpoint = sim.save();
    const issued = sample(sim).weapons + consumed;
    assert.ok(!Object.hasOwn(checkpoint, 'issuedItemIds'));
    const stringifyStart = performance.now();
    let json = JSON.stringify(checkpoint);
    const stringifyMilliseconds = performance.now() - stringifyStart;
    checkpoint = null;
    const restoreStart = performance.now();
    let restored = Simulation.restore(JSON.parse(json));
    const restoreMilliseconds = performance.now() - restoreStart;
    assert.deepEqual(sample(restored), sample(sim));
    const sourceHash = createHash('sha256').update(json).digest('hex');
    json = null;
    global.gc();
    const restoredHash = createHash('sha256')
      .update(JSON.stringify(restored.save()))
      .digest('hex');
    assert.equal(sourceHash, restoredHash);
    sim.advance(0.173456789);
    restored.advance(0.173456789);
    assert.equal(
      createHash('sha256').update(JSON.stringify(sim.save())).digest('hex'),
      createHash('sha256')
        .update(JSON.stringify(restored.save()))
        .digest('hex'),
    );
    restored = null;
    return { issued, stringifyMilliseconds, restoreMilliseconds };
  }
  const { issued, stringifyMilliseconds, restoreMilliseconds } =
    verifyRoundTrip(sim);
  await new Promise((resolve) => {
    setImmediate(resolve);
  });
  global.gc();
  parentPort.postMessage({
    type: 'complete',
    result: {
      mode,
      seconds,
      samples,
      weaponsProduced: issued,
      consumed,
      advanceMilliseconds,
      stringifyMilliseconds,
      restoreMilliseconds,
      elapsedMilliseconds: performance.now() - started,
      checkpointAndContinuationEqual: true,
      finalCollectedHeapMiB: process.memoryUsage().heapUsed / 2 ** 20,
    },
  });
}
