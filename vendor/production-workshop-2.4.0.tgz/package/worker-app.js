import { WorkerDemoClient } from './worker/client.js';
import { WorkerDemoHost } from './dist/worker-demo.js';
import { Clock } from './dist/index.js';
import { WorkerAdvanceQueue } from './worker/advance-queue.js';
const $ = (id) => document.getElementById(id);
const startPaused = new URLSearchParams(location.search).get('paused') === '1';
const percentile = (values, p) =>
  values.length
    ? [...values].sort((a, b) => a - b)[
        Math.min(values.length - 1, Math.floor(values.length * p))
      ]
    : 0;
class MainThreadClient {
  #host = new WorkerDemoHost();
  request(command) {
    const started = performance.now();
    if (!this.#host)
      return Promise.reject(new Error('Main-thread owner is closed'));
    try {
      return Promise.resolve({
        ok: true,
        result: this.#host.handle(command),
        workMilliseconds: performance.now() - started,
      });
    } catch (error) {
      return Promise.reject(error);
    }
  }
  close() {
    this.#host = null;
  }
}
let client = null,
  queue = null,
  hostClock = null,
  epoch = 0,
  ready = false,
  paused = false,
  operation = null,
  lastFrame = null,
  lastPaint = 0,
  backlogPeak = 0,
  needsPauseView = false;
let view = null,
  viewReceived = 0,
  jobNodes = [],
  hasCheckpoint = false,
  ownerTimes = [],
  replyTimes = [],
  lastOwnerTime = 0,
  lastReplyTime = 0;
let frames = [],
  measurement = null,
  taps = 0,
  lastTapPaint = 0,
  lastReplyBytes = 0,
  measurementCount = 0;
const controls = ['pause', 'measure', 'burst', 'checkpoint', 'restore'];
function setControls() {
  for (const id of controls)
    $(id).disabled =
      !ready ||
      (id === 'restore' && !hasCheckpoint) ||
      (['burst', 'checkpoint', 'restore'].includes(id) && operation) ||
      (id === 'measure' && measurement !== null) ||
      (id === 'pause' && operation === 'restore');
  $('pause').textContent = paused ? 'Resume' : 'Pause';
}
function accept(reply) {
  lastOwnerTime = reply.workMilliseconds;
  ownerTimes.push(lastOwnerTime);
  if (ownerTimes.length > 1200) ownerTimes.shift();
  if (reply.result.view) {
    view = reply.result.view;
    viewReceived = performance.now();
    // Instrument only the already bounded DTO, never a world snapshot.
    lastReplyBytes = new TextEncoder().encode(
      JSON.stringify(reply.result.view),
    ).length;
    if (!jobNodes.length) {
      $('jobs').replaceChildren(
        ...view.jobs.map((job) => {
          const article = document.createElement('article'),
            label = document.createElement('strong'),
            status = document.createElement('small'),
            bar = document.createElement('progress');
          label.textContent = job.recipeId;
          bar.max = 1;
          article.append(label, document.createElement('br'), status, bar);
          jobNodes.push({ status, bar });
          return article;
        }),
      );
    }
    view.jobs.forEach((job, index) => {
      jobNodes[index].status.textContent =
        `${job.id} · ${job.state} · ${job.batches} batches`;
    });
  }
}
async function request(command) {
  const current = epoch,
    started = performance.now(),
    m = measurement;
  const reply = await client.request(command);
  if (current !== epoch) return null;
  lastReplyTime = performance.now() - started;
  replyTimes.push(lastReplyTime);
  if (replyTimes.length > 1200) replyTimes.shift();
  accept(reply);
  if (m && measurement === m) {
    m.ownerTimes.push(reply.workMilliseconds);
    m.replyTimes.push(lastReplyTime);
  }
  return reply;
}
function fail(error) {
  paused = true;
  ready = false;
  queue?.close();
  client?.close();
  if (measurement)
    $('measure-result').textContent = 'Measurement aborted: owner failure.';
  measurement = null;
  setControls();
  $('notice').textContent = `Stopped: ${error.message}`;
}
async function start() {
  epoch++;
  queue?.close();
  client?.close();
  client = null;
  ready = false;
  paused = startPaused;
  operation = null;
  lastFrame = null;
  backlogPeak = 0;
  needsPauseView = false;
  queue = new WorkerAdvanceQueue((seconds) =>
    request({ type: 'advance', seconds }),
  );
  hostClock = new Clock((seconds) => queue.add(seconds));
  hostClock.setPaused(paused);
  view = null;
  jobNodes = [];
  $('jobs').replaceChildren();
  hasCheckpoint = false;
  ownerTimes = [];
  replyTimes = [];
  frames = [];
  measurement = null;
  $('measure-result').textContent = 'No measurement yet.';
  delete $('measure-result').dataset.result;
  $('operation-result').textContent = 'Initializing the world…';
  lastOwnerTime = 0;
  lastReplyTime = 0;
  lastReplyBytes = 0;
  lastTapPaint = 0;
  taps = 0;
  $('probe-result').textContent = '0 taps';
  for (const id of ['factories', 'active', 'batches', 'sim-time'])
    $(id).textContent = '—';
  $('sample-stock').textContent = '';
  setControls();
  $('owner').textContent =
    $('execution').value === 'worker'
      ? 'The worker owns all simulation state. Main thread owns animation and input.'
      : 'Comparison: the main thread owns simulation, rendering and input.';
  $('notice').textContent = 'Initializing 6,000 factories…';
  const current = epoch;
  // Let the start notice paint before a deliberately blocking main-thread initialization.
  await new Promise((resolve) => {
    requestAnimationFrame(() => requestAnimationFrame(resolve));
  });
  if (current !== epoch) return;
  try {
    client =
      $('execution').value === 'worker'
        ? new WorkerDemoClient((error) => {
            if (current === epoch) fail(error);
          })
        : new MainThreadClient();
    await request({ type: 'init' });
    if (current !== epoch) return;
    ready = true;
    ownerTimes = [];
    replyTimes = [];
    frames = [];
    lastFrame = null;
    hostClock.resetBaseline();
    setControls();
    $('notice').textContent =
      '6,000 factories ready. Initialization excluded from timing windows.';
  } catch (error) {
    if (current === epoch) fail(error);
  }
}
function completeMeasurement(now) {
  const m = measurement;
  const duration = now - m.start;
  const median = percentile(m.frames, 0.5),
    p95 = percentile(m.frames, 0.95),
    max = Math.max(0, ...m.frames);
  const longFrames = m.frames.filter((ms) => ms > 25).length;
  const result = {
    mode: m.mode,
    durationMilliseconds: duration,
    frames: m.frames.length,
    frameMedianMilliseconds: median,
    frameP95Milliseconds: p95,
    frameMaxMilliseconds: max,
    framesOver25Milliseconds: longFrames,
    ownerP95Milliseconds: percentile(m.ownerTimes, 0.95),
    ownerMaxMilliseconds: Math.max(0, ...m.ownerTimes),
    replyP95Milliseconds: percentile(m.replyTimes, 0.95),
    replyMaxMilliseconds: Math.max(0, ...m.replyTimes),
    backlogMaxSeconds: m.backlogPeak,
  };
  $('measure-result').textContent = JSON.stringify(result, null, 2);
  $('measure-result').dataset.result = JSON.stringify(result);
  measurement = null;
  measurementCount++;
  $('measure-result').dataset.count = String(measurementCount);
  setControls();
}
function paint(now) {
  if (now - lastPaint < 200) return;
  lastPaint = now;
  const median = percentile(frames, 0.5),
    p95 = percentile(frames, 0.95);
  $('frame-stats').textContent =
    `Recent frames: median ${median.toFixed(2)} ms · p95 ${p95.toFixed(2)} ms\nWorst ${Math.max(0, ...frames).toFixed(2)} ms · ${frames.filter((ms) => ms > 25).length} frames over 25 ms\nLast tap to animation frame: ${lastTapPaint.toFixed(2)} ms`;
  $('work-stats').textContent =
    `Last owner work: ${lastOwnerTime.toFixed(2)} ms\nOwner p95 ${percentile(ownerTimes, 0.95).toFixed(2)} ms · max ${Math.max(0, ...ownerTimes).toFixed(2)} ms\nLast reply latency: ${lastReplyTime.toFixed(2)} ms\nView payload: ${lastReplyBytes.toLocaleString()} bytes · ${view?.jobs.length ?? 0} jobs\nBuffered elapsed: ${(queue?.backlogSeconds ?? 0).toFixed(3)} s · peak ${backlogPeak.toFixed(3)} s`;
  if (view) {
    $('factories').textContent = view.summary.facilityCount.toLocaleString();
    $('active').textContent =
      `${view.counts.producing.toLocaleString()} / ${view.counts.blocked}`;
    $('batches').textContent = view.counts.batches.toLocaleString();
    $('sim-time').textContent = `${view.summary.timeSeconds.toFixed(2)} s`;
    $('sample-stock').textContent =
      `First chain: ore ${view.sampleStock.ore} · alloy ${view.sampleStock.alloy} · weapons ${view.sampleStock.weapons}`;
  }
  if (measurement)
    $('measure-result').textContent =
      `Measuring ${measurement.mode}… ${((now - measurement.start) / 1000).toFixed(1)} / ${measurement.duration / 1000} seconds`;
}
function frame(now) {
  if (lastFrame !== null && ready && !document.hidden) {
    const delta = now - lastFrame;
    frames.push(delta);
    if (frames.length > 1200) frames.shift();
    if (measurement) {
      measurement.frames.push(delta);
      if (now - measurement.start >= measurement.duration)
        completeMeasurement(now);
    }
  }
  if (ready && !document.hidden) hostClock.sample(performance.now());
  if (ready) {
    backlogPeak = Math.max(backlogPeak, queue.backlogSeconds);
    if (measurement)
      measurement.backlogPeak = Math.max(
        measurement.backlogPeak,
        queue.backlogSeconds,
      );
  }
  lastFrame = now;
  const travel = Math.max(0, $('motion').clientWidth - 30);
  $('dot').style.transform =
    `translateX(${((Math.sin(now / 500) + 1) / 2) * travel}px)`;
  if (view)
    view.jobs.forEach((job, index) => {
      const duration = { mine: 1, smelt: 1.25, forge: 1.5 }[job.recipeId];
      jobNodes[index].bar.value =
        job.state === 'producing' && !paused
          ? Math.min(1, job.progress + (now - viewReceived) / 1000 / duration)
          : job.progress;
    });
  pump(paused);
  paint(now);
  requestAnimationFrame(frame);
}
function pump(force = false) {
  if (!ready || operation || queue.busy) return;
  if (queue.pendingSeconds === 0) {
    if (needsPauseView) {
      needsPauseView = false;
      const current = epoch;
      request({ type: 'read' }).catch((error) => {
        if (current === epoch) fail(error);
      });
    }
    return;
  }
  if (!force && queue.pendingSeconds < 0.05) return;
  const current = epoch;
  queue
    .advance()
    .catch((error) => {
      if (current === epoch) fail(error);
    })
    .finally(() => {
      if (current === epoch && ready && paused) pump(true);
    });
}
function setPaused(value) {
  if (ready) hostClock.sample(performance.now()); // Capture active time up to the command boundary.
  if (value && !paused) needsPauseView = true;
  paused = value;
  hostClock.setPaused(value);
  setControls();
  if (value) pump(true); // Preserve even a fractional tick; hidden RAFs need not run.
}
async function control(type) {
  if (!ready || operation) return;
  operation = type;
  setControls();
  $('operation-result').textContent = `Executing ${type}…`;
  const current = epoch;
  hostClock.sample(performance.now());
  if (type === 'restore') setPaused(true);
  try {
    await queue.flush();
    if (current !== epoch) return;
    const reply = await request(
      type === 'burst' ? { type, ticks: 200 } : { type },
    );
    if (!reply) return;
    if (type === 'checkpoint') hasCheckpoint = true;
    if (type === 'restore') {
      hostClock.resetBaseline();
      needsPauseView = false;
    }
    $('operation-result').textContent =
      `${reply.result.type}: ${reply.workMilliseconds.toFixed(1)} ms in owner · ${lastReplyTime.toFixed(1)} ms round trip${reply.result.checkpointBytes ? ` · ${(reply.result.checkpointBytes / 1e6).toFixed(2)} MB retained in owner` : ''}`;
  } catch (error) {
    if (current === epoch) fail(error);
  } finally {
    if (current === epoch) {
      operation = null;
      setControls();
      if (ready && paused) pump(true);
    }
  }
}
$('execution').addEventListener('change', start);
$('restart').addEventListener('click', start);
$('pause').addEventListener('click', () => setPaused(!paused));
$('probe').addEventListener('click', () => {
  const started = performance.now();
  $('probe-result').textContent = `${++taps} taps`;
  requestAnimationFrame(() => {
    lastTapPaint = performance.now() - started;
  });
});
$('measure-window').addEventListener('change', () => {
  $('measure').textContent =
    `Measure ${Number($('measure-window').value) / 1000} seconds`;
});
$('measure').addEventListener('click', () => {
  frames = [];
  ownerTimes = [];
  replyTimes = [];
  delete $('measure-result').dataset.result;
  measurement = {
    mode: $('execution').value,
    start: performance.now(),
    duration: Number($('measure-window').value),
    frames: [],
    ownerTimes: [],
    replyTimes: [],
    backlogPeak: 0,
  };
  setControls();
});
$('clear-measure').addEventListener('click', () => {
  measurement = null;
  frames = [];
  ownerTimes = [];
  replyTimes = [];
  $('measure-result').textContent = 'Measurements cleared.';
  delete $('measure-result').dataset.result;
  setControls();
});
for (const type of ['burst', 'checkpoint', 'restore'])
  $(type).addEventListener('click', () => control(type));
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    setPaused(true);
    lastFrame = null;
    if (measurement) {
      measurement = null;
      $('measure-result').textContent =
        'Measurement aborted: tab became hidden.';
    }
    setControls();
  }
});
window.addEventListener('pagehide', () => {
  ready = false;
  queue?.close();
  client?.close();
});
window.addEventListener('pageshow', (event) => {
  if (event.persisted) start();
});
requestAnimationFrame(frame);
start();
