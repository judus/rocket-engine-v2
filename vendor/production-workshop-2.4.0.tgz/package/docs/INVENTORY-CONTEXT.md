# Inventory context and equipment (2.4.0)

Inventories remain the sole physical owner of stored goods. Numeric modifiers and descriptive metadata belong to an inventory; equipment is a constrained inventory, not a second item ledger. No Rocket changes, permissions, nested containers, autonomous spoilage, or gameplay effects on actors are included.

## Numeric modifiers

```js
sim.createInventory({
  id: 'fridge',
  capacity: { kind: 'slots', limit: 12, stackLimit: 5 },
  modifiers: { decay: 0.1, fermentation: 0 },
  metadata: { label: 'Cellar fridge', region: 'north', powered: true },
});
const foodId = sim.spawnItem('fridge', 'food', { decay: 1, freshness: 100 });
sim.inventory('fridge').item(foodId).attributes; // base: decay 1, freshness 100
sim.inventory('fridge').effectiveItemAttributes(foodId); // decay 0.1, freshness 100
sim.setInventoryModifiers('fridge', { decay: 1 }); // replace, e.g. power lost
```

The resource must be registered as individual. `modifiers` is a string-keyed record of finite numbers. Matching **own keys** multiply the item's numeric attributes. An absent key defaults to 1; extra inventory keys do not create attributes. Zero is valid; negative multipliers are valid for host-defined signed attributes. Games should validate their own semantic constraints, such as nonnegative decay rates. There is one multiplier layer: the current containing inventory. No object/actor/container inheritance or automatic stacking.

`effectiveItemAttributes(id)` returns a detached numeric record, or undefined when the item is not physically present. It checks finite products and throws on overflow without changing any state. Physical weight/volume admission continues to use registered static resource metadata, not these products. Rules, identity, provenance and base attributes are untouched. Bulk quantities do not have per-item attributes; the host can read inventory modifiers if it implements bulk processes.

Moving an item changes the source of its modifiers immediately. Reserved items remain physically in their source and can be queried there. In-transit cargo is absent from both endpoint inventories; Workshop applies no inventory modifiers to it. The host decides transit behavior. These queries are read-only and do not scan the world: work is proportional to the queried item's attributes. Equipment preflight reads only the single occupant and touched participant stock.

### Time and item behavior

Workshop does not interpret keys or run item decay. The game advances item behavior against simulation time, using `baseRate * inventoryMultiplier`. Process each interval with the modifiers applicable during that interval, then update base state such as freshness. Settle an item's elapsed interval before moving it or changing modifiers; do not apply a new multiplier retroactively. `inventory-context-demo.js` demonstrates explicit 10-second waits with unchanged modifiers during each interval. Restoring a checkpoint does not add wall-clock/offline decay.

A fridge only changes `decay`; it does not overwrite `freshness` or permanently rewrite the base decay rate. Likewise a hand's `power` multiplier changes the queried item power; the host decides whether/how that contributes to an actor's attack. The simulation does not automatically modify production speed, item wear, actor statistics or recipes from arbitrary keys.

## Separate metadata

`metadata` is an inventory-level JSON object. Values may be strings, finite numbers, booleans, null, dense arrays and plain objects. Top-level arrays, undefined, functions, bigint, symbols, cycles, accessors and exotic objects are rejected. Null-prototype plain records are accepted. Validation is bounded to 4,096 value nodes and nesting depth 16; large text remains subject to the existing MCP response limit. Numeric modifier records use the same plain-data validation plus finite numeric values and nonempty keys.

`setInventoryMetadata(id, value)` replaces the full object; `{}` clears it. `setInventoryModifiers(id, value)` similarly replaces modifiers; `{}` restores all defaults. Inputs and read results are detached, including nested metadata. No metadata key has automatic gameplay meaning. Item attributes remain numeric; arbitrary per-item metadata is outside this addition.

Invalid context updates throw before any change. Updates use the normal simulation command/reentry guard. They generate no stock event and do not advance `inventoryEventSequence`. The feed describes committed goods changes, not every configuration change; a host tracking configuration needs its own revision/event contract.

## Equipment slots

Create one constrained inventory per named equipment position:

```js
sim.createInventory({
  id: 'player-hand',
  attachment: { objectId: 'player', slot: 'mainHand' },
  equipment: { accepts: ['sword', 'axe'] },
  modifiers: { power: 1.5 },
  metadata: { label: 'Main hand' },
});
sim.equipItem('player-bag', 'player-hand', swordId);
sim.unequipItem('player-hand', 'player-bag');
```

Every accepted resource must already be registered with `storage: 'individual'`. `accepts` is an exact, duplicate-free resource list; `[]` closes the position. The equipment definition is immutable for the inventory lifetime. A slot can be attached to any opaque host object ID, or remain unattached. Attachment itself does not grant actor access or prove an object exists. Equipment position names are normal inventory attachment names, distinct from bag capacity slots.

An equipment inventory holds at most **one individual item**, even if ordinary capacity is increased or admission rules are relaxed. Optional unit/slot capacity, per-material capacity, weight/volume and admission rules still apply cumulatively; zero capacity can disable admission. These restrictions apply through generic transfers, exchanges, mutations, initial stock, production, cargo arrival and restore—not only the equipment helper. The helper does not create a second ownership/reservation system. No resource tags, two-handed cross-slot locks, automatic bonuses, wear, destruction, auto-unequip, or item loss policy is inferred.

`equipItem(source, equipment, itemId)` uses the existing atomic exchange: the selected item enters the equipment slot and an existing occupant returns to the source inventory. Admission checks each participant's **final** state, so a full bag can swap an item. Sources must own their unreserved outgoing item before the command. A reserved new item or old occupant, wrong resource, or inability to store the displaced item refuses the entire swap with the existing unavailable/admission result. No dropping or silent replacement. The same endpoint rejects as an invalid exchange. A non-equipment destination throws.

`unequipItem(equipment, destination)` uses the same preflight; full destinations refuse without changing anything. An empty slot succeeds with `operationId: null`. Generic transfers out of an equipment inventory also work. Host equipment effects should be derived from current contents; Workshop does not cache or revoke actor bonuses.

Successful equipment moves publish one committed inventory event with command `exchange` after both inventories are committed. Item identity, numeric attributes and manufacturing provenance survive unchanged. Observer failure is after commit: do not blindly retry. Configuration-only changes produce no fake stock events.

## Persistence, telemetry and examples

New checkpoints use **format 7**. Inventory save records optionally include modifiers, metadata and equipment. Restore validates context, equipment admission and existing provenance/reservation rules in an isolated world. Genuine formats 4, 5 and 6 remain readable; new fields mislabeled as older versions reject. Old readers reject version 7. An empty definition and an omitted definition remain distinct where supplied. No listener or retained event history is persisted.

Existing MCP inventory and summary reads expose the optional context fields without new mutation tools. The 64 KiB response bound remains enforced. Base item records remain base values; effective attributes are available through the local inventory view API.

Run `node examples/inventory-context.mjs` after building. Open `context.html` for food storage, explicit simulated waits, cooling, equipment swaps, invalid slots, metadata labels and save/restore. Reservations, failed swaps, detached reads, hostile input, overflow, JSON persistence and legacy compatibility have focused regressions in `tests/inventory-context.test.mjs`.
