# Read-only MCP telemetry

Available from `production-workshop/mcp` in 2.1.0. The optional provider has no MCP SDK or Rocket runtime dependency. It implements the structural host/provider contract: `id`, `tools(binding)` and `call(name, args, context)`.

```ts
import { createProductionTelemetryProvider } from 'production-workshop/mcp';
const provider = createProductionTelemetryProvider({
  id: 'production',
  resolveSimulation: (binding) => simulationsByScope.get(binding.scope) ?? null,
});
const unregister = service.register(provider); // Rocket's optional McpService
// Application authentication grants this provider through binding.providers.
// Unregistering does not dispose or pause the application-owned simulation.
```

The application resolver authorizes an **entire simulation** per authenticated binding. Unknown scopes fail. Mount separate simulations for partitions that must remain hidden from each other. This is not per-inventory authorization inside one simulation; do not expose a shared multi-faction simulation to callers entitled to only one faction. Definition catalogues and endpoint references belong to the selected simulation too. No caller-supplied scope argument can override the binding. Stale bindings and aborted calls fail before reads.

| Tool                            | Arguments                                      | Data                                                                                              |
| ------------------------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| `production_summary`            | `{}`                                           | Existing simulation clock and entity counts                                                       |
| `production_list`               | `kind`, optional `offset`, `limit`             | ID `entries`, `total`, offset and limit; kinds: inventories, facilities, construction, deliveries |
| `production_catalogue`          | `kind`, optional `offset`, `limit`             | Definition `entries`; kinds: resources, recipes, facilities                                       |
| `production_facility`           | `id`                                           | Detached facility snapshot plus job `explanations`                                                |
| `production_inventory`          | `id`                                           | Inventory summary; no individual item records                                                     |
| `production_object_inventories` | `objectId`, optional `offset`, `limit`         | Named inventory attachments for an application object                                             |
| `production_items`              | `id`, optional `resourceId`, `offset`, `limit` | Existing item page, including identity/provenance/quality                                         |
| `production_construction`       | `id`                                           | Construction state, material holdings/missing quantities, blockers and facility association       |
| `production_delivery`           | `id`                                           | Delivery state, commitments and cargo                                                             |

Every successful response uses `structuredContent: {status:'completed', tick, data}` and one text content block containing exactly the same JSON. Unknown tools/IDs, malformed arguments and unavailable scopes throw; the MCP host supplies its normal error envelope. All nine tools advertise read-only, non-destructive, idempotent, closed-world hints. Idempotent means no side effects; live results can change between calls.

Pages default to 50 entries; limit is 1–100 and offset a nonnegative safe integer. Insertion order is deterministic for the current state. Offset pagination is **not** a snapshot cursor: host changes can shift pages. Each read is synchronous and reports its simulation tick. Tick alone does not identify host mutations occurring between ticks. For a coherent multi-call observation the host must serialize/pause its mutations externally; the provider does not acquire locks or stop the game.

Serialized results are bounded to **64 KiB UTF-8**. Oversized reads fail rather than truncate, and pages can be reduced. A single facility, construction order, delivery or definition larger than the bound is unavailable through this first provider. Response size is bounded, not serialization peak memory: core APIs create detached reads before the limit check. There is no bulk checkpoint/world-snapshot tool. No caches, subscriptions, worker bridge or wall-clock timers are created. A resolver can supply a newly restored Simulation on later calls without reconstructing the provider.

## Meaning of the telemetry

- Time/durations are simulation seconds. Reading never advances the clock, rolls randomness, reserves inputs or completes work.
- Productivity is the current effective multiplier, not a promised sustained output rate. Nominal recipe work duration and configured capacity/staffing are separate facts.
- Workforce pool claims are not local worker attendance. Facility reads expose actual host-reported attendance and missing minimum staffing.
- Job explanations contain current blockers and conditional completion estimates. They do not predict future staffing, material arrivals, bonus rolls or transport.
- Inventory goods are arrived goods; delivery commitments and construction inbound quantities do not prove arrival. Pending batch goods are still owned by the job. In-transit items remain delivery cargo; item pages show only inventory-owned goods.
- Completed-batch counters do not constitute a persistent quest event journal or proof of newly delivered quantity. The game/quest adapter must define acceptance cuts and authoritative objective evidence.
- Definitions describe supported production configuration, not game geography, factions, permitted placement, fire/repair actions or travel feasibility. Those remain game-owned.

Run `node examples/mcp-telemetry.mjs` after `npm run build`. Existing instant/timed construction, retirement and demos retain their behavior. Current saves use format 7; genuine 4/5/6 saves remain readable. This telemetry slice introduces no mutation tools or demolition policies.

Version 2.2.0 adds `production_object_inventories({objectId,offset?,limit?})` and attachment/shared-capacity detail to `production_inventory`. See [object inventories](OBJECT-INVENTORIES.md).

Version 2.3.0 adds `inventoryEventSequence` to summary telemetry, resource `unitWeight`/`unitVolume` declarations and inventory `rules`/used weight/volume. The event position is scoped to the host timeline and is not a retained journal or an all-state revision. No write MCP tools are exposed. See [the inventory operations contract](INVENTORY-OPERATIONS.md).

Version 2.4.0 exposes optional inventory `modifiers`, `metadata` and `equipment` via existing summary/inventory reads. Item records retain base attributes; effective attributes are an explicit local `InventoryView` query. The MCP read-only authorization and response bounds are unchanged. Context configuration changes do not advance the stock-event sequence, which remains unsuitable as an all-state revision.
