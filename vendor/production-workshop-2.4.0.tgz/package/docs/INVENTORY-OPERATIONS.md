# Inventory operations (2.3.0)

Workshop owns accounting. The game validates interaction access, proximity, prices, recipes, quest permission and resource scarcity before issuing these commands. No economic policy, automatic demolition, death loss, refund, regeneration or Rocket change is introduced.

## Atomic exchanges

```js
const result = sim.exchange([
  {
    sourceInventoryId: 'player',
    destinationInventoryId: 'shop',
    quantities: { coin: 3 },
  },
  {
    sourceInventoryId: 'shop',
    destinationInventoryId: 'player',
    itemIds: [swordId],
  },
]);
```

`exchange(transfers)` takes 1–256 `InventoryTransfer` records. Each contains distinct source/destination IDs, optional bulk `quantities` and optional explicit `itemIds` (at most 256 per leg and per participant’s outgoing manifest). Missing inventories, malformed quantities and duplicated item identities throw `DefinitionError`. Individual goods require item IDs. Each item can move only once in one exchange. Zero-only legs are allowed and produce no event when the whole exchange is a no-op.

All outgoing goods must be unreserved and physically owned by their source BEFORE the exchange; incoming goods cannot fund another outgoing leg. Repeated source/resource quantities are aggregated with safe-integer checks. Each participant's FINAL stock is checked against per-material capacity, shared units/slots, resource restrictions and physical limits. Thus two full bags can swap equipment without a temporary overflow. Plans cover only participating inventories and the goods touched; the whole simulation is not copied or restored to implement rollback.

On refusal, `{ok:false, reason:'unavailable'|'admission', inventoryId}` identifies the failing participant. No participant, item counter, reservation or event position changes. On success, `{ok:true, operationId, createdItemIds:[]}` identifies the committed operation; `operationId:null` means a no-op. All synchronous commits finish before any inventory observer runs.

## Consumption, transformation and item attributes

```js
const result = sim.mutateInventory({
  inventoryId: 'player',
  consume: { water: 5 },
  consumeItemIds: [emptyBucketId],
  createItems: [{ resourceId: 'full-bucket', attributes: { durability: 80 } }],
});

sim.mutateInventory({
  inventoryId: 'player',
  consume: { charge: 1 },
  updateItems: [{ itemId: wandId, attributes: { charges: 3 } }],
});
```

`InventoryMutation` has `inventoryId` and optional `consume` (bulk), `consumeItemIds`, `produce` (bulk), `createItems` and `updateItems`. Creation records have `resourceId` plus numeric finite `attributes`. Update records have `itemId` plus an attribute patch. New items, updates and consumed item IDs are bounded to 256 each. Duplicate consumed/update IDs and updates to a consumed item reject. A reserved item cannot be consumed or updated by this transaction. Existing `updateItemAttributes` remains the explicit host wear/repair command and preserves its prior ability to update reserved equipment; pickup captures the then-current attributes.

The whole transformation uses the same preflight and result shape as exchanges. Input consumption frees space before final admission. A full output, missing input or restricted resource leaves inputs, attributes and the external-item counter untouched. Bulk output cannot masquerade as individual goods. New individual goods use framework-issued `external-N` IDs returned in `createdItemIds`; consumed goods retire and cannot be re-imported. A resource-type transformation issues a NEW identity: it does not rewrite a manufactured item's original resource provenance. Updating attributes of an existing item preserves its ID. The event links consumed/produced/updated records under one operation.

The caller authors the transformation and validates gameplay prerequisites. This is not an automatic recipe parser or proof of mass conservation: consuming a potion is intentionally destructive; creating a full bucket requires the game's explicit input/output rule. Quantities and finite attributes are validated, but arbitrary host commands are trusted as before.

## Resource restrictions and physical limits

```js
sim.createInventory({
  id: 'tank',
  capacity: { kind: 'units', limit: 100 },
  rules: { accepts: ['water'], maxWeight: 100000, maxVolume: 100000 },
});
```

`InventoryRules` supports:

- `accepts?: readonly string[]`: explicit registered resource IDs, not inferred categories. Omitted allows any registered resource; `[]` permits no goods. Duplicate or unknown IDs reject.
- `maxWeight?: number` and `maxVolume?: number`: independent nonnegative safe-integer budgets. The game chooses and documents units, e.g. grams and millilitres. Zero is valid; no decimal floating-point summation is used.

Resources can declare `unitWeight` and `unitVolume`, each a nonnegative safe integer. A budgeted dimension requires explicit metadata for every resource physically present, including currency and individual items. Missing metadata refuses admission; it is never treated as zero. Declare zero explicitly for a weightless/virtual resource. Multiplication/sum overflow also refuses before commit. Individual attribute values do not alter these fixed resource measures. If a filled container has different mass, author a distinct filled resource or account for its contents separately.

All budgets are cumulative with slots/shared units and `capacityPerMaterial`. Restrictions/physical limits apply to initial stock, deposits, spawns, transfers, exchange/mutation outputs, production starts/publication and delivery arrival/return. Reserved stock still occupies space/mass/volume; in-transit cargo belongs to its delivery until successful unloading. Failed unload keeps the cargo intact. No automatic spill, drop or destruction is performed.

`setInventoryRules(id, rules)` validates/copies a replacement ruleset and returns false if existing physical contents would violate it. On failure the prior rules remain. `{}` clears restrictions/physical budgets; shared slot/unit capacity is configured separately. Capacity may be omitted on creation when rules are supplied; the legacy arithmetic ceiling then defaults to MAX_SAFE_INTEGER, not a source of infinite goods. `summary().rules` and `snapshot().rules` return detached rules plus `usedWeight`/`usedVolume` for configured dimensions. Rule checks scan held and incoming RESOURCE kinds, not all individual item records. Large retained state still has proportional save cost.

## Committed events and journal integration

```js
const unsubscribe = sim.onInventoryEvent((event) => {
  // Keep this exact detached event for your application journal/outbox.
  pendingReports.push(event);
});
const cut = sim.inventoryEventSequence();
```

This separate subscription leaves existing `onEvent` production/construction contracts intact. `InventoryEvent` contains:

- `type:'inventory-committed'`, monotonically ordered `sequence`, `operationId:'inventory-operation-N'`, and `command`;
- `changes`: inventory ID, actual simulation `tick`, `added` and `removed` BatchOutcomes (quantities include individual counts, plus exact item records), `updatedItems` with before/after values, and optional `reference` (job/reservation/delivery identity).

Host deposit, withdraw, transfer, initial stock creation, spawn/consume, attribute changes, exchange and mutation each group their committed inventory changes into one operation. No-op, refusal, reservation/release, capacity/rule changes and attachments do not invent goods events. Production advancement allocates one operation per actual inventory commit with command `simulation-tick`, so event identities/state do not depend on elapsed-frame partitioning. Input commitment and output publication are separate confirmed facts, correlated by job reference. Pickup removal is not arrival; accepted delivery/return uses the delivery reference.

Observers run after the whole command, so a batch of queued historical changes can accompany a read of the final current state. A listener added during a notification receives subsequent commands, not an incomplete current command. Unsubscribe is explicit. Each observer receives its own detached event; observer exceptions cannot undo accounting and other observers still run. Mutations/save from observers reject. A thrown observer exception is AFTER COMMIT: do not blindly retry the gameplay operation.

Operation position advances with or without listeners and survives save/restore. This is a LIVE feed, not a retained event archive, cross-process outbox or replay/idempotency service. IDs are scoped to the application's save/timeline. A restored older checkpoint must get a new host timeline if its new history coexists with abandoned future history. Legacy saves start a new observation epoch at zero; old history is unavailable. Hosts define quest acceptance cuts and preserve their timeline/event source identity. They must queue exact events and report gaps when journal writes fail, without rerunning the successful action. No history query or model-callable inventory mutation MCP tool is added. Existing MCP summary exposes `inventoryEventSequence`; inventory telemetry includes rules/usage, and resource discovery includes physical metadata.

Event payload work is proportional to touched goods and is built only for subscribed inventory observers. With no inventory listeners, advancement updates the counter without copying payloads. Large subscribed advances can queue many events; bound host update slices and drain your journal outside synchronous observers. Tick remains simulation time, not an all-mutations revision.

## Save compatibility and examples

New saves use **format 7** with `nextInventoryOperation`, object attachments and optional per-inventory rules. Restore validates counters, rules, physical admission, existing stock/reservations and normal provenance in a new isolated world. Genuine formats **4, 5 and 6** remain readable; advanced fields mislabeled as a legacy format reject instead of silently dropping rules/position. Old readers reject format 7. Observers and event records are not saved; resubscribe after restore. The production RNG algorithm remains unchanged.

Run `node examples/inventory-operations.mjs` after building, or open `/operations.html`. The interactive example provides a paid food exchange, refused trade, water gathering, finite lake allow-list, bucket transformation, food consumption, weight expansion, event-derived activity and checkpoint restore. The earlier `/inventory.html` still demonstrates generic attachments and slot growth. No Rocket source, dependency or installed pin is changed.
