# Object inventories and capacity (2.3.0)

Workshop is the stock authority for any application object. An object is an opaque nonempty string ID: player, house, lake, vehicle, corpse or anything else. The host owns the actual object and its existence, position, access, interaction permissions and lifetime. Workshop stores the association; it does not mutate or retain a scene object. An attachment is not legal/faction ownership or permission to take goods.

```js
const bag = sim.createInventory({
  id: 'bag',
  attachment: { objectId: 'player' }, // named attachment slot defaults to "main"
  capacity: { kind: 'slots', limit: 12, stackLimit: 20 },
});
sim.createInventory({
  id: 'pantry',
  attachment: { objectId: 'house', slot: 'pantry' },
  capacity: { kind: 'units', limit: 100 },
});
sim.createInventory({
  id: 'lake-water',
  attachment: { objectId: 'lake', slot: 'water' },
  capacity: { kind: 'units', limit: 1000 },
  initial: { water: 1000 },
});
sim.transfer(sim.objectInventory('lake', 'water').id, bag.id, { water: 5 });
```

Resources must first be registered in the simulation configuration. Transfers, production, reservations and cargo use the existing commands and item identities. A failed capacity check never partly transfers or destroys goods. Picking up a physical object should remove its game representation only after the authoritative inventory transfer succeeds.

## Two kinds of slots

A **named attachment slot** (`house/pantry`, `house/tools`) identifies an inventory on an object. A **storage slot** is a unit of space inside a slot-based inventory. They are independent. An object may have multiple inventories; each inventory has at most one attachment and each object/attachment-slot pair has at most one inventory.

- `attachInventory(inventoryId, objectId, slot = 'main')`: attach an existing inventory. Exact repetition is idempotent; different attachment or occupied slot throws. Detach explicitly before reassociating. No goods move.
- `detachInventory(inventoryId)`: return the removed detached attachment, or null when unattached. Inventory, goods, jobs, workforce and reservations remain intact. It does not cancel travel or relocate cargo.
- `inventoryAttachment(inventoryId)`: detached association or null; unknown inventory throws.
- `objectInventory(objectId, slot = 'main')`: existing read-only live inventory view or undefined.
- `objectInventories(objectId)`: detached attachment list in slot insertion order; unknown object returns an empty list. This does not certify whether the host object exists.
- `removeInventory` refuses attached inventories with `object-attachment` plus all existing accounting blockers. Object deletion must have an explicit host policy; it never automatically destroys contents.

Creation validates attachment, inventory capacity and initial stock before committing either inventory or indexes. All attachment mutations obey the normal observer reentry guard. Reads do not advance the clock. Associations use Maps (no delimiter-joined key collisions). Lookup is indexed; listing one object's inventories visits only its slots. No observer events or persistent event history are added.

## Capacity

`capacity` is optional, and uses one of:

- `{kind:'units', limit}`: one shared quantity budget, without storage slots. Every bulk unit and every individual item consumes one unit.
- `{kind:'slots', limit, stackLimit}`: each bulk resource packs independently into `ceil(quantity / stackLimit)` slots. Each individual item consumes exactly one slot, even when two items have identical attributes. For example, 6 water with a stack limit of 5 consumes two slots; topping up to 10 still consumes two. Another bulk resource starts its own stack.

Limits are nonnegative safe integers; stackLimit is a positive safe integer. Zero capacity is valid. Shared modes count currency too; they are quantity models, not equipment-slot models; optional inventory rules add weight and volume budgets. No player-managed slot positions, split-stack identities, per-resource stack overrides or automatically dropped overflow are introduced.

Legacy `capacityPerMaterial` remains available: each material has that independent limit, and currency bypasses it. Specify either a shared mode, a legacy limit, or both (both restrictions apply). When only a shared mode is supplied, the internal legacy arithmetic ceiling is MAX_SAFE_INTEGER, not an unlimited stock source. Omitting both limits rejects.

`inventory.summary().capacity` and `inventory.snapshot().capacity` expose configured kind/limit/stackLimit plus `used` and `free` when shared capacity is configured. Legacy views retain their existing shape otherwise. Reserved goods still occupy physical capacity. Picked-up cargo no longer occupies the source; inbound commitments do not reserve destination space. Failed arrival preserves the exact cargo until an explicit later arrival or return.

`setInventoryCapacity(id, capacity)` changes the shared policy/limit/stack size atomically. It returns false if current contents would not fit, preserving the previous policy and stock. Invalid policies throw. Capacity can be expanded without creating goods. `increaseCapacity` and facility `capacityProvided` retain their existing per-material semantics; they do not grant new shared units or slots.

Shared admission checks scan stored resource quantities plus incoming resource keys; they do not scan individual item records. This is proportional to resource kinds held, not a constant-time claim. Legacy-only admission keeps its existing path. Same-inventory production considers immediately consumed inputs in start preflight; actual outputs and cargo are checked again before publication. Changing capacity does not guarantee future outputs will fit.

A finite lake can use an ordinary inventory. Regeneration can be explicitly authored through existing production recipes; no regeneration is inferred from an object ID. Unlimited extraction, spatial permissions, wear, quest-use restrictions and scarcity are game rules, not implicit properties of attachments.

## Persistence and telemetry

New worlds emit **format 7**, including object attachments, shared capacity, inventory rules and the inventory operation position. Restore also accepts genuine legacy formats 4, 5 and 6. It validates unique object/slot associations, existing inventory endpoints and current admission. Older readers reject format 7. See [the current persistence and event contract](INVENTORY-OPERATIONS.md). Restore never creates host scene objects.

`production_object_inventories({objectId, offset?, limit?})` pages attachments under the existing whole-simulation binding. Unknown objects return empty pages. `production_inventory({id})` now includes `attachment` (or null) and shared capacity status when configured. The provider now has nine read-only tools. Same 64KiB, live-pagination, tick/freshness and scope constraints apply; this is not per-object access control or a historical quest ledger.

Run `node examples/object-inventories.mjs` after building. Open `/inventory.html` for the interactive player/house/lake example: fill the bag, encounter full stores, transfer an individual tool, expand slots and save/restore. Save is in-memory for this demo; reload/reset starts a new example. No Rocket source or integration is required.
