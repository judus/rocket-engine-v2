# API reference

Import runtime symbols from `dist/index.js`. Generated declarations are at `dist/index.d.ts`; package exports pair the JS entry with its types. All durations use seconds except the explicitly named `tickMilliseconds` configuration and `Clock.sample` timestamps.

For object attachments and shared/slot capacity, see [Object inventories](OBJECT-INVENTORIES.md). Atomic exchanges, transformations, restrictions, weight/volume and events are documented in [Inventory operations](INVENTORY-OPERATIONS.md).

## Configuration

```ts
interface ResourceDefinition {
  id: string;
  label: string;
  kind: 'material' | 'currency';
  storage?: 'bulk' | 'individual';
}
interface RecipeDefinition {
  id: string;
  label: string;
  durationSeconds: number;
  inputs: Readonly<Record<string, number>>;
  outputs: Readonly<Record<string, number>>;
  itemAttributes?: Readonly<
    Record<string, Readonly<Record<string, { min: number; max: number }>>>
  >;
  bonusOutputs?: readonly {
    chance: number;
    outputs: Readonly<Record<string, number>>;
  }[];
  optionalInputs?: Readonly<Record<string, number>>;
  optionalAttributeBonuses?: Readonly<
    Record<string, Readonly<Record<string, number>>>
  >;
}
interface FacilityDefinition {
  id: string;
  label: string;
  category: string; // presentation metadata; no inferred behavior
  recipes: readonly string[]; // one concurrent job per recipe
  constructionCost: Readonly<Record<string, number>>;
  workersRequired?: Readonly<Record<string, number>>;
  workersProvided?: Readonly<Record<string, number>>;
  capacityProvided?: number;
  workerSlots?: number;
  operatingConditions?: readonly string[];
}
```

`Configuration` contains `resources`, `recipes`, `facilities` and optional safe-integer `seed` (default 1) and `tickMilliseconds` (positive integer, 1–1000, defaults to 50). Quantities and capacities are non-negative safe integers. IDs must be unique within their definition kind; `constructor`, `prototype` and `__proto__` are reserved record-key names and are rejected. Workforce quantity keys also reject these names. Unknown resource/recipe references, invalid quantities and invalid durations (minimum one microsecond) throw `DefinitionError` at registration.

## Simulation commands and views

Managed inventories are **read-only live handles** (`InventoryView`). Their snapshots and item views are detached copies. All mutations go through `Simulation`, which rejects command reentry during observer notification. `Inventory` and reservation primitives are no longer public package exports.

| Method                                                                          | Contract                                                                                                                                                                                                                                                                 |
| ------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `new Simulation(configuration)`                                                 | Validate and freeze complete content.                                                                                                                                                                                                                                    |
| `createInventory({id, capacityPerMaterial?, capacity?, attachment?, initial?})` | Create an owned inventory and return its read-only view. Initial quantities must be bulk.                                                                                                                                                                                |
| `inventory(id)`                                                                 | Return a read-only live inventory view; unknown ID throws.                                                                                                                                                                                                               |
| `deposit(inventoryId, quantities)`                                              | Add external bulk stock atomically; false if full.                                                                                                                                                                                                                       |
| `withdraw(inventoryId, quantities)`                                             | Consume unreserved bulk stock atomically; false if unavailable.                                                                                                                                                                                                          |
| `transfer(sourceId, destinationId, quantities)`                                 | Instant atomic bulk movement within this simulation.                                                                                                                                                                                                                     |
| `spawnItem(inventoryId, resourceId, attributes)`                                | Create a new individual good; return its ID or null if full. IDs use a saved monotonic `external-N` counter. Caller-supplied IDs are rejected, including from plain JavaScript. Failed creation does not increment the counter. Never use this to move an existing item. |
| `transferItem(sourceId, destinationId, itemId)`                                 | Instant atomic movement retaining identity/attributes; false if reserved or destination is full.                                                                                                                                                                         |
| `updateItemAttributes(inventoryId, itemId, patch)`                              | Apply numeric wear/repair data to an item physically in that inventory. Reserved items may change until pickup.                                                                                                                                                          |
| `consumeItem(inventoryId, itemId)`                                              | Explicitly destroy/consume an individual item; false if reserved. Its identity cannot be reused.                                                                                                                                                                         |
| `increaseCapacity(inventoryId, amount)`                                         | Add a nonnegative safe-integer amount to per-material capacity.                                                                                                                                                                                                          |
| `constructionBlockers(definitionId, inventoryId)`                               | Query missing construction stock and workers as `{materials, workers}`.                                                                                                                                                                                                  |
| `addFacility(definitionId, inventoryId, options?)`                              | Atomically charge construction and assign construction workforce; return `{ok:true, facilityId}` or `{ok:false, reason}`.                                                                                                                                                |
| `removalBlockers(facilityId)`                                                   | Detached blockers: active batches, workforce shortage and stock exceeding capacity after removal. Unknown ID throws.                                                                                                                                                     |
| `setFacilityDraining(facilityId, draining)`                                     | Stop new starts and release idle reservations while existing work/output finishes. Reversible.                                                                                                                                                                           |
| `removeFacility(facilityId)`                                                    | Remove an idle facility atomically, reverse workforce/capacity effects, release its holdings. Return `{ok:true, facilityId}` or `{ok:false, blockers}`. Never refund or destroy goods.                                                                                   |
| `setFacilityEnabled(facilityId, enabled)`                                       | Suspend/resume jobs. Preserve active work/outcomes; release idle input reservations when disabled.                                                                                                                                                                       |
| `setFacilityCondition(facilityId, conditionId, fulfilled)`                      | Change a registered gate. Losing a condition releases idle reservations, preserves active batches, and blocks work/publication.                                                                                                                                          |
| `advance(seconds)`                                                              | Accumulate seconds without per-call rounding, process fixed ticks, return tick count. Fractional microseconds are retained.                                                                                                                                              |
| `advanceTicks(count)`                                                           | Process a nonnegative safe-integer tick count exactly; retain any pending fractional `advance()` time. Returns void.                                                                                                                                                     |
| `summary()`                                                                     | Detached clock and counts: tick, timeSeconds, pendingSeconds, facilityCount, inventoryCount, deliveryCount. No world traversal or item records.                                                                                                                          |
| `facilityIds()`                                                                 | Detached factory IDs in construction order; no factory payloads.                                                                                                                                                                                                         |
| `facilitySnapshot(id)`                                                          | Detached view of one factory and its jobs, using an indexed lookup. Unknown ID throws.                                                                                                                                                                                   |
| `snapshot()`                                                                    | Detached complete presentation view, not a save format. Explicit whole-world operation.                                                                                                                                                                                  |
| `save()`                                                                        | Detached, versioned JSON-compatible checkpoint. Not allowed during mutation/notification.                                                                                                                                                                                |
| `Simulation.restore(data)`                                                      | Validate an unknown checkpoint and return a new isolated simulation. Invalid/incompatible saves throw `DefinitionError`.                                                                                                                                                 |
| `onEvent(listener)`                                                             | Subscribe to committed facts; returns unsubscribe function.                                                                                                                                                                                                              |
| `registry`                                                                      | Read immutable definitions.                                                                                                                                                                                                                                              |

Invalid IDs, quantities or attributes throw `DefinitionError`; ordinary insufficient stock/capacity returns false/null/result as specified. Commands are synchronous. Observer failures occur after commit; do not blindly retry.

### Production controls

| Method                                                        | Contract                                                                                                                                                                                                                                                                                                                |
| ------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `setWorkerSlot(facilityId, slotIndex, workerOrNull)`          | Assign/update `{id, efficiency}`; worker identities cannot occupy two slots. The `facility-` namespace is reserved for generated workers: `${facilityId}.worker-${slotIndex}` can only occupy that exact slot, including after it was emptied. Use other IDs for host characters.                                       |
| `setProductionModifier(facilityId, sourceId, modifierOrNull)` | Replace/remove a source with optional `productivityMultiplier` and `attributeBonuses`. Aggregate rate above 1,000,000 is rejected atomically as a numerical guard.                                                                                                                                                      |
| `setInputItems(facilityId, recipeId, itemIds)`                | Request exact individual inputs for the next batch; one-shot, detached IDs, no implicit selection. Empty array clears. See below.                                                                                                                                                                                       |
| `setOptionalInputs(facilityId, recipeId, quantities)`         | Select full declared optional quantities or zero. Active batches retain their selection; changed selections release idle reservations, clear next-batch item selection and rejoin allocation on the next tick. Identical selections (including omitted versus zero quantities) preserve reservations and FIFO position. |

Worker/modifier changes affect work from the next tick. Zero productivity releases idle reservations and prevents new consumption; already active ingredients stay consumed. Worker-slot defaults are resolved once at registration; registered facility definitions expose an explicit slot count. Worker slots and the construction population pool are separate models (see [effects](PRODUCTION-EFFECTS.md)).

### InventoryView

`id`, `capacityPerMaterial`, `summary()`, `itemPage(options?)`, `quantity(resourceId)`, `reserved(resourceId)`, `available(resourceId)`, `missing(quantities)`, `canWithdraw(quantities)`, `canDeposit(quantities)`, `item(itemId)`, `snapshot()`.

Owned quantities include reservations and individual counts. Bulk mutation/capacity checks reject positive individual counts. `item()` returns undefined when that item is not physically in the inventory. No `commit`, `release`, `depositOutcome`, or other internal mutation method is reachable through the view.

### Jobs and events

Job snapshots contain `{id, recipeId, state, progress, batchesCompleted, missingInputs, reservedInputs, demandSinceTick, selectedOptionalInputs, selectedInputItemIds, batchInputItems, pendingOutcome}`. States are `drained`, `waiting-inputs`, `producing`, `output-blocked`, `paused`, `waiting-condition`. `progress` is 0–1. `reservedInputs` shows inputs held for an idle request, not yet consumed. `missingInputs` subtracts that job's own holdings and unreserved physical stock; inbound promises are only counted by `materialDemands()`.

`output-blocked` may mean insufficient capacity to start or a resolved batch awaiting publication. The latter has progress 1 and `pendingOutcome`. Completed jobs can start another batch at the same boundary.

`SimulationEvent` is a discriminated union: facility events require `facilityId`; batch events also require `jobId` and `batchNumber`; `batch-completed` requires `outcome`. Types are `facility-built`, `facility-enabled`, `facility-condition`, `facility-draining`, `facility-removed`, `batch-started`, `batch-completed`. `batch-started` includes detached `inputs: BatchOutcome` with the quantities and latest attributes of consumed items. Batch numbers are one-based; completion includes the **actual detached outcome** (including quality and bonus items). Each listener receives its own copy. Notifications occur after the whole command, so a listener reading the world after a long advance sees final state; use event payloads for historical facts.

### Persistence

`save()` stores format `production-workshop`, version `6`, inventory operation position and rules, full registered configuration (including seed/tick size), clock remainder/compensation, ID counters, inventory stock/workforce/reservations, facilities, active/partial/deferred work, demand ordering, locked optional inputs, resolved outcomes, draining state, one-shot selections, active consumed-item records, removed-factory provenance, and deliveries.

```js
const checkpoint = JSON.stringify(sim.save());
const restored = Simulation.restore(JSON.parse(checkpoint));
restored.advance(1 / 60);
```

Restore validates references, ownership, reservation manifests, counters and phase consistency. Generated worker identities must match their slots; population totals/assignments must match construction effects. Issued production identities must agree with job batch counters and deterministic batch manifests. Pending quantities, bonus decisions and item identities are checked against the seeded batch manifest; saved attribute values are retained because current specialists may differ from those at completion. This is structural validation, not protection against a maliciously rewritten save. It does not emit construction events or charge inputs again. Subscribe observers again and replace any old inventory views with views from the restored world. New saves use version 7. Genuine versions 4, 5 and 6 are also accepted; advanced fields mislabeled as legacy reject. Legacy observation history is unavailable and its inventory event position starts at zero. See the inventory operation contract. Exhausted safe-integer counters fail before mutation; advancement conservatively reserves room for the maximum 1,000 rounds per job per tick. Version 4 pins the current batch RNG semantics; changing that algorithm requires a save-version decision.

Travel timers, host characters, UI, `Clock` timestamps/pause/speed and listener functions are outside the checkpoint. Save host-owned state separately and connect it to restored delivery/worker IDs. Do not restore a wall-clock baseline from a prior process; sample a fresh baseline. See [persistence example](../examples/persistence.mjs).

## Clock

`new Clock(seconds => simulation.advance(seconds))` adapts a monotonic millisecond timestamp source. It does not own a browser timer or schedule itself.

- `sample(nowMilliseconds)`: first sample sets baseline; subsequent samples forward all elapsed time. Backward timestamps throw.
- `speed`: positive multiplier, default 1. Set speed between samples; the next elapsed interval uses that multiplier.
- `setPaused(boolean)`: pause/resume and reset baseline; paused samples produce no progress.
- `resetBaseline()`: discard baseline, useful on explicit reset or switching host scenes.

The core has no hidden catch-up cap. The demo uses `requestAnimationFrame` and explicitly pauses on `visibilitychange`. Any host can supply its own elapsed time and pause policy; integration is independent of any game engine.

## Production endpoints and deliveries

`addFacility` accepts `{inputInventoryId?, outputInventoryId?}` as a third argument. Omitted endpoints use the construction inventory. Facility snapshots expose all three IDs.

| Method                                                      | Contract                                                                                                       |
| ----------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| `materialDemands()`                                         | Read uncovered idle-job inputs, accounting for shared stock and committed incoming supply.                     |
| `reserveDelivery(sourceId, destinationId, bulk?, itemIds?)` | Atomically reserve bulk cargo and selected items or return `{ok:false, reason}`; success returns `deliveryId`. |
| `pickupDelivery(deliveryId)`                                | Consume reserved source goods once; cargo becomes in transit.                                                  |
| `arriveDelivery(deliveryId)`                                | Unload atomically; false retains cargo in `arrival-blocked`.                                                   |
| `cancelDelivery(deliveryId)`                                | Release a delivery before pickup only.                                                                         |
| `returnDelivery(deliveryId)`                                | Unload picked-up cargo at the source after a host return trip; false retains cargo.                            |

`SimulationSnapshot.deliveries` contains detached manifests/state. See [logistics](LOGISTICS.md) for ownership, cancellation, clock ordering, mixed bulk/item delivery manifests and example host policies.

`DeliverySnapshot` also contains `itemIds` and `items`: selected identities are recorded at reservation; the item data is captured at pickup. Delivery quantities include item counts automatically. `InventorySnapshot.reservedItemIds` exposes selected equipment held by reservations, and `item(id)` returns a detached item view or undefined.

`deliverySnapshot(id)` returns one detached manifest without cloning the world. `pruneDeliveries()` removes all delivered/cancelled history records and returns the number removed. Active reservations/transit cargo are retained. Archive history externally before pruning if needed. Delivery counters and compact item issuance proofs remain valid so IDs cannot be reused. Active incoming cargo is indexed by destination for demand queries.

## Diagnostics and explanations

All inspection results are detached and grant no mutation authority.

| Method                             | Contract                                                                                                                                                                                                                                           |
| ---------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `explainJob(jobId)`                | Return phase (`idle`, `working`, `awaiting-output`), blockers, required/held/available/inbound inputs, productivity sources, remaining nominal work, deferred work and estimated completion seconds. Unknown job throws.                           |
| `locateItem(itemId)`               | Return its inventory (with reservation owner ID or null), active delivery, resolved job, or `retired` if previously issued and no longer physically owned. Unknown identity returns undefined. Terminal delivery manifests are history.            |
| `inspectReservations(inventoryId)` | Return each reservation's job/delivery owner, quantities and selected item identities. Internal reservation tokens are not exposed.                                                                                                                |
| `validateState()`                  | Run the same whole-world validator as restore and compare reconstructed snapshots/demands against live indexes. Return `{ok:true}` or `{ok:false, issues:[{code:"invalid-state",message}]}` for the first detected issue. Safe in event observers. |
| `enableDiagnostics(limit = 200)`   | Enable a bounded trace and clear existing entries/sequence. Integer limit 0–10,000; zero disables and clears it. Cannot be called in observers.                                                                                                    |
| `diagnosticTrace()`                | Detached entries `{sequence,tick,kind,subject,details}`; oldest entries are evicted at the limit.                                                                                                                                                  |

`explainJob` reports all applicable blockers together. Missing inputs subtract the job's holdings and physical available stock; inbound promises are reported separately and are not usable until unloaded. Inbound totals cover the input inventory, not an exclusive promise to that job. Output deficits describe actual pending output, or primary output for an idle job; unresolved bonuses are not predictions. Working jobs have already consumed their required inputs. Completion estimates assume unchanged productivity and conditions, include fixed-tick rounding and deferred work, and are null while idle or blocked. They do not predict downstream supply or future storage competition.

Tracing is disabled by default. It records command boundaries/errors, production events, allocation changes and delivery transitions. Successful `advance`/`advanceTicks` calls are omitted to keep idle frame updates from evicting useful history. A `threw` entry may describe an observer error after commit; it does not mean the command rolled back. The trace is debugging history, not a replay log, and is excluded from checkpoints.

Validation reconstructs a whole world and ownership inspection scans it. Use these explicitly in a debugger or test, not every frame in a large simulation. The browser inspector computes explanations only while expanded and runs validation on request. See [runnable diagnostics](../examples/diagnostics.mjs).

### Scoped reads and item windows

`inventory.summary()` returns `id`, `capacityPerMaterial`, `quantities`, `reserved`, `workforce`, `itemCount`, and `reservedItemCount`. It copies totals and workforce but omits item records and reserved identity lists. Cost depends on registered resource/worker types, not the number of equipment records. `facilitySnapshot()` copies the selected factory's jobs, worker slots, modifiers and any pending outcomes. `facilityIds()` is linear in factory count; its IDs can be cached by a host until construction or removal changes.

```js
const clock = sim.summary();
const factory = sim.facilitySnapshot(selectedFacilityId);
const storage = sim.inventory(selectedInventoryId).summary();
const page = sim.inventory(selectedInventoryId).itemPage({
  offset: 0,
  limit: 50,
  resourceId: 'weapon',
});
// page: {items, total, offset, limit}
```

`itemPage()` returns detached equipment in current insertion order. Default offset is 0, default limit is 50; offset must be a nonnegative safe integer and limit an integer from 1 to 500. An optional resource filter must name a registered individual resource. Unknown IDs or invalid bounds throw. An offset beyond the current total returns an empty item array. Reserved items are included; this is a physical-stock view, not an availability claim. Use reservation inspection or delivery command results when selecting cargo.

These are live offset windows, not durable cursors: removal, pickup, return or transfer can change page membership between reads. Filtering and skipping traverse inventory items up to the selected window; only returned items are cloned. For unfiltered windows, totals come directly from the item count. No API promises a transaction spanning multiple calls; synchronous reads without intervening commands observe the same state.

All nested values remain detached. Summaries/pages/indexes are derived views, not additional saved state. `snapshot()` is retained for debugging, comparisons and explicit complete exports. The demo uses summaries, selected factory views and 50-item windows; logistics paints bounded item windows and reads its tracked deliveries individually. See [runnable scoped reads](../examples/scoped-reads.mjs).

Checkpoint creation copies each nested owned value once, without cloning the complete already-detached result again. The checkpoint-copy and observer-isolation guarantees are preserved in save version 7. Production traces remain available without listeners; detailed event payloads are constructed/queued only when an observer exists. Subscriptions do not replay old events. Subscribers added during notification continue to receive subsequent queued events according to the existing delivery order.

## Selecting individual recipe inputs

Recipe `inputs` and selected `optionalInputs` may include resources with `storage: "individual"`. Construction costs remain bulk-only. Quantities specify how many items the batch needs; the host specifies **which identities** using `setInputItems`.

```js
// salvage inputs: { weapon: 1, power: 2 }
sim.setInputItems(recyclerId, 'salvage', [damagedWeaponId]);
sim.advance(0.05);
const job = sim.facilitySnapshot(recyclerId).jobs[0];
// job.batchInputItems: consumed weapon with attributes captured at batch start
```

A nonempty selection must exactly match all individual quantities in mandatory plus currently selected optional inputs. IDs must be unique and physically present in the facility's input inventory at selection time. Invalid lists, resource types, counts, IDs or recipe references throw without changing state. Already-reserved items may be selected, but cannot be taken from their reservation owner. Selection itself does not reserve immediately: FIFO allocation on a tick boundary holds available selected items and bulk inputs incrementally. All inputs are consumed together only when the complete bundle is available.

No selection means no arbitrary equipment is used, and the job does not hold bulk inputs while awaiting a choice. `[]` clears the next selection. A semantically identical ID list preserves idle holdings and queue position. A changed selection releases idle holdings and request age. Consumption clears the selection exactly once, so a second batch needs another choice. A selection made while a batch is active applies to the next batch; active `batchInputItems` remain unchanged. Changing optional ingredients clears queued item selection even during active production, without altering that batch's locked inputs.

Selected items may be moved/consumed before allocation. Such requests wait for those exact identities, never substitute other equipment, and survive save/restore. Clear or replace a stale selection to recover. Wear/repair remains allowed while reserved; batch start captures the latest attributes. `batchInputItems` are detached **historical records**, not physical owners, and are cleared at publication. Started events retain their own historical input manifests. Consumed identities remain provably retired through compact issuance rules.

Outputs are fresh goods with fresh identities. Recipe attributes/modifiers determine output quality; the framework does not automatically inherit input attributes or repair an item in place. Hosts can inspect equipment before selection and configure modifiers, or use `updateItemAttributes` for in-place repair. Production modifiers retain their existing live timing semantics.

`explainJob` distinguishes `missing-item-selection` (quantities) and `selected-items-unavailable` (IDs). `missingInputs` counts usable selected equipment, not arbitrary goods of the same type. `materialDemands()` attaches `itemSelection: {required, selectedIds}` when individual inputs are needed; generic inbound quantity promises do not fulfill an identity choice. A transport host must inspect this metadata and deliver/select exact goods. Demands from draining factories are omitted. The query avoids counting the same selected identity twice among competing requests.

Run [item-selection.mjs](../examples/item-selection.mjs).

## Draining and safe removal

```js
sim.setFacilityDraining(factoryId, true);
// Continue advancing the host clock; wait for work AND output publication.
const blockers = sim.removalBlockers(factoryId);
if (blockers.length === 0) {
  const result = sim.removeFacility(factoryId);
}
```

Drain is independent of enable/conditions/productivity: current batches still need their normal staff, power and output space. Idle jobs become `drained`; active jobs retain progress and outcomes. No new batch starts, including in later rounds of a fast tick. Disabling a draining factory pauses its existing work; it does not complete it automatically. Turning drain off permits starts again on the next tick. A blocked outcome must be unloaded before removal.

Removal refuses any active job (including partial work, deferred work or pending output). It also refuses if reversing construction effects would leave assigned population above the remaining population, or physical material/item stock above remaining per-material capacity. `RemovalBlocker` entries are `{code:"active-batch",jobId}`, `{code:"workforce",workerId,shortage}` and `{code:"capacity",resourceId,excess}`. Failed removal changes no simulation state, apart from optional diagnostic trace entries.

An idle factory can be removed without first requesting drain; its partial reservations are released. Removal unassigns construction workforce, removes provided population/capacity, releases worker slots and drops live jobs/indexes/demands. Construction costs are not refunded. It does not remove inventories, consume stored goods, cancel deliveries, or destroy incoming cargo. Existing inbound cargo can become arrival-blocked after capacity shrinks; it remains owned by the delivery. Other active factories may also wait for output space. Host demolition/refund/relocation policies remain external.

Compact removed-factory records retain definition/job/batch provenance in checkpoints so previously manufactured items remain valid in inventories, transit, or retired identity inspection. Facility/job IDs are never reused. Removed factories are excluded from live counts/views and cannot receive commands. Removed provenance grows with factory churn, not lifetime item production. Observe `facility-draining` and `facility-removed` for cache invalidation; callbacks must queue subsequent commands for the host's next phase.

Run [factory-removal.mjs](../examples/factory-removal.mjs).

## Retiring inventories

`inventoryRemovalBlockers(id): InventoryRemovalBlocker[]` reads all blockers. `removeInventory(id): InventoryRemovalResult` returns `{ok:true, inventoryId, prunedDeliveryIds}` or `{ok:false, blockers}`. It refuses goods (including currency/equipment), any reservations, nonzero workforce, all live facility endpoint references, and either endpoint of reserved/transit/arrival-blocked deliveries. Unknown IDs produce a typed blocker. Refusal changes no state or diagnostic trace; observer reentry is prohibited.

Success prunes only terminal delivery history referencing that inventory, removes its live view/inbound index, and preserves goods elsewhere, item/delivery counters and producer provenance. Save format is now 4. The host may reuse the inventory name for a new inventory; cached old handles remain read-only detached last-state views. Invalidate host caches from the returned receipt. No removal event is emitted.

This is empty-buffer cleanup only; `removeFacility()` is unchanged. No active work/cargo destruction, evacuation destination, refund or automatic demolition policy is added. See [the full blocker contract and demolition primitive audit](INVENTORY-RETIREMENT.md) and [runnable retirement example](../examples/inventory-retirement.mjs).

## Planets, factions and simulation contexts

A single `Simulation` can contain independent inventory networks for multiple planets and factions. Facilities draw inputs/output from their explicit endpoints and workforce from their construction inventory, never from other networks implicitly. All networks share that simulation's clock. Host metadata maps inventory/facility IDs to planets, factions and permissions; the production API is not an authorization boundary. Only explicitly authorized host transfer/delivery commands should link networks.

Separate `Simulation` instances provide separate clocks/configurations/ownership domains. IDs are unique only inside one simulation; use `(contextId, itemId)` in host references. There is currently no cross-simulation ownership transfer API. Do not consume an item in one world and `spawnItem` it in another as though that were an atomic handoff. If persistent cross-context cargo identity is required today, use distinct inventory networks in one simulation. Keep host faction/network metadata in the host save alongside the framework checkpoint.

Run [networks.mjs](../examples/networks.mjs).

## Web Worker host integration

`Simulation` is synchronous and renderer-independent. Put its instance and all mutations in one worker when main-thread frame time matters. Send ordered commands and elapsed seconds; return scoped views rather than the whole world. Keep one advance in flight and accumulate elapsed time while awaiting it. A worker changes execution ownership, not tick semantics or production rules.

The [worker lab and example protocol](WORKER.md) exercises 6,000 factories, bounded UI updates, save/JSON/restore in the owner, and a main-thread control comparison. This protocol is example-host code (`src/worker-demo.ts`), not an additional public `Simulation` API. Checkpoint export is explicit and potentially expensive; routine UI responses do not contain the complete state. Read the measurement guide for live versus catch-up tests and clock/teardown policies.

The host lab uses an elapsed-time barrier before control commands, drains fractional elapsed time on pause, and reports terminal worker failures even while idle. Its queue/client helpers remain outside the public core API. The [worker guide](WORKER.md) includes integration examples and the compact issuance model and remaining history memory limits.

## Compact item issuance

There is no per-item historical ledger. External issuance is the contiguous range `external-1` through `external-(nextItem-1)`. Production issuance is derived from job ID, completed-batch counter, deterministic bonus quantities and output index; a blocked current outcome is also issued. Quality attributes are not rerolled. `locateItem(id)` still distinguishes physical owners, issued-but-retired goods and never-issued identities, including missed bonus outputs. Names and external references are host metadata, not item identities.

Restore validates all referenced identities after producers are loaded, independently checks exclusive physical ownership and reservations, and rejects future IDs, impossible output slots, malformed IDs and conflicting resource provenance. Proof work scales with saved references rather than lifetime production. Recipes without bonuses use registered output quantities directly; bonus manifests are cached only during validation. Numeric counters fail before overflow and are never wrapped. Restoring an old save rewinds that world; independently running save branches are separate identity domains.

With a fixed producer population and bounded live goods, item churn has bounded retained identity memory. Removed producers retain compact per-job recipe/counter provenance: repeated demolition still grows producer history. Terminal deliveries retain manifests until `pruneDeliveries()` is called. Live items, inventories and explicitly retained history still cost memory. See [identity example](../examples/identity-lifecycle.mjs) and [model limits](IDENTITIES.md).

## Timed construction and local attendance

Instant `addFacility()` remains immediate. Explicit `createConstructionOrder(definitionId, siteInventoryId, {durationSeconds, inputInventoryId?, outputInventoryId?})` returns a stable order ID. Read `constructionOrderIds()`, `constructionOrderSnapshot(id)` or `constructionDemands()`. `cancelConstructionOrder(id)` releases unfinished reservations without consuming/refunding materials; `pruneConstructionOrders()` removes terminal history only. Construction consumes registered costs once at atomic activation, never at both order creation and facility completion.

`setFacilityAttendance(id, presentByType)` reports actual local attendance independently of allocated workforce and efficiency slots. `minimumWorkforce` defaults to one per positive required type; configure the full count to require full staffing. Partial attendance scales capacity: one 100%-efficient attendee in ten slots gives 10% base productivity. Below the minimum, no start/progress/publication occurs, regardless of boosts. `setFacilityEnabled()` continues to pause production independently of draining. Snapshot `attendance` and `missingWorkforce` and saved enabled/draining flags remain independent.

Save format 7 persists construction, attendance and inventory operation position explicitly; genuine legacy 4/5/6 checkpoints remain readable. Unfinished orders block endpoint inventory retirement via `construction-reference`; terminal history does not alter its existing selective delivery-pruning receipt. Reservation inspection identifies `construction` owners as well as `job` and `delivery` owners. See [all contracts and limits](TIMED-CONSTRUCTION.md) and [executable example](../examples/timed-construction.mjs).

## Optional MCP telemetry (2.1.0)

`production-workshop/mcp` exports `createProductionTelemetryProvider`, the structural provider types and read-only tools. See [MCP-TELEMETRY.md](MCP-TELEMETRY.md) for exact arguments, authenticated simulation scoping, response bounds and limits. `Simulation.inventoryIds()` and `deliveryIds()` return detached insertion-order ID lists, matching existing facility/construction enumeration.

### Inventory operations

`exchange(transfers)`, `mutateInventory(mutation)`, `setInventoryRules(id,rules)`, `onInventoryEvent(listener)` and `inventoryEventSequence()` are public Simulation APIs. Exported input/result/event types and complete admission, failure, identity and timing semantics are in [Inventory operations](INVENTORY-OPERATIONS.md). Resource definitions additionally accept integer `unitWeight` and `unitVolume`; inventory options accept `rules`.

## Inventory context and equipment

`InventoryOptions` accepts optional `modifiers`, `metadata` and `equipment`. Read them through inventory summaries/snapshots (also exposed by read-only MCP inventory telemetry). `setInventoryModifiers(id, modifiers)` and `setInventoryMetadata(id, metadata)` replace the complete value. `InventoryView.effectiveItemAttributes(itemId)` returns matching numeric products without mutating base values. `equipItem(sourceInventoryId, equipmentInventoryId, itemId)` atomically swaps the old occupant back to source; `unequipItem(equipmentInventoryId, destinationInventoryId)` atomically transfers it out. Both return `InventoryTransactionResult`. An empty unequip succeeds with a null operation ID. See [validation, persistence, limits and timing](INVENTORY-CONTEXT.md).
