# Web Worker integration and responsiveness lab

Open [worker.html](../worker.html) after `npm start`. The default mode starts a module Web Worker with **6,000 factories / 2,000 active three-stage chains**. Each chain mines ore, smelts alloy and manufactures individual weapons with seeded health/precision. Inputs and output buffers are local, capacity is intentionally ample, and production is synchronized to the same 50 ms core tick. There are no per-factory timers or visibility-based production changes.

The simulation package is unchanged: a worker is a host integration boundary, not another execution path inside `Simulation`. The lab's workload and protocol live in `src/worker-demo.ts`, not the public package entrypoint. `worker/entry.js` owns the simulation; `worker/client.js` routes browser requests; `worker-app.js` owns rendering, elapsed time and measurements.

## Ownership and scheduling

The main thread sends plain commands and elapsed seconds. The worker owns the `Simulation`, inventory state, reservations, item identities and checkpoints. Do not send live inventory handles or use the main thread as a second mutation owner. Each worker's message handler processes one synchronous command at a time, in arrival order. Request IDs route acknowledgements; they are not simulation ticks.

```js
import { WorkerDemoClient } from './worker/client.js';

const client = new WorkerDemoClient((error) => showOwnerFailure(error));
const initialized = await client.request({ type: 'init' });
const reply = await client.request({ type: 'advance', seconds: 0.05 });
if (reply.result.view) render(reply.result.view);
// Teardown/restart rejects outstanding requests and terminates the old owner.
client.close();
```

The lab keeps **one advance request in flight**. `worker/advance-queue.js` accumulates elapsed seconds while the owner is busy. Before a checkpoint, burst or restore, it commits the time captured at that command boundary. Time arriving afterward stays buffered for later work. This is a host helper, not a factory scheduler or public core API.

```js
import { WorkerAdvanceQueue } from './worker/advance-queue.js';
const elapsed = new WorkerAdvanceQueue((seconds) =>
  client.request({ type: 'advance', seconds }),
);
// The engine's clock supplies authoritative elapsed time.
function update(seconds) {
  elapsed.add(seconds);
  const pending = elapsed.advance(); // null while busy or empty
  if (pending) pending.catch(showOwnerFailure);
}
async function checkpoint() {
  await elapsed.flush(); // captures pending time now; waits for earlier work
  return client.request({ type: 'checkpoint' });
}
// On teardown, close both elapsed and client.
```

`pendingSeconds` is unsent elapsed time; `busy` includes an active advance or barrier; `backlogSeconds` includes all elapsed time added but not acknowledged. `flush()` rejects overlapping barriers. The host must serialize expensive commands and prevent ordinary dispatch from overtaking them; the lab uses an operation flag. Failed advances stop the queue. There is no timeout, silent time cap or automatic retry: retrying an unacknowledged mutation could execute it twice.

The demo uses the core `Clock` as its wall-clock adapter, sampling `performance.now()` consistently in animation callbacks and command handlers. RAF timestamps are used only for animation measurements: they can precede a command handler's timestamp. Pausing and hiding harvest elapsed time through the pause boundary and drain even fractional pending time, without waiting for another animation frame. Restoring pauses the host, commits earlier work, replaces the world, and establishes a fresh wall-clock baseline. The saved simulation remainder survives restore. **Resume** starts a new baseline. These are host policies; the simulation still receives explicit elapsed seconds.

The client rejects a malformed or unexpected reply, decoding failure or worker crash as a terminal transport failure. All pending requests reject, callbacks detach, and the worker is terminated. The optional constructor failure callback also reports failures while idle. A valid rejected command or synchronous message-cloning error rejects only that request. `close()` is idempotent, rejects outstanding requests with `AbortError`, and does not call the failure callback. Its optional second constructor argument accepts an explicit Worker-like transport; the Node example injects its adapter rather than detecting platforms.

A restart creates a fresh owner and cancels the old requests. Navigating away closes the owner; returning to a cached page initializes a fresh world. Neither action restores unsaved production. UI generation checks prevent old completions from changing a restarted view.

For replay, supply the same ordered commands at the same logical boundaries. Message latency itself does not change production accounting; command order and elapsed time do. A large catch-up request still processes all ticks synchronously in its owner.

## Bounded presentation

Ordinary advances return a view at most once per simulated second. The worker aggregates all factories and returns:

- clock/count summary;
- producing, waiting and blocked counts and completed batches;
- twelve job summaries;
- stock counts for the first chain.

The worker's aggregation is still linear in factory count, but its messages and the main-thread DOM remain bounded. No complete snapshot, equipment list or checkpoint is copied across the thread boundary during routine rendering. UI progress is interpolated between confirmed views using the fixed example recipe durations and baseline productivity, capped at 1 until the next confirmation. This is presentation only. A general game renderer must use confirmed rates/conditions and stop interpolating when appropriate.

## Example protocol

`WorkerDemoClient.request(command)` resolves `{id, ok:true, result, workMilliseconds}` or rejects an error. Work timing includes command execution and building its view, but excludes message transport. Round-trip timing in the UI includes queueing and message delivery.

| Command                      | Result                                                                                                                                                                    |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `{type:'init'}`              | Build the fixed 6,000-factory world once; `initialized` and first view.                                                                                                   |
| `{type:'advance', seconds}`  | Feed elapsed time to `Simulation.advance`; `advanced`, optionally with a view.                                                                                            |
| `{type:'read'}`              | Explicit aggregate/sample view.                                                                                                                                           |
| `{type:'burst', ticks}`      | Advance 1–2,000 exact ticks; `burst-completed` with a view. The button uses 200 ticks / 10 simulated seconds.                                                             |
| `{type:'checkpoint'}`        | Save and stringify inside the owner, retaining JSON there; `checkpointed` with byte size and no state payload.                                                            |
| `{type:'export-checkpoint'}` | Explicitly return the retained JSON string for persistence/verification. This large transfer is not part of routine rendering and may cause main-thread copying/GC costs. |
| `{type:'restore'}`           | Parse and restore the retained checkpoint in the owner; `restored` with a fresh view.                                                                                     |

Save format remains 2, with no migrations. The fixed example's ASCII content makes JSON code-unit length equal UTF-8 byte size. A general host must compute UTF-8 bytes for arbitrary Unicode content. Retaining a checkpoint consumes worker memory; a worker does not make snapshots free. The browser buttons keep full checkpoints in the owner to isolate simulation/persistence CPU work from UI work; they do not write a durable save file.

For real integration, define the required game commands explicitly and schedule them through this single ownership boundary. Do not expose arbitrary method invocation or automatic replication of the whole world. Different planet/faction inventory networks can share one worker/simulation; separate worker contexts have separate identity domains. Cross-simulation cargo handoff is not implemented.

## Measuring responsiveness

The marker is moved by main-thread `requestAnimationFrame`, not by an autonomous compositor-only CSS animation. Select a **10, 30 or 60 second** measurement window to record RAF intervals while the world runs. It displays median, p95, maximum and the count of intervals above 25 ms, plus owner/round-trip timing and peak buffered elapsed seconds. The recent monitor retains at most 1,200 intervals. Initialization is excluded from timing windows; a hidden-tab measurement aborts.

For a fresh, reproducible paused starting world, open `worker.html?paused=1`; this applies to restarts and mode changes as well. Keep the normal URL for live operation.

1. In **Web Worker** mode, let the world initialize, then measure ten seconds without other actions. Confirm all 6,000 factories are producing and none are blocked.
2. Switch to **Main thread comparison** and repeat the same live test. This uses the same workload and `WorkerDemoHost` implementation, with direct execution as the explicit experimental control.
3. For a stress comparison, repeat each mode's measurement while pressing **Advance 10 seconds in one burst**, **Checkpoint in owner**, and **Restore checkpoint**. A restore pauses game time, but frame measurement continues and includes restore blocking on the main thread.
4. Use **Tap to test response** during worker operations. Its displayed latency is click-handler-to-next-RAF time, not end-to-end hardware input latency.

A live run and a catch-up burst answer different questions. A 200-tick burst deliberately stresses a long synchronous operation; it does not represent a normal 50 ms tick. Browser refresh rate determines the actual frame budget (16.7 ms at 60 Hz, 6.94 ms at 144 Hz). The 25 ms counter is a fixed diagnostic threshold, not a claim that every shorter frame meets that budget. Concurrent workloads, browser scheduling, rendering and GC can still cause spikes. A worker removes simulation work from the UI thread; it does not reduce total CPU work or guarantee performance on other hardware.

## Runnable verification

```sh
npm run check
node examples/web-worker.mjs
npm run soak    # accelerated 300 simulated seconds; Node workers with explicit GC
```

The terminal example uses Node worker threads as a transport adapter around the same protocol/workload; it does not claim browser rendering verification. The worker test compares ordered responses against direct execution, including fractional elapsed time, exact burst ticks, bounded views, rejected commands, exact exported JSON checkpoint equality, restore and continued production. Browser frame measurements complement those deterministic checks.

### Local browser result

On the local i7-14700K in the Codex in-app Chromium browser, ten-second live measurements had approximately 7 ms median RAF intervals and 14 ms p95 in both modes. Maximum intervals were about 28 ms in worker mode and 42 ms in the main-thread control. In a fresh paused-world stress comparison (one 200-tick burst, checkpoint, then restore), maxima were about 28 ms with a worker and 729 ms on the main thread. Both stress checkpoints were 6.19 MB and retained inside their owner; all 6,000 factories were producing after the burst, with no output blockage.

These are one measured window per mode/scenario on this machine, not statistical guarantees or a throughput-speedup claim. The live runs do not establish a large typical-frame improvement. The stress runs demonstrate that long owner operations avoid blocking the UI when the owner is a worker. Occasional missed browser frames remain.

## Longer production and lifecycle checks

The tests cover out-of-order acknowledgement routing, malformed replies, idle failure, real worker exit, closing with pending requests, restart during queued work and exact checkpoint boundaries while the owner is busy. Worker/direct checkpoint and continuation comparisons use the complete serialized state.

`scripts/worker-soak.mjs` runs 6,000 factories for 300 simulated seconds in each of two actual Node workers: retain all equipment, or consume it every ten simulated seconds. It samples collected heap outside advance timing, then compares checkpoint and continued production exactly after restore. To save raw results elsewhere:

```sh
node --expose-gc scripts/worker-soak.mjs 300 /tmp/worker-soak.json
```

The local run completed **1,474,000 batches and issued 398,000 weapon identities per mode**, with all 6,000 factories producing. Exact checkpoint and continuation comparisons passed. Advancement took about 15.1 seconds of CPU work per mode; this is accelerated simulation, not a five-minute real-time browser run.

Collected heap grew from about 27.9 MiB to 179.4 MiB with equipment retained, or 110.0 MiB with all weapons consumed. After the round-trip helper returned and another GC, heaps were 139.2 and 71.2 MiB respectively; temporary state and V8 string representation affect these readings. Restore took about 1.74 and 1.06 seconds for these much larger worlds. No additional sustained restore growth was observed in this check, but it does not establish hours-long memory stability.

Those measurements describe the earlier ledger implementation. The current framework has no per-item historical ledger: external IDs use a monotonic counter and production IDs use compact job/batch provenance. The new consumption benchmark is documented in [compact identities](IDENTITIES.md). Its memory bound assumes a fixed producer population, bounded live stock and disposal of terminal delivery history. Removed-producer provenance still scales with factory churn.

A separate 30-second browser window, with one 200-tick burst and checkpoint, recorded a 7.0 ms p95 and 7.1 ms maximum RAF interval, with no intervals over 25 ms. Owner work peaked at 356.9 ms; buffered elapsed peaked at 0.3775 seconds. This is one local window, and demonstrates isolation from that owner's blocking work, not a universal frame-time guarantee.
