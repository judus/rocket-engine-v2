# Compact identities and bounded item churn

The framework owns item identities. External creation uses `spawnItem(inventoryId, resourceId, attributes)` and a saved monotonic counter. Callers cannot supply IDs. Store display names and external-system references in host data keyed by the returned ID. Failed deposits do not advance the counter; exhaustion rejects before mutation. No ID reuse, probabilistic hashing or expiry policy is involved.

Production IDs retain their existing job/batch/resource/index structure. Completed-batch counters prove which batches finished. Seeded bonus quantities prove which output slots were actually issued, including rare goods; optional ingredients and specialists affect attributes, not issuance. A resolved current output-blocked batch also owns its issued items. These proofs use existing producer state instead of a string for every destroyed item.

`locateItem()` finds inventories, reservations, transit and pending outcomes first. An issued identity with no physical owner is retired; a future batch, missed bonus, nonexistent output slot or malformed ID is unknown. Save/restore retains this distinction. Restore checks every referenced identity, exclusive physical owners, consumed-input manifests and reservations. Resource provenance must agree across references. It does not authenticate a deliberately fabricated save, and restoring an earlier save rewinds its identity domain.

Save format **4** is the sole accepted format. It has no `issuedItemIds` field. Older saves are rejected without conversion. Producer configuration and RNG semantics remain part of the checkpoint contract.

## What is bounded

For a fixed factory population and bounded live equipment, producing and consuming more items does not increase retained identity history. External issuance needs one counter; each production job needs its existing completed-batch counter. Restore visits retained references rather than all items ever produced.

Memory is not globally constant: stored goods retain attributes; active jobs retain consumed-input records until completion; saved checkpoints and host history consume memory. `pruneDeliveries()` discards delivered/cancelled manifests while preserving active cargo and counters. Removed factories retain compact per-job provenance to validate surviving and retired identities. Endless construction/demolition therefore still grows producer history; dropping it would weaken the current provenance/inspection guarantee. No automatic history deletion is introduced.

## Verification

`npm run check` covers external counter continuity, rejected custom IDs, failed deposits, duplicate owners, impossible output slots, missed bonuses, consumed identity inspection, transit from removed producers, exact serialized round trips and continued RNG behavior. Run `node examples/identity-lifecycle.mjs` after building.

`npm run soak` runs real Node workers for 300 simulated seconds with 6,000 factories, comparing retained goods against consumption every ten seconds. For a longer run:

```sh
node --expose-gc scripts/worker-soak.mjs 600 /tmp/compact-identity-soak.json
```

Collected heap is sampled after explicit GC outside advancement timing. This accelerated test verifies complete checkpoint/continuation hashes, not hours-long browser memory stability. Retained equipment should grow; consumed equipment should reach a plateau when the live world remains fixed.

## Local benchmark result

On Node v24.14.0, each mode simulated 600 seconds with 6,000 factories: **2,954,000 batches and 798,000 weapons**. With consumption every ten simulated seconds, sampled collected heap stayed between 27.3 and 28.7 MiB, ending at 27.4 MiB. Exact checkpoint and continuation hashes matched. Restore took 192 ms.

Retaining all weapons grew sampled heap to 311.5 MiB, as expected for live equipment. Restore took 2.25 seconds. Advancement CPU work was 28.03 seconds retained and 27.41 seconds consumed. These are accelerated local runs, not frame-time guarantees.

At 300 simulated seconds, consumption ended around 27.4 MiB versus about 110.0 MiB in the earlier ledger run with the same workload. This establishes a plateau over this window, not a universal leak-proof guarantee.
