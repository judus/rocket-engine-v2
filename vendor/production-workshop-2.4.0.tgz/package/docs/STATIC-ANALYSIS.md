# Static analysis and performance policy

## Commands

```sh
npm run typecheck  # strict TypeScript checking without emitting files
npm run lint       # Oxlint correctness checks and selected type-aware rules
npm run check      # both, compiled-JavaScript tests, and all runnable examples
```

Analysis tools are development dependencies. They are not imported by the framework or the browser demos. Oxlint and its type-aware companion are pinned to exact versions in the lockfile. The existing TypeScript 7 compiler remains unchanged. typescript-eslint was not installed because its current peer dependency range excludes that compiler; no peer dependency overrides or compiler downgrade were used.

## Scope

The TypeScript core uses `strict`, `noUncheckedIndexedAccess` and `exactOptionalPropertyTypes`. Oxlint adds explicit correctness rules for broken control flow, duplicate definitions/cases, invalid operations, unreachable code, precision loss, unused bindings and other defects. Selected type-aware rules catch unhandled/misused promises, awaiting non-promises, implied eval, and unsafe calls/member access/arguments.

The browser JavaScript, Node examples, workload scripts and tests receive syntax/correctness checks with appropriate globals and undefined-name detection. Type-aware rules apply only to `src/**/*.ts`; this does not claim full type checking of the untyped UI or Node clients. Generated `dist` files and dependencies are excluded from lint traversal; the existing tests execute emitted JavaScript instead.

`.oxlintrc.json` explicitly disables broad rule categories and enables named rules. Adding/upgrading a tool must not silently introduce a style preset. No formatter, mutation prohibition, loop preference, immutable-copy mandate, naming scheme, or generic complexity threshold is imposed. Unused destructured fields deliberately excluded from an object-rest result are accepted. Leading-underscore unused bindings are permitted for intentional host signatures; accidentally unused bindings are errors.

## The performance rule

Static analysis serves correctness and maintainability. It does not dictate the runtime algorithm.

- Do not replace loops, mutation, maps, caches, reservations, or indexed lookups with slower alternatives merely to satisfy a rule.
- Prefer a real defect fix. If a rule misunderstands an intentional implementation, use the narrowest justified exception and describe the invariant or measured tradeoff next to it.
- A runtime change in a hot path needs relevant correctness checks and a benchmark. An erased type annotation or comment does not need a runtime benchmark.
- Do not introduce cloning, allocation, extra traversal, wrappers, or changed accounting/ownership semantics just to get a green lint report.
- Rule additions must name the defect they catch. If a rule repeatedly produces noise for this architecture, change the rule policy rather than contorting the implementation.

Unused disable directives are reported, and warnings fail `npm run lint`. A justified, documented exception is allowed; silently disabling analysis broadly is not.

Some existing array guards pass `value as unknown` to `Array.isArray`. This prevents that predicate from widening an already declared string-array type to `any[]`. The runtime array/content checks remain in place; the annotation is erased and adds no validation work or copying.

## Verified adoption

Known-invalid temporary probes confirmed that an unhandled promise in the TypeScript core and an undefined name in a JavaScript client fail lint. The probes were then removed. The full check also runs the framework tests and runnable examples. At tooling adoption, all emitted framework JavaScript hashes matched those from before the tooling addition: no runtime code changed to satisfy the rules.

Lint and type checks complement ownership/restore tests and runtime validation; they cannot prove conservation, deterministic continuation, or acceptable game-frame costs by themselves.

References: [Oxlint configuration](https://oxc.rs/docs/guide/usage/linter/config.html), [type-aware linting](https://oxc.rs/docs/guide/usage/linter/type-aware.html).
