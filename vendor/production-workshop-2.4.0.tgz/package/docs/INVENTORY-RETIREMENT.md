# Guarded inventory retirement and host demolition boundaries

`removeInventory(id): InventoryRemovalResult` is final cleanup of an empty, unreferenced inventory. It never demolishes a factory, schedules evacuation, destroys goods, cancels work or disposes of active cargo. Rocket Engine is not modified by this feature.

```ts
type InventoryRemovalResult =
  | { ok: true; inventoryId: string; prunedDeliveryIds: string[] }
  | { ok: false; blockers: InventoryRemovalBlocker[] };
```

`inventoryRemovalBlockers(id)` returns the same detached blocker list without changing state. The order is resource stock, reservations, workforce, live facility references, then active delivery references, each in its existing registration/insertion order. Every applicable blocker is returned; a missing ID returns only `unknown-inventory`.

| Code                 | Fields                          | Meaning                                                                                                                                                                              |
| -------------------- | ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `unknown-inventory`  | none                            | Inventory is absent; repeated removal refuses.                                                                                                                                       |
| `goods`              | `resourceId`, `quantity`        | Positive stock, including currency and individual equipment.                                                                                                                         |
| `reservation`        | `token`                         | Any outstanding reservation record.                                                                                                                                                  |
| `workforce`          | `workerId`, `total`, `assigned` | Positive population or assigned workforce; free population also blocks. Zero entries do not block.                                                                                   |
| `facility-reference` | `facilityId`, `roles`           | A live factory uses this inventory for `construction`, `input`, or `output`. Disabled and draining factories still count.                                                            |
| `active-delivery`    | `deliveryId`, `state`, `role`   | A `reserved`, `in-transit` or `arrival-blocked` delivery references this inventory as `source` or `destination`. An empty source after pickup still blocks because cargo may return. |

Refusal leaves simulation state **and diagnostic traces** unchanged. Like other mutation commands, removal is forbidden inside an event observer. Successful removal uses the normal mutation guard and trace, deletes the inventory/view/inbound index, and returns a detached receipt. There is no new removal event; the host uses the receipt to invalidate its cached inventory IDs and views.

## Terminal delivery history and checkpoints

On success, removal prunes **only delivered/cancelled delivery records whose source or destination is the removed inventory**. Their IDs are returned in `prunedDeliveryIds`. These manifests are history, not goods owners. All active references were checked before mutation. Unrelated terminal history and all active deliveries remain unchanged.

Archive history before successful retirement if the game needs it for logs. Individual item identities, quality, external counters, delivery counters and removed-producer provenance are retained independently of these historical copies. Save/reload therefore has no dangling terminal endpoints, does not resurrect inventory or cargo, and cannot reuse delivery/item identities. The current save format is **6**; genuine formats 4 and 5 remain readable. Retirement itself adds no checkpoint fields or compatibility path.

Retirement removes the inventory ID from the live namespace. The caller may create a fresh inventory with the same ID. Previously returned read-only handles remain detached last-state handles; they cannot mutate the replacement. Host references/caches must be invalidated explicitly. Framework item IDs and producer IDs are never reset or reused.

`removeFacility()` is unchanged: it refuses active batches and workforce/capacity conflicts, releases idle allocations, reverses construction effects, preserves output/input inventories, retains producer provenance, and does not refund costs or cancel cargo. Retirement may remain blocked after factory removal because of other factories, goods, workforce or shipments.

## Primitive audit

| Host operation                                          | Existing support                                                       | Boundary / missing contract                                                                                                                                                                                                                           |
| ------------------------------------------------------- | ---------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Stop new production; finish current work                | `setFacilityDraining(id, true)`                                        | Releases idle allocations and prevents every new start. Existing batches need normal staff/power/productivity and output space. Disabling a factory pauses current work.                                                                              |
| Suppress production input demands                       | Draining excludes the factory from `materialDemands()`                 | Does not cancel existing deliveries or reject manual/new `reserveDelivery()` calls. No inventory-wide admission/closing gate exists; host dispatch must enforce intent across all producers sharing the buffer.                                       |
| Evacuate goods without recipe demand                    | `reserveDelivery(source, destination, bulk, itemIds)` + pickup/arrival | Explicit arbitrary cargo is supported; demand is not required. Host chooses identities, destination, travel, capacity and permissions. `transfer`/`transferItem` are explicitly instant alternatives; no stockpile shortcut is automatically applied. |
| Cancel shipment before pickup                           | `cancelDelivery(id)` for `reserved`                                    | Releases source reservations and inbound promises; source goods never left.                                                                                                                                                                           |
| Return carried cargo                                    | `returnDelivery(id)` for transit/arrival-blocked                       | Host supplies return travel timing. Unloads to original source only. Full source returns false and retains cargo; incoming promises remain until a successful return.                                                                                 |
| Redirect cargo in transit                               | None                                                                   | Returning to source, unloading, then reserving a new delivery is supported when capacity permits; in-place retargeting is not.                                                                                                                        |
| Destroy available stored bulk goods                     | `withdraw(inventoryId, quantities)`                                    | Explicit removal of unreserved available bulk stock, including currency. No all-goods demolition operation or refund policy.                                                                                                                          |
| Destroy available stored equipment                      | `consumeItem(inventoryId, itemId)`                                     | Consumes one unreserved item; identity remains retired. Reserved items return false. No implicit destruction of cargo or pending outputs.                                                                                                             |
| Cancel active production                                | None                                                                   | Consumed ingredients, elapsed/deferred work and resolved output belong to the batch. Drain completes them; disable/conditions/zero productivity pause them. There is no abort/refund/discard command.                                                 |
| Destroy reservation-held goods or pending batch outputs | None                                                                   | Host can release a pre-pickup shipment reservation or idle job demand via existing lifecycle commands; active batch/output disposal needs a new explicit contract.                                                                                    |
| Remove factory                                          | `removalBlockers()` / `removeFacility()`                               | Existing contract preserved. Work must finish; workforce/capacity dependencies must permit removal.                                                                                                                                                   |
| Remove empty buffers                                    | `inventoryRemovalBlockers()` / `removeInventory()`                     | New guarded final cleanup, not a deferred demolition queue.                                                                                                                                                                                           |

The core permits evacuating an inventory while factories still reference it, subject to ordinary stock reservations. To finish decommission, the host must stop new starts/dispatch, let active jobs finish, arrange explicit outbound deliveries, remove the factory when its existing guards allow, resolve all delivery references, and retire eligible dedicated buffers. Shared inventories generally remain. The host owns ordering and the final decision; it must use commands, never rewrite checkpoint data.

## Separate proposals requiring review

These are **not implemented** in 1.1.0:

- An active-batch abort contract must identify the job and specify treatment of already-consumed inputs, deferred work and resolved output. Define atomic refusal/success receipts and events; decide whether refund, discard or recovery is permitted. Pending produced identities must remain retired if discarded. No refund or loss policy is selected here.
- In-transit retargeting would need an explicit destination, validation of ownership/endpoints and inbound-counter capacity, atomic promise reassignment, and a stable identity/attribute-preserving manifest. Host travel timers/routes remain external. Whether a retargeted shipment keeps its original return endpoint is an undecided contract.
- Explicit cargo destruction/loss would require a receipt and identity retirement plus removal of inbound promises. It must never follow implicitly from inventory or factory removal. Authorization and game loss/refund rules need separate review.
- An optional inventory admission gate could reject new inbound dispatch while permitting existing cargo and outbound evacuation. Decide reopening/save semantics and whether construction/new factory references are also prohibited. Host-controlled dispatch is sufficient today; no automatic scheduler is proposed.

Run `node examples/inventory-retirement.mjs` after building. Tests cover every blocker, all active delivery states at both endpoints, failure atomicity including traces, selective terminal pruning, cached-view detachment, identity/provenance preservation, counters and JSON save/reload.

## Construction coordination in 2.0.0

Unfinished construction orders add `construction-reference` with `orderId` and endpoint `roles` (`site`, `input`, `output`) to the blocker union. Retirement success, atomic refusal, terminal-delivery handling and factory-removal contracts are unchanged. Terminal order history does not own stock or prevent retirement; it survives reload with historical endpoint IDs. See [construction contracts](TIMED-CONSTRUCTION.md).
