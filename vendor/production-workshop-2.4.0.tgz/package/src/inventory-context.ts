import type { InventoryMetadata, InventoryModifiers } from './models.js';
import { invariant, cloneData, validateAttributes } from './registry.js';

export function validateModifiers(
  value: InventoryModifiers,
): InventoryModifiers {
  validateMetadata(value);
  validateAttributes(value);
  return { ...value };
}
/** Bound JSON validation work and reject values that cannot round-trip honestly. */
export function validateMetadata(value: InventoryMetadata): InventoryMetadata {
  let nodes = 0;
  const ancestors = new Set<object>();
  const visit = (v: unknown, depth: number): void => {
    invariant(
      ++nodes <= 4096 && depth <= 16,
      'metadata exceeds size or depth limit',
    );
    if (v === null || typeof v === 'string' || typeof v === 'boolean') return;
    if (typeof v === 'number') {
      invariant(Number.isFinite(v), 'metadata requires finite numbers');
      return;
    }
    invariant(
      typeof v === 'object' && v !== null && !ancestors.has(v),
      'metadata requires acyclic JSON values',
    );
    invariant(
      Array.isArray(v) ||
        Object.getPrototypeOf(v) === Object.prototype ||
        Object.getPrototypeOf(v) === null,
      'metadata requires plain JSON objects',
    );
    invariant(
      Reflect.ownKeys(v).length ===
        Object.keys(v).length + (Array.isArray(v) ? 1 : 0),
      'metadata requires enumerable string keys',
    );
    ancestors.add(v);
    if (Array.isArray(v)) {
      invariant(
        Object.keys(v).length === v.length,
        'metadata requires dense arrays',
      );
      for (let i = 0; i < v.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(v, i);
        invariant(
          descriptor && 'value' in descriptor,
          'metadata requires dense data arrays',
        );
        visit(descriptor.value as unknown, depth + 1);
      }
    } else
      for (const key of Object.keys(v)) {
        const descriptor = Object.getOwnPropertyDescriptor(v, key)!;
        invariant('value' in descriptor, 'metadata cannot contain accessors');
        visit(descriptor.value as unknown, depth + 1);
      }
    ancestors.delete(v);
  };
  invariant(
    value !== null && typeof value === 'object' && !Array.isArray(value),
    'metadata requires an object',
  );
  visit(value, 0);
  return cloneData(value);
}
