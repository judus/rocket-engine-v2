import type {
  BatchOutcome,
  RecipeDefinition,
  Quantities,
  ProductionModifier,
} from './models.js';
export function resolveOutcome(
  seed: number,
  jobId: string,
  batch: number,
  recipe: RecipeDefinition,
  optionalInputs: Quantities,
  modifiers: Record<string, ProductionModifier>,
  individualResources: ReadonlySet<string>,
): BatchOutcome {
  const random = batchRandom(seed, jobId, batch);
  const quantities = quantitiesWithBonus(recipe, random);
  const items: BatchOutcome['items'] = [];
  for (const id of Object.keys(quantities).sort())
    if (individualResources.has(id))
      for (let index = 0; index < quantities[id]!; index++) {
        const attributes: Record<string, number> = Object.create(
          null,
        ) as Record<string, never>;
        for (const [key, range] of Object.entries(
          recipe.itemAttributes?.[id] ?? {},
        ).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))) {
          let bonus = Object.values(modifiers).reduce(
            (n, m) =>
              n +
              (m.attributeBonuses && Object.hasOwn(m.attributeBonuses, key)
                ? m.attributeBonuses[key]!
                : 0),
            0,
          );
          for (const [ingredient, n] of Object.entries(optionalInputs))
            if (n > 0)
              bonus +=
                recipe.optionalAttributeBonuses &&
                Object.hasOwn(recipe.optionalAttributeBonuses, ingredient) &&
                Object.hasOwn(recipe.optionalAttributeBonuses[ingredient]!, key)
                  ? recipe.optionalAttributeBonuses[ingredient]![key]!
                  : 0;
          attributes[key] =
            range.min + (range.max - range.min) * random() + bonus;
        }
        items.push({
          id: `${jobId}.batch-${batch}.${id}-${index}`,
          resourceId: id,
          attributes,
        });
      }
  return { quantities, items };
}

function batchRandom(seed: number, jobId: string, batch: number): () => number {
  // Per-batch random stream: unrelated jobs and delivery retries cannot change its rolls.
  let state = 2166136261;
  for (const c of `${seed}/${jobId}/${batch}`)
    state = Math.imul(state ^ c.charCodeAt(0), 16777619);
  return () => {
    state = (state + 0x6d2b79f5) | 0;
    let n = Math.imul(state ^ (state >>> 15), 1 | state);
    n ^= n + Math.imul(n ^ (n >>> 7), 61 | n);
    return ((n ^ (n >>> 14)) >>> 0) / 4294967296;
  };
}

function quantitiesWithBonus(
  recipe: RecipeDefinition,
  random: () => number,
): Record<string, number> {
  const quantities: Record<string, number> = Object.assign(
    Object.create(null) as Record<string, never>,
    recipe.outputs,
  );
  for (const bonus of recipe.bonusOutputs ?? [])
    if (random() < bonus.chance)
      for (const [id, n] of Object.entries(bonus.outputs))
        quantities[id] = (quantities[id] ?? 0) + n;
  return quantities;
}

/** Identity proof needs bonus quantities, never quality attributes or item allocations. */
export function producedQuantities(
  seed: number,
  jobId: string,
  batch: number,
  recipe: RecipeDefinition,
): Quantities {
  return quantitiesWithBonus(recipe, batchRandom(seed, jobId, batch));
}
