import { Simulation, type Configuration } from './index.js';
// This TypeScript example is compiled by npm run build and executed by npm run examples.
const config = {
  resources: [
    { id: 'ore', label: 'Ore', kind: 'material' },
    { id: 'alloy', label: 'Alloy', kind: 'material' },
  ],
  recipes: [
    {
      id: 'smelt',
      label: 'Smelt alloy',
      durationSeconds: 1,
      inputs: { ore: 2 },
      outputs: { alloy: 1 },
    },
  ],
  facilities: [
    {
      id: 'smelter',
      label: 'Smelter',
      category: 'production',
      recipes: ['smelt'],
      constructionCost: {},
    },
  ],
} satisfies Configuration;
const simulation = new Simulation(config);
simulation.createInventory({
  id: 'cargo',
  capacityPerMaterial: 20,
  initial: { ore: 6 },
});
const result = simulation.addFacility('smelter', 'cargo');
if (!result.ok) throw new Error(result.reason);
simulation.advance(3.05); // First boundary starts the job; three one-second batches then complete.
const stock = simulation.inventory('cargo').snapshot().quantities;
if (stock.alloy !== 3 || stock.ore !== 0)
  throw new Error('Unexpected production result');
// No console dependency: JSON string is returned/exported for browser or Node consumers.
export const resultJson = JSON.stringify(stock);
