import { Simulation } from './simulation.js';
import { DefinitionError, invariant } from './registry.js';
import type { SimulationSummary } from './models.js';

/** Example workload/protocol, deliberately separate from the production package API. */
export const workerFactoryCount = 6000;
export function createWorkerWorld(): Simulation {
  const sim = new Simulation({
    seed: 123,
    tickMilliseconds: 50,
    resources: ['ore', 'alloy', 'weapon'].map((id) => ({
      id,
      label: id,
      kind: 'material',
      ...(id === 'weapon' ? { storage: 'individual' } : {}),
    })),
    recipes: [
      {
        id: 'mine',
        label: 'Mine',
        durationSeconds: 1,
        inputs: {},
        outputs: { ore: 2 },
      },
      {
        id: 'smelt',
        label: 'Smelt',
        durationSeconds: 1.25,
        inputs: { ore: 2 },
        outputs: { alloy: 1 },
      },
      {
        id: 'forge',
        label: 'Forge',
        durationSeconds: 1.5,
        inputs: { alloy: 1 },
        outputs: { weapon: 1 },
        itemAttributes: {
          weapon: {
            health: { min: 80, max: 100 },
            precision: { min: 0.8, max: 1 },
          },
        },
      },
    ],
    facilities: ['mine', 'smelt', 'forge'].map((id) => ({
      id,
      label: id,
      category: 'production',
      recipes: [id],
      constructionCost: {},
    })),
  });
  for (let chain = 0; chain < workerFactoryCount / 3; chain++) {
    const raw = `raw-${chain}`,
      refined = `refined-${chain}`,
      finished = `finished-${chain}`;
    sim.createInventory({
      id: raw,
      capacityPerMaterial: 1000000,
      initial: { ore: 4 },
    });
    sim.createInventory({
      id: refined,
      capacityPerMaterial: 1000000,
      initial: { alloy: 2 },
    });
    sim.createInventory({ id: finished, capacityPerMaterial: 1000000 });
    sim.addFacility('mine', raw);
    sim.addFacility('smelt', raw, { outputInventoryId: refined });
    sim.addFacility('forge', refined, { outputInventoryId: finished });
  }
  return sim;
}
export type WorkerDemoCommand =
  | { type: 'init' }
  | { type: 'advance'; seconds: number }
  | { type: 'burst'; ticks: number }
  | { type: 'read' }
  | { type: 'checkpoint' }
  | { type: 'export-checkpoint' }
  | { type: 'restore' };
export interface WorkerDemoView {
  summary: SimulationSummary;
  counts: {
    producing: number;
    waiting: number;
    blocked: number;
    batches: number;
  };
  jobs: {
    id: string;
    recipeId: string;
    state: string;
    progress: number;
    batches: number;
  }[];
  sampleStock: { ore: number; alloy: number; weapons: number };
}
export interface WorkerDemoResult {
  type:
    | 'initialized'
    | 'advanced'
    | 'burst-completed'
    | 'view'
    | 'checkpointed'
    | 'checkpoint-exported'
    | 'restored';
  view: WorkerDemoView | null;
  checkpointBytes?: number;
  checkpoint?: string;
}
/** One owner, ordered commands; no wall clock or background timer in the core. */
export class WorkerDemoHost {
  #sim: Simulation | null = null;
  #checkpoint: string | null = null;
  #lastViewTick = -20;
  #facilityIds: string[] = [];
  handle(command: WorkerDemoCommand): WorkerDemoResult {
    if (command.type === 'init') {
      invariant(this.#sim === null, 'worker world already initialized');
      this.#sim = createWorkerWorld();
      this.#facilityIds = this.#sim.facilityIds();
      return { type: 'initialized', view: this.#view() };
    }
    const sim = this.#sim;
    invariant(sim, 'worker world is not initialized');
    switch (command.type) {
      case 'advance':
        sim.advance(command.seconds);
        return {
          type: 'advanced',
          view:
            sim.summary().tick - this.#lastViewTick >= 20 ? this.#view() : null,
        };
      case 'burst':
        invariant(
          Number.isSafeInteger(command.ticks) &&
            command.ticks > 0 &&
            command.ticks <= 2000,
          'burst requires 1–2000 exact ticks',
        );
        sim.advanceTicks(command.ticks);
        return { type: 'burst-completed', view: this.#view() };
      case 'read':
        return { type: 'view', view: this.#view() };
      case 'checkpoint': {
        this.#checkpoint = JSON.stringify(sim.save());
        // ASCII content/IDs in this fixed example: code units equal UTF-8 bytes.
        return {
          type: 'checkpointed',
          view: null,
          checkpointBytes: this.#checkpoint.length,
        };
      }
      case 'export-checkpoint':
        invariant(this.#checkpoint !== null, 'take a checkpoint first');
        return {
          type: 'checkpoint-exported',
          view: null,
          checkpoint: this.#checkpoint,
        };
      case 'restore':
        invariant(this.#checkpoint !== null, 'take a checkpoint first');
        this.#sim = Simulation.restore(JSON.parse(this.#checkpoint) as unknown);
        this.#facilityIds = this.#sim.facilityIds();
        return { type: 'restored', view: this.#view() };
      default:
        throw new DefinitionError('unknown worker command');
    }
  }
  #view(): WorkerDemoView {
    const sim = this.#sim!;
    const summary = sim.summary();
    const counts = { producing: 0, waiting: 0, blocked: 0, batches: 0 };
    const jobs: WorkerDemoView['jobs'] = [];
    for (const id of this.#facilityIds) {
      const f = sim.facilitySnapshot(id);
      for (const j of f.jobs) {
        counts.batches += j.batchesCompleted;
        if (j.state === 'producing') counts.producing++;
        else if (j.state === 'output-blocked') counts.blocked++;
        else counts.waiting++;
        if (jobs.length < 12)
          jobs.push({
            id: j.id,
            recipeId: j.recipeId,
            state: j.state,
            progress: j.progress,
            batches: j.batchesCompleted,
          });
      }
    }
    this.#lastViewTick = summary.tick;
    return {
      summary,
      counts,
      jobs,
      sampleStock: {
        ore: sim.inventory('raw-0').quantity('ore'),
        alloy: sim.inventory('refined-0').quantity('alloy'),
        weapons: sim.inventory('finished-0').quantity('weapon'),
      },
    };
  }
}
