import type {
  InventoryModifiers,
  InventoryMetadata,
  InventoryRules,
  InventoryMutation,
  InventoryTransfer,
  InventoryTransactionResult,
  InventoryChange,
  InventoryEvent,
  InventoryAttachment,
  InventoryCapacity,
  SimulationSummary,
  ConstructionOptions,
  ConstructionOrderSave,
  ConstructionOrderSnapshot,
  ConstructionBlocker,
  ConstructionCancellationResult,
  InventoryRemovalBlocker,
  InventoryRemovalResult,
  RetiredFacilitySave,
  RemovalBlocker,
  RemovalResult,
  FacilityInventoryOptions,
  ItemLocation,
  JobExplanation,
  ReservationInspection,
  DiagnosticEntry,
  ValidationResult,
  InventoryView,
  ProducedItem,
  SimulationSave,
  DeliverySnapshot,
  DeliveryResult,
  MaterialDemand,
  BatchOutcome,
  WorkerAssignment,
  ProductionModifier,
  CommandResult,
  Configuration,
  FacilitySnapshot,
  InventoryOptions,
  InventorySave,
  JobState,
  Quantities,
  RecipeDefinition,
  SimulationEvent,
  SimulationSnapshot,
} from './models.js';
import {
  Registry,
  DefinitionError,
  invariant,
  validateAttributes,
  cloneData,
} from './registry.js';
import { validateMetadata, validateModifiers } from './inventory-context.js';
import { resolveOutcome, producedQuantities } from './outcome.js';
import { Inventory } from './inventory.js';
interface Job {
  id: string;
  recipe: RecipeDefinition;
  durationTicks: number;
  elapsedTicks: number;
  deferredWork: number;
  optionalInputs: Record<string, number>;
  batchOptionalInputs: Record<string, number>;
  inputItemIds: string[];
  inputItemResources: Record<string, string>;
  batchInputItems: ProducedItem[];
  outcome: BatchOutcome | null;
  active: boolean;
  readySince: number | null;
  demandSince: number | null;
  demandOrder: number;
  completed: number;
  state: JobState;
}
type ProductionProvenance = Pick<
  Job,
  'id' | 'recipe' | 'completed' | 'outcome'
>;
interface Facility {
  id: string;
  definitionId: string;
  inventoryId: string;
  inputInventoryId: string;
  outputInventoryId: string;
  enabled: boolean;
  draining: boolean;
  conditions: Record<string, boolean>;
  attendance: Record<string, number>;
  attendanceReady: boolean;
  jobs: Job[];
  workerSlots: (WorkerAssignment | null)[];
  modifiers: Record<string, ProductionModifier>;
  rate: number;
}
export class Simulation {
  readonly registry: Registry;
  readonly #seed: number;
  readonly #individualResources: ReadonlySet<string>;
  readonly #individualInputRecipes: ReadonlySet<string>;
  readonly #inventories = new Map<string, Inventory>();
  readonly #inventoryAttachments = new Map<string, InventoryAttachment>();
  readonly #objectInventories = new Map<string, Map<string, string>>();
  readonly #facilities: Facility[] = [];
  readonly #retiredFacilities: RetiredFacilitySave[] = [];
  readonly #facilityIndex = new Map<string, Facility>();
  readonly #deliveries = new Map<string, DeliverySnapshot>();
  readonly #constructionOrders = new Map<string, ConstructionOrderSave>();
  readonly #pendingConstruction = new Map<string, ConstructionOrderSave>();
  #nextConstruction = 1;
  #nextDelivery = 1;
  #nextItem = 1;
  // Live job references, or compact counters after demolition; never per-item history.
  readonly #productionJobs = new Map<string, ProductionProvenance>();
  readonly #views = new Map<string, InventoryView>();
  readonly #incoming = new Map<string, Record<string, number>>();
  #tick = 0;
  #pendingMicroseconds = 0;
  #timeCompensation = 0;
  #nextId = 1;
  #demandOrder = 0;
  readonly #listeners = new Set<(event: SimulationEvent) => void>();
  #events: SimulationEvent[] = [];
  #mutating = false;
  #nextInventoryOperation = 1;
  #inventoryDirty = false;
  #inventoryPerChange = false;
  #inventoryEvents: InventoryEvent[] = [];
  #inventoryChanges: InventoryChange[] = [];
  #inventoryTargets: ((event: InventoryEvent) => void)[] = [];
  readonly #inventoryListeners = new Set<(event: InventoryEvent) => void>();
  #traceLimit = 0;
  #traceSequence = 0;
  #trace: DiagnosticEntry[] = [];
  constructor(config: Configuration) {
    this.registry = new Registry(config);
    Object.defineProperty(this, 'registry', {
      writable: false,
      configurable: false,
    });
    this.#seed = config.seed ?? 1;
    this.#individualInputRecipes = new Set(
      this.registry.recipes
        .filter((r) =>
          [
            ...Object.entries(r.inputs),
            ...Object.entries(r.optionalInputs ?? {}),
          ].some(
            ([id, n]) =>
              n > 0 && this.registry.resource(id).storage === 'individual',
          ),
        )
        .map((r) => r.id),
    );
    this.#individualResources = new Set(
      this.registry.resources
        .filter((r) => r.storage === 'individual')
        .map((r) => r.id),
    );
  }
  #markInventory(change: () => Omit<InventoryChange, 'tick'>): void {
    this.#inventoryDirty = true;
    if (this.#inventoryPerChange) {
      const sequence = this.#nextInventoryOperation++;
      if (this.#inventoryTargets.length)
        this.#inventoryEvents.push({
          type: 'inventory-committed',
          operationId: `inventory-operation-${sequence}`,
          sequence,
          command: 'simulation-tick',
          changes: [{ tick: this.#tick, ...cloneData(change()) }],
        });
    } else if (this.#inventoryTargets.length)
      this.#inventoryChanges.push({ tick: this.#tick, ...cloneData(change()) });
  }
  #observeInventory(inventory: Inventory): void {
    inventory.setReporter((change) => this.#markInventory(change));
  }
  /** Live committed feed, not a retained journal. Subscribe before a command. */
  onInventoryEvent(listener: (event: InventoryEvent) => void): () => void {
    this.#inventoryListeners.add(listener);
    return () => {
      this.#inventoryListeners.delete(listener);
    };
  }
  inventoryEventSequence(): number {
    return this.#nextInventoryOperation - 1;
  }
  #mutate<T>(command: string, action: () => T): T {
    invariant(
      !this.#mutating,
      'simulation commands cannot run inside an event observer',
    );
    invariant(
      this.#nextInventoryOperation < Number.MAX_SAFE_INTEGER,
      'inventory operation counter exhausted',
    );
    this.#mutating = true;
    this.#inventoryDirty = false;
    this.#inventoryPerChange =
      command === 'advance' || command === 'advanceTicks';
    this.#inventoryEvents = [];
    this.#inventoryChanges = [];
    this.#inventoryTargets = [...this.#inventoryListeners];
    const traceCommand = command !== 'advance' && command !== 'advanceTicks';
    if (traceCommand) this.#record('command', command, { phase: 'begin' });
    let result!: T;
    const errors: unknown[] = [];
    try {
      result = action();
      if (traceCommand) this.#record('command', command, { phase: 'returned' });
    } catch (error) {
      errors.push(error);
      this.#record('command', command, {
        phase: 'threw',
        message: error instanceof Error ? error.message : String(error),
      });
    }
    if (this.#inventoryDirty && !this.#inventoryPerChange) {
      const sequence = this.#nextInventoryOperation++;
      const event: InventoryEvent = {
        type: 'inventory-committed',
        operationId: `inventory-operation-${sequence}`,
        sequence,
        command,
        changes: this.#inventoryChanges,
      };
      this.#inventoryEvents.push(event);
    }
    for (const event of this.#inventoryEvents)
      for (const listener of this.#inventoryTargets)
        if (this.#inventoryListeners.has(listener)) {
          try {
            listener(Object.freeze(cloneData(event)));
          } catch (error) {
            errors.push(error);
          }
        }
    this.#inventoryEvents = [];
    this.#inventoryChanges = [];
    this.#inventoryTargets = [];
    this.#mutating = false;
    if (errors.length === 1) throw errors[0];
    if (errors.length)
      throw new AggregateError(
        errors,
        'Simulation observers failed after state committed',
      );
    return result;
  }
  createInventory(options: InventoryOptions): InventoryView {
    return this.#mutate('createInventory', () => {
      invariant(
        !this.#inventories.has(options.id),
        `duplicate inventory '${options.id}'`,
      );
      invariant(
        options.attachment === undefined ||
          (options.attachment !== null &&
            typeof options.attachment === 'object' &&
            !Array.isArray(options.attachment)),
        'invalid inventory attachment',
      );
      const attachment =
        options.attachment === undefined
          ? undefined
          : this.#attachment(
              options.id,
              options.attachment.objectId,
              options.attachment.slot === undefined
                ? 'main'
                : options.attachment.slot,
            );
      if (attachment) this.#checkAttachment(attachment);
      const inventory = new Inventory(this.registry, options);
      this.#inventories.set(options.id, inventory);
      const view = inventory.view();
      this.#views.set(inventory.id, view);
      if (attachment) this.#putAttachment(attachment);
      this.#observeInventory(inventory);
      if (Object.values(options.initial ?? {}).some((n) => n > 0))
        this.#markInventory(() => ({
          inventoryId: inventory.id,
          added: { quantities: { ...options.initial }, items: [] },
          removed: { quantities: {}, items: [] },
          updatedItems: [],
        }));
      return view;
    });
  }
  #attachment(
    inventoryId: string,
    objectId: string,
    slot: string,
  ): InventoryAttachment {
    invariant(
      typeof objectId === 'string' && objectId.length > 0,
      'invalid object ID',
    );
    invariant(
      typeof slot === 'string' && slot.length > 0,
      'invalid inventory slot',
    );
    return { inventoryId, objectId, slot };
  }
  #checkAttachment(a: InventoryAttachment): void {
    const previous = this.#inventoryAttachments.get(a.inventoryId);
    invariant(
      !previous ||
        (previous.objectId === a.objectId && previous.slot === a.slot),
      'inventory already attached; detach first',
    );
    const occupied = this.#objectInventories.get(a.objectId)?.get(a.slot);
    invariant(
      occupied === undefined || occupied === a.inventoryId,
      'object inventory slot occupied',
    );
  }
  #putAttachment(a: InventoryAttachment): void {
    this.#inventoryAttachments.set(a.inventoryId, a);
    let slots = this.#objectInventories.get(a.objectId);
    if (!slots) {
      slots = new Map();
      this.#objectInventories.set(a.objectId, slots);
    }
    slots.set(a.slot, a.inventoryId);
  }
  attachInventory(inventoryId: string, objectId: string, slot = 'main'): void {
    this.#mutate('attachInventory', () => {
      this.#ownedInventory(inventoryId);
      const a = this.#attachment(inventoryId, objectId, slot);
      this.#checkAttachment(a);
      this.#putAttachment(a);
    });
  }
  /** Remove only the association, preserving every good, reservation and live reference. */
  detachInventory(inventoryId: string): InventoryAttachment | null {
    return this.#mutate('detachInventory', () => {
      this.#ownedInventory(inventoryId);
      const a = this.#inventoryAttachments.get(inventoryId);
      if (!a) return null;
      const slots = this.#objectInventories.get(a.objectId)!;
      slots.delete(a.slot);
      if (!slots.size) this.#objectInventories.delete(a.objectId);
      this.#inventoryAttachments.delete(inventoryId);
      return { ...a };
    });
  }
  inventoryAttachment(inventoryId: string): InventoryAttachment | null {
    this.#ownedInventory(inventoryId);
    const a = this.#inventoryAttachments.get(inventoryId);
    return a ? { ...a } : null;
  }
  objectInventories(objectId: string): InventoryAttachment[] {
    this.#attachment('', objectId, 'main');
    return [...(this.#objectInventories.get(objectId)?.values() ?? [])].map(
      (id) => ({ ...this.#inventoryAttachments.get(id)! }),
    );
  }
  objectInventory(objectId: string, slot = 'main'): InventoryView | undefined {
    this.#attachment('', objectId, slot);
    const id = this.#objectInventories.get(objectId)?.get(slot);
    return id === undefined ? undefined : this.inventory(id);
  }
  setInventoryCapacity(
    inventoryId: string,
    capacity: InventoryCapacity,
  ): boolean {
    return this.#mutate('setInventoryCapacity', () =>
      this.#ownedInventory(inventoryId).setCapacity(capacity),
    );
  }
  setInventoryRules(inventoryId: string, rules: InventoryRules): boolean {
    return this.#mutate('setInventoryRules', () =>
      this.#ownedInventory(inventoryId).setRules(rules),
    );
  }
  setInventoryModifiers(
    inventoryId: string,
    modifiers: InventoryModifiers,
  ): void {
    this.#mutate('setInventoryModifiers', () =>
      this.#ownedInventory(inventoryId).setModifiers(modifiers),
    );
  }
  setInventoryMetadata(inventoryId: string, metadata: InventoryMetadata): void {
    this.#mutate('setInventoryMetadata', () =>
      this.#ownedInventory(inventoryId).setMetadata(metadata),
    );
  }
  /** Atomic equip/swap: an existing occupant goes back to the source inventory. */
  equipItem(
    sourceInventoryId: string,
    equipmentInventoryId: string,
    itemId: string,
  ): InventoryTransactionResult {
    const equipment = this.#ownedInventory(equipmentInventoryId);
    invariant(
      equipment.isEquipmentSlot(),
      'destination is not an equipment slot',
    );
    const occupant = equipment.itemPage({ limit: 1 }).items[0];
    return this.exchange([
      {
        sourceInventoryId,
        destinationInventoryId: equipmentInventoryId,
        itemIds: [itemId],
      },
      ...(occupant === undefined
        ? []
        : [
            {
              sourceInventoryId: equipmentInventoryId,
              destinationInventoryId: sourceInventoryId,
              itemIds: [occupant.id],
            },
          ]),
    ]);
  }
  unequipItem(
    equipmentInventoryId: string,
    destinationInventoryId: string,
  ): InventoryTransactionResult {
    const equipment = this.#ownedInventory(equipmentInventoryId);
    invariant(equipment.isEquipmentSlot(), 'source is not an equipment slot');
    return this.exchange([
      {
        sourceInventoryId: equipmentInventoryId,
        destinationInventoryId,
        itemIds: equipment.itemPage({ limit: 1 }).items.map((i) => i.id),
      },
    ]);
  }
  /** Simultaneous mixed transfers: all sources must own their outgoing goods before the exchange. */
  exchange(
    transfers: readonly InventoryTransfer[],
  ): InventoryTransactionResult {
    return this.#mutate('exchange', () => {
      invariant(
        Array.isArray(transfers as unknown) &&
          transfers.length > 0 &&
          transfers.length <= 256,
        'exchange requires 1 to 256 transfers',
      );
      const plans = new Map<
        string,
        { bulk: Record<string, number>; itemIds: string[]; added: BatchOutcome }
      >();
      const plan = (id: string) => {
        this.#ownedInventory(id);
        let p = plans.get(id);
        if (!p) {
          p = { bulk: {}, itemIds: [], added: { quantities: {}, items: [] } };
          plans.set(id, p);
        }
        return p;
      };
      const moved = new Set<string>();
      const add = (values: Record<string, number>, id: string, n: number) => {
        const total = (values[id] ?? 0) + n;
        invariant(Number.isSafeInteger(total), 'exchange quantity overflow');
        values[id] = total;
      };
      for (const transfer of transfers as readonly InventoryTransfer[]) {
        const source = this.#ownedInventory(transfer.sourceInventoryId);
        invariant(
          transfer.sourceInventoryId !== transfer.destinationInventoryId,
          'exchange endpoints must differ',
        );
        const out = plan(source.id),
          into = plan(transfer.destinationInventoryId);
        const bulk = transfer.quantities ?? {},
          ids = transfer.itemIds ?? [];
        this.registry.validate(bulk, 'exchange quantities');
        invariant(
          Array.isArray(ids as unknown) && ids.length <= 256,
          'invalid exchange item list',
        );
        for (const [id, n] of Object.entries(bulk)) {
          invariant(
            n === 0 || this.registry.resource(id).storage !== 'individual',
            'individual exchange needs item IDs',
          );
          add(out.bulk, id, n);
          add(into.added.quantities, id, n);
        }
        for (const id of ids) {
          invariant(
            typeof id === 'string' && !moved.has(id),
            'duplicate or invalid exchange item',
          );
          moved.add(id);
          const item = source.item(id);
          if (!item)
            return { ok: false, reason: 'unavailable', inventoryId: source.id };
          out.itemIds.push(id);
          into.added.items.push(item);
          add(into.added.quantities, item.resourceId, 1);
        }
      }
      const commits: (() => void)[] = [];
      for (const [id, p] of plans) {
        const prepared = this.#ownedInventory(id).prepareChange(
          p.bulk,
          p.itemIds,
          p.added,
        );
        if (!prepared.ok)
          return { ok: false, reason: prepared.reason, inventoryId: id };
        commits.push(prepared.commit);
      }
      const operationId = `inventory-operation-${this.#nextInventoryOperation}`;
      for (const commit of commits) commit();
      return {
        ok: true,
        operationId: this.#inventoryDirty ? operationId : null,
        createdItemIds: [],
      };
    });
  }
  /** Game-authorized consumption/creation/attribute changes, committed as one inventory operation. */
  mutateInventory(mutation: InventoryMutation): InventoryTransactionResult {
    return this.#mutate('mutateInventory', () => {
      const inventory = this.#ownedInventory(mutation.inventoryId);
      const produce = mutation.produce ?? {},
        create = mutation.createItems ?? [],
        updates = mutation.updateItems ?? [];
      this.registry.validate(produce, 'mutation production');
      invariant(
        Array.isArray(create as unknown) &&
          create.length <= 256 &&
          Array.isArray(updates as unknown) &&
          updates.length <= 256,
        'invalid mutation item list',
      );
      invariant(
        Number.isSafeInteger(this.#nextItem + create.length) &&
          this.#nextItem + create.length <= Number.MAX_SAFE_INTEGER,
        'item ID counter exhausted',
      );
      for (const [id, n] of Object.entries(produce))
        invariant(
          n === 0 || this.registry.resource(id).storage !== 'individual',
          'individual production needs createItems',
        );
      const added: BatchOutcome = { quantities: { ...produce }, items: [] };
      for (const [index, item] of create.entries()) {
        validateAttributes(item.attributes);
        const n = (added.quantities[item.resourceId] ?? 0) + 1;
        invariant(Number.isSafeInteger(n), 'mutation quantity overflow');
        added.quantities[item.resourceId] = n;
        added.items.push({
          id: `external-${this.#nextItem + index}`,
          resourceId: item.resourceId,
          attributes: { ...item.attributes },
        });
      }
      const prepared = inventory.prepareChange(
        mutation.consume ?? {},
        mutation.consumeItemIds ?? [],
        added,
        updates,
      );
      if (!prepared.ok)
        return {
          ok: false,
          reason: prepared.reason,
          inventoryId: inventory.id,
        };
      const operationId = `inventory-operation-${this.#nextInventoryOperation}`;
      prepared.commit();
      this.#nextItem += create.length;
      return {
        ok: true,
        operationId: this.#inventoryDirty ? operationId : null,
        createdItemIds: added.items.map((i) => i.id),
      };
    });
  }
  /** Final cleanup only: no goods destruction, cancellation or producer demolition. */
  inventoryRemovalBlockers(id: string): InventoryRemovalBlocker[] {
    const inventory = this.#inventories.get(id);
    if (!inventory) return [{ code: 'unknown-inventory' }];
    const summary = inventory.summary(),
      blockers: InventoryRemovalBlocker[] = [];
    const attachment = this.#inventoryAttachments.get(id);
    if (attachment)
      blockers.push({
        code: 'object-attachment',
        objectId: attachment.objectId,
        slot: attachment.slot,
      });
    for (const [resourceId, quantity] of Object.entries(summary.quantities))
      if (quantity > 0) blockers.push({ code: 'goods', resourceId, quantity });
    for (const token of inventory.reservationTokens())
      blockers.push({ code: 'reservation', token });
    for (const [workerId, people] of Object.entries(summary.workforce))
      if (people.total > 0 || people.assigned > 0)
        blockers.push({ code: 'workforce', workerId, ...people });
    for (const f of this.#facilities) {
      const roles: ('construction' | 'input' | 'output')[] = [];
      if (f.inventoryId === id) roles.push('construction');
      if (f.inputInventoryId === id) roles.push('input');
      if (f.outputInventoryId === id) roles.push('output');
      if (roles.length)
        blockers.push({ code: 'facility-reference', facilityId: f.id, roles });
    }
    for (const order of this.#pendingConstruction.values()) {
      const roles: ('site' | 'input' | 'output')[] = [];
      if (order.inventoryId === id) roles.push('site');
      if (order.inputInventoryId === id) roles.push('input');
      if (order.outputInventoryId === id) roles.push('output');
      if (roles.length)
        blockers.push({
          code: 'construction-reference',
          orderId: order.id,
          roles,
        });
    }
    for (const d of this.#deliveries.values())
      if (
        (d.state === 'reserved' ||
          d.state === 'in-transit' ||
          d.state === 'arrival-blocked') &&
        (d.sourceInventoryId === id || d.destinationInventoryId === id)
      )
        blockers.push({
          code: 'active-delivery',
          deliveryId: d.id,
          state: d.state,
          role: d.sourceInventoryId === id ? 'source' : 'destination',
        });
    return blockers;
  }
  removeInventory(id: string): InventoryRemovalResult {
    // Refusal is a read-only preflight, including traces; keep the usual observer guard.
    invariant(
      !this.#mutating,
      'simulation commands cannot run inside an event observer',
    );
    const blockers = this.inventoryRemovalBlockers(id);
    if (blockers.length) return { ok: false, blockers };
    return this.#mutate('removeInventory', () => {
      const prunedDeliveryIds: string[] = [];
      for (const [deliveryId, d] of this.#deliveries)
        if (d.sourceInventoryId === id || d.destinationInventoryId === id) {
          // All active references were rejected; remaining manifests are terminal history.
          this.#deliveries.delete(deliveryId);
          prunedDeliveryIds.push(deliveryId);
        }
      this.#incoming.delete(id);
      this.#views.delete(id);
      this.#inventories.delete(id);
      return { ok: true, inventoryId: id, prunedDeliveryIds };
    });
  }
  inventory(id: string): InventoryView {
    this.#ownedInventory(id);
    return this.#views.get(id)!;
  }
  #ownedInventory(id: string): Inventory {
    const i = this.#inventories.get(id);
    invariant(i, `unknown inventory '${id}'`);
    return i;
  }
  deposit(inventoryId: string, values: Quantities): boolean {
    return this.#mutate('deposit', () =>
      this.#ownedInventory(inventoryId).deposit(values),
    );
  }
  withdraw(inventoryId: string, values: Quantities): boolean {
    return this.#mutate('withdraw', () =>
      this.#ownedInventory(inventoryId).withdraw(values),
    );
  }
  transfer(
    sourceId: string,
    destinationId: string,
    values: Quantities,
  ): boolean {
    return this.#mutate('transfer', () =>
      this.#ownedInventory(sourceId).transferTo(
        this.#ownedInventory(destinationId),
        values,
      ),
    );
  }
  transferItem(
    sourceId: string,
    destinationId: string,
    itemId: string,
  ): boolean {
    return this.#mutate('transferItem', () =>
      this.#ownedInventory(sourceId).transferItemTo(
        this.#ownedInventory(destinationId),
        itemId,
      ),
    );
  }
  updateItemAttributes(
    inventoryId: string,
    itemId: string,
    patch: Readonly<Record<string, number>>,
  ): void {
    this.#mutate('updateItemAttributes', () =>
      this.#ownedInventory(inventoryId).updateItemAttributes(itemId, patch),
    );
  }
  increaseCapacity(inventoryId: string, amount: number): void {
    this.#mutate('increaseCapacity', () =>
      this.#ownedInventory(inventoryId).increaseCapacity(amount),
    );
  }
  /** Framework-owned monotonic identity. Never an import of existing goods. */
  spawnItem(
    inventoryId: string,
    resourceId: string,
    attributes: Readonly<Record<string, number>>,
  ): string | null {
    return this.#mutate('spawnItem', () => {
      invariant(
        arguments.length === 3,
        'spawnItem identities are framework-owned',
      );
      invariant(
        this.#nextItem < Number.MAX_SAFE_INTEGER,
        'item ID counter exhausted',
      );
      const itemId = `external-${this.#nextItem}`;
      const i = this.#ownedInventory(inventoryId);
      if (
        !i.depositOutcome({
          quantities: { [resourceId]: 1 },
          items: [{ id: itemId, resourceId, attributes: { ...attributes } }],
        })
      )
        return null;
      this.#nextItem++;
      return itemId;
    });
  }
  consumeItem(inventoryId: string, itemId: string): boolean {
    return this.#mutate('consumeItem', () => {
      const i = this.#ownedInventory(inventoryId);
      invariant(i.item(itemId), `unknown item '${itemId}'`);
      const token = `consume:${itemId}`;
      if (!i.reserveCargo(token, {}, [itemId])) return false;
      i.commit(token);
      return true;
    });
  }
  constructionBlockers(
    definitionId: string,
    inventoryId: string,
  ): { materials: Record<string, number>; workers: Record<string, number> } {
    const d = this.registry.facility(definitionId),
      i = this.#ownedInventory(inventoryId);
    return {
      materials: i.missing(d.constructionCost),
      workers: i.workforceMissing(
        d.workersRequired ?? {},
        d.workersProvided ?? {},
      ),
    };
  }
  addFacility(
    definitionId: string,
    inventoryId: string,
    options: FacilityInventoryOptions = {},
  ): CommandResult {
    return this.#mutate('addFacility', () => {
      const result = this.#activateFacility(definitionId, inventoryId, options);
      this.#notify();
      return result;
    });
  }
  #activateFacility(
    definitionId: string,
    inventoryId: string,
    options: FacilityInventoryOptions,
    token?: string,
  ): CommandResult {
    invariant(
      this.#nextId < Number.MAX_SAFE_INTEGER,
      'facility ID counter exhausted',
    );
    const d = this.registry.facility(definitionId),
      i = this.#ownedInventory(inventoryId),
      missing = {
        materials: token ? {} : i.missing(d.constructionCost),
        workers: i.workforceMissing(
          d.workersRequired ?? {},
          d.workersProvided ?? {},
        ),
      };
    if (
      Object.keys(missing.materials).length ||
      Object.keys(missing.workers).length
    )
      return {
        ok: false,
        reason: 'Insufficient construction resources or workforce',
      };
    this.#ownedInventory(options.inputInventoryId ?? inventoryId);
    this.#ownedInventory(options.outputInventoryId ?? inventoryId);
    // Validate all construction effects before charging any resources.
    const current = i.summary();
    invariant(
      Number.isSafeInteger(
        current.capacityPerMaterial + (d.capacityProvided ?? 0),
      ),
      'construction capacity exceeds safe integer range',
    );
    for (const workerId of new Set([
      ...Object.keys(d.workersProvided ?? {}),
      ...Object.keys(d.workersRequired ?? {}),
    ])) {
      const workers = current.workforce[workerId] ?? {
        total: 0,
        assigned: 0,
      };
      invariant(
        Number.isSafeInteger(
          workers.total + (d.workersProvided?.[workerId] ?? 0),
        ) &&
          Number.isSafeInteger(
            workers.assigned + (d.workersRequired?.[workerId] ?? 0),
          ),
        'construction workforce exceeds safe integer range',
      );
    }
    if (token) i.commit(token);
    else i.withdraw(d.constructionCost);
    i.applyFacility(
      d.workersProvided ?? {},
      d.workersRequired ?? {},
      d.capacityProvided ?? 0,
    );
    const id = `facility-${this.#nextId++}`;
    const jobs = d.recipes.map((recipeId, index): Job => {
      const recipe = this.registry.recipe(recipeId);
      return {
        id: `${id}.job-${index}`,
        recipe,
        durationTicks:
          (recipe.durationSeconds * 1e6) / this.registry.tickMicroseconds,
        elapsedTicks: 0,
        deferredWork: 0,
        optionalInputs: {},
        batchOptionalInputs: {},
        inputItemIds: [],
        inputItemResources: {},
        batchInputItems: [],
        outcome: null,
        active: false,
        readySince: null,
        demandSince: null,
        demandOrder: 0,
        completed: 0,
        state: 'waiting-inputs',
      };
    });
    const requiredCount = Object.values(d.workersRequired ?? {}).reduce(
      (a, b) => a + b,
      0,
    );
    const slotCount = d.workerSlots; // Resolved once when the definition is registered.
    const facility: Facility = {
      id,
      definitionId,
      inventoryId,
      inputInventoryId: options.inputInventoryId ?? inventoryId,
      outputInventoryId: options.outputInventoryId ?? inventoryId,
      enabled: true,
      attendance: {},
      attendanceReady: Object.values(d.workersRequired ?? {}).every(
        (n) => n === 0,
      ),
      draining: false,
      workerSlots: Array.from(
        {
          length: slotCount,
        },
        (_, slot) =>
          slot < requiredCount
            ? { id: `${id}.worker-${slot}`, efficiency: 1 }
            : null,
      ),
      modifiers: {},
      rate: requiredCount > 0 ? 0 : slotCount > 0 ? 0 : 1,
      conditions: Object.fromEntries(
        (d.operatingConditions ?? []).map((id) => [id, false]),
      ),
      jobs,
    };
    this.#facilities.push(facility);
    this.#facilityIndex.set(id, facility);
    for (const j of jobs) this.#productionJobs.set(j.id, j);
    this.#queue({ type: 'facility-built', tick: this.#tick, facilityId: id });
    return { ok: true, facilityId: id };
  }
  createConstructionOrder(
    definitionId: string,
    inventoryId: string,
    options: ConstructionOptions,
  ): string {
    return this.#mutate('createConstructionOrder', () => {
      this.registry.facility(definitionId);
      this.#ownedInventory(inventoryId);
      const inputInventoryId = options.inputInventoryId ?? inventoryId,
        outputInventoryId = options.outputInventoryId ?? inventoryId;
      this.#ownedInventory(inputInventoryId);
      this.#ownedInventory(outputInventoryId);
      const durationMicroseconds = options.durationSeconds * 1e6;
      invariant(
        Number.isSafeInteger(durationMicroseconds) && durationMicroseconds > 0,
        'invalid construction duration',
      );
      invariant(
        this.#nextConstruction < Number.MAX_SAFE_INTEGER,
        'construction ID counter exhausted',
      );
      const id = `construction-${this.#nextConstruction++}`;
      this.#constructionOrders.set(id, {
        id,
        definitionId,
        inventoryId,
        inputInventoryId,
        outputInventoryId,
        durationMicroseconds,
        elapsedMicroseconds: 0,
        state: 'waiting-materials',
        facilityId: null,
        consumedMaterials: {},
      });
      this.#pendingConstruction.set(id, this.#constructionOrders.get(id)!);
      this.#queue({
        type: 'construction-created',
        tick: this.#tick,
        orderId: id,
        facilityId: null,
      });
      this.#notify();
      return id;
    });
  }
  #construction(id: string): ConstructionOrderSave {
    const order = this.#constructionOrders.get(id);
    invariant(order, `unknown construction order '${id}'`);
    return order;
  }
  #activationBlockers(o: ConstructionOrderSave): ConstructionBlocker[] {
    const d = this.registry.facility(o.definitionId),
      i = this.#ownedInventory(o.inventoryId),
      current = i.summary(),
      blocks: ConstructionBlocker[] = [];
    const workers = i.workforceMissing(
      d.workersRequired ?? {},
      d.workersProvided ?? {},
    );
    if (Object.keys(workers).length)
      blocks.push({ code: 'workforce', quantities: workers });
    if (
      !Number.isSafeInteger(
        current.capacityPerMaterial + (d.capacityProvided ?? 0),
      )
    )
      blocks.push({ code: 'capacity-overflow' });
    for (const type of new Set([
      ...Object.keys(d.workersRequired ?? {}),
      ...Object.keys(d.workersProvided ?? {}),
    ])) {
      const p = current.workforce[type] ?? { total: 0, assigned: 0 };
      if (
        !Number.isSafeInteger(p.total + (d.workersProvided?.[type] ?? 0)) ||
        !Number.isSafeInteger(p.assigned + (d.workersRequired?.[type] ?? 0))
      ) {
        blocks.push({ code: 'workforce-overflow' });
        break;
      }
    }
    if (this.#nextId >= Number.MAX_SAFE_INTEGER)
      blocks.push({ code: 'facility-id-exhausted' });
    return blocks;
  }
  constructionOrderIds(): string[] {
    return [...this.#constructionOrders.keys()];
  }
  constructionOrderSnapshot(id: string): ConstructionOrderSnapshot {
    const o = this.#construction(id),
      terminal = o.state === 'completed' || o.state === 'cancelled';
    const reserved = terminal
      ? {}
      : { ...this.#ownedInventory(o.inventoryId).reservation(o.id) };
    const missing: Record<string, number> = {},
      blocks: ConstructionBlocker[] = [];
    if (!terminal) {
      const d = this.registry.facility(o.definitionId),
        i = this.#ownedInventory(o.inventoryId);
      for (const [resource, n] of Object.entries(d.constructionCost)) {
        const lack = Math.max(
          0,
          n - (reserved[resource] ?? 0) - i.available(resource),
        );
        if (lack) missing[resource] = lack;
        if (
          this.registry.resource(resource).kind === 'material' &&
          n > i.capacityPerMaterial
        )
          blocks.push({
            code: 'material-capacity',
            resourceId: resource,
            required: n,
            capacity: i.capacityPerMaterial,
          });
      }
      if (Object.keys(missing).length)
        blocks.push({ code: 'materials', quantities: { ...missing } });
      if (o.state === 'awaiting-activation')
        blocks.push(...this.#activationBlockers(o));
    }
    return {
      ...cloneData(o),
      progress: o.elapsedMicroseconds / o.durationMicroseconds,
      reservedMaterials: reserved,
      missingMaterials: missing,
      incomingMaterials: terminal
        ? {}
        : { ...this.#incoming.get(o.inventoryId) },
      blockers: blocks,
    };
  }
  constructionDemands(): {
    orderId: string;
    inventoryId: string;
    quantities: Record<string, number>;
  }[] {
    const free = new Map<string, Record<string, number>>(),
      result: {
        orderId: string;
        inventoryId: string;
        quantities: Record<string, number>;
      }[] = [];
    for (const o of this.#pendingConstruction.values()) {
      const inventory = this.#ownedInventory(o.inventoryId);
      let available = free.get(o.inventoryId);
      if (!available) {
        available = Object.fromEntries(
          this.registry.resources.map((r) => [r.id, inventory.available(r.id)]),
        );
        free.set(o.inventoryId, available);
      }
      const held = inventory.reservation(o.id),
        quantities: Record<string, number> = {};
      for (const [id, n] of Object.entries(
        this.registry.facility(o.definitionId).constructionCost,
      )) {
        const need = Math.max(0, n - (held[id] ?? 0)),
          covered = Math.min(need, available[id] ?? 0);
        available[id] = (available[id] ?? 0) - covered;
        if (need > covered) quantities[id] = need - covered;
      }
      if (Object.keys(quantities).length)
        result.push({ orderId: o.id, inventoryId: o.inventoryId, quantities });
    }
    return result;
  }
  cancelConstructionOrder(id: string): ConstructionCancellationResult {
    return this.#mutate('cancelConstructionOrder', () => {
      const o = this.#construction(id);
      if (o.state === 'completed' || o.state === 'cancelled')
        return { ok: false, reason: 'terminal-order' };
      const i = this.#ownedInventory(o.inventoryId),
        releasedMaterials = { ...i.reservation(o.id) };
      if (i.hasReservation(o.id)) i.release(o.id);
      o.state = 'cancelled';
      this.#pendingConstruction.delete(id);
      this.#queue({
        type: 'construction-cancelled',
        tick: this.#tick,
        orderId: id,
        facilityId: null,
      });
      this.#notify();
      return {
        ok: true,
        orderId: id,
        releasedMaterials,
        consumedMaterials: {},
      };
    });
  }
  pruneConstructionOrders(): number {
    return this.#mutate('pruneConstructionOrders', () => {
      let count = 0;
      for (const [id, o] of this.#constructionOrders)
        if (o.state === 'completed' || o.state === 'cancelled') {
          this.#constructionOrders.delete(id);
          count++;
        }
      return count;
    });
  }
  #advanceConstruction(): void {
    for (const o of this.#pendingConstruction.values()) {
      if (o.state === 'completed' || o.state === 'cancelled') continue;
      const d = this.registry.facility(o.definitionId),
        i = this.#ownedInventory(o.inventoryId);
      if (o.state === 'waiting-materials') {
        if (
          Object.entries(d.constructionCost).some(
            ([resource, n]) =>
              this.registry.resource(resource).kind === 'material' &&
              n > i.capacityPerMaterial,
          )
        )
          continue;
        i.allocate(o.id, d.constructionCost);
        if (!sameQuantities(i.reservation(o.id), d.constructionCost)) continue;
        o.state = 'building';
      }
      o.elapsedMicroseconds = Math.min(
        o.durationMicroseconds,
        o.elapsedMicroseconds + this.registry.tickMicroseconds,
      );
      if (o.elapsedMicroseconds < o.durationMicroseconds) continue;
      o.state = 'awaiting-activation';
      if (this.#activationBlockers(o).length) continue;
      const result = this.#activateFacility(
        o.definitionId,
        o.inventoryId,
        {
          inputInventoryId: o.inputInventoryId,
          outputInventoryId: o.outputInventoryId,
        },
        o.id,
      );
      invariant(result.ok, 'construction activation preflight mismatch');
      o.consumedMaterials = { ...d.constructionCost };
      o.facilityId = result.facilityId;
      o.state = 'completed';
      this.#pendingConstruction.delete(o.id);
      this.#queue({
        type: 'construction-completed',
        tick: this.#tick,
        orderId: o.id,
        facilityId: result.facilityId,
      });
    }
  }
  #facility(id: string): Facility {
    const f = this.#facilityIndex.get(id);
    invariant(f, `unknown facility '${id}'`);
    return f;
  }
  #missingAttendance(f: Facility): Record<string, number> {
    const required = this.registry.facility(f.definitionId).minimumWorkforce;
    return Object.fromEntries(
      Object.entries(required).flatMap(([type, count]) => {
        const missing = count - (f.attendance[type] ?? 0);
        return missing > 0 ? [[type, missing]] : [];
      }),
    );
  }
  setFacilityAttendance(id: string, present: Quantities): void {
    this.#mutate('setFacilityAttendance', () => {
      const f = this.#facility(id),
        required = this.registry.facility(f.definitionId).workersRequired ?? {};
      invariant(
        present !== null &&
          typeof present === 'object' &&
          !Array.isArray(present),
        'invalid attendance',
      );
      for (const [type, count] of Object.entries(present))
        invariant(
          Object.hasOwn(required, type) &&
            Number.isSafeInteger(count) &&
            count >= 0 &&
            count <= required[type]!,
          'invalid attendance count or type',
        );
      const previous = f.attendance,
        previousReady = f.attendanceReady;
      f.attendance = { ...present };
      f.attendanceReady = this.#attendanceSatisfied(f);
      const rate = this.#calculateProductivity(f);
      if (!Number.isFinite(rate) || rate > 1e6) {
        f.attendance = previous;
        f.attendanceReady = previousReady;
        invariant(false, 'productivity overflow');
      }
      f.rate = rate;
      if (!f.attendanceReady)
        for (const j of f.jobs) {
          this.#releaseDemand(f, j);
          j.state = f.enabled ? 'waiting-workers' : 'paused';
        }
    });
  }
  #attendanceSatisfied(f: Facility): boolean {
    const d = this.registry.facility(f.definitionId);
    const attended = Object.values(f.attendance).reduce((sum, n) => sum + n, 0);
    return (
      (!Object.values(d.workersRequired ?? {}).some((n) => n > 0) ||
        attended > 0) &&
      Object.entries(d.minimumWorkforce).every(
        ([type, n]) => (f.attendance[type] ?? 0) >= n,
      )
    );
  }
  #baseProductivity(f: Facility): number {
    const base = f.workerSlots.length
      ? f.workerSlots.reduce((n, w) => n + (w?.efficiency ?? 0), 0) /
        f.workerSlots.length
      : 1;
    if (
      !Object.values(
        this.registry.facility(f.definitionId).workersRequired ?? {},
      ).some((n) => n > 0)
    )
      return base;
    const attended = Object.values(f.attendance).reduce((sum, n) => sum + n, 0),
      occupied = f.workerSlots.filter(Boolean).length;
    return (
      base *
      (occupied
        ? Math.min(1, attended / occupied)
        : f.workerSlots.length
          ? 0
          : attended > 0
            ? 1
            : 0)
    );
  }
  #calculateProductivity(f: Facility): number {
    return f.attendanceReady
      ? Object.values(f.modifiers).reduce(
          (n, m) => n * (m.productivityMultiplier ?? 1),
          this.#baseProductivity(f),
        )
      : 0;
  }
  setWorkerSlot(
    id: string,
    slot: number,
    worker: WorkerAssignment | null,
  ): void {
    this.#mutate('setWorkerSlot', () => {
      const f = this.#facility(id);
      invariant(
        Number.isInteger(slot) && slot >= 0 && slot < f.workerSlots.length,
        'invalid worker slot',
      );
      if (worker) {
        invariant(
          typeof worker.id === 'string' &&
            worker.id.length > 0 &&
            Number.isFinite(worker.efficiency) &&
            worker.efficiency >= 0 &&
            worker.efficiency <= 100,
          'invalid worker',
        );
        invariant(
          !worker.id.startsWith('facility-') ||
            worker.id === `${f.id}.worker-${slot}`,
          'generated worker identity cannot be assigned to another slot',
        );
        invariant(
          !this.#facilities.some((other) =>
            other.workerSlots.some(
              (w, index) =>
                w?.id === worker.id && (other !== f || index !== slot),
            ),
          ),
          'worker already assigned',
        );
      }
      const previous = f.workerSlots[slot]!;
      f.workerSlots[slot] = worker ? { ...worker } : null;
      const rate = this.#calculateProductivity(f);
      if (!Number.isFinite(rate) || rate > 1e6) {
        f.workerSlots[slot] = previous;
        invariant(false, 'productivity overflow');
      }
      f.rate = rate;
      if (rate === 0) for (const j of f.jobs) this.#releaseDemand(f, j);
    });
  }
  setProductionModifier(
    id: string,
    source: string,
    modifier: ProductionModifier | null,
  ): void {
    this.#mutate('setProductionModifier', () => {
      const f = this.#facility(id);
      invariant(
        typeof source === 'string' &&
          source.length > 0 &&
          !['__proto__', 'constructor', 'prototype'].includes(source),
        'invalid modifier source',
      );
      if (modifier === null) {
        const previous = f.modifiers[source];
        delete f.modifiers[source];
        const rate = this.#calculateProductivity(f);
        if (!Number.isFinite(rate) || rate > 1e6) {
          if (previous) f.modifiers[source] = previous;
          invariant(false, 'productivity overflow');
        }
        f.rate = rate;
        if (rate === 0) for (const j of f.jobs) this.#releaseDemand(f, j);
        return;
      }
      const value = modifier.productivityMultiplier ?? 1;
      invariant(
        Number.isFinite(value) && value >= 0 && value <= 100,
        'invalid productivity multiplier',
      );
      validateAttributes(modifier.attributeBonuses ?? {}, 1e12);
      const previous = f.modifiers[source];
      f.modifiers[source] = cloneData(modifier);
      const rate = this.#calculateProductivity(f);
      if (!Number.isFinite(rate) || rate > 1e6) {
        if (previous) f.modifiers[source] = previous;
        else delete f.modifiers[source];
        invariant(false, 'productivity overflow');
      }
      f.rate = rate;
      if (rate === 0) for (const j of f.jobs) this.#releaseDemand(f, j);
    });
  }
  /** Select only declared optional ingredients, for the NEXT batch. */
  setOptionalInputs(
    facilityId: string,
    recipeId: string,
    inputs: Quantities,
  ): void {
    this.#mutate('setOptionalInputs', () => {
      const j = this.#facility(facilityId).jobs.find(
        (j) => j.recipe.id === recipeId,
      );
      invariant(j, 'recipe is not available at facility');
      this.registry.validate(inputs, 'optional inputs selection');
      for (const [id, n] of Object.entries(inputs))
        invariant(
          n === 0 || n === j.recipe.optionalInputs?.[id],
          'select declared ingredient quantity or zero',
        );
      if (sameQuantities(j.optionalInputs, inputs)) return;
      this.#releaseDemand(this.#facility(facilityId), j);
      j.optionalInputs = { ...inputs };
      j.inputItemIds = [];
      j.inputItemResources = {};
    });
  }
  /** One-shot next-batch selection. Selection is a request, not an immediate reservation. */
  setInputItems(
    facilityId: string,
    recipeId: string,
    itemIds: readonly string[],
  ): void {
    this.#mutate('setInputItems', () => {
      const f = this.#facility(facilityId),
        j = f.jobs.find((j) => j.recipe.id === recipeId);
      invariant(j, 'recipe is not available at facility');
      invariant(
        Array.isArray(itemIds as unknown) &&
          itemIds.every((id) => typeof id === 'string' && id.length > 0) &&
          new Set(itemIds).size === itemIds.length,
        'invalid or duplicate input item IDs',
      );
      const counts: Record<string, number> = Object.create(null) as Record<
        string,
        never
      >;
      const resources: Record<string, string> = Object.create(null) as Record<
        string,
        never
      >;
      for (const id of itemIds) {
        const item = this.#ownedInventory(f.inputInventoryId).item(id);
        invariant(
          item,
          `selected input item '${id}' is not in the input inventory`,
        );
        counts[item.resourceId] = (counts[item.resourceId] ?? 0) + 1;
        resources[id] = item.resourceId;
      }
      if (itemIds.length)
        invariant(
          sameQuantities(counts, this.#individualInputs(j)),
          'select exactly the required individual input quantities',
        );
      const previousIds = new Set(j.inputItemIds);
      if (
        previousIds.size === itemIds.length &&
        itemIds.every((id) => previousIds.has(id))
      )
        return;
      this.#releaseDemand(f, j);
      j.inputItemIds = [...itemIds];
      j.inputItemResources = resources;
    });
  }
  #individualInputs(j: Job): Record<string, number> {
    if (!this.#individualInputRecipes.has(j.recipe.id)) return {};
    return Object.fromEntries(
      Object.entries(this.#inputs(j)).filter(
        ([id, n]) => n > 0 && this.#individualResources.has(id),
      ),
    );
  }
  #missingInputs(f: Facility, j: Job): Record<string, number> {
    const input = this.#ownedInventory(f.inputInventoryId),
      held = input.reservation(j.id);
    const selected = j.inputItemIds.length
      ? input.availableSelectedItems(j.inputItemIds, j.id)
      : {};
    return Object.fromEntries(
      Object.entries(this.#inputs(j)).flatMap(([id, n]) => {
        const available = this.#individualResources.has(id)
          ? (selected[id] ?? 0)
          : (held[id] ?? 0) + input.available(id);
        const missing = Math.max(0, n - available);
        return missing ? [[id, missing]] : [];
      }),
    );
  }
  /** Drain permits existing work/publication but prevents all new starts. */
  setFacilityDraining(id: string, draining: boolean): void {
    this.#mutate('setFacilityDraining', () => {
      invariant(typeof draining === 'boolean', 'draining must be boolean');
      const f = this.#facility(id);
      f.draining = draining;
      if (draining)
        for (const j of f.jobs) {
          this.#releaseDemand(f, j);
          if (!j.active) j.state = 'drained';
        }
      this.#queue({
        type: 'facility-draining',
        tick: this.#tick,
        facilityId: id,
      });
      this.#notify();
    });
  }
  removalBlockers(id: string): RemovalBlocker[] {
    const f = this.#facility(id),
      d = this.registry.facility(f.definitionId),
      i = this.#ownedInventory(f.inventoryId);
    const blockers: RemovalBlocker[] = f.jobs
      .filter((j) => j.active)
      .map((j) => ({ code: 'active-batch', jobId: j.id }));
    for (const [workerId, p] of Object.entries(i.summary().workforce)) {
      const shortage =
        p.assigned -
        (d.workersRequired?.[workerId] ?? 0) -
        p.total +
        (d.workersProvided?.[workerId] ?? 0);
      if (shortage > 0)
        blockers.push({ code: 'workforce', workerId, shortage });
    }
    const capacity = i.capacityPerMaterial - (d.capacityProvided ?? 0);
    for (const r of this.registry.resources)
      if (r.kind === 'material' && i.quantity(r.id) > capacity)
        blockers.push({
          code: 'capacity',
          resourceId: r.id,
          excess: i.quantity(r.id) - capacity,
        });
    return blockers;
  }
  /** No implicit destruction/refund. Output/input inventories and deliveries survive. */
  removeFacility(id: string): RemovalResult {
    return this.#mutate('removeFacility', () => {
      const f = this.#facility(id),
        blockers = this.removalBlockers(id);
      if (blockers.length) return { ok: false, blockers };
      const d = this.registry.facility(f.definitionId),
        retainedWorkerTypes = new Set<string>();
      for (const other of this.#facilities)
        if (other !== f && other.inventoryId === f.inventoryId) {
          const definition = this.registry.facility(other.definitionId);
          for (const workerId of [
            ...Object.keys(definition.workersProvided ?? {}),
            ...Object.keys(definition.workersRequired ?? {}),
          ])
            retainedWorkerTypes.add(workerId);
        }
      for (const j of f.jobs) this.#releaseDemand(f, j);
      this.#ownedInventory(f.inventoryId).removeFacility(
        d.workersProvided ?? {},
        d.workersRequired ?? {},
        d.capacityProvided ?? 0,
        retainedWorkerTypes,
      );
      this.#retiredFacilities.push({
        id: f.id,
        definitionId: f.definitionId,
        jobs: f.jobs.map((j) => ({
          id: j.id,
          recipeId: j.recipe.id,
          completed: j.completed,
        })),
      });
      for (const j of f.jobs)
        this.#productionJobs.set(j.id, {
          id: j.id,
          recipe: j.recipe,
          completed: j.completed,
          outcome: null,
        });
      this.#facilities.splice(this.#facilities.indexOf(f), 1);
      this.#facilityIndex.delete(id);
      this.#queue({
        type: 'facility-removed',
        tick: this.#tick,
        facilityId: id,
      });
      this.#notify();
      return { ok: true, facilityId: id };
    });
  }
  #inputs(j: Job): Record<string, number> {
    const inputs: Record<string, number> = Object.assign(
      Object.create(null) as Record<string, never>,
      j.recipe.inputs,
    );
    for (const [id, n] of Object.entries(j.optionalInputs))
      inputs[id] = (inputs[id] ?? 0) + n;
    // Registry validates the maximum combined recipe inputs; selections use declared quantities.
    return inputs;
  }
  setFacilityEnabled(id: string, enabled: boolean): void {
    this.#mutate('setFacilityEnabled', () => {
      invariant(typeof enabled === 'boolean', 'enabled must be boolean');
      const f = this.#facility(id);
      f.enabled = enabled;
      for (const j of f.jobs) {
        j.state = enabled
          ? !f.attendanceReady
            ? 'waiting-workers'
            : !Object.values(f.conditions).every(Boolean)
              ? 'waiting-condition'
              : j.active
                ? j.readySince !== null
                  ? 'output-blocked'
                  : 'producing'
                : 'waiting-inputs'
          : 'paused';
        if (!enabled) this.#releaseDemand(f, j);
      }
      this.#queue({
        type: 'facility-enabled',
        tick: this.#tick,
        facilityId: id,
      });
      this.#notify();
    });
  }
  /** Named requirements let the host model operators/power without changing production. */
  setFacilityCondition(
    id: string,
    conditionId: string,
    fulfilled: boolean,
  ): void {
    this.#mutate('setFacilityCondition', () => {
      const f = this.#facility(id);
      invariant(
        Object.hasOwn(f.conditions, conditionId),
        `unknown operating condition '${conditionId}'`,
      );
      invariant(typeof fulfilled === 'boolean', 'condition must be boolean');
      f.conditions[conditionId] = fulfilled;
      for (const j of f.jobs)
        if (!fulfilled) {
          j.state = f.enabled ? 'waiting-condition' : 'paused';
          this.#releaseDemand(f, j);
        }
      this.#queue({
        type: 'facility-condition',
        tick: this.#tick,
        facilityId: id,
      });
      this.#notify();
    });
  }
  /** Advance by elapsed seconds. Fixed ticks preserve leftover time; there is no wall-clock cap. */
  advance(seconds: number): number {
    return this.#mutate('advance', () => {
      invariant(
        Number.isFinite(seconds) && seconds >= 0,
        'advance: seconds must be finite and non-negative',
      );
      const micros = seconds * 1e6;
      invariant(
        Number.isFinite(micros) &&
          micros <= Number.MAX_SAFE_INTEGER &&
          this.#pendingMicroseconds + micros <= Number.MAX_SAFE_INTEGER,
        'advance: elapsed time is too large',
      );
      // Preflight the same compensated, tolerance-aware tick count the loop will process.
      const delta = micros - this.#timeCompensation;
      const total = this.#pendingMicroseconds + delta;
      const ticks = Math.floor((total + 1e-7) / this.registry.tickMicroseconds);
      invariant(
        Number.isSafeInteger(this.#tick + ticks),
        'advance: tick overflow',
      );
      this.#checkCounterBudget(ticks);
      // Compensated addition retains sub-microsecond fractions rather than rounding each frame.
      this.#timeCompensation = total - this.#pendingMicroseconds - delta;
      this.#pendingMicroseconds = total;
      let count = 0;
      const tick = this.registry.tickMicroseconds;
      while (this.#pendingMicroseconds >= tick - 1e-7) {
        this.#pendingMicroseconds -= tick;
        if (Math.abs(this.#pendingMicroseconds) < 1e-7)
          this.#pendingMicroseconds = 0;
        this.#step();
        count++;
      }
      this.#notify();
      return count;
    });
  }
  /** Exact host ticks; does not consume a pending fractional advance(). */
  advanceTicks(count: number): void {
    this.#mutate('advanceTicks', () => {
      invariant(
        Number.isSafeInteger(count) &&
          count >= 0 &&
          Number.isSafeInteger(this.#tick + count),
        'invalid tick count',
      );
      this.#checkCounterBudget(count);
      for (let n = 0; n < count; n++) this.#step();
      this.#notify();
    });
  }
  #releaseDemand(f: Facility, j: Job): void {
    if (j.active) return;
    const i = this.#ownedInventory(f.inputInventoryId);
    if (i.hasReservation(j.id)) i.release(j.id);
    j.demandSince = null;
    j.demandOrder = 0;
    j.deferredWork = 0;
  }
  #checkCounterBudget(ticks: number): void {
    if (!ticks) return;
    const futureJobs = [...this.#pendingConstruction.values()].reduce(
      (n, o) => n + this.registry.facility(o.definitionId).recipes.length,
      0,
    );
    const maximumRequests =
      (this.#facilities.reduce((n, f) => n + f.jobs.length * 1000, 0) +
        futureJobs * 1000) *
      ticks;
    invariant(
      Number.isSafeInteger(
        this.#nextInventoryOperation +
          maximumRequests * 2 +
          this.#pendingConstruction.size,
      ),
      'inventory operation counter exhausted',
    );
    invariant(
      Number.isSafeInteger(this.#demandOrder + maximumRequests),
      'demand order exhausted',
    );
    for (const f of this.#facilities)
      for (const j of f.jobs)
        invariant(
          Number.isSafeInteger(j.completed + 1000 * ticks),
          'batch counter exhausted',
        );
  }
  #step(): void {
    // advance/advanceTicks preflight the entire command before the first tick.
    this.#tick++;
    this.#advanceConstruction();
    const enabled = this.#facilities.filter(
      (f) =>
        f.enabled &&
        Object.values(f.conditions).every(Boolean) &&
        f.attendanceReady,
    );
    for (const f of this.#facilities)
      if (
        !f.enabled ||
        !Object.values(f.conditions).every(Boolean) ||
        !f.attendanceReady
      )
        for (const j of f.jobs)
          j.state = !f.enabled
            ? 'paused'
            : !Object.values(f.conditions).every(Boolean)
              ? 'waiting-condition'
              : 'waiting-workers';
    const work = new Map<Job, number>();
    for (const f of enabled)
      for (const j of f.jobs) {
        work.set(
          j,
          j.active && j.readySince === null && f.rate > 0
            ? f.rate + j.deferredWork
            : 0,
        );
        if (f.rate > 0) j.deferredWork = 0;
      }
    // Multiple rounds spend only this tick's earned work, with allocation between completions.
    // A processing limit bounds pathological boosts; unspent active work is deferred, never discarded.
    for (let round = 0; round < 1000; round++) {
      let progressed = false;
      for (const f of enabled)
        for (const j of f.jobs) {
          if (!j.active || j.readySince !== null) continue;
          const budget = work.get(j)!;
          const used = Math.min(
            budget,
            Math.max(0, j.durationTicks - j.elapsedTicks),
          );
          j.elapsedTicks += used;
          work.set(j, Math.max(0, budget - used));
          j.state = f.rate === 0 ? 'paused' : 'producing';
          if (
            j.elapsedTicks >=
            j.durationTicks - Number.EPSILON * Math.max(1, j.durationTicks) * 16
          ) {
            j.elapsedTicks = j.durationTicks;
            j.outcome = resolveOutcome(
              this.#seed,
              j.id,
              j.completed,
              j.recipe,
              j.batchOptionalInputs,
              f.modifiers,
              this.#individualResources,
            );
            j.readySince = this.#tick;
          }
        }
      const completed = enabled
        .flatMap((f) =>
          f.jobs.filter((j) => j.readySince !== null).map((j) => ({ f, j })),
        )
        .sort(
          (a, b) =>
            a.j.readySince! - b.j.readySince! ||
            a.j.demandOrder - b.j.demandOrder,
        );
      for (const { f, j } of completed) {
        if (
          !this.#ownedInventory(f.outputInventoryId).depositOutcome(
            j.outcome!,
            j.id,
          )
        ) {
          j.state = 'output-blocked';
          work.set(j, 0); // No work is earned while unloading is blocked.
          continue;
        }
        const outcome = j.outcome!;
        j.completed++;
        j.outcome = null;
        j.batchInputItems = [];
        j.active = false;
        j.elapsedTicks = 0;
        j.readySince = null;
        j.demandSince = null;
        progressed = true;
        if (this.#listeners.size)
          this.#queue({
            type: 'batch-completed',
            tick: this.#tick,
            facilityId: f.id,
            jobId: j.id,
            batchNumber: j.completed,
            outcome: cloneData(outcome),
          });
        else
          this.#record('event', 'batch-completed', {
            facilityId: f.id,
            jobId: j.id,
          });
      }
      for (const f of enabled)
        for (const j of f.jobs)
          if (
            !f.draining &&
            !j.active &&
            j.demandSince === null &&
            f.rate > 0
          ) {
            j.demandSince = this.#tick;
            invariant(
              this.#demandOrder < Number.MAX_SAFE_INTEGER,
              'demand order exhausted',
            );
            j.demandOrder = ++this.#demandOrder;
            j.state = 'waiting-inputs';
          }
      const demands = enabled
        .flatMap((f) =>
          f.jobs.filter((j) => !j.active && !f.draining).map((j) => ({ f, j })),
        )
        .sort((a, b) => a.j.demandOrder - b.j.demandOrder);
      for (const { f, j } of demands) {
        const inventory = this.#ownedInventory(f.inputInventoryId);
        const output = this.#ownedInventory(f.outputInventoryId);
        if (f.rate === 0) {
          j.state = 'paused';
          continue;
        }
        const inputs = this.#inputs(j);
        if (
          this.#individualInputRecipes.has(j.recipe.id) &&
          !j.inputItemIds.length &&
          Object.keys(this.#individualInputs(j)).length
        ) {
          this.#releaseDemand(f, j);
          j.state = 'waiting-inputs';
          work.set(j, 0);
          continue;
        }
        if (
          Object.entries(inputs).some(
            ([id, n]) =>
              this.registry.resource(id).kind === 'material' &&
              n > inventory.capacityPerMaterial,
          )
        ) {
          this.#releaseDemand(f, j);
          j.state = 'waiting-inputs';
          work.set(j, 0);
          continue;
        }
        if (
          !(inventory === output
            ? inventory.canStartBatch(inputs, j.recipe.outputs)
            : output.canDepositBatch(j.recipe.outputs))
        ) {
          this.#releaseDemand(f, j);
          j.state = 'output-blocked';
          work.set(j, 0);
          continue;
        }
        const previousHeld = inventory.reservation(j.id);
        inventory.allocate(j.id, inputs, j.inputItemIds);
        if (!sameQuantities(previousHeld, inventory.reservation(j.id)))
          this.#record('allocation', j.id, {
            inventoryId: inventory.id,
            quantities: inventory.reservation(j.id),
          });
        const held = inventory.reservation(j.id);
        if (Object.entries(inputs).some(([id, n]) => (held[id] ?? 0) < n)) {
          j.state = 'waiting-inputs';
          work.set(j, 0); // Waiting time cannot be banked as production.
          continue;
        }
        const consumed = inventory.commit(j.id);
        j.batchInputItems = consumed.items;
        j.inputItemIds = [];
        j.inputItemResources = {};
        j.batchOptionalInputs = { ...j.optionalInputs };
        j.active = true;
        j.demandSince = null;
        j.state = 'producing';
        this.#queue({
          type: 'batch-started',
          tick: this.#tick,
          facilityId: f.id,
          jobId: j.id,
          batchNumber: j.completed + 1,
          inputs: this.#listeners.size ? cloneData(consumed) : consumed,
        });
      }
      if (
        !progressed &&
        !enabled.some((f) =>
          f.jobs.some(
            (j) => j.active && j.readySince === null && (work.get(j) ?? 0) > 0,
          ),
        )
      )
        break;
    }
    for (const f of enabled)
      for (const j of f.jobs) {
        if (f.draining && !j.active) j.state = 'drained';
        if (f.rate > 0)
          j.deferredWork = j.active && j.readySince === null ? work.get(j)! : 0;
      }
  }
  /** Missing next-batch inputs after accounting for stock and committed inbound cargo. */
  materialDemands(): MaterialDemand[] {
    const available = new Map<string, Record<string, number>>();
    for (const inventory of this.#inventories.values()) {
      const stock = Object.fromEntries(
        this.registry.resources.map((r) => [r.id, inventory.available(r.id)]),
      );
      for (const [id, n] of Object.entries(
        this.#incoming.get(inventory.id) ?? {},
      ))
        stock[id] = Math.min(Number.MAX_SAFE_INTEGER, (stock[id] ?? 0) + n);
      available.set(inventory.id, stock);
    }
    const requests = this.#facilities
      .filter(
        (f) =>
          f.enabled &&
          !f.draining &&
          f.attendanceReady &&
          f.rate > 0 &&
          Object.values(f.conditions).every(Boolean),
      )
      .flatMap((f) => f.jobs.filter((j) => !j.active).map((j) => ({ f, j })))
      .sort((a, b) => a.j.demandOrder - b.j.demandOrder);
    const result: MaterialDemand[] = [];
    const claimedItems = new Set<string>();
    for (const { f, j } of requests) {
      const stock = available.get(f.inputInventoryId)!;
      const quantities: Record<string, number> = {};
      const inventory = this.#ownedInventory(f.inputInventoryId);
      const held = inventory.reservation(j.id);
      const selected: Record<string, number> = Object.create(null) as Record<
        string,
        never
      >;
      for (const id of inventory.availableSelectedItemIds(
        j.inputItemIds,
        j.id,
      )) {
        // Own holdings are already subtracted; count each unreserved identity once across competing requests.
        if (!claimedItems.has(id)) {
          const resourceId = j.inputItemResources[id]!;
          selected[resourceId] = (selected[resourceId] ?? 0) + 1;
          claimedItems.add(id);
        }
      }
      for (const [id, required] of Object.entries(this.#inputs(j))) {
        const n = required - (held[id] ?? 0);
        const use = this.#individualResources.has(id)
          ? Math.min(
              n,
              Math.max(0, (selected[id] ?? 0) - (held[id] ?? 0)),
              stock[id] ?? 0,
            )
          : Math.min(stock[id] ?? 0, n);
        stock[id] = (stock[id] ?? 0) - use;
        if (use < n) quantities[id] = n - use;
      }
      if (Object.keys(quantities).length)
        result.push({
          facilityId: f.id,
          jobId: j.id,
          inventoryId: f.inputInventoryId,
          quantities,
          ...(Object.keys(this.#individualInputs(j)).length
            ? {
                itemSelection: {
                  required: this.#individualInputs(j),
                  selectedIds: [...j.inputItemIds],
                },
              }
            : {}),
        });
    }
    return result;
  }
  /** Reserve source goods, without teleporting them or scheduling travel. Select individual goods by ID. */
  reserveDelivery(
    sourceId: string,
    destinationId: string,
    quantities: Quantities = {},
    itemIds: readonly string[] = [],
  ): DeliveryResult {
    return this.#mutate('reserveDelivery', () => {
      const source = this.#ownedInventory(sourceId);
      this.#ownedInventory(destinationId);
      invariant(sourceId !== destinationId, 'delivery endpoints must differ');
      this.registry.validate(quantities, 'delivery cargo');
      invariant(Array.isArray(itemIds as unknown), 'invalid cargo item IDs');
      invariant(
        Object.values(quantities).some((n) => n > 0) || itemIds.length > 0,
        'delivery cargo must not be empty',
      );
      const incoming = this.#incoming.get(destinationId) ?? {};
      const incomingManifest = { ...quantities };
      for (const itemId of itemIds) {
        const item = source.item(itemId);
        if (item)
          incomingManifest[item.resourceId] =
            (incomingManifest[item.resourceId] ?? 0) + 1;
      }
      for (const [resource, n] of Object.entries(incomingManifest))
        invariant(
          Number.isSafeInteger((incoming[resource] ?? 0) + n),
          'inbound cargo exceeds safe integer range',
        );
      invariant(
        this.#nextDelivery < Number.MAX_SAFE_INTEGER,
        'delivery ID counter exhausted',
      );
      const id = `delivery-${this.#nextDelivery}`;
      if (!source.reserveCargo(`logistics:${id}`, quantities, itemIds))
        return {
          ok: false,
          reason: 'Source bulk cargo or selected items unavailable',
        };
      this.#nextDelivery++;
      this.#deliveries.set(id, {
        id,
        sourceInventoryId: sourceId,
        destinationInventoryId: destinationId,
        quantities: { ...incomingManifest },
        itemIds: [...itemIds],
        items: [],
        state: 'reserved',
      });
      this.#indexIncoming(this.#delivery(id), 1);
      return { ok: true, deliveryId: id };
    });
  }
  #indexIncoming(d: DeliverySnapshot, direction: 1 | -1): void {
    const totals =
      this.#incoming.get(d.destinationInventoryId) ??
      (Object.create(null) as Record<string, number>);
    for (const [id, n] of Object.entries(d.quantities)) {
      const next = (totals[id] ?? 0) + direction * n;
      invariant(
        Number.isSafeInteger(next) && next >= 0,
        'invalid inbound cargo total',
      );
      totals[id] = next;
    }
    this.#incoming.set(d.destinationInventoryId, totals);
  }
  deliverySnapshot(id: string): DeliverySnapshot {
    return cloneData(this.#delivery(id));
  }
  /** Terminal records are history, not owners. Hosts can archive them before removal. */
  pruneDeliveries(): number {
    return this.#mutate('pruneDeliveries', () => {
      let count = 0;
      for (const [id, d] of this.#deliveries)
        if (d.state === 'delivered' || d.state === 'cancelled') {
          this.#deliveries.delete(id);
          count++;
        }
      return count;
    });
  }
  #delivery(id: string): DeliverySnapshot {
    const d = this.#deliveries.get(id);
    invariant(d, `unknown delivery '${id}'`);
    return d;
  }
  pickupDelivery(id: string): void {
    this.#mutate('pickupDelivery', () => {
      const d = this.#delivery(id);
      invariant(d.state === 'reserved', 'delivery is not awaiting pickup');
      const cargo = this.#ownedInventory(d.sourceInventoryId).commit(
        `logistics:${id}`,
      );
      d.items = cargo.items;
      d.state = 'in-transit';
      this.#record('delivery', d.id, { state: d.state });
    });
  }
  arriveDelivery(id: string): boolean {
    return this.#mutate('arriveDelivery', () => {
      const d = this.#delivery(id);
      invariant(
        d.state === 'in-transit' || d.state === 'arrival-blocked',
        'delivery is not carrying cargo',
      );
      if (
        !this.#ownedInventory(d.destinationInventoryId).depositOutcome(
          {
            quantities: d.quantities,
            items: d.items,
          },
          d.id,
        )
      ) {
        d.state = 'arrival-blocked';
        this.#record('delivery', d.id, { state: d.state });
        return false;
      }
      this.#indexIncoming(d, -1);
      d.state = 'delivered';
      this.#record('delivery', d.id, { state: d.state });
      return true;
    });
  }
  /** Cancel only before pickup. The source stock never left its inventory. */
  cancelDelivery(id: string): void {
    this.#mutate('cancelDelivery', () => {
      const d = this.#delivery(id);
      invariant(
        d.state === 'reserved',
        'only a reserved delivery can be cancelled; carrying cargo must be returned',
      );
      this.#ownedInventory(d.sourceInventoryId).release(`logistics:${id}`);
      this.#indexIncoming(d, -1);
      d.state = 'cancelled';
      this.#record('delivery', d.id, { state: d.state });
    });
  }
  /** Host calls after a return journey; failed unloading retains cargo. */
  returnDelivery(id: string): boolean {
    return this.#mutate('returnDelivery', () => {
      const d = this.#delivery(id);
      invariant(
        d.state === 'in-transit' || d.state === 'arrival-blocked',
        'delivery is not carrying cargo',
      );
      if (
        !this.#ownedInventory(d.sourceInventoryId).depositOutcome(
          {
            quantities: d.quantities,
            items: d.items,
          },
          d.id,
        )
      )
        return false;
      this.#indexIncoming(d, -1);
      d.state = 'cancelled';
      this.#record('delivery', d.id, { state: d.state });
      return true;
    });
  }
  /** Observers receive committed facts. Reentrant simulation commands are rejected. */
  onEvent(listener: (event: SimulationEvent) => void): () => void {
    this.#listeners.add(listener);
    return () => {
      this.#listeners.delete(listener);
    };
  }
  #queue(event: SimulationEvent): void {
    this.#record('event', event.type, {
      facilityId: event.facilityId,
      ...('jobId' in event ? { jobId: event.jobId } : {}),
      ...('orderId' in event ? { orderId: event.orderId } : {}),
    });
    if (this.#listeners.size) this.#events.push(event);
  }
  #notify(): void {
    if (!this.#events.length) return;
    const events = this.#events;
    this.#events = [];
    const errors: unknown[] = [];
    for (const event of events)
      for (const listener of [...this.#listeners]) {
        try {
          listener(Object.freeze(cloneData(event)));
        } catch (error) {
          errors.push(error);
        }
      }
    if (errors.length)
      throw new AggregateError(
        errors,
        'Simulation observers failed after state committed',
      );
  }
  /** Explicit diagnostics only: shares the restore validator, not a per-tick check. */
  validateState(): ValidationResult {
    try {
      const restored = Simulation.restore(this.#checkpoint());
      invariant(
        JSON.stringify(restored.snapshot()) ===
          JSON.stringify(this.snapshot()) &&
          JSON.stringify(restored.materialDemands()) ===
            JSON.stringify(this.materialDemands()),
        'live indexes differ from reconstructed state',
      );
      return { ok: true };
    } catch (error) {
      return {
        ok: false,
        issues: [
          {
            code: 'invalid-state',
            message: error instanceof Error ? error.message : String(error),
          },
        ],
      };
    }
  }
  #wasIssued(
    id: string,
    manifests?: Map<string, Quantities>,
    expectedResource?: string,
  ): boolean {
    const external = /^external-([1-9][0-9]*)$/.exec(id);
    if (external) {
      const n = Number(external[1]);
      return Number.isSafeInteger(n) && n < this.#nextItem;
    }
    const match =
      /^(facility-[1-9][0-9]*\.job-(?:0|[1-9][0-9]*))\.batch-(0|[1-9][0-9]*)\.(.+)-(0|[1-9][0-9]*)$/.exec(
        id,
      );
    if (!match) return false;
    const j = this.#productionJobs.get(match[1]!),
      batch = Number(match[2]);
    if (!j || !Number.isSafeInteger(batch) || batch > j.completed) return false;
    if (batch === j.completed)
      return (
        j.outcome?.items.some(
          (item) =>
            item.id === id &&
            (expectedResource === undefined ||
              item.resourceId === expectedResource),
        ) ?? false
      );
    let manifest: Quantities = j.recipe.outputs;
    if (j.recipe.bonusOutputs?.length) {
      const key = `${j.id}/${batch}`;
      const cached = manifests?.get(key);
      if (cached) manifest = cached;
      else {
        manifest = producedQuantities(this.#seed, j.id, batch, j.recipe);
        manifests?.set(key, manifest);
      }
    }
    const index = Number(match[4]),
      resource = match[3]!;
    return (
      (expectedResource === undefined || resource === expectedResource) &&
      Number.isSafeInteger(index) &&
      this.#individualResources.has(resource) &&
      index < (manifest[resource] ?? 0)
    );
  }
  locateItem(itemId: string): ItemLocation | undefined {
    for (const i of this.#inventories.values())
      if (i.item(itemId)) {
        const reservation = i
          .save()
          .reservations.find((r) => r.itemIds.includes(itemId));
        return {
          kind: 'inventory',
          inventoryId: i.id,
          reservationOwner: reservation
            ? reservation.token.startsWith('logistics:')
              ? reservation.token.slice(10)
              : reservation.token
            : null,
        };
      }
    for (const d of this.#deliveries.values())
      if (
        ['in-transit', 'arrival-blocked'].includes(d.state) &&
        d.itemIds.includes(itemId)
      )
        return { kind: 'delivery', deliveryId: d.id };
    for (const f of this.#facilities)
      for (const j of f.jobs)
        if (j.outcome?.items.some((i) => i.id === itemId))
          return { kind: 'job', jobId: j.id, facilityId: f.id };
    return this.#wasIssued(itemId) ? { kind: 'retired' } : undefined;
  }
  inspectReservations(inventoryId: string): ReservationInspection[] {
    return this.#ownedInventory(inventoryId)
      .save()
      .reservations.map((r) => ({
        owner: r.token.startsWith('logistics:')
          ? { kind: 'delivery', id: r.token.slice(10) }
          : r.token.startsWith('construction-')
            ? { kind: 'construction', id: r.token }
            : { kind: 'job', id: r.token },
        quantities: { ...r.quantities },
        itemIds: [...r.itemIds],
      }));
  }
  explainJob(jobId: string): JobExplanation {
    const f = this.#facilities.find((f) => f.jobs.some((j) => j.id === jobId));
    invariant(f, `unknown job '${jobId}'`);
    const j = f.jobs.find((j) => j.id === jobId)!;
    const input = this.#ownedInventory(f.inputInventoryId),
      output = this.#ownedInventory(f.outputInventoryId);
    const required = this.#inputs(j),
      held = input.reservation(j.id);
    const blockers: JobExplanation['blockers'] = [];
    if (!f.enabled) blockers.push({ code: 'disabled' });
    if (!f.attendanceReady)
      blockers.push({
        code: 'missing-workforce',
        quantities: this.#missingAttendance(f),
      });
    if (f.draining && !j.active) blockers.push({ code: 'draining' });
    if (
      !j.active &&
      !j.inputItemIds.length &&
      Object.keys(this.#individualInputs(j)).length
    )
      blockers.push({
        code: 'missing-item-selection',
        quantities: this.#individualInputs(j),
      });
    if (!j.active && j.inputItemIds.length) {
      const reserved = new Set(input.snapshot().reservedItemIds);
      const own = new Set(
        input.save().reservations.find((r) => r.token === j.id)?.itemIds ?? [],
      );
      const unavailable = j.inputItemIds.filter(
        (id) => !input.item(id) || (reserved.has(id) && !own.has(id)),
      );
      if (unavailable.length)
        blockers.push({
          code: 'selected-items-unavailable',
          itemIds: unavailable,
        });
    }
    for (const [id, fulfilled] of Object.entries(f.conditions))
      if (!fulfilled) blockers.push({ code: 'condition', conditionId: id });
    if (f.rate === 0 && j.outcome === null)
      blockers.push({ code: 'zero-productivity' });
    const missing: Record<string, number> = {},
      impossible: Record<string, number> = {},
      space: Record<string, number> = {};
    const missingInputs = j.active ? {} : this.#missingInputs(f, j);
    if (!j.active)
      for (const [id, n] of Object.entries(required)) {
        const deficit = missingInputs[id] ?? 0;
        if (deficit) missing[id] = deficit;
        if (
          this.registry.resource(id).kind === 'material' &&
          n > input.capacityPerMaterial
        )
          impossible[id] = n - input.capacityPerMaterial;
      }
    const outcome = j.outcome?.quantities ?? j.recipe.outputs;
    if (!j.active || j.outcome)
      for (const [id, n] of Object.entries(outcome))
        if (this.registry.resource(id).kind === 'material') {
          const projected =
            output.quantity(id) -
            (!j.active && input === output ? (required[id] ?? 0) : 0) +
            n;
          if (projected > output.capacityPerMaterial)
            space[id] = projected - output.capacityPerMaterial;
        }
    if (Object.keys(missing).length)
      blockers.push({ code: 'missing-inputs', quantities: missing });
    if (Object.keys(impossible).length)
      blockers.push({ code: 'input-capacity', quantities: impossible });
    if (Object.keys(space).length)
      blockers.push({ code: 'output-capacity', quantities: space });
    const tickSeconds = this.registry.tickMicroseconds / 1e6;
    const remaining = Math.max(0, j.durationTicks - j.elapsedTicks);
    return {
      jobId,
      facilityId: f.id,
      phase: j.outcome ? 'awaiting-output' : j.active ? 'working' : 'idle',
      blockers,
      requiredInputs: { ...required },
      reservedInputs: { ...held },
      availableInputs: Object.fromEntries(
        Object.keys(required).map((id) => [id, input.available(id)]),
      ),
      inboundInputs: { ...this.#incoming.get(input.id) },
      productivity: {
        base: f.workerSlots.length
          ? f.workerSlots.reduce((n, w) => n + (w?.efficiency ?? 0), 0) /
            f.workerSlots.length
          : 1,
        modifiers: Object.fromEntries(
          Object.entries(f.modifiers).map(([id, m]) => [
            id,
            m.productivityMultiplier ?? 1,
          ]),
        ),
        effective: f.rate,
      },
      remainingWorkSeconds: remaining * tickSeconds,
      deferredWorkSeconds: j.deferredWork * tickSeconds,
      estimatedCompletionSeconds:
        j.active && blockers.length === 0 && f.rate > 0
          ? Math.ceil(Math.max(0, remaining - j.deferredWork) / f.rate) *
            tickSeconds
          : null,
    };
  }
  enableDiagnostics(limit = 200): void {
    invariant(
      !this.#mutating,
      'diagnostics configuration cannot change in an observer',
    );
    invariant(
      Number.isSafeInteger(limit) && limit >= 0 && limit <= 10000,
      'invalid diagnostic trace limit',
    );
    this.#traceLimit = limit;
    this.#trace = [];
    this.#traceSequence = 0;
  }
  diagnosticTrace(): DiagnosticEntry[] {
    return cloneData(this.#trace);
  }
  #record(
    kind: DiagnosticEntry['kind'],
    subject: string,
    details: Record<string, unknown>,
  ): void {
    if (!this.#traceLimit) return;
    this.#trace.push({
      sequence: ++this.#traceSequence,
      tick: this.#tick,
      kind,
      subject,
      details: cloneData(details),
    });
    if (this.#trace.length > this.#traceLimit) this.#trace.shift();
  }
  /** Complete JSON-compatible checkpoint. Observers are intentionally not persisted. */
  save(): SimulationSave {
    invariant(!this.#mutating, 'cannot save during a command or notification');
    return this.#checkpoint();
  }
  #checkpoint(): SimulationSave {
    // Each nested value crosses the ownership boundary once; no second world clone.
    const state = {
      format: 'production-workshop' as const,
      configuration: cloneData({
        resources: this.registry.resources,
        recipes: this.registry.recipes,
        facilities: this.registry.facilities,
        seed: this.#seed,
        tickMilliseconds: this.registry.tickMicroseconds / 1000,
      }),
      tick: this.#tick,
      pendingMicroseconds: this.#pendingMicroseconds,
      timeCompensation: this.#timeCompensation,
      nextConstruction: this.#nextConstruction,
      constructionOrders: [...this.#constructionOrders.values()].map((o) =>
        cloneData(o),
      ),
      nextId: this.#nextId,
      nextDelivery: this.#nextDelivery,
      nextItem: this.#nextItem,
      demandOrder: this.#demandOrder,
      inventories: [...this.#inventories.values()].map((i) => i.save()),
      facilities: this.#facilities.map((f) => ({
        id: f.id,
        definitionId: f.definitionId,
        inventoryId: f.inventoryId,
        inputInventoryId: f.inputInventoryId,
        outputInventoryId: f.outputInventoryId,
        enabled: f.enabled,
        draining: f.draining,
        conditions: { ...f.conditions },
        attendance: { ...f.attendance },
        workerSlots: cloneData(f.workerSlots),
        modifiers: cloneData(f.modifiers),
        jobs: f.jobs.map(({ recipe, durationTicks, ...j }) => ({
          ...j,
          recipeId: recipe.id,
          optionalInputs: { ...j.optionalInputs },
          batchOptionalInputs: { ...j.batchOptionalInputs },
          inputItemIds: [...j.inputItemIds],
          inputItemResources: { ...j.inputItemResources },
          batchInputItems: cloneData(j.batchInputItems),
          outcome: j.outcome ? cloneData(j.outcome) : null,
        })),
      })),
      retiredFacilities: cloneData(this.#retiredFacilities),
      deliveries: [...this.#deliveries.values()].map((d) => cloneData(d)),
    };
    return {
      ...state,
      version: 7,
      nextInventoryOperation: this.#nextInventoryOperation,
      inventoryAttachments: [...this.#inventoryAttachments.values()].map(
        (a) => ({ ...a }),
      ),
    };
  }

  /** Validate a checkpoint into a new isolated world. Never mutates an existing world. */
  static restore(data: unknown): Simulation {
    try {
      return Simulation.#restoreChecked(data);
    } catch (error) {
      if (error instanceof DefinitionError) throw error;
      throw new DefinitionError('malformed production-workshop save');
    }
  }
  static #restoreChecked(data: unknown): Simulation {
    invariant(
      data !== null && typeof data === 'object' && !Array.isArray(data),
      'invalid save object',
    );
    const header = data as { format?: unknown; version?: unknown };
    invariant(
      header.format === 'production-workshop' &&
        (header.version === 4 ||
          header.version === 5 ||
          header.version === 6 ||
          header.version === 7),
      'unsupported save format or version',
    );
    // Validate opaque context before cloning can erase non-JSON values or descriptors.
    const raw = data as SimulationSave;
    invariant(Array.isArray(raw.inventories), 'invalid saved inventories');
    for (const inventory of raw.inventories) {
      if (inventory.metadata !== undefined)
        validateMetadata(inventory.metadata);
      if (inventory.modifiers !== undefined)
        validateModifiers(inventory.modifiers);
    }
    const state = cloneData(data) as SimulationSave;
    const s = new Simulation(state.configuration);
    const integer = (n: number, min = 0) =>
      invariant(Number.isSafeInteger(n) && n >= min, 'invalid saved integer');
    const finite = (n: number) =>
      invariant(
        Number.isFinite(n) && n >= 0 && n <= Number.MAX_SAFE_INTEGER,
        'invalid saved work/time',
      );
    if (state.version !== 7)
      invariant(
        state.inventories.every(
          (i) =>
            !['modifiers', 'metadata', 'equipment'].some((k) =>
              Object.hasOwn(i, k),
            ),
        ),
        'inventory context requires save version 7',
      );
    if (state.version === 6 || state.version === 7) {
      integer(state.nextInventoryOperation, 1);
      s.#nextInventoryOperation = state.nextInventoryOperation;
    } else
      invariant(
        !Object.hasOwn(state, 'nextInventoryOperation') &&
          state.inventories.every((i) => !Object.hasOwn(i, 'rules')) &&
          state.configuration.resources.every(
            (r) => r.unitWeight === undefined && r.unitVolume === undefined,
          ),
        'advanced inventory state requires save version 6',
      );
    integer(state.tick);
    integer(state.nextId, 1);
    integer(state.nextDelivery, 1);
    integer(state.nextItem, 1);
    integer(state.nextConstruction, 1);
    integer(state.demandOrder);
    finite(state.pendingMicroseconds);
    invariant(
      state.pendingMicroseconds < s.registry.tickMicroseconds &&
        Number.isFinite(state.timeCompensation) &&
        Math.abs(state.timeCompensation) < 1,
      'invalid saved clock remainder',
    );
    s.#nextItem = state.nextItem;
    const referencedIds = new Set<string>();
    const referencedResources = new Map<string, string>();
    const reference = (id: string, resourceId?: string) => {
      invariant(
        typeof id === 'string' && id.length > 0,
        'invalid saved item identity',
      );
      referencedIds.add(id);
      if (resourceId !== undefined) {
        const previous = referencedResources.get(id);
        invariant(
          previous === undefined || previous === resourceId,
          'conflicting item resource provenance',
        );
        referencedResources.set(id, resourceId);
      }
      return true;
    };
    const owners = new Set<string>();
    const own = (items: ProducedItem[]) => {
      invariant(Array.isArray(items), 'invalid saved items');
      for (const item of items) {
        invariant(
          reference(item.id, item.resourceId) && !owners.has(item.id),
          'duplicate or unissued saved item identity',
        );
        owners.add(item.id);
      }
    };
    const outcome = (o: BatchOutcome) => {
      const validator = new Inventory(s.registry, {
        id: 'validation',
        capacityPerMaterial: Number.MAX_SAFE_INTEGER,
      });
      invariant(validator.depositOutcome(o), 'invalid saved outcome');
    };
    invariant(
      Array.isArray(state.inventories) &&
        Array.isArray(state.facilities) &&
        Array.isArray(state.deliveries),
      'invalid saved collections',
    );
    const physicalItems = new Map<string, ProducedItem>();
    const reservationOwners = new Map<string, string>();
    const savedReservations = new Map<
      string,
      {
        inventoryId: string;
        reservation: InventorySave['reservations'][number];
      }
    >();
    for (const i of state.inventories) {
      invariant(!s.#inventories.has(i.id), 'duplicate saved inventory');
      const inventory = Inventory.restore(s.registry, i);
      s.#inventories.set(i.id, inventory);
      s.#views.set(i.id, inventory.view());
      s.#observeInventory(inventory);
      own(i.items);
      if (s.#individualInputRecipes.size)
        for (const item of i.items) physicalItems.set(item.id, item);
      for (const r of i.reservations) {
        invariant(
          !reservationOwners.has(r.token),
          'duplicate saved reservation token',
        );
        reservationOwners.set(r.token, i.id);
        savedReservations.set(r.token, { inventoryId: i.id, reservation: r });
      }
    }
    if (state.version === 5 || state.version === 6 || state.version === 7) {
      invariant(
        Array.isArray(state.inventoryAttachments),
        'invalid saved inventory attachments',
      );
      for (const a of state.inventoryAttachments) {
        s.#ownedInventory(a.inventoryId);
        invariant(
          !s.#inventoryAttachments.has(a.inventoryId),
          'duplicate saved inventory attachment',
        );
        const attachment = s.#attachment(a.inventoryId, a.objectId, a.slot);
        s.#checkAttachment(attachment);
        s.#putAttachment(attachment);
      }
    } else {
      invariant(
        !Object.hasOwn(state, 'inventoryAttachments') &&
          state.inventories.every((i) => !Object.hasOwn(i, 'capacity')),
        'extended inventory state requires save version 5',
      );
    }
    const workers = new Set<string>();
    const jobIds = new Set<string>();
    const demandOrders = new Set<number>();
    let maxFacility = 0,
      maxDelivery = 0;
    const takeReservation = (
      token: string,
      inventoryId: string,
      quantities: Quantities,
      itemIds: string[] = [],
    ) => {
      invariant(
        reservationOwners.get(token) === inventoryId,
        'missing or misplaced saved reservation',
      );
      const r = savedReservations.get(token)!.reservation;
      invariant(
        sameQuantities(r.quantities, quantities) &&
          JSON.stringify(r.itemIds) === JSON.stringify(itemIds),
        'saved reservation does not match owner',
      );
      reservationOwners.delete(token);
    };
    for (const saved of state.facilities) {
      const d = s.registry.facility(saved.definitionId);
      const idNumber = /^facility-([1-9][0-9]*)$/.exec(saved.id)?.[1];
      invariant(
        idNumber && !s.#facilityIndex.has(saved.id),
        'invalid or duplicate saved facility',
      );
      integer(Number(idNumber), 1);
      maxFacility = Math.max(maxFacility, Number(idNumber));
      s.#ownedInventory(saved.inventoryId);
      s.#ownedInventory(saved.inputInventoryId);
      s.#ownedInventory(saved.outputInventoryId);
      invariant(
        typeof saved.enabled === 'boolean' &&
          typeof saved.draining === 'boolean' &&
          saved.conditions &&
          sameKeys(
            saved.conditions,
            Object.fromEntries(
              (d.operatingConditions ?? []).map((id) => [id, false]),
            ),
          ) &&
          Object.values(saved.conditions).every((v) => typeof v === 'boolean'),
        'invalid saved conditions',
      );
      invariant(
        saved.attendance !== null &&
          typeof saved.attendance === 'object' &&
          !Array.isArray(saved.attendance),
        'invalid saved attendance',
      );
      for (const [type, count] of Object.entries(saved.attendance))
        invariant(
          Object.hasOwn(d.workersRequired ?? {}, type) &&
            Number.isSafeInteger(count) &&
            count >= 0 &&
            count <= d.workersRequired![type]!,
          'invalid saved attendance count or type',
        );
      const slots = d.workerSlots;
      invariant(
        Array.isArray(saved.workerSlots) && saved.workerSlots.length === slots,
        'invalid saved worker slots',
      );
      for (const [slot, w] of saved.workerSlots.entries())
        if (w !== null) {
          invariant(
            !w.id.startsWith('facility-') ||
              w.id === `${saved.id}.worker-${slot}`,
            'invalid generated worker identity',
          );
          invariant(
            typeof w.id === 'string' &&
              w.id.length > 0 &&
              !workers.has(w.id) &&
              Number.isFinite(w.efficiency) &&
              w.efficiency >= 0 &&
              w.efficiency <= 100,
            'invalid or duplicate saved worker',
          );
          workers.add(w.id);
        }
      invariant(
        saved.modifiers &&
          typeof saved.modifiers === 'object' &&
          !Array.isArray(saved.modifiers),
        'invalid saved modifiers',
      );
      for (const [source, m] of Object.entries(saved.modifiers)) {
        invariant(
          source.length > 0 &&
            !['__proto__', 'constructor', 'prototype'].includes(source) &&
            m &&
            Number.isFinite(m.productivityMultiplier ?? 1) &&
            (m.productivityMultiplier ?? 1) >= 0 &&
            (m.productivityMultiplier ?? 1) <= 100,
          'invalid saved modifier',
        );
        validateAttributes(m.attributeBonuses ?? {}, 1e12);
      }
      invariant(
        Array.isArray(saved.jobs) && saved.jobs.length === d.recipes.length,
        'invalid saved jobs',
      );
      const f: Facility = {
        ...saved,
        rate: 0,
        jobs: [],
        attendanceReady: false,
      };
      f.attendanceReady = s.#attendanceSatisfied(f);
      f.rate = s.#calculateProductivity(f);
      invariant(
        Number.isFinite(f.rate) && f.rate <= 1e6,
        'saved productivity overflow',
      );
      for (let index = 0; index < saved.jobs.length; index++) {
        const j = saved.jobs[index]!;
        const recipe = s.registry.recipe(j.recipeId);
        invariant(
          j.recipeId === d.recipes[index] &&
            j.id === `${f.id}.job-${index}` &&
            !jobIds.has(j.id),
          'invalid saved job identity',
        );
        jobIds.add(j.id);
        const durationTicks =
          (recipe.durationSeconds * 1e6) / s.registry.tickMicroseconds;
        finite(j.elapsedTicks);
        finite(j.deferredWork);
        integer(j.completed);
        integer(j.demandOrder);
        invariant(
          j.elapsedTicks <= durationTicks &&
            typeof j.active === 'boolean' &&
            [
              'drained',
              'waiting-inputs',
              'producing',
              'output-blocked',
              'paused',
              'waiting-condition',
              'waiting-workers',
            ].includes(j.state),
          'invalid saved job state',
        );
        for (const inputs of [j.optionalInputs, j.batchOptionalInputs]) {
          s.registry.validate(inputs, 'saved optional inputs');
          for (const [id, n] of Object.entries(inputs))
            invariant(
              n === 0 || n === recipe.optionalInputs?.[id],
              'invalid saved optional ingredient',
            );
        }
        for (const tick of [j.readySince, j.demandSince])
          if (tick !== null) {
            integer(tick, 1);
            invariant(tick <= state.tick, 'saved job timestamp in future');
          }
        invariant(
          j.demandOrder <= state.demandOrder &&
            (!j.active || j.demandSince === null),
          'invalid saved demand order',
        );
        if (j.demandOrder > 0) {
          invariant(
            !demandOrders.has(j.demandOrder),
            'duplicate saved demand order',
          );
          demandOrders.add(j.demandOrder);
        }
        invariant(
          (j.readySince !== null) === (j.outcome !== null) &&
            (j.active ||
              (j.readySince === null &&
                j.elapsedTicks === 0 &&
                j.deferredWork === 0)),
          'inconsistent saved batch phase',
        );
        if (j.outcome) {
          invariant(
            j.active &&
              j.elapsedTicks === durationTicks &&
              j.deferredWork === 0,
            'invalid saved completed batch',
          );
          outcome(j.outcome);
          own(j.outcome.items);
          if (s.#individualInputRecipes.size)
            for (const item of j.outcome.items)
              physicalItems.set(item.id, item);
          const expected = resolveOutcome(
            s.#seed,
            j.id,
            j.completed,
            recipe,
            j.batchOptionalInputs,
            {},
            s.#individualResources,
          );
          invariant(
            sameQuantities(j.outcome.quantities, expected.quantities),
            'saved outcome does not match deterministic batch manifest',
          );
          invariant(
            JSON.stringify(j.outcome.items.map((i) => [i.id, i.resourceId])) ===
              JSON.stringify(expected.items.map((i) => [i.id, i.resourceId])),
            'invalid saved produced identity',
          );
          for (const item of j.outcome.items)
            invariant(
              sameKeys(
                item.attributes,
                recipe.itemAttributes?.[item.resourceId] ?? {},
              ),
              'invalid manufactured attribute keys',
            );
        } else
          invariant(
            !j.active || j.elapsedTicks < durationTicks,
            'saved active job already complete',
          );
        if (reservationOwners.has(j.id)) {
          invariant(
            !j.active &&
              !f.draining &&
              f.enabled &&
              f.attendanceReady &&
              Object.values(f.conditions).every(Boolean) &&
              f.rate > 0 &&
              j.demandSince !== null,
            'inactive saved reservation owner',
          );
          const required = { ...recipe.inputs };
          for (const [id, n] of Object.entries(j.optionalInputs))
            required[id] = (required[id] ?? 0) + n;
          const held = s.#ownedInventory(f.inputInventoryId).reservation(j.id);
          invariant(
            Object.entries(held).every(([id, n]) => n <= (required[id] ?? 0)),
            'saved allocation exceeds request',
          );
          const r = savedReservations.get(j.id)!.reservation;
          invariant(
            r.itemIds.every((id) => j.inputItemIds.includes(id)),
            'saved job holds unselected items',
          );
          takeReservation(j.id, f.inputInventoryId, held, r.itemIds);
        }
        invariant(
          Array.isArray(j.inputItemIds) &&
            j.inputItemIds.every(
              (id) => typeof id === 'string' && reference(id),
            ) &&
            new Set(j.inputItemIds).size === j.inputItemIds.length &&
            Array.isArray(j.batchInputItems),
          'invalid saved input item selection',
        );
        // Selected identities may have moved or been consumed since selection; they remain an explicit waiting request.
        invariant(
          j.inputItemResources &&
            typeof j.inputItemResources === 'object' &&
            !Array.isArray(j.inputItemResources) &&
            sameKeys(
              j.inputItemResources,
              Object.fromEntries(j.inputItemIds.map((id) => [id, true])),
            ),
          'invalid selected item resource map',
        );
        const selectedCounts: Record<string, number> = Object.create(
          null,
        ) as Record<string, never>;
        for (const id of j.inputItemIds) {
          const resourceId = j.inputItemResources[id]!;
          reference(id, resourceId);
          invariant(
            s.#individualResources.has(resourceId),
            'selected input requires individual resource',
          );
          const item = physicalItems.get(id);
          invariant(
            !item || item.resourceId === resourceId,
            'selected item resource mismatch',
          );
          selectedCounts[resourceId] = (selectedCounts[resourceId] ?? 0) + 1;
        }
        const job = { ...j, recipe, durationTicks };
        invariant(
          !j.inputItemIds.length ||
            sameQuantities(selectedCounts, s.#individualInputs(job)),
          'saved selection differs from recipe inputs',
        );
        if (j.batchInputItems.length) {
          invariant(j.active, 'idle job retains consumed item records');
          const quantities: Record<string, number> = Object.create(
            null,
          ) as Record<string, never>;
          for (const item of j.batchInputItems) {
            invariant(
              reference(item.id, item.resourceId),
              'unissued consumed input identity',
            );
            quantities[item.resourceId] =
              (quantities[item.resourceId] ?? 0) + 1;
          }
          outcome({ quantities, items: j.batchInputItems });
          const expected = { ...recipe.inputs };
          for (const [id, n] of Object.entries(j.batchOptionalInputs))
            expected[id] = (expected[id] ?? 0) + n;
          invariant(
            sameQuantities(
              quantities,
              Object.fromEntries(
                Object.entries(expected).filter(([id]) =>
                  s.#individualResources.has(id),
                ),
              ),
            ),
            'consumed input manifest mismatch',
          );
        } else
          invariant(
            !j.active ||
              ![
                ...Object.entries(recipe.inputs),
                ...Object.entries(j.batchOptionalInputs),
              ].some(([id, n]) => n > 0 && s.#individualResources.has(id)),
            'missing consumed input items',
          );
        f.jobs.push(job);
      }
      s.#facilities.push(f);
      s.#facilityIndex.set(f.id, f);
      for (const j of f.jobs) s.#productionJobs.set(j.id, j);
    }
    invariant(
      Array.isArray(state.retiredFacilities),
      'invalid retired facilities',
    );
    const retiredIndex = new Map<string, RetiredFacilitySave>();
    for (const f of state.retiredFacilities) {
      const d = s.registry.facility(f.definitionId),
        match = /^facility-([1-9][0-9]*)$/.exec(f.id);
      invariant(
        match && !s.#facilityIndex.has(f.id) && !retiredIndex.has(f.id),
        'invalid retired facility identity',
      );
      integer(Number(match[1]), 1);
      maxFacility = Math.max(maxFacility, Number(match[1]));
      retiredIndex.set(f.id, f);
      invariant(
        Array.isArray(f.jobs) && f.jobs.length === d.recipes.length,
        'invalid retired jobs',
      );
      f.jobs.forEach((j, index) => {
        invariant(
          j.id === `${f.id}.job-${index}` && j.recipeId === d.recipes[index],
          'invalid retired job identity',
        );
        integer(j.completed);
      });
      s.#retiredFacilities.push(f);
    }
    for (const f of s.#retiredFacilities)
      for (const j of f.jobs)
        s.#productionJobs.set(j.id, {
          id: j.id,
          completed: j.completed,
          recipe: s.registry.recipe(j.recipeId),
          outcome: null,
        });
    // Aggregate construction effects once; avoid scanning all factories per inventory.
    const capacityByInventory = new Map<string, number>();
    const workforceByInventory = new Map<
      string,
      Record<string, { total: number; assigned: number }>
    >();
    for (const f of s.#facilities) {
      let expected = workforceByInventory.get(f.inventoryId);
      if (!expected) {
        expected = Object.create(null) as Record<
          string,
          { total: number; assigned: number }
        >;
        workforceByInventory.set(f.inventoryId, expected);
      }
      const definition = s.registry.facility(f.definitionId);
      const capacity =
        (capacityByInventory.get(f.inventoryId) ?? 0) +
        (definition.capacityProvided ?? 0);
      invariant(Number.isSafeInteger(capacity), 'saved capacity overflow');
      capacityByInventory.set(f.inventoryId, capacity);
      for (const id of new Set([
        ...Object.keys(definition.workersProvided ?? {}),
        ...Object.keys(definition.workersRequired ?? {}),
      ])) {
        const people = expected[id] ?? { total: 0, assigned: 0 };
        people.total += definition.workersProvided?.[id] ?? 0;
        people.assigned += definition.workersRequired?.[id] ?? 0;
        invariant(
          Number.isSafeInteger(people.total) &&
            Number.isSafeInteger(people.assigned),
          'saved workforce overflow',
        );
        expected[id] = people;
      }
    }
    for (const inventory of s.#inventories.values()) {
      const expected: Record<string, { total: number; assigned: number }> =
        workforceByInventory.get(inventory.id) ??
        (Object.create(null) as Record<string, never>);
      invariant(
        inventory.capacityPerMaterial >=
          (capacityByInventory.get(inventory.id) ?? 0),
        'saved capacity conflicts with construction effects',
      );
      const actual = inventory.summary().workforce;
      invariant(
        sameKeys(actual, expected) &&
          Object.entries(expected).every(
            ([id, v]) =>
              actual[id]?.total === v.total &&
              actual[id]?.assigned === v.assigned,
          ),
        'saved workforce conflicts with facility construction',
      );
    }
    invariant(
      Array.isArray(state.constructionOrders),
      'invalid saved construction orders',
    );
    let maxConstruction = 0;
    const completedFacilities = new Set<string>();
    for (const o of state.constructionOrders) {
      const match = /^construction-([1-9][0-9]*)$/.exec(o.id);
      invariant(
        match && !s.#constructionOrders.has(o.id),
        'invalid or duplicate construction identity',
      );
      integer(Number(match[1]), 1);
      invariant(
        Number(match[1]) > maxConstruction,
        'construction orders not in creation order',
      );
      maxConstruction = Number(match[1]);
      integer(o.durationMicroseconds, 1);
      integer(o.elapsedMicroseconds);
      invariant(
        o.elapsedMicroseconds <= o.durationMicroseconds &&
          [
            'waiting-materials',
            'building',
            'awaiting-activation',
            'completed',
            'cancelled',
          ].includes(o.state),
        'invalid saved construction progress',
      );
      const definition = s.registry.facility(o.definitionId),
        terminal = o.state === 'completed' || o.state === 'cancelled';
      invariant(
        [o.inventoryId, o.inputInventoryId, o.outputInventoryId].every(
          (id) => typeof id === 'string' && id.length > 0,
        ),
        'invalid construction endpoint',
      );
      s.registry.validate(
        o.consumedMaterials,
        'construction consumed materials',
      );
      if (!terminal) {
        s.#ownedInventory(o.inventoryId);
        s.#ownedInventory(o.inputInventoryId);
        s.#ownedInventory(o.outputInventoryId);
        invariant(
          o.facilityId === null && sameQuantities(o.consumedMaterials, {}),
          'uncompleted construction charged materials or owns facility',
        );
        const record = savedReservations.get(o.id),
          held = record?.reservation.quantities ?? {};
        invariant(
          !record ||
            (record.inventoryId === o.inventoryId &&
              record.reservation.itemIds.length === 0),
          'misplaced construction reservation',
        );
        invariant(
          Object.entries(held).every(
            ([id, n]) => n <= (definition.constructionCost[id] ?? 0),
          ),
          'construction reservation exceeds cost',
        );
        if (o.state === 'waiting-materials')
          invariant(
            o.elapsedMicroseconds === 0,
            'waiting construction retains progress',
          );
        else {
          invariant(
            record && sameQuantities(held, definition.constructionCost),
            'building lacks reserved construction materials',
          );
          invariant(
            o.state === 'building'
              ? o.elapsedMicroseconds > 0 &&
                  o.elapsedMicroseconds < o.durationMicroseconds
              : o.elapsedMicroseconds === o.durationMicroseconds,
            'inconsistent construction phase',
          );
        }
        if (record) takeReservation(o.id, o.inventoryId, held);
      } else {
        invariant(
          !reservationOwners.has(o.id),
          'terminal construction retains reservation',
        );
        if (o.state === 'cancelled')
          invariant(
            o.facilityId === null && sameQuantities(o.consumedMaterials, {}),
            'cancelled construction charged materials',
          );
        else {
          invariant(
            typeof o.facilityId === 'string' &&
              !completedFacilities.has(o.facilityId) &&
              o.elapsedMicroseconds === o.durationMicroseconds &&
              sameQuantities(o.consumedMaterials, definition.constructionCost),
            'invalid completed construction association or charge',
          );
          const live = s.#facilityIndex.get(o.facilityId),
            retired = retiredIndex.get(o.facilityId);
          invariant(
            (live ?? retired)?.definitionId === o.definitionId,
            'construction facility is absent or mismatched',
          );
          if (live)
            invariant(
              live.inventoryId === o.inventoryId &&
                live.inputInventoryId === o.inputInventoryId &&
                live.outputInventoryId === o.outputInventoryId,
              'construction activation endpoints mismatch',
            );
          completedFacilities.add(o.facilityId);
        }
      }
      s.#constructionOrders.set(o.id, o);
      if (!terminal) s.#pendingConstruction.set(o.id, o);
    }
    invariant(
      state.nextConstruction > maxConstruction,
      'construction counter would collide',
    );
    s.#nextConstruction = state.nextConstruction;
    for (const d of state.deliveries) {
      const idNumber = /^delivery-([1-9][0-9]*)$/.exec(d.id)?.[1];
      invariant(
        idNumber && !s.#deliveries.has(d.id),
        'invalid or duplicate saved delivery',
      );
      integer(Number(idNumber), 1);
      maxDelivery = Math.max(maxDelivery, Number(idNumber));
      s.#ownedInventory(d.sourceInventoryId);
      s.#ownedInventory(d.destinationInventoryId);
      invariant(
        d.sourceInventoryId !== d.destinationInventoryId &&
          [
            'reserved',
            'in-transit',
            'arrival-blocked',
            'delivered',
            'cancelled',
          ].includes(d.state),
        'invalid saved delivery state',
      );
      s.registry.validate(d.quantities, 'saved cargo');
      invariant(
        Object.values(d.quantities).some((n) => n > 0) &&
          Array.isArray(d.itemIds) &&
          d.itemIds.every((id) => typeof id === 'string' && reference(id)) &&
          new Set(d.itemIds).size === d.itemIds.length &&
          Array.isArray(d.items),
        'invalid saved cargo identities',
      );
      if (d.state === 'reserved') {
        invariant(d.items.length === 0, 'reserved cargo must remain at source');
        takeReservation(
          `logistics:${d.id}`,
          d.sourceInventoryId,
          d.quantities,
          d.itemIds,
        );
      } else if (d.state === 'in-transit' || d.state === 'arrival-blocked') {
        outcome({ quantities: d.quantities, items: d.items });
        own(d.items);
        if (s.#individualInputRecipes.size)
          for (const item of d.items) physicalItems.set(item.id, item);
        invariant(
          JSON.stringify(d.items.map((i) => i.id)) ===
            JSON.stringify(d.itemIds),
          'saved manifest identity mismatch',
        );
      } else {
        // Terminal item records are historical copies, not physical owners.
        for (const item of d.items) reference(item.id, item.resourceId);
        if (d.items.length) {
          outcome({ quantities: d.quantities, items: d.items });
          invariant(
            JSON.stringify(d.items.map((i) => i.id)) ===
              JSON.stringify(d.itemIds),
            'invalid historical item manifest',
          );
        }
      }
      s.#deliveries.set(d.id, d);
      if (['reserved', 'in-transit', 'arrival-blocked'].includes(d.state))
        s.#indexIncoming(d, 1);
    }
    for (const f of s.#facilities)
      for (const j of f.jobs)
        for (const id of j.inputItemIds) {
          const item = physicalItems.get(id);
          invariant(
            !item || item.resourceId === j.inputItemResources[id],
            'selected item resource mismatch',
          );
        }
    const consumedIds = new Set<string>();
    for (const f of s.#facilities)
      for (const j of f.jobs)
        for (const item of j.batchInputItems) {
          invariant(
            !owners.has(item.id) && !consumedIds.has(item.id),
            'consumed input still has a physical owner or duplicate batch history',
          );
          consumedIds.add(item.id);
        }
    const manifests = new Map<string, Quantities>();
    for (const id of referencedIds)
      invariant(
        s.#wasIssued(id, manifests, referencedResources.get(id)),
        'unissued saved item identity or invalid batch provenance',
      );
    invariant(reservationOwners.size === 0, 'orphan saved reservation');
    invariant(
      state.nextId > maxFacility && state.nextDelivery > maxDelivery,
      'saved ID counter would collide',
    );
    s.#tick = state.tick;
    s.#pendingMicroseconds = state.pendingMicroseconds;
    s.#timeCompensation = state.timeCompensation;
    s.#nextId = state.nextId;
    s.#nextDelivery = state.nextDelivery;
    s.#demandOrder = state.demandOrder;
    return s;
  }
  summary(): SimulationSummary {
    return {
      tick: this.#tick,
      timeSeconds: (this.#tick * this.registry.tickMicroseconds) / 1e6,
      pendingSeconds: this.#pendingMicroseconds / 1e6,
      facilityCount: this.#facilities.length,
      inventoryCount: this.#inventories.size,
      deliveryCount: this.#deliveries.size,
    };
  }
  inventoryIds(): string[] {
    return [...this.#inventories.keys()];
  }
  deliveryIds(): string[] {
    return [...this.#deliveries.keys()];
  }
  facilityIds(): string[] {
    return this.#facilities.map((f) => f.id);
  }
  facilitySnapshot(id: string): FacilitySnapshot {
    return this.#facilitySnapshot(this.#facility(id));
  }
  #facilitySnapshot(f: Facility): FacilitySnapshot {
    return {
      id: f.id,
      definitionId: f.definitionId,
      inventoryId: f.inventoryId,
      inputInventoryId: f.inputInventoryId,
      outputInventoryId: f.outputInventoryId,
      enabled: f.enabled,
      draining: f.draining,
      conditions: { ...f.conditions },
      attendance: { ...f.attendance },
      missingWorkforce: this.#missingAttendance(f),
      workerSlots: cloneData(f.workerSlots),
      modifiers: cloneData(f.modifiers),
      productivity: f.rate,
      jobs: f.jobs.map((j) => ({
        id: j.id,
        recipeId: j.recipe.id,
        state: j.state,
        progress: j.elapsedTicks / j.durationTicks,
        batchesCompleted: j.completed,
        missingInputs: j.active ? {} : this.#missingInputs(f, j),
        selectedInputItemIds: [...j.inputItemIds],
        batchInputItems: cloneData(j.batchInputItems),
        reservedInputs: {
          ...this.#ownedInventory(f.inputInventoryId).reservation(j.id),
        },
        demandSinceTick: j.demandSince,
        selectedOptionalInputs: { ...j.optionalInputs },
        pendingOutcome: j.outcome ? cloneData(j.outcome) : null,
      })),
    };
  }
  snapshot(): SimulationSnapshot {
    const facilities = this.#facilities.map((f) => this.#facilitySnapshot(f));
    return {
      ...(this.#inventoryAttachments.size
        ? {
            inventoryAttachments: [...this.#inventoryAttachments.values()].map(
              (a) => ({ ...a }),
            ),
          }
        : {}),
      tick: this.#tick,
      timeSeconds: (this.#tick * this.registry.tickMicroseconds) / 1e6,
      pendingSeconds: this.#pendingMicroseconds / 1e6,
      inventories: [...this.#inventories.values()].map((i) => i.snapshot()),
      facilities,
      constructionOrders: [...this.#constructionOrders.keys()].map((id) =>
        this.constructionOrderSnapshot(id),
      ),
      deliveries: [...this.#deliveries.values()].map((d) => cloneData(d)),
    };
  }
}

function sameKeys(a: object, b: object): boolean {
  return (
    JSON.stringify(Object.keys(a).sort()) ===
    JSON.stringify(Object.keys(b).sort())
  );
}
function sameQuantities(a: Quantities, b: Quantities): boolean {
  return [...new Set([...Object.keys(a), ...Object.keys(b)])].every(
    (id) => (a[id] ?? 0) === (b[id] ?? 0),
  );
}
