import { Simulation } from './simulation.js';
import { invariant } from './registry.js';

/** Structural MCP subset: no transport, SDK dependency or engine ownership. */
export interface TelemetryBinding {
  readonly scope: string;
  readonly isCurrent: () => boolean;
}
export interface TelemetryContext {
  readonly binding: TelemetryBinding;
  readonly signal: { readonly aborted: boolean };
}
export interface TelemetryTool {
  name: string;
  description: string;
  inputSchema: {
    type: 'object';
    properties: Record<string, object>;
    additionalProperties: false;
    required?: string[];
  };
  annotations: {
    readOnlyHint: true;
    destructiveHint: false;
    idempotentHint: true;
    openWorldHint: false;
  };
}
export interface TelemetryResult {
  [key: string]: unknown;
  content: { type: 'text'; text: string }[];
  structuredContent: Record<string, unknown>;
}
export interface TelemetryProvider {
  readonly id: string;
  tools(binding: TelemetryBinding): readonly TelemetryTool[];
  call(
    name: string,
    args: Readonly<Record<string, unknown>>,
    context: TelemetryContext,
  ): TelemetryResult;
}
/** Resolve the complete simulation this authenticated binding is allowed to inspect. */
export interface TelemetryOptions {
  readonly id: string;
  readonly resolveSimulation: (binding: TelemetryBinding) => Simulation | null;
}
const integer = { type: 'integer', minimum: 0 };
const page = {
  offset: integer,
  limit: { type: 'integer', minimum: 1, maximum: 100 },
};
const id = { type: 'string', minLength: 1 };
function tool(
  name: string,
  description: string,
  properties: Record<string, object>,
  required: string[] = [],
): TelemetryTool {
  return {
    name,
    description,
    inputSchema: {
      type: 'object',
      properties,
      additionalProperties: false,
      required,
    },
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  };
}
const kinds = [
  'inventories',
  'facilities',
  'construction',
  'deliveries',
] as const;
const definitions = ['resources', 'recipes', 'facilities'] as const;
const tools = [
  tool(
    'production_summary',
    'Read simulation tick/time and entity counts. Time is simulation seconds; this read does not advance time. Counts include retained history.',
    {},
  ),
  tool(
    'production_list',
    'Page entity IDs in insertion order. Offset pages are live reads, not a retained snapshot.',
    { kind: { type: 'string', enum: kinds }, ...page },
    ['kind'],
  ),
  tool(
    'production_catalogue',
    'Page registered resource, recipe or facility definitions. Recipe duration is nominal work seconds, not a guaranteed delivery time.',
    { kind: { type: 'string', enum: definitions }, ...page },
    ['kind'],
  ),
  tool(
    'production_facility',
    'Read one facility: pause/drain, reported attendance, effective productivity and jobs. Include job explanations for current blockers and conditional estimates; no guaranteed throughput claim.',
    { id },
    ['id'],
  ),
  tool(
    'production_inventory',
    'Read inventory quantities, reservations, workforce allocation and item counts. Workforce allocation is not on-site attendance; goods here are arrived, not inbound commitments.',
    { id },
    ['id'],
  ),
  tool(
    'production_object_inventories',
    'Page inventory attachments for an application object ID. Named slots are associations, not storage slots or access permissions. Unknown objects return an empty page.',
    { objectId: id, ...page },
    ['objectId'],
  ),
  tool(
    'production_items',
    'Page individual inventory goods with their identities, provenance and quality attributes. In-transit and pending-output goods are read through their delivery/facility.',
    { id, resourceId: id, ...page },
    ['id'],
  ),
  tool(
    'production_construction',
    'Read one construction order: material holdings, missing materials, blockers, progress and completion association. Incoming deliveries are not arrived materials.',
    { id },
    ['id'],
  ),
  tool(
    'production_delivery',
    'Read one delivery and its cargo, item identities and state. Workshop does not know travel distance, destination reachability or arrival time.',
    { id },
    ['id'],
  ),
];
function number(
  args: Readonly<Record<string, unknown>>,
  key: string,
  fallback: number,
  min: number,
  max: number,
): number {
  const value = args[key] === undefined ? fallback : args[key];
  invariant(
    Number.isSafeInteger(value) &&
      (value as number) >= min &&
      (value as number) <= max,
    `Invalid ${key}`,
  );
  return value as number;
}
function textArg(args: Readonly<Record<string, unknown>>, key: string): string {
  const value = args[key];
  invariant(typeof value === 'string' && value.length > 0, `Invalid ${key}`);
  return value;
}
function windowOf<T>(
  values: readonly T[],
  args: Readonly<Record<string, unknown>>,
): { entries: T[]; total: number; offset: number; limit: number } {
  const offset = number(args, 'offset', 0, 0, Number.MAX_SAFE_INTEGER),
    limit = number(args, 'limit', 50, 1, 100);
  return {
    entries: values.slice(offset, offset + limit),
    total: values.length,
    offset,
    limit,
  };
}
/** UTF-8 length including replacement encoding for unpaired UTF-16 surrogates. */
function bytes(text: string): number {
  let count = 0;
  for (const char of text) {
    const cp = char.codePointAt(0)!;
    count += cp < 128 ? 1 : cp < 2048 ? 2 : cp < 65536 ? 3 : 4;
  }
  return count;
}
export function createProductionTelemetryProvider(
  options: TelemetryOptions,
): TelemetryProvider {
  invariant(
    typeof options.id === 'string' && options.id.length > 0,
    'Telemetry provider needs an id',
  );
  const providerId = options.id,
    resolve = options.resolveSimulation;
  function simulation(binding: TelemetryBinding): Simulation {
    invariant(binding.isCurrent(), 'Stale telemetry binding');
    const sim = resolve(binding);
    invariant(sim instanceof Simulation, 'Telemetry scope unavailable');
    return sim;
  }
  return {
    id: providerId,
    tools(binding) {
      simulation(binding);
      return JSON.parse(JSON.stringify(tools)) as TelemetryTool[];
    },
    call(name, args, context) {
      invariant(!context.signal.aborted, 'Telemetry call aborted');
      const sim = simulation(context.binding),
        spec = tools.find((t) => t.name === name);
      invariant(spec, 'Unknown telemetry tool');
      invariant(
        args !== null && typeof args === 'object' && !Array.isArray(args),
        'Expected arguments object',
      );
      invariant(
        Object.keys(args).every((key) =>
          Object.hasOwn(spec.inputSchema.properties, key),
        ),
        'Unknown telemetry argument',
      );
      for (const key of spec.inputSchema.required ?? [])
        invariant(Object.hasOwn(args, key), `Missing ${key}`);
      let data: unknown;
      switch (name) {
        case 'production_summary':
          data = {
            ...sim.summary(),
            inventoryEventSequence: sim.inventoryEventSequence(),
          };
          break;
        case 'production_list': {
          const kind = textArg(args, 'kind');
          invariant(
            (kinds as readonly string[]).includes(kind),
            'Invalid entity kind',
          );
          const ids =
            kind === 'inventories'
              ? sim.inventoryIds()
              : kind === 'facilities'
                ? sim.facilityIds()
                : kind === 'construction'
                  ? sim.constructionOrderIds()
                  : sim.deliveryIds();
          data = windowOf(ids, args);
          break;
        }
        case 'production_catalogue': {
          const kind = textArg(args, 'kind');
          invariant(
            (definitions as readonly string[]).includes(kind),
            'Invalid definition kind',
          );
          data = windowOf<unknown>(
            kind === 'resources'
              ? sim.registry.resources
              : kind === 'recipes'
                ? sim.registry.recipes
                : sim.registry.facilities,
            args,
          );
          break;
        }
        case 'production_facility': {
          const facility = sim.facilitySnapshot(textArg(args, 'id'));
          data = {
            ...facility,
            explanations: facility.jobs.map((job) => sim.explainJob(job.id)),
          };
          break;
        }
        case 'production_inventory':
          data = {
            ...sim.inventory(textArg(args, 'id')).summary(),
            attachment: sim.inventoryAttachment(textArg(args, 'id')),
          };
          break;
        case 'production_object_inventories':
          data = windowOf(
            sim.objectInventories(textArg(args, 'objectId')),
            args,
          );
          break;
        case 'production_items': {
          const resourceId =
            args.resourceId === undefined
              ? undefined
              : textArg(args, 'resourceId');
          data = sim.inventory(textArg(args, 'id')).itemPage({
            offset: number(args, 'offset', 0, 0, Number.MAX_SAFE_INTEGER),
            limit: number(args, 'limit', 50, 1, 100),
            ...(resourceId === undefined ? {} : { resourceId }),
          });
          break;
        }
        case 'production_construction':
          data = sim.constructionOrderSnapshot(textArg(args, 'id'));
          break;
        case 'production_delivery':
          data = sim.deliverySnapshot(textArg(args, 'id'));
          break;
      }
      // Serialize once: bounds the response and detaches immutable registry definitions too.
      const encoded = JSON.stringify({
        status: 'completed',
        tick: sim.summary().tick,
        data,
      });
      invariant(
        bytes(encoded) <= 65536,
        'Telemetry result exceeds 64 KiB; use smaller pages',
      );
      return {
        content: [{ type: 'text', text: encoded }],
        structuredContent: JSON.parse(encoded) as Record<string, unknown>,
      };
    },
  };
}
