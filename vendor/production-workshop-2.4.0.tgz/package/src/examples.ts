import { Simulation } from './simulation.js';
import { settlementConfiguration } from './settlement-content.js';
import type { Configuration } from './models.js';
export { settlementConfiguration } from './settlement-content.js';
export const shipConfiguration = {
  seed: 42,
  resources: [
    { id: 'credits', label: 'Credits', kind: 'currency' },
    { id: 'ore', label: 'Ore', kind: 'material' },
    { id: 'silica', label: 'Silica', kind: 'material' },
    { id: 'alloy', label: 'Alloy', kind: 'material' },
    { id: 'circuit', label: 'Circuit', kind: 'material' },
    { id: 'sensor', label: 'Advanced Sensor', kind: 'material' },
    {
      id: 'weapon',
      label: 'Ship weapon',
      kind: 'material',
      storage: 'individual',
    },
    { id: 'reinforcement', label: 'Reinforcement', kind: 'material' },
  ],
  recipes: [
    {
      id: 'refine',
      label: 'Refine alloy',
      durationSeconds: 1,
      inputs: { ore: 2 },
      outputs: { alloy: 1 },
    },
    {
      id: 'circuits',
      label: 'Print circuits',
      durationSeconds: 1.5,
      inputs: { silica: 1, alloy: 1 },
      outputs: { circuit: 2 },
    },
    {
      id: 'sensors',
      label: 'Fabricate sensors',
      durationSeconds: 2,
      inputs: { alloy: 1, circuit: 2 },
      outputs: { sensor: 1 },
    },
    {
      id: 'weapons',
      label: 'Fabricate weapon',
      durationSeconds: 4,
      inputs: { alloy: 1, circuit: 1 },
      outputs: { weapon: 1 },
      itemAttributes: {
        weapon: {
          maxHealth: { min: 80, max: 90 },
          precision: { min: 0.8, max: 0.9 },
        },
      },
      optionalInputs: { reinforcement: 1 },
      optionalAttributeBonuses: { reinforcement: { maxHealth: 10 } },
    },
  ],
  // Quality is item data, never a separate resource ID for each quality tier.
  facilities: [
    {
      id: 'refinery',
      label: 'Onboard Refinery',
      category: 'module',
      recipes: ['refine'],
      constructionCost: { credits: 50 },
    },
    {
      id: 'circuit-printer',
      label: 'Circuit Printer',
      category: 'module',
      recipes: ['circuits'],
      constructionCost: { credits: 75 },
    },
    {
      id: 'fabricator',
      label: 'Sensor Fabricator',
      category: 'module',
      recipes: ['sensors'],
      constructionCost: { credits: 100 },
    },
    {
      id: 'weapon-fabricator',
      label: 'Weapon Fabricator',
      category: 'module',
      recipes: ['weapons'],
      constructionCost: { credits: 50 },
    },
  ],
} satisfies Configuration;
export function createSettlement(): Simulation {
  const sim = new Simulation({
    ...settlementConfiguration,
    seed: 42,
    resources: [
      ...settlementConfiguration.resources,
      { id: 'diamond', label: 'Diamond', kind: 'material' },
    ],
    recipes: settlementConfiguration.recipes.map((r) =>
      r.id === 'coal-mine.recipe-0'
        ? { ...r, bonusOutputs: [{ chance: 0.01, outputs: { diamond: 1 } }] }
        : r,
    ),
  });
  sim.createInventory({
    id: 'settlement',
    capacityPerMaterial: 20,
    initial: { timber: 10, 'steel-beam': 10, credits: 1000 },
  });
  for (const id of ['farmer-residence', 'forester', 'sawmill']) {
    const result = sim.addFacility(id, 'settlement');
    if (!result.ok) throw new Error(result.reason);
    sim.setFacilityAttendance(
      result.facilityId,
      sim.registry.facility(id).workersRequired ?? {},
    );
  }
  return sim;
}
export function createShip(): Simulation {
  const sim = new Simulation(shipConfiguration);
  sim.createInventory({
    id: 'ship',
    capacityPerMaterial: 100,
    initial: { ore: 60, silica: 20, reinforcement: 10, credits: 1000 },
  });
  for (const id of [
    'refinery',
    'circuit-printer',
    'fabricator',
    'weapon-fabricator',
  ]) {
    const result = sim.addFacility(id, 'ship');
    if (!result.ok) throw new Error(result.reason);
    sim.setFacilityAttendance(
      result.facilityId,
      sim.registry.facility(id).workersRequired ?? {},
    );
  }
  return sim;
}
