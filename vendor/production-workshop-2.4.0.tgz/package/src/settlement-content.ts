import type { Configuration } from './models.js';
/** Converted from the archived Settings.js. Original recipes retained; effective durations are 20× faster. */
export const settlementConfiguration = {
  resources: [
    {
      id: 'credits',
      label: 'Credits',
      kind: 'currency',
    },
    {
      id: 'timber',
      label: 'Timber',
      kind: 'material',
    },
    {
      id: 'steel-beam',
      label: 'Steel Beam',
      kind: 'material',
    },
    {
      id: 'log',
      label: 'Log',
      kind: 'material',
    },
    {
      id: 'fish',
      label: 'Fish',
      kind: 'material',
    },
    {
      id: 'potato',
      label: 'Potato',
      kind: 'material',
    },
    {
      id: 'schnapps',
      label: 'Schnapps',
      kind: 'material',
    },
    {
      id: 'wool',
      label: 'Wool',
      kind: 'material',
    },
    {
      id: 'cloth',
      label: 'Cloth',
      kind: 'material',
    },
    {
      id: 'clay',
      label: 'Clay',
      kind: 'material',
    },
    {
      id: 'brick',
      label: 'Brick',
      kind: 'material',
    },
    {
      id: 'pig',
      label: 'Pig',
      kind: 'material',
    },
    {
      id: 'sausage',
      label: 'Sausage',
      kind: 'material',
    },
    {
      id: 'grain',
      label: 'Grain',
      kind: 'material',
    },
    {
      id: 'flour',
      label: 'Flour',
      kind: 'material',
    },
    {
      id: 'bread',
      label: 'Bread',
      kind: 'material',
    },
    {
      id: 'iron',
      label: 'Iron',
      kind: 'material',
    },
    {
      id: 'coal',
      label: 'Coal',
      kind: 'material',
    },
    {
      id: 'steel',
      label: 'Steel',
      kind: 'material',
    },
    {
      id: 'tallow',
      label: 'Tallow',
      kind: 'material',
    },
    {
      id: 'soap',
      label: 'Soap',
      kind: 'material',
    },
    {
      id: 'hop',
      label: 'Hop',
      kind: 'material',
    },
    {
      id: 'malt',
      label: 'Malt',
      kind: 'material',
    },
    {
      id: 'beer',
      label: 'Beer',
      kind: 'material',
    },
    {
      id: 'quartz',
      label: 'Quartz',
      kind: 'material',
    },
    {
      id: 'glass',
      label: 'Glass',
      kind: 'material',
    },
    {
      id: 'window',
      label: 'Window',
      kind: 'material',
    },
    {
      id: 'beef',
      label: 'Beef',
      kind: 'material',
    },
    {
      id: 'pepper',
      label: 'Pepper',
      kind: 'material',
    },
    {
      id: 'goulash',
      label: 'Goulash',
      kind: 'material',
    },
    {
      id: 'canned-food',
      label: 'Canned Food',
      kind: 'material',
    },
    {
      id: 'machine',
      label: 'Machine',
      kind: 'material',
    },
    {
      id: 'cement',
      label: 'Cement',
      kind: 'material',
    },
    {
      id: 'concrete',
      label: 'Concrete',
      kind: 'material',
    },
  ],
  recipes: [
    {
      id: 'farmer-residence.recipe-0',
      label: 'Farmer Residence production',
      durationSeconds: 3,
      inputs: {},
      outputs: {
        credits: 1,
      },
    },
    {
      id: 'forester.recipe-0',
      label: 'Forester production',
      durationSeconds: 0.75,
      inputs: {},
      outputs: {
        log: 1,
      },
    },
    {
      id: 'sawmill.recipe-0',
      label: 'Sawmill production',
      durationSeconds: 0.75,
      inputs: {
        log: 1,
      },
      outputs: {
        timber: 1,
      },
    },
    {
      id: 'fishery.recipe-0',
      label: 'Fishery production',
      durationSeconds: 1.5,
      inputs: {},
      outputs: {
        fish: 1,
      },
    },
    {
      id: 'potato-farm.recipe-0',
      label: 'Potato Farm production',
      durationSeconds: 1.5,
      inputs: {},
      outputs: {
        potato: 1,
      },
    },
    {
      id: 'schnapps-distillery.recipe-0',
      label: 'Schnapps Distillery production',
      durationSeconds: 1.5,
      inputs: {
        potato: 1,
      },
      outputs: {
        schnapps: 1,
      },
    },
    {
      id: 'sheep-farm.recipe-0',
      label: 'Sheep Farm production',
      durationSeconds: 1.5,
      inputs: {},
      outputs: {
        wool: 1,
      },
    },
    {
      id: 'framework-knitters.recipe-0',
      label: 'Framework Knitters production',
      durationSeconds: 1.5,
      inputs: {
        wool: 1,
      },
      outputs: {
        cloth: 1,
      },
    },
    {
      id: 'worker-residence.recipe-0',
      label: 'Worker Residence production',
      durationSeconds: 3,
      inputs: {},
      outputs: {
        credits: 2,
      },
    },
    {
      id: 'clay-pit.recipe-0',
      label: 'Clay Pit production',
      durationSeconds: 1.5,
      inputs: {},
      outputs: {
        clay: 1,
      },
    },
    {
      id: 'brick-factory.recipe-0',
      label: 'Brick Factory production',
      durationSeconds: 3,
      inputs: {
        clay: 1,
      },
      outputs: {
        brick: 1,
      },
    },
    {
      id: 'pig-farm.recipe-0',
      label: 'Pig Farm production',
      durationSeconds: 3,
      inputs: {},
      outputs: {
        pig: 1,
      },
    },
    {
      id: 'slaughterhouse.recipe-0',
      label: 'Slaughterhouse production',
      durationSeconds: 3,
      inputs: {
        pig: 1,
      },
      outputs: {
        sausage: 1,
      },
    },
    {
      id: 'grain-farm.recipe-0',
      label: 'Grain Farm production',
      durationSeconds: 3,
      inputs: {},
      outputs: {
        grain: 1,
      },
    },
    {
      id: 'flour-mill.recipe-0',
      label: 'Flour Mill production',
      durationSeconds: 1.5,
      inputs: {
        grain: 1,
      },
      outputs: {
        flour: 1,
      },
    },
    {
      id: 'bakery.recipe-0',
      label: 'Bakery production',
      durationSeconds: 3,
      inputs: {
        flour: 1,
      },
      outputs: {
        bread: 1,
      },
    },
    {
      id: 'iron-mine.recipe-0',
      label: 'Iron Mine production',
      durationSeconds: 0.75,
      inputs: {},
      outputs: {
        iron: 1,
      },
    },
    {
      id: 'charcoal-kiln.recipe-0',
      label: 'Charcoal Kiln production',
      durationSeconds: 1.5,
      inputs: {},
      outputs: {
        coal: 1,
      },
    },
    {
      id: 'furnace.recipe-0',
      label: 'Furnace production',
      durationSeconds: 1.5,
      inputs: {
        iron: 1,
        coal: 1,
      },
      outputs: {
        steel: 1,
      },
    },
    {
      id: 'steelworks.recipe-0',
      label: 'Steelworks production',
      durationSeconds: 2.25,
      inputs: {
        steel: 1,
        coal: 1,
      },
      outputs: {
        'steel-beam': 1,
      },
    },
    {
      id: 'rendering-works.recipe-0',
      label: 'Rendering Works production',
      durationSeconds: 3,
      inputs: {
        pig: 1,
      },
      outputs: {
        tallow: 1,
      },
    },
    {
      id: 'soap-factory.recipe-0',
      label: 'Soap Factory production',
      durationSeconds: 1.5,
      inputs: {
        tallow: 1,
      },
      outputs: {
        soap: 1,
      },
    },
    {
      id: 'hop-farm.recipe-0',
      label: 'Hop Farm production',
      durationSeconds: 4.5,
      inputs: {},
      outputs: {
        hop: 1,
      },
    },
    {
      id: 'malthouse.recipe-0',
      label: 'Malthouse production',
      durationSeconds: 1.5,
      inputs: {
        grain: 1,
      },
      outputs: {
        malt: 1,
      },
    },
    {
      id: 'brewery.recipe-0',
      label: 'Brewery production',
      durationSeconds: 3,
      inputs: {
        malt: 1,
        hop: 1,
      },
      outputs: {
        beer: 1,
      },
    },
    {
      id: 'artisan-residence.recipe-0',
      label: 'Artisan Residence production',
      durationSeconds: 3,
      inputs: {},
      outputs: {
        credits: 4,
      },
    },
    {
      id: 'sand-mine.recipe-0',
      label: 'Sand Mine production',
      durationSeconds: 1.5,
      inputs: {},
      outputs: {
        quartz: 1,
      },
    },
    {
      id: 'glassmakers.recipe-0',
      label: 'Glassmakers production',
      durationSeconds: 1.5,
      inputs: {
        quartz: 1,
      },
      outputs: {
        glass: 1,
      },
    },
    {
      id: 'window-makers.recipe-0',
      label: 'Window Makers production',
      durationSeconds: 3,
      inputs: {
        glass: 1,
      },
      outputs: {
        window: 1,
      },
    },
    {
      id: 'cattle-farm.recipe-0',
      label: 'Cattle Farm production',
      durationSeconds: 6,
      inputs: {},
      outputs: {
        beef: 1,
      },
    },
    {
      id: 'red-pepper-farm.recipe-0',
      label: 'Red Pepper Farm production',
      durationSeconds: 6,
      inputs: {},
      outputs: {
        pepper: 1,
      },
    },
    {
      id: 'artisanal-kitchen.recipe-0',
      label: 'Artisanal Kitchen production',
      durationSeconds: 3,
      inputs: {
        beef: 1,
        pepper: 1,
      },
      outputs: {
        goulash: 1,
      },
    },
    {
      id: 'cannery.recipe-0',
      label: 'Cannery production',
      durationSeconds: 4.5,
      inputs: {
        goulash: 1,
        iron: 1,
      },
      outputs: {
        'canned-food': 1,
      },
    },
    {
      id: 'coal-mine.recipe-0',
      label: 'Coal Mine production',
      durationSeconds: 1.5,
      inputs: {},
      outputs: {
        coal: 1,
      },
    },
    {
      id: 'machine-factory.recipe-0',
      label: 'Machine Factory production',
      durationSeconds: 6,
      inputs: {
        steel: 1,
      },
      outputs: {
        machine: 1,
      },
    },
    {
      id: 'engineer-residence.recipe-0',
      label: 'Engineer Residence production',
      durationSeconds: 3,
      inputs: {},
      outputs: {
        credits: 6,
      },
    },
    {
      id: 'limestone-quarry.recipe-0',
      label: 'Limestone Quarry production',
      durationSeconds: 1.5,
      inputs: {},
      outputs: {
        cement: 1,
      },
    },
    {
      id: 'concrete-factory.recipe-0',
      label: 'Concrete Factory production',
      durationSeconds: 3,
      inputs: {},
      outputs: {
        concrete: 1,
      },
    },
    {
      id: 'investor-residence.recipe-0',
      label: 'Investor Residence production',
      durationSeconds: 3,
      inputs: {},
      outputs: {
        credits: 8,
      },
    },
  ],
  facilities: [
    {
      id: 'small-warehouse',
      label: 'Small Warehouse',
      category: 'warehouse',
      recipes: [],
      constructionCost: {
        timber: 2,
        credits: 100,
      },
      workersRequired: {
        farmers: 2,
      },
      capacityProvided: 20,
    },
    {
      id: 'medium-warehouse',
      label: 'Medium Warehouse',
      category: 'warehouse',
      recipes: [],
      constructionCost: {
        timber: 4,
        credits: 100,
      },
      workersRequired: {
        farmers: 2,
        workers: 1,
      },
      capacityProvided: 50,
    },
    {
      id: 'large-warehouse',
      label: 'Large Warehouse',
      category: 'warehouse',
      recipes: [],
      constructionCost: {
        timber: 8,
        credits: 100,
      },
      workersRequired: {
        workers: 2,
        artisans: 1,
      },
      capacityProvided: 100,
    },
    {
      id: 'grand-warehouse',
      label: 'Grand Warehouse',
      category: 'warehouse',
      recipes: [],
      constructionCost: {
        timber: 16,
        credits: 100,
      },
      workersRequired: {
        artisans: 2,
        engineers: 1,
      },
      capacityProvided: 150,
    },
    {
      id: 'farmer-residence',
      label: 'Farmer Residence',
      category: 'house',
      recipes: ['farmer-residence.recipe-0'],
      constructionCost: {
        timber: 2,
        credits: 100,
      },
      workersProvided: {
        farmers: 10,
      },
    },
    {
      id: 'forester',
      label: 'Forester',
      category: 'workshop',
      recipes: ['forester.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'sawmill',
      label: 'Sawmill',
      category: 'workshop',
      recipes: ['sawmill.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'fishery',
      label: 'Fishery',
      category: 'workshop',
      recipes: ['fishery.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'potato-farm',
      label: 'Potato Farm',
      category: 'workshop',
      recipes: ['potato-farm.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'schnapps-distillery',
      label: 'Schnapps Distillery',
      category: 'workshop',
      recipes: ['schnapps-distillery.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'sheep-farm',
      label: 'Sheep Farm',
      category: 'workshop',
      recipes: ['sheep-farm.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'framework-knitters',
      label: 'Framework Knitters',
      category: 'workshop',
      recipes: ['framework-knitters.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'worker-residence',
      label: 'Worker Residence',
      category: 'house',
      recipes: ['worker-residence.recipe-0'],
      constructionCost: {
        timber: 6,
      },
      workersProvided: {
        workers: 20,
      },
    },
    {
      id: 'clay-pit',
      label: 'Clay Pit',
      category: 'workshop',
      recipes: ['clay-pit.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 10,
      },
    },
    {
      id: 'brick-factory',
      label: 'Brick Factory',
      category: 'workshop',
      recipes: ['brick-factory.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 10,
      },
    },
    {
      id: 'pig-farm',
      label: 'Pig Farm',
      category: 'workshop',
      recipes: ['pig-farm.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'slaughterhouse',
      label: 'Slaughterhouse',
      category: 'workshop',
      recipes: ['slaughterhouse.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 5,
      },
    },
    {
      id: 'grain-farm',
      label: 'Grain Farm',
      category: 'workshop',
      recipes: ['grain-farm.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'flour-mill',
      label: 'Flour Mill',
      category: 'workshop',
      recipes: ['flour-mill.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 5,
      },
    },
    {
      id: 'bakery',
      label: 'Bakery',
      category: 'workshop',
      recipes: ['bakery.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 5,
      },
    },
    {
      id: 'iron-mine',
      label: 'Iron Mine',
      category: 'workshop',
      recipes: ['iron-mine.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 20,
      },
    },
    {
      id: 'charcoal-kiln',
      label: 'Charcoal Kiln',
      category: 'workshop',
      recipes: ['charcoal-kiln.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 20,
      },
    },
    {
      id: 'furnace',
      label: 'Furnace',
      category: 'workshop',
      recipes: ['furnace.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 20,
      },
    },
    {
      id: 'steelworks',
      label: 'Steelworks',
      category: 'workshop',
      recipes: ['steelworks.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 20,
      },
    },
    {
      id: 'rendering-works',
      label: 'Rendering Works',
      category: 'workshop',
      recipes: ['rendering-works.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 10,
      },
    },
    {
      id: 'soap-factory',
      label: 'Soap Factory',
      category: 'workshop',
      recipes: ['soap-factory.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 10,
      },
    },
    {
      id: 'hop-farm',
      label: 'Hop Farm',
      category: 'workshop',
      recipes: ['hop-farm.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'malthouse',
      label: 'Malthouse',
      category: 'workshop',
      recipes: ['malthouse.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 10,
      },
    },
    {
      id: 'brewery',
      label: 'Brewery',
      category: 'workshop',
      recipes: ['brewery.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 10,
      },
    },
    {
      id: 'artisan-residence',
      label: 'Artisan Residence',
      category: 'house',
      recipes: ['artisan-residence.recipe-0'],
      constructionCost: {
        timber: 12,
        brick: 2,
        'steel-beam': 2,
      },
      workersProvided: {
        artisans: 30,
      },
    },
    {
      id: 'sand-mine',
      label: 'Sand Mine',
      category: 'workshop',
      recipes: ['sand-mine.recipe-0'],
      constructionCost: {},
      workersRequired: {
        artisans: 20,
      },
    },
    {
      id: 'glassmakers',
      label: 'Glassmakers',
      category: 'workshop',
      recipes: ['glassmakers.recipe-0'],
      constructionCost: {},
      workersRequired: {
        artisans: 40,
      },
    },
    {
      id: 'window-makers',
      label: 'Window Makers',
      category: 'workshop',
      recipes: ['window-makers.recipe-0'],
      constructionCost: {},
      workersRequired: {
        artisans: 40,
      },
    },
    {
      id: 'cattle-farm',
      label: 'Cattle Farm',
      category: 'workshop',
      recipes: ['cattle-farm.recipe-0'],
      constructionCost: {},
      workersRequired: {
        farmers: 5,
      },
    },
    {
      id: 'red-pepper-farm',
      label: 'Red Pepper Farm',
      category: 'workshop',
      recipes: ['red-pepper-farm.recipe-0'],
      constructionCost: {},
      workersRequired: {
        artisans: 5,
      },
    },
    {
      id: 'artisanal-kitchen',
      label: 'Artisanal Kitchen',
      category: 'workshop',
      recipes: ['artisanal-kitchen.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 10,
      },
    },
    {
      id: 'cannery',
      label: 'Cannery',
      category: 'workshop',
      recipes: ['cannery.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 10,
      },
    },
    {
      id: 'coal-mine',
      label: 'Coal Mine',
      category: 'workshop',
      recipes: ['coal-mine.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 20,
      },
    },
    {
      id: 'machine-factory',
      label: 'Machine Factory',
      category: 'workshop',
      recipes: ['machine-factory.recipe-0'],
      constructionCost: {},
      workersRequired: {
        workers: 50,
      },
    },
    {
      id: 'engineer-residence',
      label: 'Engineer Residence',
      category: 'house',
      recipes: ['engineer-residence.recipe-0'],
      constructionCost: {
        timber: 20,
        brick: 5,
        'steel-beam': 4,
        window: 2,
      },
      workersProvided: {
        engineers: 40,
      },
    },
    {
      id: 'limestone-quarry',
      label: 'Limestone Quarry',
      category: 'workshop',
      recipes: ['limestone-quarry.recipe-0'],
      constructionCost: {
        timber: 8,
        brick: 15,
        'steel-beam': 12,
        window: 10,
        credits: 6000,
      },
      workersRequired: {
        workers: 25,
      },
    },
    {
      id: 'concrete-factory',
      label: 'Concrete Factory',
      category: 'workshop',
      recipes: ['concrete-factory.recipe-0'],
      constructionCost: {
        timber: 20,
        brick: 30,
        'steel-beam': 24,
        window: 25,
        credits: 15000,
      },
      workersRequired: {
        engineers: 75,
      },
    },
    {
      id: 'investor-residence',
      label: 'Investor Residence',
      category: 'house',
      recipes: ['investor-residence.recipe-0'],
      constructionCost: {
        timber: 30,
        brick: 9,
        'steel-beam': 7,
        window: 5,
        concrete: 3,
      },
      workersProvided: {
        investors: 50,
      },
    },
  ],
} satisfies Configuration;
