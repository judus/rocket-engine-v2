import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
import { createObjectInventoryDemo } from '../object-inventory-demo.js';
let sim = createObjectInventoryDemo();
assert.equal(sim.objectInventories('house').length, 2);
assert.equal(sim.transfer('lake-water', 'player-bag', { water: 15 }), true);
const before = sim.save();
assert.equal(sim.transfer('lake-water', 'player-bag', { water: 1 }), false);
assert.deepEqual(sim.save(), before);
assert.equal(sim.transfer('player-bag', 'house-pantry', { water: 8 }), true);
assert.equal(sim.transfer('player-bag', 'house-pantry', { water: 1 }), false);
const tool = sim.inventory('house-tools').itemPage().items[0];
assert.equal(sim.transferItem('house-tools', 'player-bag', tool.id), true);
sim = Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
assert.equal(
  sim.objectInventory('player').item(tool.id).attributes.durability,
  100,
);
assert.equal(sim.inventory('lake-water').quantity('water'), 15);
console.log(
  'Object inventories: player slots, house shared capacity/multiple stores, finite lake, exact item transfer and format-7 restore verified.',
);
