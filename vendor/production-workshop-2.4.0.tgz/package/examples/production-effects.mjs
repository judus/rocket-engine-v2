import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
import { createShip, createSettlement } from '../dist/examples.js';

// Configure three slots, independent of a game's population/character service.
const factory = new Simulation({
  resources: [{ id: 'coal', label: 'Coal', kind: 'material' }],
  recipes: [
    {
      id: 'mine',
      label: 'Mine',
      durationSeconds: 1,
      inputs: {},
      outputs: { coal: 1 },
    },
  ],
  facilities: [
    {
      id: 'mine',
      label: 'Mine',
      category: 'industry',
      workerSlots: 3,
      recipes: ['mine'],
      constructionCost: {},
    },
  ],
});
factory.createInventory({ id: 'planet', capacityPerMaterial: 100 });
const id = factory.addFacility('mine', 'planet').facilityId;
factory.setWorkerSlot(id, 0, { id: 'alice', efficiency: 0.8 });
factory.setWorkerSlot(id, 1, { id: 'bob', efficiency: 0.2 }); // Third slot stays empty.
factory.setProductionModifier(id, 'specialist', {
  productivityMultiplier: 1.2,
});
assert.ok(
  Math.abs(factory.snapshot().facilities[0].productivity - 0.4) < 1e-12,
);
factory.advance(1.05);
const partial = factory.snapshot().facilities[0].jobs[0].progress;
factory.setProductionModifier(id, 'damage', { productivityMultiplier: 0 });
factory.advance(2);
assert.equal(factory.snapshot().facilities[0].jobs[0].progress, partial);
factory.setProductionModifier(id, 'damage', null);
factory.advance(2);
assert.ok(factory.inventory('planet').quantity('coal') > 0);
console.log(
  'Three slots, two workers and specialist:',
  factory.snapshot().facilities[0].productivity,
);

// Same weapon resource, unique items, quality at completion, ingredient at start.
const ship = createShip();
const weapon = ship
  .snapshot()
  .facilities.find((f) => f.definitionId === 'weapon-fabricator');
ship.setOptionalInputs(weapon.id, 'weapons', { reinforcement: 1 });
ship.setProductionModifier(weapon.id, 'specialist', {
  productivityMultiplier: 1.2,
  attributeBonuses: { maxHealth: 10, precision: 0.1 },
});
ship.advance(30);
const goods = ship.inventory('ship').snapshot().items;
assert.ok(goods.length > 0);
assert.ok(
  goods.every(
    (item) =>
      item.attributes.maxHealth >= 100 && item.attributes.maxHealth < 110,
  ),
);
console.log('Individually manufactured weapons:', goods);
const first = goods[0];
ship.updateItemAttributes('ship', first.id, { currentHealth: 40 }); // Wear.
ship.updateItemAttributes('ship', first.id, {
  currentHealth: first.attributes.maxHealth,
}); // Host repair rule.

// Real 1% coal-mine bonus, not a forced win. Fixed seed makes this reproducible.
const settlement = createSettlement();
assert.ok(settlement.addFacility('worker-residence', 'settlement').ok);
const mine = settlement.addFacility('coal-mine', 'settlement');
assert.ok(mine.ok);
settlement.setFacilityAttendance(mine.facilityId, { workers: 20 });
// Provide capacity for 500 batches so the mine keeps running.
settlement.increaseCapacity('settlement', 1000);
settlement.advance(750.05);
const diamonds = settlement.inventory('settlement').quantity('diamond');
assert.ok(diamonds > 0 && diamonds < 25);
console.log('Diamonds from 500 coal batches at 1%:', diamonds);
