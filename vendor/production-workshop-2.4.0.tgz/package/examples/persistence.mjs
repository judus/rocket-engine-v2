import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
import { createShip } from '../dist/examples.js';
const original = createShip();
original.advance(20.012345678);
original.createInventory({ id: 'outpost', capacityPerMaterial: 20 });
const weapon = original.inventory('ship').snapshot().items[0];
original.updateItemAttributes('ship', weapon.id, { currentHealth: 42 });
const sent = original.reserveDelivery('ship', 'outpost', { sensor: 1 }, [
  weapon.id,
]);
assert.ok(sent.ok);
original.pickupDelivery(sent.deliveryId);
// Vehicle movement belongs to the host. Save it alongside the framework checkpoint.
const checkpoint = JSON.stringify({
  production: original.save(),
  journeys: [{ deliveryId: sent.deliveryId, remainingSeconds: 3 }],
});
const parsed = JSON.parse(checkpoint);
const restored = Simulation.restore(parsed.production);
assert.deepEqual(restored.snapshot(), original.snapshot());
for (const s of [original, restored]) {
  s.advance(parsed.journeys[0].remainingSeconds);
  assert.equal(s.arriveDelivery(sent.deliveryId), true);
  s.advance(10);
}
assert.deepEqual(restored.save(), original.save());
assert.equal(
  restored.inventory('outpost').item(weapon.id).attributes.currentHealth,
  42,
);
assert.equal(restored.pruneDeliveries(), 1);
console.log(
  'JSON restore preserves active production, clock remainder, transit identity and wear.',
);
