import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
// Planet/faction membership and permission to trade are host metadata.
const sim = new Simulation({
  resources: [
    { id: 'ore', label: 'Ore', kind: 'material' },
    { id: 'alloy', label: 'Alloy', kind: 'material' },
  ],
  recipes: [
    {
      id: 'smelt',
      label: 'Smelt',
      durationSeconds: 1,
      inputs: { ore: 2 },
      outputs: { alloy: 1 },
    },
  ],
  facilities: [
    {
      id: 'home',
      label: 'Residence',
      category: 'population',
      recipes: [],
      constructionCost: {},
      workersProvided: { smith: 1 },
    },
    {
      id: 'smelter',
      label: 'Smelter',
      category: 'production',
      recipes: ['smelt'],
      constructionCost: {},
      workersRequired: { smith: 1 },
    },
  ],
});
const networks = [
  { id: 'earth.player', planet: 'earth', faction: 'player', ore: 4 },
  { id: 'earth.neighbours', planet: 'earth', faction: 'neighbours', ore: 2 },
  { id: 'mars.player', planet: 'mars', faction: 'player', ore: 0 },
];
for (const n of networks) {
  sim.createInventory({
    id: n.id,
    capacityPerMaterial: 20,
    initial: { ore: n.ore },
  });
  assert.equal(sim.addFacility('smelter', n.id).ok, false); // Other networks' workers are not borrowed.
  assert.ok(sim.addFacility('home', n.id).ok);
  const smelter = sim.addFacility('smelter', n.id);
  assert.ok(smelter.ok);
  sim.setFacilityAttendance(smelter.facilityId, { smith: 1 });
}
sim.advance(3.05);
assert.equal(sim.inventory('earth.player').quantity('alloy'), 2);
assert.equal(sim.inventory('earth.neighbours').quantity('alloy'), 1);
assert.equal(sim.inventory('mars.player').quantity('alloy'), 0);
// An explicitly authorized host trade/logistics action links otherwise independent stock.
const delivery = sim.reserveDelivery('earth.player', 'mars.player', { ore: 2 });
assert.equal(delivery.ok, false); // Source ore has already been consumed.
assert.ok(sim.transfer('earth.player', 'mars.player', { alloy: 1 }));
const restored = Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
assert.equal(restored.inventory('mars.player').quantity('alloy'), 1);
assert.deepEqual(restored.validateState(), { ok: true });
console.log(
  'Networks: separate planets/factions retain independent stock and workforce under one clock.',
);
