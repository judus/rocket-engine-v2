import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';

const sim = new Simulation({
  resources: [
    { id: 'ore', label: 'Ore', kind: 'material' },
    { id: 'weapon', label: 'Weapon', kind: 'material', storage: 'individual' },
  ],
  recipes: [
    {
      id: 'forge',
      label: 'Forge',
      durationSeconds: 1,
      inputs: { ore: 2 },
      outputs: { weapon: 1 },
      itemAttributes: { weapon: { health: { min: 80, max: 90 } } },
    },
  ],
  facilities: [
    {
      id: 'forge',
      label: 'Forge',
      category: 'production',
      recipes: ['forge'],
      constructionCost: {},
    },
  ],
});
sim.createInventory({
  id: 'store',
  capacityPerMaterial: 10,
  initial: { ore: 1 },
});
sim.createInventory({ id: 'ship', capacityPerMaterial: 10 });
const built = sim.addFacility('forge', 'store');
assert.ok(built.ok);
const jobId = `${built.facilityId}.job-0`;
sim.enableDiagnostics(40);
sim.advanceTicks(1);
const waiting = sim.explainJob(jobId);
assert.deepEqual(waiting.reservedInputs, { ore: 1 });
assert.deepEqual(waiting.blockers, [
  { code: 'missing-inputs', quantities: { ore: 1 } },
]);
assert.equal(sim.inspectReservations('store')[0].owner.id, jobId);
sim.deposit('store', { ore: 1 });
sim.advance(1.05);
const item = sim.inventory('store').snapshot().items[0];
assert.ok(item);
assert.equal(sim.locateItem(item.id).kind, 'inventory');
const delivery = sim.reserveDelivery('store', 'ship', {}, [item.id]);
assert.ok(delivery.ok);
assert.equal(sim.locateItem(item.id).reservationOwner, delivery.deliveryId);
sim.pickupDelivery(delivery.deliveryId);
assert.deepEqual(sim.locateItem(item.id), {
  kind: 'delivery',
  deliveryId: delivery.deliveryId,
});
const resumed = Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
assert.deepEqual(resumed.validateState(), { ok: true });
resumed.arriveDelivery(delivery.deliveryId);
assert.deepEqual(resumed.inventory('ship').item(item.id), item);
assert.equal(resumed.locateItem(item.id).inventoryId, 'ship');
assert.deepEqual(resumed.diagnosticTrace(), []);
console.log(
  'Diagnostics: input blockers, held stock, ownership, trace and restore validated.',
);
console.log(sim.diagnosticTrace());
