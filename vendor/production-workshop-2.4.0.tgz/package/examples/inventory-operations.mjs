import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
import {
  createInventoryOperationsDemo,
  buyFood,
  fillBucket,
} from '../inventory-operations-demo.js';
let sim = createInventoryOperationsDemo();
const events = [];
sim.onInventoryEvent((e) => events.push(e));
assert.equal(buyFood(sim).ok, true);
assert.equal(sim.inventory('bag').quantity('coin'), 2);
assert.equal(sim.inventory('trader').quantity('food'), 4);
const before = sim.save();
assert.equal(buyFood(sim).ok, false);
assert.deepEqual(sim.save(), before);
assert.equal(sim.transfer('lake', 'bag', { water: 5 }), true);
const empty = sim.inventory('bag').itemPage({ resourceId: 'bucket' }).items[0];
const filled = fillBucket(sim);
assert.equal(filled.ok, true);
assert.equal(sim.locateItem(empty.id).kind, 'retired');
assert.equal(
  sim.inventory('bag').item(filled.createdItemIds[0]).attributes.durability,
  80,
);
assert.equal(sim.inventory('bag').summary().rules.usedWeight, 8);
assert.equal(sim.transfer('lake', 'bag', { water: 5 }), false);
const tool = sim.inventory('trader').itemPage({ resourceId: 'tool' }).items[0];
assert.equal(sim.transferItem('trader', 'lake', tool.id), false);
assert.equal(events.length, 3);
const sequence = sim.inventoryEventSequence();
sim = Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
const later = [];
sim.onInventoryEvent((e) => later.push(e));
assert.equal(
  sim.mutateInventory({ inventoryId: 'bag', consume: { food: 1 } }).ok,
  true,
);
assert.equal(later[0].sequence, sequence + 1);
console.log(
  'Inventory operations: atomic purchase/refusal, filtered lake, weighted/slotted bag, bucket transformation, consumption and persisted event identity verified.',
);
