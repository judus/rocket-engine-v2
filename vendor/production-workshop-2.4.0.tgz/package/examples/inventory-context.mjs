import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
import {
  createInventoryContextDemo,
  advanceFreshness,
} from '../inventory-context-demo.js';
const sim = createInventoryContextDemo();
const apple = sim.inventory('bag').itemPage({ resourceId: 'apple' }).items[0];
assert.equal(sim.transferItem('bag', 'fridge', apple.id), true);
advanceFreshness(sim, 10);
assert.equal(sim.inventory('fridge').item(apple.id).attributes.freshness, 99);
assert.equal(sim.inventory('fridge').item(apple.id).attributes.decay, 1);
const sword = sim.inventory('bag').itemPage({ resourceId: 'sword' }).items[0];
assert.equal(sim.equipItem('bag', 'hand', sword.id).ok, true);
assert.equal(sim.inventory('hand').effectiveItemAttributes(sword.id).power, 15);
assert.equal(
  sim.inventory('bag').itemPage({ resourceId: 'sword' }).items[0].attributes
    .power,
  6,
);
const hat = sim.inventory('bag').itemPage({ resourceId: 'hat' }).items[0];
assert.equal(sim.equipItem('bag', 'hand', hat.id).ok, false);
assert.equal(sim.equipItem('bag', 'head', hat.id).ok, true);
const saved = JSON.parse(JSON.stringify(sim.save()));
assert.deepEqual(Simulation.restore(saved).save(), saved);
console.log(
  'Inventory context: item-owned decay, metadata, atomic equipment swaps and restore verified.',
);
