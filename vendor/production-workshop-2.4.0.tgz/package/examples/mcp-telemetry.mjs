import assert from 'node:assert/strict';
import { createShip } from '../dist/examples.js';
import { createProductionTelemetryProvider } from '../dist/mcp.js';
const sim = createShip();
const provider = createProductionTelemetryProvider({
  id: 'ship-production',
  resolveSimulation: (binding) => (binding.scope === 'ship' ? sim : null),
});
const context = {
  binding: { scope: 'ship', isCurrent: () => true },
  signal: { aborted: false },
};
sim.advance(2); // Only the game advances simulation time.
const before = sim.save();
console.log(provider.call('production_summary', {}, context).structuredContent);
console.log(
  provider.call('production_facility', { id: sim.facilityIds()[0] }, context)
    .structuredContent,
);
assert.deepEqual(sim.save(), before);
// With Rocket's optional host: service.register(provider).
// Host registration/disposal never owns or stops this simulation.
