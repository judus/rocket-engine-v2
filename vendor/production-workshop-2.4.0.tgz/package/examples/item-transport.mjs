import assert from 'node:assert/strict';
import { createShip } from '../dist/examples.js';
const sim = createShip();
sim.advance(20);
const cargo = sim.inventory('ship');
const weapon = cargo.snapshot().items[0];
assert.ok(weapon);
sim.updateItemAttributes(cargo.id, weapon.id, { currentHealth: 42 });
const original = cargo.item(weapon.id);
const outpost = sim.createInventory({ id: 'outpost', capacityPerMaterial: 0 });
const delivery = sim.reserveDelivery('ship', 'outpost', { sensor: 1 }, [
  weapon.id,
]);
assert.ok(delivery.ok);
assert.equal(sim.transferItem(cargo.id, outpost.id, weapon.id), false);
sim.pickupDelivery(delivery.deliveryId);
assert.equal(cargo.item(weapon.id), undefined);
assert.deepEqual(sim.snapshot().deliveries[0].items[0], original);
// The game's vehicle travels. Arrival cannot unload into this tiny outpost yet.
assert.equal(sim.arriveDelivery(delivery.deliveryId), false);
assert.equal(outpost.quantity('sensor'), 0); // Mixed delivery stays atomic.
assert.deepEqual(sim.snapshot().deliveries[0].items[0], original);
sim.increaseCapacity(outpost.id, 2);
assert.equal(sim.arriveDelivery(delivery.deliveryId), true);
assert.deepEqual(outpost.item(weapon.id), original);
assert.equal(outpost.quantity('sensor'), 1);
console.log(
  'Manufactured weapon delivered unchanged with bulk cargo:',
  outpost.item(weapon.id),
);
