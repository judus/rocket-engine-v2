import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
// Salvage the damaged weapon deliberately, keeping the pristine weapon untouched.
const sim = new Simulation({
  tickMilliseconds: 50,
  resources: [
    { id: 'weapon', label: 'Weapon', kind: 'material', storage: 'individual' },
    { id: 'power', label: 'Energy cells', kind: 'material' },
    { id: 'alloy', label: 'Alloy', kind: 'material' },
  ],
  recipes: [
    {
      id: 'salvage',
      label: 'Salvage equipment',
      durationSeconds: 1,
      inputs: { weapon: 1, power: 2 },
      outputs: { alloy: 3 },
    },
  ],
  facilities: [
    {
      id: 'recycler',
      label: 'Recycler',
      category: 'ship',
      recipes: ['salvage'],
      constructionCost: {},
    },
  ],
});
sim.createInventory({
  id: 'ship',
  capacityPerMaterial: 20,
  initial: { power: 4 },
});
const damaged = sim.spawnItem('ship', 'weapon', { health: 20, precision: 0.7 });
const pristine = sim.spawnItem('ship', 'weapon', {
  health: 100,
  precision: 0.95,
});
const factory = sim.addFacility('recycler', 'ship').facilityId;
sim.advance(0.1); // No selection: neither weapon is silently picked.
assert.equal(sim.inventory('ship').quantity('weapon'), 2);
sim.setInputItems(factory, 'salvage', [damaged]);
sim.advance(0.05); // Reserve/consume the complete bundle at a tick boundary.
assert.equal(
  sim.facilitySnapshot(factory).jobs[0].batchInputItems[0].attributes.health,
  20,
);
const restored = Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
restored.advance(2);
assert.equal(restored.inventory('ship').quantity('alloy'), 3);
assert.ok(restored.inventory('ship').item(pristine));
assert.equal(restored.inventory('ship').item(damaged), undefined);
assert.deepEqual(restored.locateItem(damaged), { kind: 'retired' });
assert.equal(restored.facilitySnapshot(factory).jobs[0].batchesCompleted, 1);
assert.deepEqual(restored.validateState(), { ok: true });
console.log(
  'Item selection: exact damaged weapon consumed once; pristine weapon preserved after restore.',
);
