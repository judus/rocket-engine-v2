import { resultJson } from '../dist/minimal-example.js';
console.log('Compiled TypeScript minimal example:', resultJson);
