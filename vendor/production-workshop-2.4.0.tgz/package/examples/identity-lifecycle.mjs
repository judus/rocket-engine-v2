import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
import { createShip } from '../dist/examples.js';
const sim = createShip();
const inventoryId = 'ship';
const id = sim.spawnItem(inventoryId, 'weapon', { health: 87, precision: 0.9 });
assert.ok(id);
sim.consumeItem(inventoryId, id);
const restored = Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
assert.deepEqual(restored.locateItem(id), { kind: 'retired' });
const next = restored.spawnItem(inventoryId, 'weapon', { health: 100 });
assert.notEqual(next, id);
assert.ok(!Object.hasOwn(restored.save(), 'issuedItemIds'));
console.log(
  'Compact identities: consumed identity remains retired after restore; next spawn receives a fresh ID.',
);
