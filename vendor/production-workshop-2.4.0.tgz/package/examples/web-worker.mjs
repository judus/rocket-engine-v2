import { NodeWorkerTransport } from './node-worker-transport.mjs';
import { WorkerDemoClient } from '../worker/client.js';
import assert from 'node:assert/strict';
import { WorkerDemoHost } from '../dist/worker-demo.js';
// Same example protocol/workload, with Node's transport for a runnable terminal check.
const transport = new NodeWorkerTransport(
  new URL('./worker-node-entry.mjs', import.meta.url),
);
const client = new WorkerDemoClient(() => {}, transport);
const request = (command) => client.request(command);
try {
  const reference = new WorkerDemoHost();
  assert.deepEqual(
    (await request({ type: 'init' })).result,
    reference.handle({ type: 'init' }),
  );
  for (const seconds of [0.017, 0.033, 0.35, 0.6]) {
    assert.deepEqual(
      (await request({ type: 'advance', seconds })).result,
      reference.handle({ type: 'advance', seconds }),
    );
  }
  const advanced = await request({ type: 'burst', ticks: 200 });
  assert.deepEqual(
    advanced.result,
    reference.handle({ type: 'burst', ticks: 200 }),
  );
  assert.equal(advanced.result.view.counts.producing, 6000);
  assert.equal(advanced.result.view.jobs.length, 12);
  const saved = await request({ type: 'checkpoint' });
  assert.deepEqual(saved.result, reference.handle({ type: 'checkpoint' }));
  await request({ type: 'advance', seconds: 0.173456789 });
  reference.handle({ type: 'advance', seconds: 0.173456789 });
  const restored = await request({ type: 'restore' });
  assert.deepEqual(restored.result, reference.handle({ type: 'restore' }));
  console.log(
    `Worker example: 6000 active factories; 12 job views; checkpoint ${(saved.result.checkpointBytes / 1e6).toFixed(2)} MB; worker/direct parity passed.`,
  );
} finally {
  client.close();
}
