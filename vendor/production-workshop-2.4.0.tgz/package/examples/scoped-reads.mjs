import assert from 'node:assert/strict';
import { createShip } from '../dist/examples.js';
import { Simulation } from '../dist/index.js';
const sim = createShip();
sim.advance(12);
const summary = sim.summary();
assert.equal(summary.facilityCount, 4);
const factory = sim.facilitySnapshot(sim.facilityIds()[3]);
assert.ok(factory.jobs[0].batchesCompleted > 0);
const inventory = sim.inventory('ship');
const totals = inventory.summary();
assert.equal('items' in totals, false);
const first = inventory.itemPage({ resourceId: 'weapon', limit: 1 });
assert.ok(first.total > 0);
const equipment = first.items[0];
equipment.attributes.maxHealth = -1;
assert.ok(inventory.item(equipment.id).attributes.maxHealth >= 80);
const restored = Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
assert.deepEqual(
  restored.facilitySnapshot(factory.id),
  sim.facilitySnapshot(factory.id),
);
console.log(
  'Scoped reads:',
  summary,
  totals.itemCount,
  'items; first weapon window',
  first.total,
);
