import { parentPort } from 'node:worker_threads';
import { performance } from 'node:perf_hooks';
import { WorkerDemoHost } from '../dist/worker-demo.js';
const host = new WorkerDemoHost();
parentPort.on('message', ({ id, command }) => {
  const started = performance.now();
  try {
    parentPort.postMessage({
      id,
      ok: true,
      result: host.handle(command),
      workMilliseconds: performance.now() - started,
    });
  } catch (error) {
    parentPort.postMessage({
      id,
      ok: false,
      error: { name: error.name, message: error.message },
    });
  }
});
