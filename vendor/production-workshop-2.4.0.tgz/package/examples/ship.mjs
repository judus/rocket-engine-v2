import { createShip } from '../dist/examples.js';
const sim = createShip();
const unsubscribe = sim.onEvent((event) => {
  if (event.type === 'batch-completed')
    console.log(`Tick ${event.tick}: ${event.jobId} finished`);
});
sim.advance(10);
unsubscribe();
console.log(
  'Ship after 10 seconds:',
  sim.inventory('ship').snapshot().quantities,
);
