import test from 'node:test';
import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
import { createProductionTelemetryProvider } from '../dist/mcp.js';
function fixture() {
  const sim = new Simulation({
    resources: [
      { id: 'ore', label: 'Ore', kind: 'material' },
      {
        id: 'weapon',
        label: 'Weapon',
        kind: 'material',
        storage: 'individual',
      },
    ],
    recipes: [
      {
        id: 'forge',
        label: 'Forge',
        inputs: { ore: 1 },
        outputs: { weapon: 1 },
        durationSeconds: 1,
      },
    ],
    facilities: [
      {
        id: 'forge',
        label: 'Forge',
        category: 'production',
        constructionCost: { ore: 2 },
        recipes: ['forge'],
      },
    ],
  });
  sim.createInventory({
    id: 'site',
    capacityPerMaterial: 100,
    initial: { ore: 20 },
  });
  sim.createInventory({ id: 'destination', capacityPerMaterial: 100 });
  sim.addFacility('forge', 'site');
  const binding = { scope: 'planet-a', isCurrent: () => true },
    context = { binding, signal: { aborted: false } };
  const provider = createProductionTelemetryProvider({
    id: 'production',
    resolveSimulation: (b) => (b.scope === 'planet-a' ? sim : null),
  });
  const call = (name, args = {}) =>
    provider.call(name, args, context).structuredContent;
  return { sim, provider, binding, context, call };
}
test('all telemetry tools preserve complete checkpoint and diagnostic state', () => {
  const { sim, call, provider, binding } = fixture();
  sim.enableDiagnostics();
  const order = sim.createConstructionOrder('forge', 'site', {
    durationSeconds: 2,
  });
  const item = sim.spawnItem('site', 'weapon', { precision: 95 });
  const delivery = sim.reserveDelivery('site', 'destination', {}, [
    item,
  ]).deliveryId;
  sim.advance(0.5);
  const before = sim.save(),
    trace = sim.diagnosticTrace();
  assert.equal(provider.tools(binding).length, 9);
  assert.equal(call('production_summary').data.tick, 10);
  for (const kind of [
    'inventories',
    'facilities',
    'construction',
    'deliveries',
  ])
    assert.ok(call('production_list', { kind }).data.entries.length);
  for (const kind of ['resources', 'recipes', 'facilities'])
    assert.ok(call('production_catalogue', { kind }).data.entries.length);
  const facility = call('production_facility', { id: 'facility-1' }).data;
  assert.equal(facility.jobs[0].progress, 0.45);
  assert.equal(facility.explanations[0].phase, 'working');
  assert.equal(
    'items' in call('production_inventory', { id: 'site' }).data,
    false,
  );
  assert.equal(
    call('production_items', { id: 'site' }).data.items[0].attributes.precision,
    95,
  );
  assert.equal(
    call('production_construction', { id: order }).data.state,
    'building',
  );
  assert.equal(
    call('production_delivery', { id: delivery }).data.itemIds[0],
    item,
  );
  assert.deepEqual(sim.save(), before);
  assert.deepEqual(sim.diagnosticTrace(), trace);
});
test('reads are detached and fresh; restored simulation can replace mounted instance', () => {
  let { sim, provider, call, binding, context } = fixture();
  const result = call('production_catalogue', { kind: 'recipes' });
  result.data.entries[0].outputs.weapon = 99;
  assert.equal(sim.registry.recipe('forge').outputs.weapon, 1);
  const schemas = provider.tools(binding);
  schemas[0].name = 'destroy';
  assert.equal(provider.tools(binding)[0].name, 'production_summary');
  sim.advance(1.05);
  const items = call('production_items', { id: 'site' }).data.items;
  assert.equal(items.length, 1);
  items[0].attributes.precision = 999;
  assert.equal(
    sim.inventory('site').item(items[0].id).attributes.precision,
    undefined,
  );
  const restored = Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
  const mounted = createProductionTelemetryProvider({
    id: 'mounted',
    resolveSimulation: () => sim,
  });
  const first = mounted.call(
    'production_facility',
    { id: 'facility-1' },
    context,
  );
  sim = restored;
  assert.deepEqual(
    mounted.call('production_facility', { id: 'facility-1' }, context),
    first,
  );
});
test('scope isolation and stale/aborted/invalid calls fail without mutation', () => {
  const { sim, provider, context, call } = fixture();
  const before = sim.save();
  for (const [name, args] of [
    ['unknown', {}],
    ['production_summary', { advance: 1 }],
    ['production_items', { id: 'site', limit: 101 }],
    ['production_items', { id: 'site', offset: null }],
    ['production_list', { kind: 'jobs' }],
    ['production_catalogue', {}],
    ['production_inventory', { id: 3 }],
    ['production_facility', { id: 'missing' }],
  ])
    assert.throws(() => call(name, args));
  assert.throws(() =>
    provider.call(
      'production_summary',
      {},
      { ...context, binding: { scope: 'planet-b', isCurrent: () => true } },
    ),
  );
  assert.throws(() =>
    provider.tools({ scope: 'planet-a', isCurrent: () => false }),
  );
  assert.throws(() =>
    provider.call(
      'production_summary',
      {},
      { ...context, signal: { aborted: true } },
    ),
  );
  assert.deepEqual(sim.save(), before);
});
test('ID and item paging keeps insertion order and enforces response bound without truncation', () => {
  const { sim, call } = fixture();
  assert.deepEqual(
    call('production_list', { kind: 'inventories', offset: 1, limit: 1 }).data,
    { entries: ['destination'], total: 2, offset: 1, limit: 1 },
  );
  for (let i = 0; i < 3; i++) sim.spawnItem('site', 'weapon', { precision: i });
  assert.equal(
    call('production_items', { id: 'site', offset: 1, limit: 1 }).data.items[0]
      .attributes.precision,
    1,
  );
  const large = new Simulation({
    resources: [{ id: 'ore', label: '🚀'.repeat(20000), kind: 'material' }],
    recipes: [],
    facilities: [],
  });
  const p = createProductionTelemetryProvider({
    id: 'large',
    resolveSimulation: () => large,
  });
  const before = large.save();
  assert.throws(
    () =>
      p.call(
        'production_catalogue',
        { kind: 'resources' },
        {
          binding: { scope: 'large', isCurrent: () => true },
          signal: { aborted: false },
        },
      ),
    /64 KiB/,
  );
  assert.deepEqual(large.save(), before);
});

test('inventory context telemetry exposes detached base configuration without mutation', () => {
  const { sim, call } = fixture();
  sim.createInventory({
    id: 'hand',
    attachment: { objectId: 'player', slot: 'mainHand' },
    equipment: { accepts: ['weapon'] },
    modifiers: { precision: 0.5 },
    metadata: { label: 'Main hand', nested: { a: 1 } },
  });
  const id = sim.spawnItem('hand', 'weapon', { precision: 90 });
  const before = sim.save();
  const data = call('production_inventory', { id: 'hand' }).data;
  assert.deepEqual(data.equipment, { accepts: ['weapon'] });
  assert.deepEqual(data.modifiers, { precision: 0.5 });
  assert.equal(data.metadata.nested.a, 1);
  assert.equal(
    call('production_items', { id: 'hand' }).data.items[0].attributes.precision,
    90,
  );
  data.metadata.nested.a = 99;
  data.modifiers.precision = 100;
  data.equipment.accepts.push('ore');
  assert.deepEqual(sim.save(), before);
  assert.equal(sim.inventory('hand').effectiveItemAttributes(id).precision, 45);
});
