import test from 'node:test';
import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
function world() {
  return new Simulation({
    resources: [
      {
        id: 'food',
        label: 'Food',
        kind: 'material',
        storage: 'individual',
        unitWeight: 1,
      },
      {
        id: 'sword',
        label: 'Sword',
        kind: 'material',
        storage: 'individual',
        unitWeight: 3,
      },
      {
        id: 'hat',
        label: 'Hat',
        kind: 'material',
        storage: 'individual',
        unitWeight: 1,
      },
      { id: 'water', label: 'Water', kind: 'material' },
    ],
    recipes: [],
    facilities: [],
  });
}
function setup() {
  const s = world();
  s.createInventory({
    id: 'bag',
    capacity: { kind: 'slots', limit: 1, stackLimit: 10 },
    modifiers: { decay: 2 },
    metadata: { title: 'Backpack' },
  });
  s.createInventory({
    id: 'hand',
    attachment: { objectId: 'player', slot: 'mainHand' },
    equipment: { accepts: ['sword'] },
    modifiers: { power: 1.5 },
  });
  return s;
}
const spawn = (s, inventory, resource, attrs) => {
  const id = s.spawnItem(inventory, resource, attrs);
  return s.inventory(inventory).item(id);
};
const unchanged = (s, action) => {
  const before = s.save();
  action();
  assert.deepEqual(s.save(), before);
};
test('modifiers are detached matching-key multipliers, never permanent attributes or automatic time', () => {
  const s = setup();
  const item = spawn(s, 'bag', 'food', { decay: 1, freshness: 100, power: 10 });
  assert.equal(s.inventory('bag').effectiveItemAttributes(item.id).decay, 2);
  s.createInventory({
    id: 'fridge',
    capacityPerMaterial: 5,
    modifiers: { decay: 0.1, irrelevant: 2 },
  });
  assert.equal(s.transferItem('bag', 'fridge', item.id), true);
  assert.deepEqual(s.inventory('fridge').effectiveItemAttributes(item.id), {
    decay: 0.1,
    freshness: 100,
    power: 10,
  });
  s.advanceTicks(20);
  assert.equal(s.inventory('fridge').item(item.id).attributes.freshness, 100);
  const modifiers = { decay: 0, power: -2 };
  s.setInventoryModifiers('fridge', modifiers);
  modifiers.power = 900;
  assert.equal(
    s.inventory('fridge').effectiveItemAttributes(item.id).power,
    -20,
  );
  assert.equal(s.inventory('fridge').effectiveItemAttributes(item.id).decay, 0);
  const view = s.inventory('fridge').summary();
  view.modifiers.decay = 200;
  assert.equal(s.inventory('fridge').effectiveItemAttributes(item.id).decay, 0);
  s.setInventoryModifiers('fridge', {});
  assert.deepEqual(
    s.inventory('fridge').effectiveItemAttributes(item.id),
    item.attributes,
  );
  assert.equal(
    s.inventory('fridge').effectiveItemAttributes('missing'),
    undefined,
  );
  const effective = s.inventory('fridge').effectiveItemAttributes(item.id);
  effective.decay = 8;
  assert.deepEqual(s.inventory('fridge').item(item.id), item);
  s.setInventoryModifiers('fridge', { power: Number.MAX_VALUE });
  unchanged(s, () =>
    assert.throws(
      () => s.inventory('fridge').effectiveItemAttributes(item.id),
      /overflow/,
    ),
  );
});
test('metadata is separate inert JSON, deeply copied, replaceable and safe for special keys', () => {
  const s = setup(),
    metadata = JSON.parse(
      '{"label":"Cold","nested":{"a":[null,true,3]},"__proto__":{"x":1}}',
    );
  s.setInventoryMetadata('bag', metadata);
  metadata.nested.a[2] = 99;
  const snapshot = s.inventory('bag').snapshot();
  assert.equal(snapshot.metadata.nested.a[2], 3);
  snapshot.metadata.nested.a[2] = 8;
  assert.equal(s.inventory('bag').summary().metadata.nested.a[2], 3);
  assert.equal(
    Object.hasOwn(s.inventory('bag').summary().metadata, '__proto__'),
    true,
  );
  assert.deepEqual(s.inventory('bag').summary().modifiers, { decay: 2 });
  s.setInventoryMetadata('bag', {});
  assert.deepEqual(s.inventory('bag').summary().metadata, {});
});
test('invalid modifier/metadata input refuses atomically, with bounded validation', () => {
  const s = setup();
  const cycle = {};
  cycle.self = cycle;
  let deep = {};
  for (let n = 0; n < 18; n++) deep = { deep };
  const accessor = Object.defineProperty({}, 'a', {
    enumerable: true,
    get() {
      throw Error('should not invoke');
    },
  });
  const arrayAccessor = [1];
  Object.defineProperty(arrayAccessor, 0, {
    get() {
      throw Error('should not invoke');
    },
    enumerable: true,
  });
  const hidden = Object.defineProperty({}, 'a', { value: 1 });
  const symbol = { [Symbol('a')]: 1 };
  for (const bad of [
    null,
    [],
    undefined,
    new Date(),
    cycle,
    deep,
    { a: Infinity },
    { a: undefined },
    { a: () => 1 },
    { a: 1n },
    { a: new Map() },
    { a: Array(2) },
    { a: arrayAccessor },
    accessor,
    hidden,
    symbol,
    { a: Array(4097).fill(0) },
  ])
    unchanged(s, () => assert.throws(() => s.setInventoryMetadata('bag', bad)));
  for (const bad of [
    null,
    [],
    { a: Infinity },
    { a: NaN },
    { a: '1' },
    { '': 1 },
    new Date(),
    accessor,
  ])
    unchanged(s, () =>
      assert.throws(() => s.setInventoryModifiers('bag', bad)),
    );
  unchanged(s, () =>
    assert.throws(() =>
      s.createInventory({ id: 'bad', capacityPerMaterial: 1, metadata: cycle }),
    ),
  );
  unchanged(s, () =>
    assert.throws(() => s.setInventoryMetadata('missing', {})),
  );
  unchanged(s, () =>
    assert.throws(() => s.setInventoryModifiers('missing', {})),
  );
});
test('equip, full-bag swap and unequip share exact identities, atomic events and capacity', () => {
  const s = setup(),
    a = spawn(s, 'bag', 'sword', { power: 10, durability: 80 });
  const events = [];
  s.onInventoryEvent((e) => events.push(e));
  assert.equal(s.equipItem('bag', 'hand', a.id).ok, true);
  assert.equal(s.inventory('bag').quantity('sword'), 0);
  assert.deepEqual(s.objectInventory('player', 'mainHand').item(a.id), a);
  assert.equal(s.inventory('hand').effectiveItemAttributes(a.id).power, 15);
  const b = spawn(s, 'bag', 'sword', { power: 20 });
  const prior = events.length;
  assert.equal(s.equipItem('bag', 'hand', b.id).ok, true);
  assert.equal(events.length, prior + 1);
  assert.equal(events.at(-1).changes.length, 2);
  assert.deepEqual(s.inventory('bag').item(a.id), a);
  assert.deepEqual(s.inventory('hand').item(b.id), b);
  unchanged(s, () => assert.equal(s.unequipItem('hand', 'bag').ok, false));
  s.createInventory({ id: 'stash', capacityPerMaterial: 10 });
  assert.equal(s.unequipItem('hand', 'stash').ok, true);
  const sequence = s.inventoryEventSequence();
  assert.equal(s.unequipItem('hand', 'stash').operationId, null);
  assert.equal(s.inventoryEventSequence(), sequence);
});
test('equipment restrictions hold across generic admission paths and cannot be relaxed by capacity/rules', () => {
  const s = setup();
  const hat = spawn(s, 'bag', 'hat', {});
  unchanged(s, () =>
    assert.equal(s.equipItem('bag', 'hand', hat.id).ok, false),
  );
  unchanged(s, () => assert.equal(s.deposit('hand', { water: 1 }), false));
  unchanged(s, () =>
    assert.equal(
      s.mutateInventory({
        inventoryId: 'hand',
        createItems: [{ resourceId: 'hat', attributes: {} }],
      }).ok,
      false,
    ),
  );
  s.setInventoryCapacity('hand', { kind: 'units', limit: 100 });
  s.setInventoryRules('hand', {});
  const sword = spawn(s, 'hand', 'sword', {});
  unchanged(s, () =>
    assert.equal(
      s.mutateInventory({
        inventoryId: 'hand',
        createItems: [{ resourceId: 'sword', attributes: {} }],
      }).ok,
      false,
    ),
  );
  const slot = s.inventory('hand').summary();
  slot.equipment.accepts.push('hat');
  assert.deepEqual(s.inventory('hand').summary().equipment, {
    accepts: ['sword'],
  });
  unchanged(s, () =>
    assert.throws(() => s.equipItem('bag', 'bag', hat.id), /equipment slot/),
  );
  unchanged(s, () =>
    assert.throws(() => s.unequipItem('bag', 'hand'), /equipment slot/),
  );
  unchanged(s, () =>
    assert.throws(() => s.equipItem('hand', 'hand', sword.id), /endpoints/),
  );
  unchanged(s, () =>
    assert.equal(s.equipItem('bag', 'hand', 'missing').ok, false),
  );
  s.setInventoryRules('hand', { accepts: [] }); // occupied: rejected
  assert.equal(s.inventory('hand').quantity('sword'), 1);
});
test('equipment definitions and initial goods are validated before inventory insertion', () => {
  const s = setup();
  for (const equipment of [
    null,
    [],
    {},
    { accepts: ['water'] },
    { accepts: ['unknown'] },
    { accepts: ['sword', 'sword'] },
    { accepts: ['sword'], extra: true },
  ])
    unchanged(s, () =>
      assert.throws(() => s.createInventory({ id: 'bad', equipment })),
    );
  unchanged(s, () =>
    assert.throws(() =>
      s.createInventory({
        id: 'bad',
        equipment: { accepts: ['sword'] },
        initial: { water: 1 },
      }),
    ),
  );
  s.createInventory({ id: 'closed', equipment: { accepts: [] } });
  assert.equal(s.inventory('closed').canDeposit({ water: 1 }), false);
});
test('context replacement is inert for goods events; observers cannot reenter through new commands', () => {
  const s = setup(),
    events = [];
  s.onInventoryEvent((e) => {
    events.push(e);
    assert.throws(
      () => s.setInventoryModifiers('bag', {}),
      /reentran|command/i,
    );
    assert.throws(() => s.setInventoryMetadata('bag', {}), /reentran|command/i);
  });
  const before = s.inventoryEventSequence();
  s.setInventoryModifiers('bag', { decay: 0.5 });
  s.setInventoryMetadata('bag', { title: 'New' });
  assert.equal(s.inventoryEventSequence(), before);
  assert.equal(events.length, 0);
  spawn(s, 'bag', 'food', { decay: 1 });
  assert.equal(events.length, 1);
});
test('format 7 round-trips equipment, modifiers, metadata; genuine 6 is accepted, relabeled new state refused', () => {
  const s = setup(),
    item = spawn(s, 'bag', 'sword', { power: 10 });
  s.equipItem('bag', 'hand', item.id);
  const saved = JSON.parse(JSON.stringify(s.save())),
    r = Simulation.restore(saved);
  assert.equal(saved.version, 7);
  assert.deepEqual(r.save(), saved);
  assert.equal(r.inventory('hand').effectiveItemAttributes(item.id).power, 15);
  assert.equal(r.unequipItem('hand', 'bag').ok, true);
  for (const version of [4, 5, 6]) {
    const bad = s.save();
    bad.version = version;
    assert.throws(() => Simulation.restore(bad), /version 7/);
  }
  const legacy = world();
  legacy.createInventory({ id: 'a', capacityPerMaterial: 10 });
  const v6 = legacy.save();
  v6.version = 6;
  assert.equal(Simulation.restore(v6).save().version, 7);
  for (const change of [
    (i) => (i.modifiers = { power: Infinity }),
    (i) => (i.metadata = { bad: undefined }),
    (i) => (i.equipment = { accepts: ['hat'] }),
  ]) {
    const bad = s.save();
    change(bad.inventories[1]);
    assert.throws(() => Simulation.restore(bad));
  }
});
test('reserved equipment cannot swap or unequip; in-transit modifiers follow physical location', () => {
  const s = setup();
  s.createInventory({
    id: 'destination',
    capacityPerMaterial: 10,
    modifiers: { power: 0.5 },
  });
  const a = spawn(s, 'hand', 'sword', { power: 10 }),
    b = spawn(s, 'bag', 'sword', { power: 20 });
  const d = s.reserveDelivery('hand', 'destination', {}, [a.id]).deliveryId;
  unchanged(s, () => assert.equal(s.equipItem('bag', 'hand', b.id).ok, false));
  unchanged(s, () =>
    assert.equal(s.unequipItem('hand', 'destination').ok, false),
  );
  assert.equal(s.inventory('hand').effectiveItemAttributes(a.id).power, 15);
  s.pickupDelivery(d);
  assert.equal(s.inventory('hand').effectiveItemAttributes(a.id), undefined);
  assert.equal(s.equipItem('bag', 'hand', b.id).ok, true);
  assert.equal(s.arriveDelivery(d), true);
  assert.equal(
    s.inventory('destination').effectiveItemAttributes(a.id).power,
    5,
  );
  assert.equal(s.inventory('destination').item(a.id).attributes.power, 10);
});
test('equipping checks the displaced item against source admission before any changes', () => {
  const s = setup();
  const old = spawn(s, 'hand', 'sword', { power: 1 }),
    next = spawn(s, 'bag', 'sword', { power: 2 });
  s.setInventoryRules('bag', { maxWeight: 3 });
  s.createInventory({ id: 'heavy', equipment: { accepts: ['sword', 'food'] } });
  const food = spawn(s, 'heavy', 'food', {});
  // A different accepted resource can make the swap-back invalid.
  s.createInventory({
    id: 'food-only',
    rules: { accepts: ['food'] },
    capacityPerMaterial: 10,
  });
  s.transferItem('heavy', 'food-only', food.id);
  s.transferItem('hand', 'heavy', old.id);
  unchanged(s, () =>
    assert.equal(s.equipItem('food-only', 'heavy', food.id).ok, false),
  );
  assert.equal(s.inventory('heavy').item(old.id).id, old.id);
  assert.equal(s.equipItem('bag', 'heavy', next.id).ok, true);
});
test('modifier special keys use own-key lookup; JSON metadata admits null-prototype plain records', () => {
  const s = setup();
  const id = s.spawnItem(
    'bag',
    'food',
    JSON.parse('{"constructor":2,"__proto__":4,"decay":1}'),
  );
  s.setInventoryModifiers(
    'bag',
    JSON.parse('{"constructor":3,"__proto__":0.5}'),
  );
  assert.deepEqual(
    s.inventory('bag').effectiveItemAttributes(id),
    JSON.parse('{"constructor":6,"__proto__":2,"decay":1}'),
  );
  const metadata = Object.assign(Object.create(null), {
    a: [1, { b: 'value' }],
  });
  s.setInventoryMetadata('bag', metadata);
  assert.deepEqual(s.inventory('bag').summary().metadata, {
    a: [1, { b: 'value' }],
  });
});

test('equipment admission governs cargo arrival and automatic production, including restored worlds', () => {
  const s = setup();
  s.createInventory({ id: 'remote', capacityPerMaterial: 10 });
  const first = s.spawnItem('hand', 'sword', {}),
    incoming = s.spawnItem('remote', 'sword', {});
  const d = s.reserveDelivery('remote', 'hand', {}, [incoming]).deliveryId;
  s.pickupDelivery(d);
  assert.equal(s.arriveDelivery(d), false);
  const restored = Simulation.restore(JSON.parse(JSON.stringify(s.save())));
  assert.equal(restored.unequipItem('hand', 'bag').ok, true);
  assert.equal(restored.arriveDelivery(d), true);
  assert.equal(restored.inventory('bag').item(first).id, first);
  assert.equal(restored.inventory('hand').item(incoming).id, incoming);
  const p = new Simulation({
    resources: [
      { id: 'sword', label: 'Sword', kind: 'material', storage: 'individual' },
    ],
    recipes: [
      {
        id: 'forge',
        label: 'Forge',
        durationSeconds: 1,
        inputs: {},
        outputs: { sword: 1 },
        itemAttributes: { sword: { power: { min: 5, max: 5 } } },
      },
    ],
    facilities: [
      {
        id: 'forge',
        label: 'Forge',
        category: 'production',
        recipes: ['forge'],
        constructionCost: {},
      },
    ],
  });
  p.createInventory({ id: 'site', capacityPerMaterial: 10 });
  p.createInventory({ id: 'hand', equipment: { accepts: ['sword'] } });
  p.addFacility('forge', 'site', { outputInventoryId: 'hand' });
  p.advance(3);
  assert.equal(p.inventory('hand').quantity('sword'), 1);
  const r = Simulation.restore(JSON.parse(JSON.stringify(p.save())));
  assert.equal(r.unequipItem('hand', 'site').ok, true);
  r.advance(2);
  assert.equal(r.inventory('hand').quantity('sword'), 1);
  assert.equal(r.inventory('site').quantity('sword'), 1);
});
