// An owner that exits before acknowledging its queued commands.
