import test from 'node:test';
import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
function world(capacity = 10) {
  const sim = new Simulation({
    seed: 42,
    resources: [
      {
        id: 'weapon',
        label: 'Weapon',
        kind: 'material',
        storage: 'individual',
      },
      { id: 'gem', label: 'Gem', kind: 'material', storage: 'individual' },
    ],
    recipes: [
      {
        id: 'forge',
        label: 'Forge',
        durationSeconds: 0.05,
        inputs: {},
        outputs: { weapon: 1 },
        bonusOutputs: [{ chance: 0.5, outputs: { gem: 1 } }],
      },
    ],
    facilities: [
      {
        id: 'forge',
        label: 'Forge',
        category: 'test',
        constructionCost: {},
        recipes: ['forge'],
      },
    ],
  });
  sim.createInventory({ id: 'store', capacityPerMaterial: capacity });
  sim.createInventory({ id: 'other', capacityPerMaterial: capacity });
  const f = sim.addFacility('forge', 'store').facilityId;
  return { sim, f };
}
const restore = (s) => Simulation.restore(JSON.parse(JSON.stringify(s.save())));
function consumeAll(sim) {
  for (const item of sim.inventory('store').itemPage({ limit: 500 }).items)
    sim.consumeItem('store', item.id);
}
test('external issuance is contiguous, rejects caller IDs, survives consumption and failed creation', () => {
  const { sim } = world(1);
  const first = sim.spawnItem('store', 'weapon', {});
  assert.equal(first, 'external-1');
  const before = sim.save();
  assert.equal(sim.spawnItem('store', 'weapon', {}), null);
  assert.deepEqual(sim.save(), before);
  assert.throws(
    () => sim.spawnItem('other', 'weapon', {}, first),
    /framework-owned/,
  );
  assert.deepEqual(sim.save(), before);
  sim.consumeItem('store', first);
  const copy = restore(sim);
  assert.deepEqual(copy.locateItem(first), { kind: 'retired' });
  assert.equal(copy.spawnItem('store', 'weapon', {}), 'external-2');
  assert.equal(copy.locateItem('external-3'), undefined);
  const invalid = copy.save();
  invalid.nextItem = 2;
  assert.throws(() => Simulation.restore(invalid), /unissued/);
});
test('production churn leaves no item tombstones and retains exact issued versus missed bonus proof', () => {
  const { sim } = world();
  let issued, missed;
  for (let n = 0; n < 2000; n++) {
    sim.advanceTicks(1);
    for (const item of sim.inventory('store').itemPage({ limit: 10 }).items)
      if (item.resourceId === 'gem') issued = item.id;
    const batch =
      sim.facilitySnapshot('facility-1').jobs[0].batchesCompleted - 1;
    if (batch >= 0 && !sim.inventory('store').quantity('gem'))
      missed = `facility-1.job-0.batch-${batch}.gem-0`;
    consumeAll(sim);
  }
  const saved = sim.save();
  assert.ok(!Object.hasOwn(saved, 'issuedItemIds'));
  assert.equal(saved.inventories[0].items.length, 0);
  assert.ok(issued && missed);
  const copy = restore(sim);
  assert.deepEqual(copy.locateItem(issued), { kind: 'retired' });
  assert.equal(copy.locateItem(missed), undefined);
  assert.equal(
    copy.locateItem('facility-1.job-0.batch-999999.weapon-0'),
    undefined,
  );
  assert.equal(
    copy.locateItem('facility-1.job-0.batch-0.weapon-01'),
    undefined,
  );
  sim.advance(0.073);
  copy.advance(0.073);
  assert.deepEqual(copy.save(), sim.save());
  consumeAll(sim);
  const size = JSON.stringify(sim.save()).length;
  for (let n = 0; n < 2000; n++) {
    sim.advanceTicks(1);
    consumeAll(sim);
  }
  assert.ok(JSON.stringify(sim.save()).length <= size + 64);
  assert.deepEqual(restore(sim).save(), sim.save());
  assert.deepEqual(restore(copy).save(), copy.save());
});
test('restore rejects invented bonus items and duplicate owners without a historical ledger', () => {
  const { sim } = world();
  sim.advanceTicks(2);
  const item = sim
    .inventory('store')
    .itemPage({ resourceId: 'weapon', limit: 1 }).items[0];
  const duplicate = sim.save();
  duplicate.inventories[1].items.push(structuredClone(item));
  duplicate.inventories[1].quantities.weapon = 1;
  assert.throws(() => Simulation.restore(duplicate), /duplicate/);
  const invented = sim.save();
  invented.inventories[0].items.find((i) => i.id === item.id).id =
    'facility-1.job-0.batch-0.weapon-1';
  assert.throws(() => Simulation.restore(invented), /unissued/);
  const wrongResource = sim.save();
  const wrong = wrongResource.inventories[0].items.find(
    (i) => i.id === item.id,
  );
  wrong.resourceId = 'gem';
  wrongResource.inventories[0].quantities.weapon--;
  wrongResource.inventories[0].quantities.gem =
    (wrongResource.inventories[0].quantities.gem ?? 0) + 1;
  assert.throws(() => Simulation.restore(wrongResource), /unissued|provenance/);
  const impossibleBonus = sim.save();
  impossibleBonus.inventories[0].items.push({
    id: 'facility-1.job-0.batch-0.gem-1',
    resourceId: 'gem',
    attributes: {},
  });
  impossibleBonus.inventories[0].quantities.gem =
    (impossibleBonus.inventories[0].quantities.gem ?? 0) + 1;
  assert.throws(() => Simulation.restore(impossibleBonus), /unissued/);
  const future = sim.save();
  future.inventories[0].items.find((i) => i.id === item.id).id = 'external-999';
  assert.throws(() => Simulation.restore(future), /unissued/);
});
test('removed producer provenance validates live cargo and retired goods after history pruning', () => {
  const { sim, f } = world();
  sim.advanceTicks(2);
  sim.setFacilityDraining(f, true);
  sim.advanceTicks(1);
  const item = sim
    .inventory('store')
    .itemPage({ resourceId: 'weapon', limit: 1 }).items[0];
  const d = sim.reserveDelivery('store', 'other', {}, [item.id]);
  sim.pickupDelivery(d.deliveryId);
  assert.ok(sim.removeFacility(f).ok);
  const copy = restore(sim);
  assert.equal(copy.locateItem(item.id).kind, 'delivery');
  copy.arriveDelivery(d.deliveryId);
  copy.pruneDeliveries();
  assert.deepEqual(copy.inventory('other').item(item.id), item);
  copy.consumeItem('other', item.id);
  assert.deepEqual(restore(copy).locateItem(item.id), { kind: 'retired' });
});
