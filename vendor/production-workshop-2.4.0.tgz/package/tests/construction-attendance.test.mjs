import test from 'node:test';
import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
function world({ staffed = false, capacity = 10 } = {}) {
  const s = new Simulation({
    resources: [
      { id: 'ore', label: 'Ore', kind: 'material' },
      { id: 'wood', label: 'Wood', kind: 'material' },
      { id: 'credits', label: 'Credits', kind: 'currency' },
      {
        id: 'weapon',
        label: 'Weapon',
        kind: 'material',
        storage: 'individual',
      },
    ],
    recipes: [
      {
        id: 'make',
        label: 'Make',
        durationSeconds: 0.15,
        inputs: { ore: 1 },
        outputs: { weapon: 1 },
        itemAttributes: { weapon: { health: { min: 80, max: 100 } } },
      },
    ],
    facilities: [
      {
        id: 'factory',
        label: 'Factory',
        category: 'test',
        recipes: ['make'],
        constructionCost: { wood: 2, credits: 3 },
        capacityProvided: 2,
        ...(staffed
          ? { workersRequired: { smith: 2 }, minimumWorkforce: { smith: 2 } }
          : {}),
      },
      {
        id: 'home',
        label: 'Home',
        category: 'test',
        recipes: [],
        constructionCost: {},
        workersProvided: { smith: 4 },
      },
      {
        id: 'auto',
        label: 'Auto',
        category: 'test',
        recipes: ['make'],
        constructionCost: {},
      },
    ],
  });
  s.createInventory({
    id: 'site',
    capacityPerMaterial: capacity,
    initial: { ore: 4 },
  });
  s.createInventory({
    id: 'warehouse',
    capacityPerMaterial: 20,
    initial: { wood: 10, credits: 20, ore: 10 },
  });
  s.createInventory({ id: 'output', capacityPerMaterial: 0 });
  return s;
}
const reload = (s) => Simulation.restore(JSON.parse(JSON.stringify(s.save())));
const fund = (s) => s.transfer('warehouse', 'site', { wood: 2, credits: 3 });
const order = (s) =>
  s.createConstructionOrder('factory', 'site', { durationSeconds: 0.2 });
test('instant addFacility stays immediate; timed order has no early production or benefits', () => {
  const s = world();
  fund(s);
  const id = order(s);
  assert.equal(s.facilityIds().length, 0);
  assert.equal(s.inventory('site').capacityPerMaterial, 10);
  s.advance(0.1);
  const active = s.constructionOrderSnapshot(id);
  assert.equal(active.progress, 0.5);
  assert.equal(
    s.inspectReservations('site').find((r) => r.owner.id === id).owner.kind,
    'construction',
  );
  assert.equal(s.facilityIds().length, 0);
  assert.equal(s.inventory('site').quantity('wood'), 2);
  assert.equal(s.inventory('site').available('wood'), 0);
  s.advance(0.1);
  const complete = s.constructionOrderSnapshot(id);
  assert.equal(complete.state, 'completed');
  assert.equal(complete.consumedMaterials.wood, 2);
  assert.equal(s.inventory('site').quantity('wood'), 0);
  assert.equal(s.inventory('site').capacityPerMaterial, 12);
  assert.equal(s.facilityIds().length, 1);
  const direct = world();
  fund(direct);
  assert.ok(direct.addFacility('factory', 'site').ok);
  assert.equal(direct.facilityIds().length, 1);
  assert.equal(direct.inventory('site').quantity('wood'), 0);
  assert.equal(direct.inventory('site').capacityPerMaterial, 12);
});
test('incoming commitments do not start construction; arrived site materials do', () => {
  const s = world();
  const id = order(s),
    d = s.reserveDelivery('warehouse', 'site', { wood: 2, credits: 3 });
  s.pickupDelivery(d.deliveryId);
  s.advance(0.3);
  assert.equal(s.constructionOrderSnapshot(id).progress, 0);
  assert.deepEqual(s.constructionOrderSnapshot(id).missingMaterials, {
    wood: 2,
    credits: 3,
  });
  assert.equal(s.constructionOrderSnapshot(id).incomingMaterials.wood, 2);
  assert.deepEqual(s.constructionDemands()[0].quantities, {
    wood: 2,
    credits: 3,
  });
  const copy = reload(s);
  assert.equal(copy.deliverySnapshot(d.deliveryId).state, 'in-transit');
  copy.arriveDelivery(d.deliveryId);
  copy.advance(0.2);
  assert.equal(copy.constructionOrderSnapshot(id).state, 'completed');
});
test('competing orders hold partial materials in creation order without double spending', () => {
  const s = world();
  s.transfer('warehouse', 'site', { wood: 1, credits: 6 });
  const first = order(s),
    second = order(s);
  s.advance(0.1);
  assert.equal(s.constructionOrderSnapshot(first).reservedMaterials.wood, 1);
  assert.equal(s.constructionOrderSnapshot(second).reservedMaterials.wood, 0);
  assert.equal(s.constructionOrderSnapshot(first).progress, 0);
  assert.equal(s.inventory('site').reserved('credits'), 6);
  s.transfer('warehouse', 'site', { wood: 1 });
  s.advance(0.2);
  assert.equal(s.constructionOrderSnapshot(first).state, 'completed');
  assert.equal(s.constructionOrderSnapshot(second).state, 'waiting-materials');
  s.transfer('warehouse', 'site', { wood: 2 });
  s.advance(0.2);
  assert.equal(s.constructionOrderSnapshot(second).state, 'completed');
  assert.equal(s.facilityIds().length, 2);
  assert.equal(s.inventory('site').quantity('credits'), 0);
});
for (const phase of ['unfunded', 'partial', 'building', 'awaiting-activation'])
  test(`cancellation at ${phase} releases holdings without destroying stock or cargo`, () => {
    const s = world({ staffed: phase === 'awaiting-activation' });
    const id = order(s);
    if (phase === 'partial') s.transfer('warehouse', 'site', { wood: 1 });
    else if (phase !== 'unfunded') fund(s);
    if (phase !== 'unfunded')
      s.advance(phase === 'awaiting-activation' ? 0.2 : 0.05);
    const d = s.reserveDelivery('warehouse', 'site', { ore: 1 });
    s.pickupDelivery(d.deliveryId);
    const before = s.inventory('site').snapshot().quantities;
    const r = s.cancelConstructionOrder(id);
    assert.ok(r.ok);
    assert.deepEqual(r.consumedMaterials, {});
    assert.deepEqual(s.inventory('site').snapshot().quantities, before);
    assert.equal(s.deliverySnapshot(d.deliveryId).state, 'in-transit');
    assert.equal(s.inventory('site').reserved('wood'), 0);
    assert.equal(s.facilityIds().length, 0);
    assert.equal(s.constructionOrderSnapshot(id).state, 'cancelled');
    assert.deepEqual(reload(s).save(), s.save());
    assert.equal(s.cancelConstructionOrder(id).ok, false);
  });
test('activation can wait for workforce; paid materials remain reserved, then charged once', () => {
  const s = world({ staffed: true });
  fund(s);
  const id = order(s);
  s.advance(0.2);
  assert.equal(s.constructionOrderSnapshot(id).state, 'awaiting-activation');
  assert.equal(s.constructionOrderSnapshot(id).blockers[0].code, 'workforce');
  assert.equal(s.inventory('site').quantity('wood'), 2);
  const copy = reload(s);
  copy.addFacility('home', 'site');
  copy.advanceTicks(1);
  const complete = copy.constructionOrderSnapshot(id);
  assert.equal(complete.state, 'completed');
  assert.equal(copy.facilityIds().length, 2);
  assert.equal(copy.inventory('site').quantity('credits'), 0);
  assert.deepEqual(copy.facilitySnapshot(complete.facilityId).attendance, {});
  const before = complete.facilityId;
  copy.advance(1);
  assert.equal(copy.constructionOrderSnapshot(id).facilityId, before);
  assert.equal(copy.facilityIds().length, 2);
  assert.equal(copy.cancelConstructionOrder(id).ok, false);
});
test('activation overflow and exhausted facility IDs never charge or partially activate', () => {
  for (const field of ['capacity', 'nextId']) {
    const s = world();
    fund(s);
    const id = order(s);
    const data = s.save();
    if (field === 'capacity')
      data.inventories[0].capacityPerMaterial = Number.MAX_SAFE_INTEGER;
    else data.nextId = Number.MAX_SAFE_INTEGER;
    const copy = Simulation.restore(data);
    copy.advance(0.2);
    assert.equal(
      copy.constructionOrderSnapshot(id).state,
      'awaiting-activation',
    );
    assert.equal(copy.facilityIds().length, 0);
    assert.equal(copy.inventory('site').quantity('wood'), 2);
    assert.deepEqual(copy.constructionOrderSnapshot(id).consumedMaterials, {});
    assert.deepEqual(reload(copy).save(), copy.save());
  }
});
test('construction counter and duration validation reject before mutation', () => {
  const s = world();
  const before = s.save();
  for (const durationSeconds of [0, -1, NaN, Infinity, 0.0000001])
    assert.throws(() =>
      s.createConstructionOrder('factory', 'site', { durationSeconds }),
    );
  assert.deepEqual(s.save(), before);
  const data = s.save();
  data.nextConstruction = Number.MAX_SAFE_INTEGER;
  const copy = Simulation.restore(data);
  assert.throws(() => order(copy), /exhausted/);
  assert.deepEqual(copy.save(), data);
});
test('save/reload mid-construction and elapsed partitions preserve exact completion and RNG state', () => {
  const a = world(),
    b = world();
  fund(a);
  fund(b);
  const id = order(a);
  order(b);
  a.advance(0.073);
  let resumed = reload(a);
  a.advance(0.427);
  resumed.advance(0.427);
  for (let n = 0; n < 50; n++) b.advance(0.01);
  assert.deepEqual(resumed.save(), a.save());
  assert.deepEqual(b.save(), a.save());
  assert.equal(a.constructionOrderSnapshot(id).state, 'completed');
});
test('restore rejects malformed order ownership, charges, progress and associations', () => {
  const s = world();
  fund(s);
  const id = order(s);
  s.advance(0.05);
  for (const corrupt of [
    (d) => (d.nextConstruction = 1),
    (d) => (d.constructionOrders[0].elapsedMicroseconds = 999999),
    (d) => (d.constructionOrders[0].inventoryId = 'missing'),
    (d) => (d.constructionOrders[0].consumedMaterials = { wood: 2 }),
    (d) => (d.constructionOrders[0].facilityId = 'facility-1'),
    (d) => (d.inventories[0].reservations[0].token = 'orphan'),
    (d) => d.constructionOrders.push(structuredClone(d.constructionOrders[0])),
  ]) {
    const data = s.save();
    corrupt(data);
    assert.throws(() => Simulation.restore(data));
  }
  s.advance(0.15);
  const done = s.save();
  done.constructionOrders[0].facilityId = 'facility-999';
  assert.throws(() => Simulation.restore(done));
  assert.equal(s.constructionOrderSnapshot(id).state, 'completed');
});
test('active orders guard inventory retirement; terminal history survives retirement and factory removal', () => {
  const s = world();
  fund(s);
  const id = s.createConstructionOrder('factory', 'site', {
    durationSeconds: 0.1,
    inputInventoryId: 'warehouse',
    outputInventoryId: 'output',
  });
  const before = s.save();
  assert.equal(
    s.removeInventory('output').blockers[0].code,
    'construction-reference',
  );
  assert.deepEqual(s.save(), before);
  s.advance(0.1);
  const f = s.constructionOrderSnapshot(id).facilityId;
  s.setFacilityDraining(f, true);
  assert.ok(s.removeFacility(f).ok);
  assert.ok(s.removeInventory('output').ok);
  assert.deepEqual(reload(s).save(), s.save());
  assert.equal(s.pruneConstructionOrders(), 1);
  assert.throws(() => s.constructionOrderSnapshot(id), /unknown/);
  assert.equal(s.save().nextConstruction, 2);
});
test('paused production freezes work and pending publication; unrelated production and deliveries continue', () => {
  const s = world();
  s.increaseCapacity('output', 1);
  const paused = s.addFacility('auto', 'site', {
    outputInventoryId: 'output',
  }).facilityId;
  const other = s.addFacility('auto', 'warehouse').facilityId;
  s.advance(0.1);
  const mid = s.facilitySnapshot(paused).jobs[0].progress;
  const filler = s.spawnItem('output', 'weapon', {});
  s.setFacilityEnabled(paused, false);
  const d = s.reserveDelivery('warehouse', 'site', { ore: 1 });
  s.pickupDelivery(d.deliveryId);
  s.advance(0.5);
  s.arriveDelivery(d.deliveryId);
  assert.equal(s.facilitySnapshot(paused).jobs[0].progress, mid);
  assert.ok(s.facilitySnapshot(other).jobs[0].batchesCompleted > 0);
  s.setFacilityEnabled(paused, true);
  s.advance(0.15);
  assert.ok(s.facilitySnapshot(paused).jobs[0].pendingOutcome);
  s.setFacilityEnabled(paused, false);
  s.consumeItem('output', filler);
  let copy = reload(s);
  copy.advance(0.5);
  assert.equal(copy.inventory('output').quantity('weapon'), 0);
  copy.setFacilityEnabled(paused, true);
  copy.advanceTicks(1);
  assert.equal(copy.inventory('output').quantity('weapon'), 1);
});
test('required attendance blocks starts, advancement and publication even with boosts; autonomous work continues', () => {
  const s = world({ staffed: true });
  s.increaseCapacity('output', 1);
  s.addFacility('home', 'site');
  fund(s);
  const f = s.addFacility('factory', 'site', {
    outputInventoryId: 'output',
  }).facilityId;
  const other = s.addFacility('auto', 'warehouse').facilityId;
  s.setProductionModifier(f, 'boost', { productivityMultiplier: 100 });
  s.advance(0.2);
  assert.equal(s.facilitySnapshot(f).jobs[0].progress, 0);
  assert.equal(s.inventory('site').quantity('ore'), 4);
  assert.ok(s.facilitySnapshot(other).jobs[0].batchesCompleted > 0);
  s.setFacilityAttendance(f, { smith: 1 });
  s.advance(0.1);
  assert.equal(s.facilitySnapshot(f).jobs[0].progress, 0);
  s.setProductionModifier(f, 'boost', null);
  s.setFacilityAttendance(f, { smith: 2 });
  s.advance(0.1);
  const progress = s.facilitySnapshot(f).jobs[0].progress;
  assert.ok(progress > 0);
  const filler = s.spawnItem('output', 'weapon', {});
  const owned = s.facilitySnapshot(f).jobs[0].batchInputItems;
  s.setFacilityAttendance(f, {});
  let copy = reload(s);
  copy.advance(0.3);
  assert.equal(copy.facilitySnapshot(f).jobs[0].progress, progress);
  assert.deepEqual(copy.facilitySnapshot(f).jobs[0].batchInputItems, owned);
  copy.setFacilityAttendance(f, { smith: 2 });
  copy.advance(0.15);
  assert.ok(copy.facilitySnapshot(f).jobs[0].pendingOutcome);
  copy.setFacilityAttendance(f, { smith: 0 });
  copy.consumeItem('output', filler);
  copy.advance(0.2);
  assert.equal(copy.inventory('output').quantity('weapon'), 0);
  copy.setFacilityAttendance(f, { smith: 2 });
  copy.advanceTicks(1);
  assert.equal(copy.inventory('output').quantity('weapon'), 1);
});
test('attendance validation and pause/drain persistence cannot invent staff or enable remote work', () => {
  const s = world({ staffed: true });
  s.addFacility('home', 'site');
  fund(s);
  const f = s.addFacility('factory', 'site').facilityId;
  for (const attendance of [
    { smith: 3 },
    { smith: -1 },
    { smith: 0.5 },
    { other: 2 },
  ]) {
    const before = s.save();
    assert.throws(() => s.setFacilityAttendance(f, attendance));
    assert.deepEqual(s.save(), before);
  }
  s.setFacilityAttendance(f, { smith: 2 });
  s.advance(0.1);
  s.setFacilityDraining(f, true);
  s.setFacilityEnabled(f, false);
  const copy = reload(s);
  assert.equal(copy.facilitySnapshot(f).draining, true);
  assert.equal(copy.facilitySnapshot(f).enabled, false);
  assert.deepEqual(copy.facilitySnapshot(f).attendance, { smith: 2 });
  const data = copy.save();
  data.facilities.find((i) => i.id === f).attendance.smith = 3;
  assert.throws(() => Simulation.restore(data));
  delete data.facilities.find((i) => i.id === f).attendance;
  assert.throws(() => Simulation.restore(data));
  copy.setFacilityEnabled(f, true);
  copy.advance(0.3);
  assert.equal(copy.facilitySnapshot(f).jobs[0].batchesCompleted, 1);
  assert.equal(copy.facilitySnapshot(f).jobs[0].state, 'drained');
});

test('one attending worker in ten slots runs at 10 percent; full staffing is an explicit minimum', () => {
  for (const minimum of [undefined, { smith: 10 }]) {
    const c = world().save().configuration;
    c.facilities.find((f) => f.id === 'factory').workersRequired = {
      smith: 10,
    };
    c.facilities.find((f) => f.id === 'factory').workerSlots = 10;
    c.facilities.find((f) => f.id === 'home').workersProvided = { smith: 10 };
    if (minimum)
      c.facilities.find((f) => f.id === 'factory').minimumWorkforce = minimum;
    else delete c.facilities.find((f) => f.id === 'factory').minimumWorkforce;
    const s = new Simulation(c);
    s.createInventory({
      id: 'site',
      capacityPerMaterial: 20,
      initial: { ore: 10, wood: 2, credits: 3 },
    });
    s.addFacility('home', 'site');
    const f = s.addFacility('factory', 'site').facilityId;
    s.setFacilityAttendance(f, { smith: 1 });
    assert.equal(s.facilitySnapshot(f).productivity, minimum ? 0 : 0.1);
    s.advance(0.2);
    if (minimum) {
      assert.equal(s.facilitySnapshot(f).jobs[0].progress, 0);
      assert.equal(s.facilitySnapshot(f).missingWorkforce.smith, 9);
    } else assert.ok(s.facilitySnapshot(f).jobs[0].progress > 0);
    s.setFacilityAttendance(f, { smith: 10 });
    assert.equal(s.facilitySnapshot(f).productivity, 1);
    assert.deepEqual(reload(s).save(), s.save());
  }
});
test('completion events associate exactly one facility and remain valid in observers after reload', () => {
  const s = world();
  fund(s);
  const id = order(s);
  s.advance(0.1);
  const copy = reload(s);
  const events = [];
  copy.onEvent((e) => {
    events.push(e);
    assert.deepEqual(copy.validateState(), { ok: true });
    assert.throws(() => copy.cancelConstructionOrder(id), /observer/);
  });
  copy.advance(1);
  assert.equal(
    events.filter((e) => e.type === 'construction-completed').length,
    1,
  );
  assert.equal(events.filter((e) => e.type === 'facility-built').length, 1);
  const done = events.find((e) => e.type === 'construction-completed');
  assert.equal(done.orderId, id);
  assert.equal(done.facilityId, copy.constructionOrderSnapshot(id).facilityId);
  copy.advance(1);
  assert.equal(
    events.filter((e) => e.type === 'construction-completed').length,
    1,
  );
});
test('construction demand prediction never assigns the same free site materials to two orders', () => {
  const s = world();
  fund(s);
  const first = order(s),
    second = order(s);
  assert.deepEqual(s.constructionDemands(), [
    {
      orderId: second,
      inventoryId: 'site',
      quantities: { wood: 2, credits: 3 },
    },
  ]);
  assert.equal(s.constructionOrderSnapshot(first).progress, 0);
  s.advanceTicks(1);
  assert.deepEqual(s.constructionDemands(), [
    {
      orderId: second,
      inventoryId: 'site',
      quantities: { wood: 2, credits: 3 },
    },
  ]);
});
test('minimum staffing definitions reject impossible counts and saved partial attendance is exact', () => {
  for (const minimumWorkforce of [
    { smith: 3 },
    { other: 1 },
    { smith: -1 },
    { smith: 0.5 },
  ]) {
    const config = world({ staffed: true }).save().configuration;
    config.facilities.find((f) => f.id === 'factory').minimumWorkforce =
      minimumWorkforce;
    assert.throws(() => new Simulation(config));
  }
  const c = world({ staffed: true }).save().configuration;
  c.facilities.find((f) => f.id === 'factory').minimumWorkforce = { smith: 1 };
  const s = new Simulation(c);
  s.createInventory({
    id: 'site',
    capacityPerMaterial: 10,
    initial: { wood: 2, credits: 3, ore: 5 },
  });
  s.addFacility('home', 'site');
  const f = s.addFacility('factory', 'site').facilityId;
  s.setFacilityAttendance(f, { smith: 1 });
  assert.equal(s.facilitySnapshot(f).productivity, 0.5);
  s.advance(0.1);
  const copy = reload(s);
  assert.equal(copy.facilitySnapshot(f).attendance.smith, 1);
  assert.equal(copy.facilitySnapshot(f).productivity, 0.5);
  s.advance(0.7);
  for (let n = 0; n < 70; n++) copy.advance(0.01);
  assert.deepEqual(copy.save(), s.save());
});
test('workforce claimed during construction delays activation without losing reserved materials', () => {
  const s = world({ staffed: true });
  s.addFacility('home', 'site');
  s.transfer('warehouse', 'site', { wood: 6, credits: 9 });
  const id = order(s);
  s.advance(0.1);
  const first = s.addFacility('factory', 'site').facilityId,
    second = s.addFacility('factory', 'site').facilityId;
  s.setFacilityEnabled(first, false);
  s.setFacilityEnabled(second, false);
  s.advance(0.1);
  assert.equal(s.constructionOrderSnapshot(id).state, 'awaiting-activation');
  assert.equal(s.inventory('site').quantity('wood'), 2);
  assert.equal(s.inventory('site').reserved('wood'), 2);
  assert.deepEqual(s.constructionOrderSnapshot(id).consumedMaterials, {});
  assert.ok(s.removeFacility(first).ok);
  const copy = reload(s);
  copy.advanceTicks(1);
  assert.equal(copy.constructionOrderSnapshot(id).state, 'completed');
  assert.equal(copy.inventory('site').quantity('wood'), 0);
  assert.equal(copy.facilityIds().length, 3);
});
