import test from 'node:test';
import assert from 'node:assert/strict';
import { Simulation, DefinitionError } from '../dist/index.js';
function fixture({
  inputs = { ore: 2, weapon: 1 },
  optionalInputs = {},
  durationSeconds = 1,
} = {}) {
  const sim = new Simulation({
    tickMilliseconds: 100,
    resources: [
      { id: 'ore', label: 'Ore', kind: 'material' },
      { id: 'alloy', label: 'Alloy', kind: 'material' },
      ...['weapon', 'tool'].map((id) => ({
        id,
        label: id,
        kind: 'material',
        storage: 'individual',
      })),
    ],
    recipes: [
      {
        id: 'recycle',
        label: 'Recycle',
        durationSeconds,
        inputs,
        optionalInputs,
        outputs: { alloy: 1 },
      },
    ],
    facilities: [
      {
        id: 'factory',
        label: 'Factory',
        category: 'production',
        recipes: ['recycle'],
        constructionCost: {},
        workersRequired: { smith: 1 },
      },
      {
        id: 'home',
        label: 'Home',
        category: 'population',
        recipes: [],
        constructionCost: {},
        workersProvided: { smith: 2, zero: 0 },
      },
      {
        id: 'warehouse',
        label: 'Warehouse',
        category: 'storage',
        recipes: [],
        constructionCost: {},
        capacityProvided: 10,
      },
    ],
  });
  sim.createInventory({
    id: 'store',
    capacityPerMaterial: 10,
    initial: { ore: 8 },
  });
  sim.createInventory({ id: 'buffer', capacityPerMaterial: 10 });
  sim.createInventory({ id: 'destination', capacityPerMaterial: 10 });
  const home = sim.addFacility('home', 'store').facilityId;
  const f = sim.addFacility('factory', 'store').facilityId;
  sim.setFacilityAttendance(f, { smith: 1 });
  const a = sim.spawnItem('store', 'weapon', { health: 20 });
  const b = sim.spawnItem('store', 'weapon', { health: 100 });
  const tool = sim.spawnItem('store', 'tool', { precision: 0.9 });
  return { sim, f, home, a, b, tool, job: `${f}.job-0` };
}
const roundtrip = (sim) =>
  Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
const valid = (sim) => assert.deepEqual(sim.validateState(), { ok: true });
test('individual recipes require explicit one-shot selection and never consume another item', () => {
  const { sim, f, a, b, job } = fixture();
  sim.advance(0.2);
  assert.equal(sim.inventory('store').reserved('ore'), 0);
  assert.ok(
    sim
      .explainJob(job)
      .blockers.some((b) => b.code === 'missing-item-selection'),
  );
  assert.deepEqual(sim.materialDemands()[0].itemSelection, {
    required: { weapon: 1 },
    selectedIds: [],
  });
  const selected = [a];
  sim.setInputItems(f, 'recycle', selected);
  selected[0] = b;
  sim.advance(0.1);
  assert.equal(sim.inventory('store').item(a), undefined);
  assert.equal(sim.inventory('store').item(b).attributes.health, 100);
  const view = sim.facilitySnapshot(f).jobs[0];
  assert.deepEqual(view.selectedInputItemIds, []);
  assert.equal(view.batchInputItems[0].id, a);
  view.batchInputItems[0].attributes.health = 999;
  assert.equal(
    sim.facilitySnapshot(f).jobs[0].batchInputItems[0].attributes.health,
    20,
  );
  assert.deepEqual(sim.locateItem(a), { kind: 'retired' });
  sim.advance(3);
  assert.equal(sim.facilitySnapshot(f).jobs[0].batchesCompleted, 1);
  assert.ok(sim.inventory('store').item(b));
  valid(sim);
});
test('selected equipment and bulk are reserved incrementally with delivery competition and latest attributes', () => {
  const { sim, f, a, b, job } = fixture();
  sim.withdraw('store', { ore: 8 });
  sim.deposit('store', { ore: 1 });
  const d = sim.reserveDelivery('store', 'destination', {}, [a]);
  assert.ok(d.ok);
  sim.setInputItems(f, 'recycle', [a]);
  sim.advance(0.1);
  assert.equal(sim.inventory('store').reserved('ore'), 1);
  assert.ok(
    sim
      .explainJob(job)
      .blockers.some((b) => b.code === 'selected-items-unavailable'),
  );
  assert.deepEqual(sim.materialDemands()[0].quantities, { ore: 1, weapon: 1 });
  sim.cancelDelivery(d.deliveryId);
  sim.advance(0.1);
  assert.deepEqual(
    sim.inspectReservations('store').find((r) => r.owner.id === job).itemIds,
    [a],
  );
  assert.equal(sim.consumeItem('store', a), false);
  assert.equal(sim.transferItem('store', 'destination', a), false);
  sim.updateItemAttributes('store', a, { health: 35 });
  sim.deposit('store', { ore: 1 });
  let inputs;
  sim.onEvent((e) => {
    if (e.type === 'batch-started') {
      inputs = e.inputs;
      e.inputs.items[0].attributes.health = 999;
    }
  });
  const restored = roundtrip(sim);
  sim.advance(0.1);
  restored.advance(0.1);
  assert.equal(inputs.items[0].id, a);
  assert.equal(
    sim.facilitySnapshot(f).jobs[0].batchInputItems[0].attributes.health,
    35,
  );
  assert.deepEqual(sim.save(), restored.save());
  assert.ok(sim.inventory('store').item(b));
  valid(sim);
});
test('selection changes are atomic, release holdings, and reject incorrect identities and quantities', () => {
  const { sim, f, a, b, tool } = fixture();
  sim.withdraw('store', { ore: 8 });
  sim.deposit('store', { ore: 1 });
  sim.setInputItems(f, 'recycle', [a]);
  sim.advance(0.1);
  const before = sim.save();
  for (const ids of [[a, a], [a, b], [tool], ['unknown'], null]) {
    assert.throws(() => sim.setInputItems(f, 'recycle', ids), DefinitionError);
    assert.deepEqual(sim.save(), before);
  }
  sim.setInputItems(f, 'recycle', [a]);
  assert.deepEqual(sim.save(), before);
  sim.setInputItems(f, 'recycle', [b]);
  assert.equal(sim.inventory('store').reserved('weapon'), 0);
  assert.equal(sim.inventory('store').reserved('ore'), 0);
  sim.advance(0.1);
  assert.deepEqual(sim.facilitySnapshot(f).jobs[0].selectedInputItemIds, [b]);
  sim.setInputItems(f, 'recycle', []);
  assert.deepEqual(sim.inspectReservations('store'), []);
  valid(sim);
});
test('next selection during an active batch survives restore without changing consumed history', () => {
  const { sim, f, a, b } = fixture();
  sim.setInputItems(f, 'recycle', [a]);
  sim.advance(0.4);
  sim.setInputItems(f, 'recycle', [b]);
  const restored = roundtrip(sim);
  assert.equal(restored.facilitySnapshot(f).jobs[0].batchInputItems[0].id, a);
  assert.deepEqual(restored.facilitySnapshot(f).jobs[0].selectedInputItemIds, [
    b,
  ]);
  sim.advance(2);
  restored.advance(2);
  assert.deepEqual(sim.save(), restored.save());
  assert.equal(sim.facilitySnapshot(f).jobs[0].batchesCompleted, 2);
  valid(restored);
});
test('optional individual ingredients use exact combined quantities and changing options clears the next selection', () => {
  const { sim, f, a, b } = fixture({
    inputs: { weapon: 1 },
    optionalInputs: { weapon: 1, tool: 1 },
  });
  sim.setOptionalInputs(f, 'recycle', { weapon: 1 });
  assert.throws(() => sim.setInputItems(f, 'recycle', [a]), DefinitionError);
  sim.setInputItems(f, 'recycle', [a, b]);
  sim.advance(0.1);
  sim.setOptionalInputs(f, 'recycle', { tool: 1 });
  assert.deepEqual(sim.facilitySnapshot(f).jobs[0].selectedInputItemIds, []);
  const restored = roundtrip(sim);
  sim.advance(1);
  restored.advance(1);
  assert.deepEqual(sim.save(), restored.save());
  valid(sim);
});
test('moving or consuming a selected but unreserved identity leaves a waiting request across restore', () => {
  for (const move of [true, false]) {
    const { sim, f, a, b } = fixture();
    sim.setInputItems(f, 'recycle', [a]);
    if (move) sim.transferItem('store', 'destination', a);
    else sim.consumeItem('store', a);
    const restored = roundtrip(sim);
    sim.advance(1);
    restored.advance(1);
    assert.deepEqual(sim.save(), restored.save());
    assert.equal(sim.facilitySnapshot(f).jobs[0].batchesCompleted, 0);
    assert.ok(sim.inventory('store').item(b));
    valid(sim);
  }
});
test('two jobs selecting the same identity compete through the reservation owner, not duplicated stock', () => {
  const { sim, f, a } = fixture();
  const second = sim.addFacility('factory', 'store').facilityId;
  sim.setFacilityAttendance(second, { smith: 1 });
  sim.setInputItems(f, 'recycle', [a]);
  sim.setInputItems(second, 'recycle', [a]);
  sim.advance(2);
  assert.equal(
    sim.facilitySnapshot(f).jobs[0].batchesCompleted +
      sim.facilitySnapshot(second).jobs[0].batchesCompleted,
    1,
  );
  valid(roundtrip(sim));
});
test('removal refuses active work unchanged; drain completes exactly once and releases construction workforce', () => {
  const { sim, f, a, home } = fixture();
  sim.setInputItems(f, 'recycle', [a]);
  sim.advance(0.4);
  const before = sim.save();
  assert.deepEqual(sim.removeFacility(f), {
    ok: false,
    blockers: [{ code: 'active-batch', jobId: `${f}.job-0` }],
  });
  assert.deepEqual(sim.save(), before);
  sim.setFacilityDraining(f, true);
  const restored = roundtrip(sim);
  sim.advance(2);
  restored.advance(2);
  assert.deepEqual(sim.save(), restored.save());
  assert.equal(sim.facilitySnapshot(f).jobs[0].state, 'drained');
  assert.equal(sim.facilitySnapshot(f).jobs[0].batchesCompleted, 1);
  const events = [];
  sim.onEvent((e) => events.push(e));
  assert.ok(sim.removeFacility(f).ok);
  assert.equal(events.at(-1).type, 'facility-removed');
  assert.deepEqual(sim.facilityIds(), [home]);
  assert.equal(sim.inventory('store').summary().workforce.smith.assigned, 0);
  assert.ok(sim.removeFacility(home).ok);
  assert.deepEqual(sim.inventory('store').summary().workforce, {});
  assert.throws(() => sim.facilitySnapshot(f), DefinitionError);
  assert.throws(() => sim.removeFacility(f), DefinitionError);
  valid(roundtrip(sim));
});
test('idle removal releases selected-item and bulk reservations without refunding construction costs', () => {
  const { sim, f, a } = fixture();
  sim.withdraw('store', { ore: 8 });
  sim.deposit('store', { ore: 1 });
  sim.setInputItems(f, 'recycle', [a]);
  sim.advance(0.1);
  assert.equal(sim.inventory('store').reserved('weapon'), 1);
  const stock = sim.inventory('store').summary().quantities;
  assert.ok(sim.removeFacility(f).ok);
  assert.deepEqual(sim.inventory('store').summary().quantities, stock);
  assert.equal(sim.inventory('store').reserved('weapon'), 0);
  assert.equal(sim.inventory('store').reserved('ore'), 0);
  assert.deepEqual(sim.materialDemands(), []);
  valid(sim);
});
test('workforce providers and capacity contributors cannot be removed while their effects are still needed', () => {
  const { sim, f, home } = fixture();
  const second = sim.addFacility('factory', 'store').facilityId;
  const before = sim.save();
  assert.deepEqual(sim.removeFacility(home), {
    ok: false,
    blockers: [{ code: 'workforce', workerId: 'smith', shortage: 2 }],
  });
  assert.deepEqual(sim.save(), before);
  sim.removeFacility(f);
  sim.removeFacility(second);
  assert.ok(sim.removeFacility(home).ok);
  const warehouse = sim.addFacility('warehouse', 'store').facilityId;
  sim.deposit('store', { ore: 10 });
  assert.equal(sim.inventory('store').capacityPerMaterial, 20);
  assert.deepEqual(sim.removalBlockers(warehouse), [
    { code: 'capacity', resourceId: 'ore', excess: 8 },
  ]);
  sim.withdraw('store', { ore: 8 });
  assert.ok(sim.removeFacility(warehouse).ok);
  assert.equal(sim.inventory('store').capacityPerMaterial, 10);
  valid(sim);
});
test('draining a blocked outcome keeps ownership and waits for output capacity; disabled drain remains paused', () => {
  const { sim, f, a } = fixture();
  sim.deposit('store', { alloy: 10 });
  sim.setInputItems(f, 'recycle', [a]);
  sim.withdraw('store', { alloy: 1 });
  sim.advance(0.1);
  sim.deposit('store', { alloy: 1 });
  sim.setFacilityDraining(f, true);
  sim.advance(1);
  assert.equal(sim.facilitySnapshot(f).jobs[0].state, 'output-blocked');
  assert.equal(sim.removeFacility(f).ok, false);
  sim.withdraw('store', { alloy: 1 });
  sim.setFacilityEnabled(f, false);
  sim.advance(1);
  assert.equal(sim.removeFacility(f).ok, false);
  sim.setFacilityEnabled(f, true);
  sim.advance(0.1);
  assert.ok(sim.removeFacility(f).ok);
  valid(roundtrip(sim));
});
test('turning drain off resumes production and does not alter active input history', () => {
  const { sim, f, a, b } = fixture();
  sim.setInputItems(f, 'recycle', [a]);
  sim.advance(0.2);
  sim.setInputItems(f, 'recycle', [b]);
  sim.setFacilityDraining(f, true);
  sim.advance(1);
  assert.ok(sim.inventory('store').item(b));
  sim.setFacilityDraining(f, false);
  sim.advance(1.2);
  assert.equal(sim.facilitySnapshot(f).jobs[0].batchesCompleted, 2);
  valid(sim);
});
test('removed manufacturing provenance preserves live, travelling and consumed goods through save/restore', () => {
  const sim = new Simulation({
    tickMilliseconds: 100,
    resources: [
      {
        id: 'weapon',
        label: 'Weapon',
        kind: 'material',
        storage: 'individual',
      },
    ],
    recipes: [
      {
        id: 'forge',
        label: 'Forge',
        durationSeconds: 0.1,
        inputs: {},
        outputs: { weapon: 1 },
        itemAttributes: { weapon: { health: { min: 80, max: 90 } } },
      },
    ],
    facilities: [
      {
        id: 'forge',
        label: 'Forge',
        category: 'production',
        recipes: ['forge'],
        constructionCost: {},
      },
    ],
  });
  sim.createInventory({ id: 'ship', capacityPerMaterial: 10 });
  sim.createInventory({ id: 'planet', capacityPerMaterial: 10 });
  const f = sim.addFacility('forge', 'ship').facilityId;
  sim.advance(0.3);
  sim.setFacilityDraining(f, true);
  sim.advance(0.1);
  const [a, b, c] = sim.inventory('ship').itemPage().items;
  assert.ok(c);
  const d = sim.reserveDelivery('ship', 'planet', {}, [a.id]);
  sim.pickupDelivery(d.deliveryId);
  sim.consumeItem('ship', b.id);
  assert.ok(sim.removeFacility(f).ok);
  const restored = roundtrip(sim);
  assert.deepEqual(restored.locateItem(a.id), {
    kind: 'delivery',
    deliveryId: d.deliveryId,
  });
  assert.deepEqual(restored.locateItem(b.id), { kind: 'retired' });
  assert.deepEqual(restored.inventory('ship').item(c.id), c);
  assert.ok(restored.arriveDelivery(d.deliveryId));
  assert.deepEqual(restored.inventory('planet').item(a.id), a);
  const next = restored.addFacility('forge', 'ship');
  assert.notEqual(next.facilityId, f);
  valid(restored);
  for (const mutate of [
    (s) => (s.retiredFacilities = []),
    (s) => (s.retiredFacilities[0].jobs[0].completed = 0),
    (s) => (s.nextId = 1),
  ]) {
    const data = sim.save();
    mutate(data);
    assert.throws(() => Simulation.restore(data), DefinitionError);
  }
});
test('save rejects forged selection resources, consumed identity ownership and removed-factory conflicts', () => {
  const { sim, f, a } = fixture();
  sim.setInputItems(f, 'recycle', [a]);
  const selected = sim.save();
  selected.facilities[1].jobs[0].inputItemResources[a] = 'tool';
  assert.throws(() => Simulation.restore(selected), DefinitionError);
  sim.advance(0.1);
  const saved = sim.save();
  for (const mutate of [
    (s) => (s.facilities[1].jobs[0].batchInputItems = []),
    (s) => (s.facilities[1].jobs[0].batchInputItems[0].id = 'pristine'),
    (s) => (s.inventories[0].capacityPerMaterial = 0),
  ]) {
    const data = structuredClone(saved);
    mutate(data);
    assert.throws(() => Simulation.restore(data), DefinitionError);
  }
});
test('observers cannot remove facilities and removal observer failures occur after commit', () => {
  const { sim, f } = fixture({ inputs: { ore: 2 } });
  sim.onEvent((e) => {
    if (e.type === 'facility-removed') {
      assert.throws(() => sim.addFacility('factory', 'store'), DefinitionError);
      throw new Error('observer');
    }
  });
  assert.throws(() => sim.removeFacility(f), AggregateError);
  assert.equal(sim.facilityIds().includes(f), false);
  valid(sim);
});
test('demand introspection does not promise the same selected identity to two requests', () => {
  const { sim, f, a } = fixture();
  const second = sim.addFacility('factory', 'store').facilityId;
  sim.setFacilityAttendance(second, { smith: 1 });
  sim.setInputItems(f, 'recycle', [a]);
  sim.setInputItems(second, 'recycle', [a]);
  const demands = sim.materialDemands();
  assert.equal(demands.length, 1);
  assert.equal(demands[0].facilityId, second);
  assert.equal(demands[0].quantities.weapon, 1);
  valid(sim);
});
test('individual same-resource transformations use local endpoints and produce a fresh identity', () => {
  const sim = new Simulation({
    tickMilliseconds: 100,
    resources: [
      {
        id: 'weapon',
        label: 'Weapon',
        kind: 'material',
        storage: 'individual',
      },
    ],
    recipes: [
      {
        id: 'upgrade',
        label: 'Upgrade',
        durationSeconds: 0.1,
        inputs: { weapon: 1 },
        outputs: { weapon: 1 },
        itemAttributes: { weapon: { health: { min: 100, max: 100 } } },
      },
    ],
    facilities: [
      {
        id: 'factory',
        label: 'Factory',
        category: 'production',
        recipes: ['upgrade'],
        constructionCost: {},
      },
    ],
  });
  sim.createInventory({ id: 'ship', capacityPerMaterial: 0 });
  sim.createInventory({ id: 'buffer', capacityPerMaterial: 1 });
  const f = sim.addFacility('factory', 'ship', {
    inputInventoryId: 'buffer',
    outputInventoryId: 'buffer',
  }).facilityId;
  const old = sim.spawnItem('buffer', 'weapon', { health: 20 });
  sim.setInputItems(f, 'upgrade', [old]);
  sim.advance(0.2);
  const item = sim.inventory('buffer').itemPage().items[0];
  assert.notEqual(item.id, old);
  assert.equal(item.attributes.health, 100);
  sim.setFacilityDraining(f, true);
  assert.ok(sim.removeFacility(f).ok);
  assert.deepEqual(roundtrip(sim).inventory('buffer').item(item.id), item);
  valid(sim);
});
test('all concurrent jobs drain before removal, and removed facilities do not cancel inventory deliveries', () => {
  const sim = new Simulation({
    tickMilliseconds: 100,
    resources: [{ id: 'ore', label: 'Ore', kind: 'material' }],
    recipes: [0.2, 0.5].map((durationSeconds, n) => ({
      id: `r${n}`,
      label: 'Extract',
      durationSeconds,
      inputs: {},
      outputs: { ore: 1 },
    })),
    facilities: [
      {
        id: 'factory',
        label: 'Factory',
        category: 'production',
        recipes: ['r0', 'r1'],
        constructionCost: {},
      },
    ],
  });
  sim.createInventory({
    id: 'planet',
    capacityPerMaterial: 10,
    initial: { ore: 1 },
  });
  sim.createInventory({ id: 'ship', capacityPerMaterial: 10 });
  const f = sim.addFacility('factory', 'planet').facilityId;
  const d = sim.reserveDelivery('planet', 'ship', { ore: 1 });
  sim.advance(0.1);
  sim.setFacilityDraining(f, true);
  sim.advance(0.2);
  assert.equal(sim.removeFacility(f).ok, false);
  sim.advance(0.3);
  assert.ok(sim.removeFacility(f).ok);
  sim.pickupDelivery(d.deliveryId);
  sim.arriveDelivery(d.deliveryId);
  assert.equal(sim.inventory('ship').quantity('ore'), 1);
  assert.equal(sim.inventory('planet').quantity('ore'), 2);
  valid(roundtrip(sim));
});
test('zero optional quantities do not hide mandatory individual inputs', () => {
  const { sim, f, a } = fixture({
    inputs: { weapon: 1 },
    optionalInputs: { weapon: 0 },
  });
  sim.setInputItems(f, 'recycle', [a]);
  sim.advance(0.1);
  valid(roundtrip(sim));
});
test('reordering an unchanged selection preserves FIFO age and item reservations', () => {
  const { sim, f, a, b } = fixture({ inputs: { weapon: 2, ore: 2 } });
  sim.withdraw('store', { ore: 8 });
  sim.deposit('store', { ore: 1 });
  sim.setInputItems(f, 'recycle', [a, b]);
  sim.advance(0.1);
  const before = sim.save();
  sim.setInputItems(f, 'recycle', [b, a]);
  assert.deepEqual(sim.save(), before);
  valid(sim);
});

test('restore rejects unsupported save headers without input mutation', () => {
  const { sim } = fixture({ inputs: { ore: 2 } });
  sim.advance(0.35);
  const current = sim.save();
  assert.equal(current.version, 7);
  assert.deepEqual(roundtrip(sim).save(), current);
  for (const version of [1, 0, 2, 3, 999, '4', undefined]) {
    const data = structuredClone(current);
    data.version = version;
    const before = structuredClone(data);
    assert.throws(
      () => Simulation.restore(data),
      /unsupported save format or version/,
    );
    assert.deepEqual(data, before);
    assert.deepEqual(sim.save(), current);
  }
});
