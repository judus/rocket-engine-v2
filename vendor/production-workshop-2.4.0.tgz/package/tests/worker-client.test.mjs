import test from 'node:test';
import assert from 'node:assert/strict';
import { WorkerDemoClient } from '../worker/client.js';
class Transport {
  sent = [];
  terminations = 0;
  onmessage = null;
  onerror = null;
  onmessageerror = null;
  sendError = null;
  postMessage(value) {
    if (this.sendError) throw this.sendError;
    this.sent.push(value);
  }
  terminate() {
    this.terminations++;
  }
  reply(id, result = { type: 'view', view: null }) {
    this.onmessage({ data: { id, ok: true, result, workMilliseconds: 1 } });
  }
}
test('request routing supports ordered IDs and out-of-order acknowledgements', async () => {
  const transport = new Transport(),
    client = new WorkerDemoClient(() => {}, transport);
  const first = client.request({ type: 'read' }),
    second = client.request({ type: 'checkpoint' });
  assert.deepEqual(
    transport.sent.map((v) => v.id),
    [1, 2],
  );
  transport.reply(2, { type: 'checkpointed', view: null });
  transport.reply(1);
  assert.equal((await first).result.type, 'view');
  assert.equal((await second).result.type, 'checkpointed');
  client.close();
});
test('close rejects all pending requests, releases callbacks and is idempotent', async () => {
  const transport = new Transport();
  let failures = 0;
  const client = new WorkerDemoClient(() => failures++, transport);
  const pending = [
    client.request({ type: 'read' }),
    client.request({ type: 'checkpoint' }),
  ];
  const settled = Promise.allSettled(pending);
  client.close();
  client.close();
  for (const reply of await settled) {
    assert.equal(reply.status, 'rejected');
    assert.equal(reply.reason.name, 'AbortError');
  }
  await assert.rejects(client.request({ type: 'read' }), {
    name: 'AbortError',
  });
  assert.equal(transport.terminations, 1);
  assert.equal(transport.onmessage, null);
  assert.equal(transport.onerror, null);
  assert.equal(failures, 0);
});
test('idle transport crashes notify the host and future requests retain the original failure', async () => {
  const transport = new Transport(),
    failures = [];
  const client = new WorkerDemoClient(
    (error) => failures.push(error),
    transport,
  );
  transport.onerror({ message: 'worker crashed' });
  assert.equal(failures.length, 1);
  await assert.rejects(client.request({ type: 'read' }), /worker crashed/);
  client.close();
  assert.equal(transport.terminations, 1);
});
test('decode failure and malformed replies fail closed rather than leave unresolved requests', async () => {
  for (const kind of [
    'decode',
    'unknown',
    'invalid-success',
    'invalid-error',
    'null',
  ]) {
    const transport = new Transport(),
      failures = [];
    const client = new WorkerDemoClient(
      (error) => failures.push(error),
      transport,
    );
    const settled = Promise.allSettled([
      client.request({ type: 'read' }),
      client.request({ type: 'checkpoint' }),
    ]);
    if (kind === 'decode') transport.onmessageerror();
    else
      transport.onmessage({
        data:
          kind === 'unknown'
            ? { id: 99, ok: true, result: {}, workMilliseconds: 1 }
            : kind === 'invalid-success'
              ? { id: 1, ok: true, result: {}, workMilliseconds: NaN }
              : kind === 'invalid-error'
                ? { id: 1, ok: false, error: { message: 1 } }
                : null,
      });
    assert.ok((await settled).every((r) => r.status === 'rejected'));
    assert.equal(failures.length, 1);
    assert.equal(transport.terminations, 1);
  }
});
test('remote command rejection and synchronous clone errors affect one request, not the owner', async () => {
  const transport = new Transport();
  let failures = 0;
  const client = new WorkerDemoClient(() => failures++, transport);
  const bad = client.request({ type: 'advance', seconds: -1 });
  transport.onmessage({
    data: {
      id: 1,
      ok: false,
      error: { name: 'DefinitionError', message: 'invalid elapsed time' },
    },
  });
  await assert.rejects(bad, { name: 'DefinitionError' });
  transport.sendError = new Error('not cloneable');
  await assert.rejects(client.request({ type: 'read' }), /not cloneable/);
  transport.sendError = null;
  const good = client.request({ type: 'read' });
  transport.reply(3);
  assert.equal((await good).ok, true);
  assert.equal(failures, 0);
  client.close();
});

test('actual worker exit rejects outstanding requests rather than hanging the bridge', async () => {
  const { NodeWorkerTransport } = await import(
    '../examples/node-worker-transport.mjs'
  );
  const failures = [],
    client = new WorkerDemoClient(
      (error) => failures.push(error),
      new NodeWorkerTransport(
        new URL('./fixtures/worker-exit.mjs', import.meta.url),
      ),
    );
  await assert.rejects(client.request({ type: 'read' }), /exited unexpectedly/);
  assert.equal(failures.length, 1);
  client.close();
});
test('restart while actual worker work is queued isolates the new owner and rejects old requests', async () => {
  const { NodeWorkerTransport } = await import(
    '../examples/node-worker-transport.mjs'
  );
  const url = new URL('../examples/worker-node-entry.mjs', import.meta.url);
  const old = new WorkerDemoClient(() => {}, new NodeWorkerTransport(url));
  const settled = Promise.allSettled([
    old.request({ type: 'init' }),
    old.request({ type: 'burst', ticks: 2000 }),
    old.request({ type: 'checkpoint' }),
  ]);
  old.close();
  const current = new WorkerDemoClient(() => {}, new NodeWorkerTransport(url));
  try {
    assert.ok(
      (await settled).every(
        (r) => r.status === 'rejected' && r.reason.name === 'AbortError',
      ),
    );
    const initialized = await current.request({ type: 'init' });
    assert.equal(initialized.result.view.summary.tick, 0);
    const advanced = await current.request({ type: 'advance', seconds: 0.05 });
    assert.equal(advanced.result.type, 'advanced');
    const view = await current.request({ type: 'read' });
    assert.equal(view.result.view.summary.tick, 1);
  } finally {
    current.close();
  }
});
