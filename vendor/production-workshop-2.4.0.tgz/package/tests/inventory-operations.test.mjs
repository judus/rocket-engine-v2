import test from 'node:test';
import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
const config = () => ({
  resources: [
    {
      id: 'coin',
      label: 'Coin',
      kind: 'currency',
      unitWeight: 0,
      unitVolume: 0,
    },
    {
      id: 'water',
      label: 'Water',
      kind: 'material',
      unitWeight: 1,
      unitVolume: 1,
    },
    {
      id: 'food',
      label: 'Food',
      kind: 'material',
      unitWeight: 2,
      unitVolume: 1,
    },
    { id: 'ore', label: 'Ore', kind: 'material', unitWeight: 3, unitVolume: 2 },
    {
      id: 'tool',
      label: 'Tool',
      kind: 'material',
      storage: 'individual',
      unitWeight: 4,
      unitVolume: 2,
    },
    {
      id: 'bucket',
      label: 'Empty bucket',
      kind: 'material',
      storage: 'individual',
      unitWeight: 1,
      unitVolume: 2,
    },
    {
      id: 'full-bucket',
      label: 'Full bucket',
      kind: 'material',
      storage: 'individual',
      unitWeight: 6,
      unitVolume: 5,
    },
    { id: 'unknown-mass', label: 'Unknown', kind: 'material' },
  ],
  recipes: [
    {
      id: 'forge',
      label: 'Forge',
      inputs: { ore: 2 },
      outputs: { tool: 1 },
      durationSeconds: 0.1,
    },
  ],
  facilities: [
    {
      id: 'forge',
      label: 'Forge',
      category: 'test',
      recipes: ['forge'],
      constructionCost: {},
    },
  ],
});
const world = () => new Simulation(config());
const store = (s, id, options = {}) =>
  s.createInventory({ id, capacityPerMaterial: 100, ...options });
const same = (s, action) => {
  const before = s.save();
  action();
  assert.deepEqual(s.save(), before);
};
const reload = (s) => Simulation.restore(JSON.parse(JSON.stringify(s.save())));

test('atomic purchase transfers payment and exact item; insufficient payment changes nothing', () => {
  const s = world();
  store(s, 'player', { initial: { coin: 5 } });
  store(s, 'merchant');
  const tool = s.spawnItem('merchant', 'tool', { quality: 90 });
  const events = [];
  s.onInventoryEvent((e) => events.push(e));
  const legs = [
    {
      sourceInventoryId: 'player',
      destinationInventoryId: 'merchant',
      quantities: { coin: 3 },
    },
    {
      sourceInventoryId: 'merchant',
      destinationInventoryId: 'player',
      itemIds: [tool],
    },
  ];
  const r = s.exchange(legs);
  assert.equal(r.ok, true);
  assert.equal(events.length, 1);
  assert.equal(events[0].operationId, r.operationId);
  assert.equal(events[0].changes.length, 2);
  assert.equal(s.inventory('player').quantity('coin'), 2);
  assert.equal(s.inventory('merchant').quantity('coin'), 3);
  assert.equal(s.inventory('player').item(tool).attributes.quality, 90);
  same(s, () =>
    assert.equal(
      s.exchange([
        {
          sourceInventoryId: 'player',
          destinationInventoryId: 'merchant',
          quantities: { coin: 3 },
        },
      ]).reason,
      'unavailable',
    ),
  );
  assert.equal(events.length, 1);
  assert.deepEqual(reload(s).save(), s.save());
});

test('full bags swap simultaneously; source funding cannot borrow incoming goods', () => {
  const s = world();
  store(s, 'a', { capacity: { kind: 'slots', limit: 1, stackLimit: 1 } });
  store(s, 'b', { capacity: { kind: 'slots', limit: 1, stackLimit: 1 } });
  const a = s.spawnItem('a', 'tool', {}),
    b = s.spawnItem('b', 'bucket', {});
  assert.equal(s.transferItem('a', 'b', a), false);
  assert.equal(
    s.exchange([
      { sourceInventoryId: 'a', destinationInventoryId: 'b', itemIds: [a] },
      { sourceInventoryId: 'b', destinationInventoryId: 'a', itemIds: [b] },
    ]).ok,
    true,
  );
  assert.ok(s.inventory('a').item(b));
  assert.ok(s.inventory('b').item(a));
  const funded = world();
  store(funded, 'a', { initial: { coin: 2 } });
  store(funded, 'b');
  store(funded, 'c');
  same(funded, () =>
    assert.equal(
      funded.exchange([
        {
          sourceInventoryId: 'a',
          destinationInventoryId: 'b',
          quantities: { coin: 2 },
        },
        {
          sourceInventoryId: 'b',
          destinationInventoryId: 'c',
          quantities: { coin: 2 },
        },
      ]).ok,
      false,
    ),
  );
});

test('multi-party exchange aggregates legs, checks restrictions and rejects duplicate identities', () => {
  const s = world();
  store(s, 'a', { initial: { water: 3 } });
  store(s, 'b', { rules: { accepts: ['water'] } });
  store(s, 'c', { initial: { food: 2 } });
  same(s, () =>
    assert.equal(
      s.exchange([
        {
          sourceInventoryId: 'a',
          destinationInventoryId: 'b',
          quantities: { water: 2 },
        },
        {
          sourceInventoryId: 'a',
          destinationInventoryId: 'c',
          quantities: { water: 2 },
        },
      ]).ok,
      false,
    ),
  );
  same(s, () =>
    assert.equal(
      s.exchange([
        {
          sourceInventoryId: 'a',
          destinationInventoryId: 'b',
          quantities: { water: 2 },
        },
        {
          sourceInventoryId: 'c',
          destinationInventoryId: 'b',
          quantities: { food: 1 },
        },
      ]).reason,
      'admission',
    ),
  );
  assert.equal(
    s.exchange([
      {
        sourceInventoryId: 'a',
        destinationInventoryId: 'b',
        quantities: { water: 2 },
      },
      {
        sourceInventoryId: 'c',
        destinationInventoryId: 'a',
        quantities: { food: 1 },
      },
    ]).ok,
    true,
  );
  const item = s.spawnItem('a', 'tool', {});
  same(s, () =>
    assert.throws(
      () =>
        s.exchange([
          {
            sourceInventoryId: 'a',
            destinationInventoryId: 'c',
            itemIds: [item, item],
          },
        ]),
      /duplicate/,
    ),
  );
  for (const legs of [
    [],
    Array(257).fill({}),
    [{ sourceInventoryId: 'a', destinationInventoryId: 'a' }],
    [{ sourceInventoryId: 'missing', destinationInventoryId: 'b' }],
    [
      {
        sourceInventoryId: 'a',
        destinationInventoryId: 'b',
        quantities: { tool: 1 },
      },
    ],
  ])
    same(s, () => assert.throws(() => s.exchange(legs)));
  same(s, () =>
    assert.equal(
      s.exchange([
        {
          sourceInventoryId: 'a',
          destinationInventoryId: 'c',
          itemIds: ['missing'],
        },
      ]).reason,
      'unavailable',
    ),
  );
  const n = s.inventoryEventSequence();
  assert.equal(
    s.exchange([
      {
        sourceInventoryId: 'a',
        destinationInventoryId: 'c',
        quantities: { water: 0 },
      },
    ]).operationId,
    null,
  );
  assert.equal(s.inventoryEventSequence(), n);
});

test('reserved bulk and items cannot be exchanged, consumed or transformed', () => {
  const s = world();
  store(s, 'a', { initial: { water: 3 } });
  store(s, 'b');
  const id = s.spawnItem('a', 'bucket', {});
  s.reserveDelivery('a', 'b', { water: 3 }, [id]);
  for (const run of [
    () =>
      s.exchange([
        { sourceInventoryId: 'a', destinationInventoryId: 'b', itemIds: [id] },
      ]),
    () => s.mutateInventory({ inventoryId: 'a', consumeItemIds: [id] }),
    () => s.mutateInventory({ inventoryId: 'a', consume: { water: 1 } }),
    () =>
      s.mutateInventory({
        inventoryId: 'a',
        updateItems: [{ itemId: id, attributes: { uses: 2 } }],
      }),
  ])
    same(s, () => assert.equal(run().reason, 'unavailable'));
});

test('one transaction consumes a bucket and water, creates a new full-bucket identity and preserves provenance', () => {
  const s = world();
  store(s, 'a', {
    capacity: { kind: 'slots', limit: 2, stackLimit: 5 },
    rules: { maxWeight: 6, maxVolume: 7 },
    initial: { water: 5 },
  });
  const bucket = s.spawnItem('a', 'bucket', { durability: 70 });
  const events = [];
  s.onInventoryEvent((e) => events.push(e));
  const result = s.mutateInventory({
    inventoryId: 'a',
    consume: { water: 5 },
    consumeItemIds: [bucket],
    createItems: [
      { resourceId: 'full-bucket', attributes: { durability: 70 } },
    ],
  });
  assert.equal(result.ok, true);
  const [full] = result.createdItemIds;
  assert.notEqual(bucket, full);
  assert.equal(s.locateItem(bucket).kind, 'retired');
  assert.equal(s.inventory('a').quantity('water'), 0);
  assert.equal(s.inventory('a').item(full).resourceId, 'full-bucket');
  assert.equal(events.length, 1);
  assert.equal(events[0].changes[0].removed.items[0].id, bucket);
  assert.equal(events[0].changes[0].added.items[0].id, full);
  const restored = reload(s);
  assert.equal(restored.locateItem(bucket).kind, 'retired');
  assert.equal(restored.inventory('a').item(full).attributes.durability, 70);
});

test('failed transformations preserve inputs, item counters and item attributes; exact identity updates are atomic', () => {
  const s = world();
  store(s, 'a', {
    capacity: { kind: 'units', limit: 2 },
    initial: { food: 1 },
  });
  const id = s.spawnItem('a', 'bucket', { uses: 0 });
  same(s, () =>
    assert.equal(
      s.mutateInventory({
        inventoryId: 'a',
        consume: { food: 1 },
        produce: { water: 3 },
        updateItems: [{ itemId: id, attributes: { uses: 1 } }],
      }).reason,
      'admission',
    ),
  );
  same(s, () =>
    assert.equal(
      s.mutateInventory({
        inventoryId: 'a',
        consume: { food: 2 },
        createItems: [{ resourceId: 'tool', attributes: {} }],
      }).reason,
      'unavailable',
    ),
  );
  const r = s.mutateInventory({
    inventoryId: 'a',
    consume: { food: 1 },
    produce: { water: 1 },
    updateItems: [{ itemId: id, attributes: { uses: 1 } }],
  });
  assert.equal(r.ok, true);
  assert.equal(s.inventory('a').item(id).attributes.uses, 1);
  const before = s.inventoryEventSequence();
  assert.equal(s.mutateInventory({ inventoryId: 'a' }).operationId, null);
  assert.equal(s.inventoryEventSequence(), before);
  for (const mutation of [
    { consumeItemIds: [id, id] },
    {
      consumeItemIds: [id],
      updateItems: [{ itemId: id, attributes: { uses: 2 } }],
    },
    { produce: { tool: 1 } },
    { createItems: [{ resourceId: 'water', attributes: {} }] },
    { updateItems: [{ itemId: id, attributes: { uses: NaN } }] },
    {
      updateItems: [
        { itemId: id, attributes: {} },
        { itemId: id, attributes: {} },
      ],
    },
  ])
    same(s, () =>
      assert.throws(() => s.mutateInventory({ inventoryId: 'a', ...mutation })),
    );
  assert.equal(
    s.mutateInventory({ inventoryId: 'a', consumeItemIds: [id] }).ok,
    true,
  );
  assert.equal(s.locateItem(id).kind, 'retired');
});

test('resource restrictions apply to initial stock, plain commands, new items and blocked cargo without loss', () => {
  const s = world();
  same(s, () =>
    assert.throws(
      () =>
        store(s, 'bad', {
          rules: { accepts: ['water'] },
          initial: { food: 1 },
        }),
      /capacity/,
    ),
  );
  store(s, 'a', { initial: { water: 4, food: 4 } });
  store(s, 'tank', { rules: { accepts: ['water'] } });
  assert.equal(s.deposit('tank', { water: 1 }), true);
  same(s, () => assert.equal(s.deposit('tank', { food: 1 }), false));
  same(s, () =>
    assert.equal(s.transfer('a', 'tank', { water: 1, food: 1 }), false),
  );
  same(s, () => assert.equal(s.spawnItem('tank', 'tool', {}), null));
  const d = s.reserveDelivery('a', 'tank', { food: 2 }).deliveryId;
  s.pickupDelivery(d);
  assert.equal(s.arriveDelivery(d), false);
  assert.equal(s.deliverySnapshot(d).state, 'arrival-blocked');
  assert.equal(
    s.setInventoryRules('tank', { accepts: ['water', 'food'] }),
    true,
  );
  assert.equal(s.arriveDelivery(d), true);
  assert.equal(s.inventory('tank').quantity('food'), 2);
  same(s, () =>
    assert.equal(s.setInventoryRules('tank', { accepts: ['water'] }), false),
  );
  const list = s.inventory('tank').summary().rules;
  list.accepts.length = 0;
  assert.equal(s.inventory('tank').snapshot().rules.accepts.length, 2);
  assert.deepEqual(reload(s).save(), s.save());
  assert.equal(s.setInventoryRules('tank', {}), true);
});

test('weight, volume, shared slots and per-material limits all constrain admission', () => {
  const s = world();
  store(s, 'bag', {
    capacity: { kind: 'slots', limit: 3, stackLimit: 5 },
    rules: { maxWeight: 7, maxVolume: 5 },
  });
  assert.equal(s.deposit('bag', { water: 3 }), true);
  const id = s.spawnItem('bag', 'tool', {});
  assert.ok(id);
  assert.deepEqual(s.inventory('bag').summary().rules, {
    maxWeight: 7,
    maxVolume: 5,
    usedWeight: 7,
    usedVolume: 5,
  });
  same(s, () => assert.equal(s.deposit('bag', { water: 1 }), false));
  same(s, () => assert.equal(s.deposit('bag', { 'unknown-mass': 1 }), false));
  same(s, () =>
    assert.equal(s.setInventoryRules('bag', { maxWeight: 6 }), false),
  );
  assert.equal(
    s.setInventoryRules('bag', { maxWeight: 8, maxVolume: 6 }),
    true,
  );
  assert.equal(s.deposit('bag', { water: 1 }), true);
  const volume = world();
  store(volume, 'v', { rules: { maxVolume: 2 } });
  assert.equal(volume.deposit('v', { water: 2 }), true);
  same(volume, () => assert.equal(volume.deposit('v', { food: 1 }), false));
  const zero = world();
  store(zero, 'z', {
    rules: { maxWeight: 0, maxVolume: 0 },
    initial: { coin: 100 },
  });
  assert.equal(zero.deposit('z', { water: 1 }), false);
  assert.deepEqual(reload(s).save(), s.save());
});

test('physical arithmetic overflow and malformed rules/metadata reject without mutation', () => {
  for (const field of ['unitWeight', 'unitVolume'])
    for (const value of [-1, 0.1, Infinity, NaN]) {
      const c = config();
      c.resources[0][field] = value;
      assert.throws(() => new Simulation(c));
    }
  const s = world();
  for (const rules of [
    null,
    [],
    { accepts: null },
    { accepts: ['water', 'water'] },
    { accepts: ['missing'] },
    { maxWeight: -1 },
    { maxVolume: 0.2 },
    { maxWeight: Infinity },
    { other: 1 },
  ])
    same(s, () => assert.throws(() => store(s, 'bad', { rules })));
  store(s, 'large', {
    capacityPerMaterial: Number.MAX_SAFE_INTEGER,
    capacity: { kind: 'units', limit: Number.MAX_SAFE_INTEGER },
    rules: { maxWeight: Number.MAX_SAFE_INTEGER },
  });
  same(s, () =>
    assert.equal(s.deposit('large', { ore: Number.MAX_SAFE_INTEGER }), false),
  );
  store(s, 'plain');
  for (const rules of [{ maxVolume: -1 }, { accepts: ['missing'] }])
    same(s, () => assert.throws(() => s.setInventoryRules('plain', rules)));
});

test('production checks restrictions and physical limits before start and again before publication', () => {
  const s = world();
  store(s, 'site', {
    initial: { ore: 4 },
    rules: { maxWeight: 12, maxVolume: 8, accepts: ['ore'] },
  });
  const f = s.addFacility('forge', 'site').facilityId;
  s.advance(0.3);
  assert.equal(s.inventory('site').quantity('ore'), 4);
  assert.equal(
    s.setInventoryRules('site', {
      accepts: ['ore', 'tool'],
      maxWeight: 12,
      maxVolume: 8,
    }),
    true,
  );
  s.advanceTicks(1);
  assert.equal(s.inventory('site').quantity('ore'), 2);
  // Tighten to what the remaining stock fits. The output now cannot fit alongside it.
  assert.equal(
    s.setInventoryRules('site', { maxWeight: 6, maxVolume: 4 }),
    true,
  );
  s.advance(0.3);
  assert.equal(s.inventory('site').quantity('tool'), 0);
  assert.ok(s.facilitySnapshot(f).jobs[0].pendingOutcome);
  const restored = reload(s);
  assert.equal(
    restored.setInventoryRules('site', { maxWeight: 12, maxVolume: 8 }),
    true,
  );
  restored.advance(0.4);
  assert.equal(restored.inventory('site').quantity('tool'), 2);
  assert.equal(restored.facilitySnapshot(f).jobs[0].batchesCompleted, 2);
});

test('inventory events cover goods and attribute commits, omit reservation/no-op/refusal and continue after restore', () => {
  let s = world();
  store(s, 'a');
  store(s, 'b');
  const events = [];
  s.onInventoryEvent((e) => events.push(e));
  assert.equal(s.deposit('a', { water: 3 }), true);
  s.withdraw('a', { water: 1 });
  s.transfer('a', 'b', { water: 1 });
  const id = s.spawnItem('a', 'tool', { uses: 0 });
  s.updateItemAttributes('a', id, { uses: 1 });
  s.transferItem('a', 'b', id);
  s.consumeItem('b', id);
  assert.equal(events.length, 7);
  assert.equal(events[2].changes.length, 2);
  assert.equal(events[4].changes[0].updatedItems[0].after.attributes.uses, 1);
  const before = s.inventoryEventSequence();
  s.deposit('a', { water: 0 });
  s.transfer('a', 'a', { water: 1 });
  assert.equal(s.withdraw('a', { water: 99 }), false);
  const d = s.reserveDelivery('a', 'b', { water: 1 }).deliveryId;
  assert.equal(s.inventoryEventSequence(), before);
  s.pickupDelivery(d);
  s.arriveDelivery(d);
  assert.equal(events.length, 9);
  assert.equal(events[7].changes[0].reference, `logistics:${d}`);
  const sequence = s.inventoryEventSequence();
  s = reload(s);
  const later = [];
  s.onInventoryEvent((e) => later.push(e));
  s.deposit('a', { water: 1 });
  assert.equal(later[0].sequence, sequence + 1);
  assert.equal(later[0].operationId, `inventory-operation-${sequence + 1}`);
});

test('observer errors occur after atomic commit; reentry and event cross-listener mutation are isolated', () => {
  const s = world();
  store(s, 'a', { initial: { coin: 5 } });
  store(s, 'b');
  const received = [];
  s.onInventoryEvent((e) => {
    e.changes[0].added.quantities.coin = 999;
    assert.throws(() => s.deposit('a', { coin: 1 }), /observer/);
    assert.throws(() => s.save(), /during/);
    throw new Error('observer failure');
  });
  s.onInventoryEvent((e) => received.push(e));
  assert.throws(
    () =>
      s.exchange([
        {
          sourceInventoryId: 'a',
          destinationInventoryId: 'b',
          quantities: { coin: 2 },
        },
      ]),
    /observer failure/,
  );
  assert.equal(s.inventory('a').quantity('coin'), 3);
  assert.equal(s.inventory('b').quantity('coin'), 2);
  assert.notEqual(received[0].changes[0].added.quantities.coin, 999);
  assert.equal(s.validateState().ok, true);
});

test('production event identities and checkpoints are deterministic across advance partitions and subscribers', () => {
  const run = (chunks) => {
    const s = world();
    store(s, 'site', { initial: { ore: 20 } });
    s.addFacility('forge', 'site');
    const events = [];
    s.onInventoryEvent((e) => events.push(e));
    for (const n of chunks) s.advance(n);
    return { s, events };
  };
  const a = run([1]),
    b = run([0.15, 0.2, 0.25, 0.4]);
  assert.deepEqual(a.s.save(), b.s.save());
  assert.deepEqual(a.events, b.events);
  assert.ok(
    a.events.some((e) => e.changes[0].reference === 'facility-1.job-0'),
  );
  const c = world();
  store(c, 'site', { initial: { ore: 20 } });
  c.addFacility('forge', 'site');
  c.advance(1);
  assert.deepEqual(c.save(), a.s.save());
});

test('format 6 persists operation position and rules; honest legacy 4/5 saves remain readable', () => {
  const s = world();
  store(s, 'a', {
    initial: { water: 1 },
    rules: { accepts: ['water'], maxWeight: 2 },
  });
  assert.equal(s.save().version, 7);
  assert.deepEqual(reload(s).save(), s.save());
  for (const edit of [
    (state) => (state.nextInventoryOperation = 0),
    (state) => (state.nextInventoryOperation = 1.5),
    (state) => (state.inventories[0].rules.maxWeight = 0),
    (state) => (state.inventories[0].rules.accepts = ['ore']),
    (state) => (state.version = 5),
  ]) {
    const state = s.save();
    edit(state);
    assert.throws(() => Simulation.restore(state));
  }
  const empty = new Simulation({
    resources: [{ id: 'water', label: 'Water', kind: 'material' }],
    recipes: [],
    facilities: [],
  });
  store(empty, 'a', { initial: { water: 1 } });
  for (const version of [4, 5]) {
    const state = empty.save();
    state.version = version;
    delete state.nextInventoryOperation;
    if (version === 4) delete state.inventoryAttachments;
    const copy = structuredClone(state);
    const restored = Simulation.restore(state);
    assert.equal(restored.inventory('a').quantity('water'), 1);
    assert.equal(restored.inventoryEventSequence(), 0);
    assert.deepEqual(state, copy);
  }
  const exhausted = s.save();
  exhausted.nextInventoryOperation = Number.MAX_SAFE_INTEGER;
  const e = Simulation.restore(exhausted);
  same(e, () =>
    assert.throws(() => e.deposit('a', { water: 1 }), /counter exhausted/),
  );
  const near = s.save();
  near.nextInventoryOperation = Number.MAX_SAFE_INTEGER - 1;
  const n = Simulation.restore(near);
  n.addFacility('forge', 'a');
  same(n, () => assert.throws(() => n.advance(1), /counter exhausted/));
});

test('late subscription, unsubscription, attribute no-ops and multiple observer failures preserve commit semantics', () => {
  const s = world();
  store(s, 'a');
  const seen = [],
    late = [];
  let addLate = true;
  const stop = s.onInventoryEvent((e) => {
    seen.push(e);
    if (addLate) {
      addLate = false;
      s.onInventoryEvent((next) => late.push(next));
    }
  });
  s.deposit('a', { water: 1 });
  assert.equal(late.length, 0);
  s.deposit('a', { water: 1 });
  assert.equal(late.length, 1);
  stop();
  s.deposit('a', { water: 1 });
  assert.equal(seen.length, 2);
  assert.equal(late.length, 2);
  const id = s.spawnItem('a', 'bucket', { uses: 0 });
  const sequence = s.inventoryEventSequence();
  s.updateItemAttributes('a', id, { uses: 0 });
  assert.equal(s.inventoryEventSequence(), sequence);
  assert.equal(
    s.mutateInventory({
      inventoryId: 'a',
      updateItems: [{ itemId: id, attributes: {} }],
    }).operationId,
    null,
  );
  assert.equal(s.transferItem('a', 'a', id), true);
  assert.equal(s.inventoryEventSequence(), sequence);
  s.onInventoryEvent(() => {
    throw new Error('one');
  });
  s.onInventoryEvent(() => {
    throw new Error('two');
  });
  assert.throws(() => s.deposit('a', { water: 1 }), AggregateError);
  assert.equal(s.inventory('a').quantity('water'), 4);
  assert.equal(s.inventoryEventSequence(), sequence + 1);
});

test('rule limits remain safe through returns and invalid or oversized transaction inputs', () => {
  const s = world();
  store(s, 'a', { initial: { water: 3 } });
  store(s, 'b');
  const d = s.reserveDelivery('a', 'b', { water: 2 }).deliveryId;
  s.pickupDelivery(d);
  assert.equal(s.setInventoryRules('a', { accepts: [] }), false); // one physical water still remains
  s.withdraw('a', { water: 1 });
  assert.equal(s.setInventoryRules('a', { accepts: [] }), true);
  assert.equal(s.returnDelivery(d), false);
  assert.equal(s.deliverySnapshot(d).state, 'in-transit');
  assert.equal(s.setInventoryRules('a', { accepts: ['water'] }), true);
  assert.equal(s.returnDelivery(d), true);
  for (const mutation of [
    { createItems: Array(257).fill({ resourceId: 'bucket', attributes: {} }) },
    { updateItems: Array(257).fill({ itemId: 'missing', attributes: {} }) },
    { createItems: [{ resourceId: 'bucket', attributes: null }] },
  ])
    same(s, () =>
      assert.throws(() => s.mutateInventory({ inventoryId: 'a', ...mutation })),
    );
  same(s, () =>
    assert.throws(() =>
      s.exchange([
        {
          sourceInventoryId: 'a',
          destinationInventoryId: 'b',
          itemIds: Array(257).fill('x'),
        },
      ]),
    ),
  );
  same(s, () =>
    assert.throws(
      () =>
        s.exchange([
          {
            sourceInventoryId: 'a',
            destinationInventoryId: 'b',
            quantities: { water: Number.MAX_SAFE_INTEGER },
          },
          {
            sourceInventoryId: 'a',
            destinationInventoryId: 'b',
            quantities: { water: 1 },
          },
        ]),
      /overflow/,
    ),
  );
});
