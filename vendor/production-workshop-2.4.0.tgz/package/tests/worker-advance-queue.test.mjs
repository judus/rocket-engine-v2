import test from 'node:test';
import assert from 'node:assert/strict';
import { WorkerAdvanceQueue } from '../worker/advance-queue.js';
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((a, b) => {
    resolve = a;
    reject = b;
  });
  return { promise, resolve, reject };
};
test('busy owner accumulates elapsed time and commits it once without parallel advances', async () => {
  const sent = [],
    waiters = [];
  const queue = new WorkerAdvanceQueue((seconds) => {
    sent.push(seconds);
    const waiter = deferred();
    waiters.push(waiter);
    return waiter.promise;
  });
  queue.add(0.1);
  const first = queue.advance();
  await Promise.resolve();
  queue.add(0.2);
  queue.add(0.05);
  assert.equal(queue.advance(), null);
  assert.equal(queue.pendingSeconds, 0.25);
  assert.equal(queue.busy, true);
  waiters[0].resolve('first');
  assert.equal(await first, 'first');
  const second = queue.advance();
  await Promise.resolve();
  assert.deepEqual(sent, [0.1, 0.25]);
  waiters[1].resolve('second');
  await second;
  assert.equal(queue.pendingSeconds, 0);
  assert.ok(queue.backlogSeconds < 1e-12);
  assert.equal(queue.busy, false);
});
test('checkpoint barrier drains earlier elapsed time and leaves later elapsed time for the next phase', async () => {
  const sent = [],
    waiters = [];
  const queue = new WorkerAdvanceQueue((seconds) => {
    sent.push(seconds);
    const waiter = deferred();
    waiters.push(waiter);
    return waiter.promise;
  });
  queue.add(0.1);
  const first = queue.advance();
  await Promise.resolve();
  queue.add(0.23);
  const boundary = queue.flush();
  queue.add(0.17);
  assert.equal(queue.advance(), null);
  assert.throws(() => queue.flush(), /already active/);
  waiters[0].resolve();
  await first;
  await Promise.resolve();
  await Promise.resolve();
  assert.deepEqual(sent, [0.1, 0.23]);
  waiters[1].resolve();
  await boundary;
  assert.equal(queue.pendingSeconds, 0.17);
  const last = queue.advance();
  await Promise.resolve();
  waiters[2].resolve();
  await last;
  assert.deepEqual(sent, [0.1, 0.23, 0.17]);
  assert.ok(queue.backlogSeconds < 1e-12);
});
test('pause barrier commits fractional elapsed time and an empty barrier sends no extra advance', async () => {
  const sent = [];
  const queue = new WorkerAdvanceQueue(async (seconds) => {
    sent.push(seconds);
  });
  queue.add(0.017);
  await queue.flush();
  assert.deepEqual(sent, [0.017]);
  assert.equal(queue.pendingSeconds, 0);
  await queue.flush();
  assert.deepEqual(sent, [0.017]);
});
test('failure is terminal and cannot turn failed work into a retry or a false successful checkpoint barrier', async () => {
  const error = new Error('owner failed');
  const queue = new WorkerAdvanceQueue(async () => {
    throw error;
  });
  queue.add(0.1);
  await assert.rejects(queue.advance(), error);
  assert.throws(() => queue.add(0.2), error);
  assert.throws(() => queue.flush(), error);
  assert.throws(() => queue.advance(), error);
  queue.close();
});
test('closing during a barrier rejects it without sending captured work to a new owner', async () => {
  const waiter = deferred();
  let sends = 0;
  const queue = new WorkerAdvanceQueue(() => {
    sends++;
    return waiter.promise;
  });
  queue.add(0.1);
  const first = queue.advance();
  await Promise.resolve();
  queue.add(0.2);
  const barrier = queue.flush();
  const rejected = assert.rejects(barrier, /closed/);
  queue.close();
  waiter.resolve();
  await first;
  await rejected;
  assert.equal(sends, 1);
  assert.throws(() => queue.add(0.1), /closed/);
});
