import test from 'node:test';
import assert from 'node:assert/strict';
import { Simulation } from '../dist/index.js';
import { createProductionTelemetryProvider } from '../dist/mcp.js';
const world = () =>
  new Simulation({
    resources: [
      { id: 'water', label: 'Water', kind: 'material' },
      { id: 'ore', label: 'Ore', kind: 'material' },
      { id: 'coin', label: 'Coin', kind: 'currency' },
      { id: 'tool', label: 'Tool', kind: 'material', storage: 'individual' },
    ],
    recipes: [
      {
        id: 'craft',
        label: 'Craft',
        inputs: { ore: 2 },
        outputs: { tool: 1 },
        durationSeconds: 0.1,
      },
    ],
    facilities: [
      {
        id: 'forge',
        label: 'Forge',
        category: 'test',
        recipes: ['craft'],
        constructionCost: {},
      },
    ],
  });
const roundtrip = (sim) =>
  Simulation.restore(JSON.parse(JSON.stringify(sim.save())));
function unchanged(sim, action) {
  const before = sim.save();
  action();
  assert.deepEqual(sim.save(), before);
}

test('arbitrary objects and named inventory slots are exclusive, detached and persistent', () => {
  const sim = world();
  const attachment = { objectId: 'player', slot: 'bag' };
  sim.createInventory({
    id: 'bag',
    capacity: { kind: 'units', limit: 10 },
    attachment,
  });
  attachment.objectId = 'changed';
  sim.createInventory({
    id: 'pantry',
    capacityPerMaterial: 20,
    attachment: { objectId: 'house' },
  });
  sim.createInventory({ id: 'tank', capacityPerMaterial: 20 });
  sim.attachInventory('tank', 'house', 'water');
  sim.attachInventory('tank', 'house', 'water');
  assert.equal(sim.objectInventory('house').id, 'pantry');
  assert.equal(sim.objectInventory('house', 'water').id, 'tank');
  assert.equal(sim.objectInventory('missing'), undefined);
  assert.deepEqual(sim.objectInventories('missing'), []);
  const detached = sim.objectInventories('house');
  detached[0].objectId = 'oops';
  const single = sim.inventoryAttachment('bag');
  single.slot = 'oops';
  assert.equal(sim.inventoryAttachment('bag').slot, 'bag');
  assert.equal(sim.inventoryAttachment('bag').objectId, 'player');
  const snapshot = sim.snapshot();
  assert.equal(snapshot.inventoryAttachments.length, 3);
  snapshot.inventoryAttachments[0].objectId = 'mutated-snapshot';
  assert.equal(sim.inventoryAttachment('bag').objectId, 'player');
  assert.equal(sim.save().version, 7);
  assert.deepEqual(roundtrip(sim).save(), sim.save());
  assert.equal(roundtrip(sim).objectInventory('house', 'water').id, 'tank');
  unchanged(sim, () =>
    assert.throws(
      () => sim.attachInventory('tank', 'boat'),
      /already attached/,
    ),
  );
  unchanged(sim, () =>
    assert.throws(
      () => sim.attachInventory('bag', 'house'),
      /already attached/,
    ),
  );
  sim.createInventory({ id: 'spare', capacityPerMaterial: 1 });
  unchanged(sim, () =>
    assert.throws(() => sim.attachInventory('spare', 'house'), /occupied/),
  );
  unchanged(sim, () =>
    assert.throws(
      () =>
        sim.createInventory({
          id: 'rejected',
          capacityPerMaterial: 10,
          attachment: { objectId: 'house' },
        }),
      /occupied/,
    ),
  );
  assert.ok(!sim.inventoryIds().includes('rejected'));
  unchanged(sim, () =>
    assert.throws(
      () =>
        sim.createInventory({
          id: 'bad',
          capacityPerMaterial: -1,
          attachment: { objectId: 'new' },
        }),
      /capacity/,
    ),
  );
  assert.deepEqual(sim.objectInventories('new'), []);
});

test('detach does not move stock or cancel reservations; retirement requires explicit detach', () => {
  const sim = world();
  sim.createInventory({
    id: 'lake',
    capacityPerMaterial: 30,
    initial: { water: 20 },
    attachment: { objectId: 'lake' },
  });
  sim.createInventory({ id: 'player', capacityPerMaterial: 5 });
  const d = sim.reserveDelivery('lake', 'player', { water: 3 }).deliveryId;
  const before = sim.inventory('lake').snapshot();
  assert.deepEqual(sim.detachInventory('lake'), {
    inventoryId: 'lake',
    objectId: 'lake',
    slot: 'main',
  });
  assert.deepEqual(sim.inventory('lake').snapshot(), before);
  assert.equal(sim.detachInventory('lake'), null);
  sim.attachInventory('lake', 'pond', 'water');
  sim.pickupDelivery(d);
  assert.equal(sim.arriveDelivery(d), true);
  assert.equal(sim.inventory('player').quantity('water'), 3);
  sim.createInventory({
    id: 'empty',
    capacityPerMaterial: 0,
    attachment: { objectId: 'empty' },
  });
  assert.deepEqual(sim.removeInventory('empty'), {
    ok: false,
    blockers: [{ code: 'object-attachment', objectId: 'empty', slot: 'main' }],
  });
  sim.detachInventory('empty');
  assert.equal(sim.removeInventory('empty').ok, true);
  assert.equal(sim.objectInventory('empty'), undefined);
  assert.deepEqual(roundtrip(sim).save(), sim.save());
});

test('attachment commands validate arguments and refuse observer reentry', () => {
  const sim = world();
  sim.createInventory({ id: 'a', capacityPerMaterial: 10 });
  for (const [objectId, slot] of [
    ['', 'main'],
    [null, 'main'],
    ['object', ''],
    ['object', 3],
  ]) {
    unchanged(sim, () =>
      assert.throws(() => sim.attachInventory('a', objectId, slot), /invalid/),
    );
    assert.throws(() => sim.objectInventory(objectId, slot), /invalid/);
  }
  assert.throws(() => sim.objectInventories(''), /invalid/);
  for (const action of [
    () => sim.attachInventory('missing', 'x'),
    () => sim.detachInventory('missing'),
    () => sim.inventoryAttachment('missing'),
  ])
    assert.throws(action, /unknown/);
  let observed = 0;
  sim.onEvent(() => {
    observed++;
    assert.throws(() => sim.attachInventory('a', 'x'), /observer/);
    assert.throws(() => sim.detachInventory('a'), /observer/);
    assert.throws(
      () => sim.setInventoryCapacity('a', { kind: 'units', limit: 2 }),
      /observer/,
    );
  });
  sim.addFacility('forge', 'a');
  assert.ok(observed > 0);
  assert.equal(sim.inventoryAttachment('a'), null);
});

test('shared unit capacity counts all materials, currency and individual goods atomically', () => {
  const sim = world();
  const capacity = { kind: 'units', limit: 5 };
  sim.createInventory({ id: 'bag', capacity, initial: { water: 2, coin: 1 } });
  capacity.limit = 99;
  assert.equal(sim.deposit('bag', { ore: 2 }), true);
  unchanged(sim, () => assert.equal(sim.deposit('bag', { water: 1 }), false));
  unchanged(sim, () => assert.equal(sim.spawnItem('bag', 'tool', {}), null));
  assert.equal(sim.withdraw('bag', { water: 1 }), true);
  const item = sim.spawnItem('bag', 'tool', { quality: 7 });
  assert.ok(item);
  assert.deepEqual(sim.inventory('bag').summary().capacity, {
    kind: 'units',
    limit: 5,
    used: 5,
    free: 0,
  });
  const read = sim.inventory('bag').summary();
  read.capacity.limit = 200;
  assert.equal(sim.inventory('bag').snapshot().capacity.limit, 5);
  unchanged(sim, () =>
    assert.equal(
      sim.setInventoryCapacity('bag', { kind: 'units', limit: 4 }),
      false,
    ),
  );
  assert.equal(
    sim.setInventoryCapacity('bag', { kind: 'units', limit: 6 }),
    true,
  );
  assert.equal(sim.deposit('bag', { coin: 1 }), true);
  assert.deepEqual(roundtrip(sim).save(), sim.save());
});

test('slot capacity packs bulk by resource stack limit and counts each individual item', () => {
  const sim = world();
  sim.createInventory({
    id: 'bag',
    capacity: { kind: 'slots', limit: 3, stackLimit: 5 },
    initial: { water: 6 },
  });
  assert.equal(sim.inventory('bag').summary().capacity.used, 2);
  const id = sim.spawnItem('bag', 'tool', {});
  assert.ok(id);
  assert.equal(sim.deposit('bag', { water: 4 }), true); // fill the second existing stack
  unchanged(sim, () => assert.equal(sim.deposit('bag', { water: 1 }), false));
  unchanged(sim, () => assert.equal(sim.deposit('bag', { ore: 1 }), false));
  assert.equal(sim.withdraw('bag', { water: 5 }), true); // free one slot
  assert.equal(sim.deposit('bag', { ore: 5 }), true);
  assert.equal(sim.inventory('bag').summary().capacity.used, 3);
  sim.createInventory({
    id: 'chest',
    capacity: { kind: 'slots', limit: 1, stackLimit: 20 },
  });
  assert.equal(sim.transferItem('bag', 'chest', id), true);
  assert.equal(sim.inventory('chest').item(id).id, id);
  unchanged(sim, () =>
    assert.equal(sim.transfer('bag', 'chest', { ore: 1 }), false),
  );
  assert.equal(sim.inventory('bag').summary().capacity.used, 2);
  assert.deepEqual(roundtrip(sim).save(), sim.save());
  assert.equal(
    sim.setInventoryCapacity('bag', { kind: 'units', limit: 10 }),
    true,
  );
});

test('invalid capacity and overflow fail before publication; legacy capacity remains unchanged', () => {
  const sim = world();
  for (const capacity of [
    null,
    {},
    { kind: 'weight', limit: 2 },
    { kind: 'units', limit: -1 },
    { kind: 'units', limit: Infinity },
    { kind: 'slots', limit: 1, stackLimit: 0 },
    { kind: 'slots', limit: 1, stackLimit: 1.5 },
  ])
    unchanged(sim, () =>
      assert.throws(
        () => sim.createInventory({ id: 'bad', capacity }),
        /capacity|stack/,
      ),
    );
  unchanged(sim, () =>
    assert.throws(
      () =>
        sim.createInventory({
          id: 'full',
          capacity: { kind: 'units', limit: 1 },
          initial: { water: 2 },
        }),
      /capacity/,
    ),
  );
  sim.createInventory({ id: 'legacy', capacityPerMaterial: 2 });
  assert.equal(sim.deposit('legacy', { water: 2, ore: 2, coin: 100 }), true);
  assert.equal(sim.save().version, 7);
  sim.createInventory({
    id: 'both',
    capacityPerMaterial: 2,
    capacity: { kind: 'units', limit: 10 },
  });
  assert.equal(sim.deposit('both', { water: 3 }), false);
  sim.createInventory({
    id: 'large',
    capacity: { kind: 'units', limit: Number.MAX_SAFE_INTEGER },
  });
  assert.equal(sim.deposit('large', { water: Number.MAX_SAFE_INTEGER }), true);
  unchanged(sim, () => assert.equal(sim.deposit('large', { coin: 1 }), false));
  unchanged(sim, () =>
    assert.throws(
      () =>
        sim.setInventoryCapacity('legacy', {
          kind: 'slots',
          limit: 1,
          stackLimit: 0,
        }),
      /stack/,
    ),
  );
});

test('full destination preserves cargo and identity until capacity becomes available', () => {
  const sim = world();
  sim.createInventory({
    id: 'source',
    capacityPerMaterial: 100,
    initial: { ore: 10 },
  });
  sim.createInventory({
    id: 'dest',
    capacity: { kind: 'slots', limit: 1, stackLimit: 5 },
    initial: { water: 5 },
  });
  const item = sim.spawnItem('source', 'tool', { quality: 88 });
  const d = sim.reserveDelivery('source', 'dest', {}, [item]).deliveryId;
  sim.pickupDelivery(d);
  assert.equal(sim.arriveDelivery(d), false);
  assert.equal(sim.deliverySnapshot(d).state, 'arrival-blocked');
  assert.equal(sim.locateItem(item).kind, 'delivery');
  assert.equal(
    sim.setInventoryCapacity('dest', {
      kind: 'slots',
      limit: 2,
      stackLimit: 5,
    }),
    true,
  );
  assert.equal(sim.arriveDelivery(d), true);
  assert.equal(sim.inventory('dest').item(item).attributes.quality, 88);
  assert.deepEqual(roundtrip(sim).save(), sim.save());
});

test('same-inventory production frees consumed input capacity and blocks outputs safely', () => {
  const sim = world();
  sim.createInventory({
    id: 'site',
    capacity: { kind: 'units', limit: 2 },
    initial: { ore: 2 },
  });
  sim.addFacility('forge', 'site');
  sim.advance(0.2);
  assert.equal(sim.inventory('site').quantity('tool'), 1);
  assert.equal(sim.inventory('site').quantity('ore'), 0);
  const blocked = world();
  blocked.createInventory({
    id: 'site',
    capacity: { kind: 'slots', limit: 1, stackLimit: 4 },
    initial: { ore: 4 },
  });
  blocked.addFacility('forge', 'site');
  blocked.advance(0.3);
  assert.equal(blocked.inventory('site').quantity('ore'), 4);
  assert.equal(blocked.inventory('site').quantity('tool'), 0);
  assert.equal(
    blocked.setInventoryCapacity('site', {
      kind: 'slots',
      limit: 2,
      stackLimit: 4,
    }),
    true,
  );
  blocked.advance(0.5);
  assert.equal(blocked.inventory('site').quantity('ore'), 0);
  assert.equal(blocked.inventory('site').quantity('tool'), 2);
  assert.deepEqual(roundtrip(blocked).save(), blocked.save());
});

test('restore rejects orphan/duplicate/conflicting attachments, malformed limits and overfull stores', () => {
  const sim = world();
  sim.createInventory({
    id: 'a',
    capacity: { kind: 'units', limit: 3 },
    initial: { water: 3 },
    attachment: { objectId: 'player' },
  });
  sim.createInventory({ id: 'b', capacityPerMaterial: 3 });
  const state = sim.save();
  const bad = (edit) => {
    const copy = structuredClone(state);
    edit(copy);
    assert.throws(() => Simulation.restore(copy));
    assert.deepEqual(sim.save(), state);
  };
  bad((s) => s.inventoryAttachments.push({ ...s.inventoryAttachments[0] }));
  bad((s) =>
    s.inventoryAttachments.push({
      inventoryId: 'b',
      objectId: 'player',
      slot: 'main',
    }),
  );
  bad((s) => (s.inventoryAttachments[0].inventoryId = 'missing'));
  bad((s) => (s.inventoryAttachments[0].slot = ''));
  bad((s) => delete s.inventoryAttachments);
  bad((s) => (s.inventories[0].capacity.limit = 2));
  bad(
    (s) =>
      (s.inventories[0].capacity = { kind: 'slots', limit: 3, stackLimit: 0 }),
  );
  bad((s) => (s.version = 4));
  const old = world();
  old.createInventory({ id: 'plain', capacityPerMaterial: 5 });
  assert.deepEqual(roundtrip(old).save(), old.save());
});

test('object telemetry is read-only, paged and scoped; capacity and attachment are visible', () => {
  const sim = world();
  sim.createInventory({
    id: 'bag',
    capacity: { kind: 'slots', limit: 2, stackLimit: 5 },
    attachment: { objectId: 'player' },
  });
  sim.createInventory({
    id: 'pocket',
    capacityPerMaterial: 2,
    attachment: { objectId: 'player', slot: 'pocket' },
  });
  const binding = { scope: 'game', isCurrent: () => true };
  const context = { binding, signal: { aborted: false } };
  const provider = createProductionTelemetryProvider({
    id: 'test',
    resolveSimulation: (b) => (b.scope === 'game' ? sim : null),
  });
  const before = sim.save();
  sim.enableDiagnostics();
  const trace = sim.diagnosticTrace();
  const call = (name, args) =>
    provider.call(name, args, context).structuredContent.data;
  assert.equal(
    call('production_inventory', { id: 'bag' }).capacity.kind,
    'slots',
  );
  assert.equal(
    call('production_inventory', { id: 'bag' }).attachment.objectId,
    'player',
  );
  const page = call('production_object_inventories', {
    objectId: 'player',
    offset: 1,
    limit: 1,
  });
  assert.equal(page.total, 2);
  assert.equal(page.entries[0].inventoryId, 'pocket');
  page.entries[0].slot = 'changed';
  assert.equal(
    call('production_object_inventories', { objectId: 'unknown' }).total,
    0,
  );
  for (const args of [
    {},
    { objectId: '' },
    { objectId: 'player', extra: 1 },
    { objectId: 'player', limit: 0 },
  ])
    assert.throws(() => call('production_object_inventories', args));
  assert.throws(
    () =>
      provider.call(
        'production_object_inventories',
        { objectId: 'player' },
        { ...context, binding: { ...binding, scope: 'other' } },
      ),
    /unavailable/,
  );
  assert.deepEqual(sim.save(), before);
  assert.deepEqual(sim.diagnosticTrace(), trace);
});

test('shared capacity loss preserves a completed production outcome until it can publish', () => {
  const sim = world();
  sim.createInventory({
    id: 'site',
    capacity: { kind: 'units', limit: 2 },
    initial: { ore: 2 },
  });
  sim.createInventory({ id: 'store', capacity: { kind: 'units', limit: 10 } });
  const facility = sim.addFacility('forge', 'site');
  assert.equal(facility.ok, true);
  sim.advanceTicks(1); // consume inputs and start the batch
  assert.equal(sim.inventory('site').quantity('ore'), 0);
  assert.equal(sim.deposit('site', { water: 2 }), true);
  sim.advance(0.3);
  const pending = sim.facilitySnapshot(facility.facilityId).jobs[0]
    .pendingOutcome;
  assert.ok(pending);
  assert.equal(sim.inventory('site').quantity('tool'), 0);
  const restored = roundtrip(sim);
  assert.deepEqual(
    restored.facilitySnapshot(facility.facilityId).jobs[0].pendingOutcome,
    pending,
  );
  assert.equal(restored.transfer('site', 'store', { water: 2 }), true);
  restored.advanceTicks(1);
  assert.deepEqual(
    restored.inventory('site').item(pending.items[0].id),
    pending.items[0],
  );
  restored.advance(0.3);
  assert.equal(restored.inventory('site').quantity('tool'), 1);
  assert.equal(
    restored.facilitySnapshot(facility.facilityId).jobs[0].batchesCompleted,
    1,
  );
});
