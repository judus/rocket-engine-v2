import { build } from 'esbuild';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';

const result = await build({
  entryPoints: {
    index: 'src/index.ts',
    host: 'src/host/index.ts',
    cai: 'src/cai/index.ts',
    'examples/browser': 'examples/browser.ts',
    'examples/chat-browser': 'examples/chat-browser.ts',
    'examples/narrative-browser': 'examples/narrative-browser.ts',
    'examples/fake-cai-backend': 'examples/fake-cai-backend.ts',
  },
  outdir: 'dist/browser',
  bundle: true,
  platform: 'browser',
  format: 'esm',
  target: 'es2022',
  sourcemap: true,
  metafile: true,
  legalComments: 'eof',
});
const packages = new Set();
for (const input of Object.keys(result.metafile.inputs)) {
  const match = /^(.*node_modules\/(?:@[^/]+\/)?[^/]+)\//.exec(input);
  if (match) packages.add(match[1]);
}
const notices = ['Bundled browser dependencies and licenses.'];
for (const root of [...packages].sort()) {
  const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
  const files = (await readdir(root)).filter((name) =>
    /^(license|copying|notice)(\.|$)/i.test(name),
  );
  if (!files.length) throw new Error('Missing license notice: ' + root);
  notices.push(`\n${pkg.name}@${pkg.version} (${pkg.license ?? 'see below'})`);
  for (const file of files)
    notices.push(await readFile(join(root, file), 'utf8'));
}
await writeFile('dist/browser/THIRD-PARTY-NOTICES.txt', notices.join('\n'));
await writeFile(
  'dist/browser/build-meta.json',
  JSON.stringify(result.metafile, null, 2) + '\n',
);
console.log('Browser ESM entries built in ' + dirname('dist/browser/index.js'));
