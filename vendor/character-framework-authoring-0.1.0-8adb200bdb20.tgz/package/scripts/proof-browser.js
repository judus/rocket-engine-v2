const { chromium } = await import(
  process.env.BROWSER_PROOF_PLAYWRIGHT ?? 'playwright'
);
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, relative, extname } from 'node:path';
const root = resolve(process.argv[2] ?? '.');
const server = createServer(async (req, res) => {
  try {
    const path = resolve(
      root,
      '.' + new URL(req.url, 'http://localhost').pathname,
    );
    if (relative(root, path).startsWith('..')) {
      res.writeHead(404).end();
      return;
    }
    const content = await readFile(path);
    res
      .writeHead(200, {
        'Content-Type':
          extname(path) === '.html' ? 'text/html' : 'text/javascript',
      })
      .end(content);
  } catch {
    res.writeHead(404).end();
  }
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({
  ...(process.env.BROWSER_PROOF_CHROME
    ? { executablePath: process.env.BROWSER_PROOF_CHROME }
    : { channel: 'chrome' }),
  headless: true,
  args: ['--no-sandbox'],
});
try {
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(
    `http://127.0.0.1:${server.address().port}/demo/situation-browser-proof.html`,
  );
  await page.waitForFunction(() => globalThis.browserProof !== undefined, {
    timeout: 15000,
  });
  const result = await page.evaluate(() => globalThis.browserProof);
  console.log(
    JSON.stringify({ browser: await browser.version(), result, errors }),
  );
  if (!result.ok || result.nodeGlobals || errors.length) process.exitCode = 1;
} finally {
  await browser.close();
  server.close();
}
