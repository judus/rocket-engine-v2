import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const artifact = process.argv[2];
if (!artifact)
  throw new Error(
    'Pass a retained quest-builder-watchtower artifact directory',
  );
const document = new URL(
  '../docs/QUEST-BUILDER-TOOLS-WALKTHROUGH.md',
  import.meta.url,
);
const original = await readFile(document, 'utf8');
const marker = original.indexOf('### 1.');
if (marker < 0) throw new Error('Walkthrough marker not found');
const calls = JSON.parse(
  await readFile(join(artifact, 'builder-calls.json'), 'utf8'),
);
const schemas = JSON.parse(
  await readFile(join(artifact, 'tool-schemas.json'), 'utf8'),
);
const mermaid = await readFile(join(artifact, 'quest.mmd'), 'utf8');
const sections = calls.map(
  (c, i) =>
    `### ${i + 1}. \`${c.tool}\`\n\nInput:\n\n\`\`\`json\n${JSON.stringify(c.arguments, null, 2)}\n\`\`\`\n\nObserved response:\n\n\`\`\`json\n${JSON.stringify(c.result, null, 2)}\n\`\`\`\n\n`,
);
await writeFile(
  document,
  original.slice(0, marker) +
    sections.join('') +
    `## Final saved logic\n\n\`\`\`mermaid\n${mermaid}\`\`\`\n\nExact condition/action details appear in the inspection responses above. The diagram is generated from saved authoring records at the same revision.\n`,
);
await writeFile(
  new URL(
    '../docs/contracts/quest-builder-tools.prototype.json',
    import.meta.url,
  ),
  JSON.stringify(
    {
      status: 'experimental local prototype; not deployed MCP API',
      tools: schemas,
    },
    null,
    2,
  ) + '\n',
);
console.log(
  JSON.stringify({
    schemas: Object.keys(schemas).length,
    calls: calls.length,
    artifact,
  }),
);
