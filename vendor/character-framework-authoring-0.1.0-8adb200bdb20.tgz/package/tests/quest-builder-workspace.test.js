import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { QuestBuilderWorkspace } from '../examples/quest-builder-workspace.js';
import { CharacterRuntime } from '../dist/src/index.js';
import { Ajv2020 } from 'ajv/dist/2020.js';
import { setImmediate } from 'node:timers/promises';

const capabilities = [
  {
    name: 'inspect',
    kind: 'inspection',
    inputSchema: {
      type: 'object',
      properties: {},
      additionalProperties: false,
    },
    outputSchema: {
      type: 'object',
      properties: {
        count: { type: 'integer', minimum: 0 },
        ready: { type: 'boolean' },
        nested: { type: 'object', properties: { score: { type: 'integer' } } },
      },
    },
    evidenceStream: { ref: 'events', captureKeys: [] },
  },
  {
    name: 'act',
    kind: 'action',
    inputSchema: {
      type: 'object',
      properties: { target: { enum: ['a', 'b'] } },
      required: ['target'],
      additionalProperties: false,
    },
    outputSchema: {
      type: 'object',
      properties: { applied: { type: 'boolean' } },
    },
  },
  {
    name: 'produce',
    kind: 'action',
    inputSchema: {
      type: 'object',
      properties: {},
      additionalProperties: false,
    },
    outputSchema: {
      type: 'object',
      properties: {
        ticket: {
          type: 'object',
          properties: { id: { type: 'string' }, amount: { type: 'integer' } },
        },
      },
    },
  },
  {
    name: 'consume',
    kind: 'action',
    inputSchema: {
      type: 'object',
      properties: { target: { type: 'string' }, note: { type: 'string' } },
      required: ['target', 'note'],
      additionalProperties: false,
    },
    outputSchema: {
      type: 'object',
      properties: { applied: { type: 'boolean' } },
    },
  },
];
async function fixture(t) {
  const dir = await mkdtemp(join(tmpdir(), 'cfw-builder-test-'));
  t.after(() => rm(dir, { recursive: true }));
  const options = {
    path: join(dir, 'workspace.json'),
    capabilities,
    host: async () => ({ status: 'completed', technicalReady: true }),
  };
  const workspace = new QuestBuilderWorkspace(options);
  const r = await workspace.call('create_quest_draft', {
    title: 'Test',
    premise: 'Test branching',
  });
  let draft = { id: r.draftId, revision: r.revision };
  const call = async (name, args) => {
    const r = await workspace.call(name, { draft, ...args });
    if (r.revision) draft = { id: r.draftId, revision: r.revision };
    return r;
  };
  const a = (await call('add_stage', { title: 'A', purpose: 'Start' })).created
    .stageId;
  const b = (await call('add_stage', { title: 'B', purpose: 'End' })).created
    .stageId;
  return {
    workspace,
    options,
    call,
    a,
    b,
    get draft() {
      return draft;
    },
  };
}
test('builder rejects stale/invalid edits and blocks unavailable temporal boundaries at publication', async (t) => {
  const f = await fixture(t);
  const revision = f.draft.revision;
  assert.equal(
    (
      await f.workspace.call('set_start_stage', {
        draft: { ...f.draft, revision: 1 },
        stageId: f.a,
      })
    ).code,
    'revision_conflict',
  );
  assert.equal(
    (
      await f.call('create_fact_condition', {
        capability: 'inspect',
        arguments: {},
        comparison: { field: 'ready', operator: 'at_least', value: true },
      })
    ).status,
    'rejected',
  );
  assert.equal(f.draft.revision, revision);
  const condition = (
    await f.call('create_event_condition', {
      capability: 'inspect',
      arguments: {},
      comparison: { field: 'count', operator: 'at_least', value: 1 },
      since: { stageId: f.a },
    })
  ).created.conditionId;
  assert.equal(
    (
      await f.call('add_transition', {
        from: f.b,
        to: f.a,
        conditionId: condition,
        priority: 10,
      })
    ).status,
    'completed',
  );
  await f.call('set_start_stage', { stageId: f.b });
  await f.call('declare_ending', { stageId: f.a, ending: true });
  const review = await f.call('review_quest_draft', {});
  assert.equal(review.technicalReady, false);
  assert.ok(
    review.findings.some((e) =>
      e.message.includes('Unavailable event boundary'),
    ),
  );
  assert.equal((await f.call('publish_quest_draft', {})).status, 'rejected');
  const read = (
    await new QuestBuilderWorkspace(f.options).call('inspect_quest_draft', {
      draftId: f.draft.id,
    })
  ).data;
  assert.equal(read.revision, f.draft.revision);
  assert.equal(read.records.length, 1);
});
test('builder shared condition edits require exact user set and stage interaction guards compile to both choices', async (t) => {
  const f = await fixture(t);
  await f.call('update_stage', {
    stageId: f.a,
    title: 'A',
    purpose: 'Choose',
    dialogue: 'Choose a path',
  });
  const conditionId = (
    await f.call('create_fact_condition', {
      capability: 'inspect',
      arguments: {},
      comparison: { field: 'ready', operator: 'equals', value: true },
    })
  ).created.conditionId;
  await f.call('set_interaction_requirement', { stageId: f.a, conditionId });
  await f.call('add_choice', { from: f.a, to: f.b, label: 'First' });
  await f.call('add_choice', { from: f.a, to: f.b, label: 'Second' });
  const state = f.workspace.state.drafts[0];
  const compiled = f.workspace.compile(state);
  for (const c of compiled.situations[0].choices)
    assert.deepEqual(c.when, compiled.situations[0].dialogue.requires);
  const replacement = {
    mode: 'fact',
    capability: 'inspect',
    arguments: {},
    comparison: { field: 'ready', operator: 'equals', value: false },
  };
  const rejected = await f.call('update_condition', {
    conditionId,
    replacement,
    affectedRecordIds: [],
  });
  assert.equal(rejected.code, 'condition_users_changed');
  assert.equal(
    (
      await f.call('update_condition', {
        conditionId,
        replacement,
        affectedRecordIds: rejected.affectedRecordIds,
      })
    ).status,
    'completed',
  );
});
test('builder replaces/removes effects and rejects referenced-stage deletion without silent retargeting', async (t) => {
  const f = await fixture(t);
  const recordId = (
    await f.call('add_entry_consequence', {
      stageId: f.a,
      capability: 'act',
      arguments: { target: 'a' },
    })
  ).created.recordId;
  assert.equal(
    (
      await f.call('edit_record', {
        recordId,
        change: {
          operation: 'replace',
          kind: 'consequence',
          value: {
            stageId: f.a,
            capability: 'act',
            arguments: { target: 'b' },
          },
        },
      })
    ).status,
    'completed',
  );
  assert.deepEqual(
    f.workspace
      .compile(f.workspace.state.drafts[0])
      .situations[0].onEnter.map((a) => a.arguments),
    [{ target: 'b' }],
  );
  const r = await f.call('remove_stage', { stageId: f.a });
  assert.equal(r.code, 'stage_referenced');
  assert.deepEqual(r.referencingIds, [recordId]);
  await f.call('edit_record', { recordId, change: { operation: 'remove' } });
  assert.equal(
    (await f.call('remove_stage', { stageId: f.a })).status,
    'completed',
  );
});

test('builder can discard unused branch conditions and returns semantic feedback and actionable missing-field errors', async (t) => {
  const f = await fixture(t);
  const c = (
    await f.call('create_event_condition', {
      capability: 'inspect',
      arguments: {},
      comparison: { field: 'count', operator: 'at_least', value: 1 },
      since: { stageId: f.a },
    })
  ).created.conditionId;
  const bad = await f.call('add_transition', {
    from: f.a,
    to: f.b,
    conditionId: c,
  });
  assert.equal(bad.code, 'invalid_input');
  assert.equal(bad.revision, f.draft.revision);
  assert.ok(bad.findings.some((e) => e.path === '/priority'));
  const r = (
    await f.call('add_transition', {
      from: f.a,
      to: f.b,
      conditionId: c,
      priority: 10,
    })
  ).created.recordId;
  const a = (
    await f.call('add_entry_consequence', {
      stageId: f.a,
      capability: 'act',
      arguments: { target: 'a' },
    })
  ).created.recordId;
  const view = (
    await f.workspace.call('inspect_quest_draft', { draftId: f.draft.id })
  ).data;
  assert.match(view.mermaid, /events since s1 entry/);
  assert.match(view.mermaid, /inspect/);
  assert.match(view.mermaid, /enter .*act/);
  assert.equal(
    (await f.call('remove_condition', { conditionId: c })).code,
    'condition_referenced',
  );
  const edited = await f.call('edit_record', {
    recordId: a,
    change: {
      operation: 'replace',
      kind: 'consequence',
      value: { stageId: f.a, capability: 'act', arguments: { target: 'b' } },
    },
  });
  assert.equal(edited.changedId, a);
  assert.deepEqual(edited.savedMeaning.arguments, { target: 'b' });
  await f.call('edit_record', { recordId: r, change: { operation: 'remove' } });
  await f.call('edit_record', { recordId: a, change: { operation: 'remove' } });
  assert.equal(
    (await f.call('remove_stage', { stageId: f.a })).code,
    'stage_referenced',
  );
  await f.call('remove_condition', { conditionId: c });
  assert.equal(
    (await f.call('remove_stage', { stageId: f.a })).status,
    'completed',
  );
});

test('builder intent is revisable before publication; publication freezes saved draft and is inspectable after reopen', async (t) => {
  const f = await fixture(t);
  await f.call('update_quest_intent', {
    title: 'A stronger conflict',
    premise: 'A changed motive',
  });
  await f.call('remove_stage', { stageId: f.b });
  await f.call('set_start_stage', { stageId: f.a });
  await f.call('declare_ending', { stageId: f.a, ending: true });
  let publishes = 0;
  f.workspace.host = async () => {
    publishes++;
    return {
      status: 'completed',
      publication: {
        definitionId: 'immutable-definition',
        digest: 'verified-by-host',
      },
    };
  };
  const published = await f.call('publish_quest_draft', {});
  assert.equal(published.publication.sourceRevision, f.draft.revision);
  const reopened = new QuestBuilderWorkspace(f.options);
  const view = (
    await reopened.call('inspect_quest_draft', { draftId: f.draft.id })
  ).data;
  assert.equal(view.intent.premise, 'A changed motive');
  assert.deepEqual(view.publication, published.publication);
  assert.equal(
    (
      await reopened.call('update_quest_intent', {
        draft: f.draft,
        title: 'Changed',
        premise: 'Invalid after publish',
      })
    ).code,
    'draft_published',
  );
  assert.deepEqual(
    await reopened.call('publish_quest_draft', { draft: f.draft }),
    published,
  );
  assert.equal(publishes, 1);
});

test('builder supports nested paths, earlier-stage evidence, separate shared/choice guards and objective repair', async (t) => {
  const f = await fixture(t);
  const end = (await f.call('add_stage', { title: 'End', purpose: 'Finish' }))
    .created.stageId;
  const ready = (
    await f.call('create_fact_condition', {
      capability: 'inspect',
      arguments: {},
      comparison: { path: ['nested', 'score'], operator: 'at_least', value: 2 },
    })
  ).created.conditionId;
  const event = (
    await f.call('create_event_condition', {
      capability: 'inspect',
      arguments: {},
      comparison: { path: ['count'], operator: 'at_least', value: 1 },
      since: { stageId: f.a },
    })
  ).created.conditionId;
  await f.call('set_start_stage', { stageId: f.a });
  await f.call('add_transition', {
    from: f.a,
    to: f.b,
    conditionId: ready,
    priority: 10,
  });
  await f.call('update_stage', {
    stageId: f.b,
    title: 'B',
    purpose: 'Choose',
    dialogue: 'Choose',
  });
  await f.call('set_interaction_requirement', {
    stageId: f.b,
    conditionId: event,
  });
  await f.call('add_choice', {
    from: f.b,
    to: end,
    label: 'Score-qualified option',
    conditionId: ready,
  });
  const objective = (
    await f.call('add_objective', {
      stageId: f.b,
      description: 'Observe progress',
      conditionId: event,
    })
  ).created.recordId;
  assert.equal(f.workspace.uses(f.workspace.state.drafts[0], event).length, 3);
  await f.call('declare_ending', { stageId: end, ending: true });
  assert.equal((await f.call('review_quest_draft', {})).technicalReady, true);
  const compiled = f.workspace.compile(f.workspace.state.drafts[0]);
  assert.deepEqual(compiled.situations[1].choices[0].when.expect.path, [
    'nested',
    'score',
  ]);
  assert.equal(
    compiled.situations[1].dialogue.requires.evidence.after.situationRef,
    f.a,
  );
  assert.equal(compiled.situations[1].objectives[0].id, objective);
  assert.equal(
    (await f.call('remove_condition', { conditionId: event })).code,
    'condition_referenced',
  );
  await f.call('edit_record', {
    recordId: objective,
    change: {
      operation: 'replace',
      kind: 'objective',
      value: {
        stageId: f.b,
        description: 'Score progress',
        conditionId: ready,
      },
    },
  });
  assert.match(
    (await f.workspace.call('inspect_quest_draft', { draftId: f.draft.id }))
      .data.mermaid,
    /objective .*Score progress/,
  );
  await f.call('edit_record', {
    recordId: objective,
    change: { operation: 'remove' },
  });
  // Bypassing the boundary must block publication rather than move its cursor.
  await f.call('add_choice', { from: f.a, to: f.b, label: 'Still enters A' });
  await f.call('set_start_stage', { stageId: f.b });
  assert.equal((await f.call('review_quest_draft', {})).technicalReady, false);
});

test('builder translates typed action results and blocks wrong types, forward producers and dangling references', async (t) => {
  const f = await fixture(t);
  await f.call('remove_stage', { stageId: f.b });
  await f.call('set_start_stage', { stageId: f.a });
  const producer = (
    await f.call('add_entry_consequence', {
      stageId: f.a,
      capability: 'produce',
      arguments: {},
    })
  ).created.recordId;
  const argument = (
    await f.call('from_action_result', {
      recordId: producer,
      path: ['ticket', 'id'],
    })
  ).argument;
  assert.equal(
    (
      await f.call('add_entry_consequence', {
        stageId: f.a,
        capability: 'consume',
        arguments: { target: argument, note: 42 },
      })
    ).status,
    'rejected',
  );
  const consumer = (
    await f.call('add_entry_consequence', {
      stageId: f.a,
      capability: 'consume',
      arguments: { target: argument, note: 'Use confirmed ticket' },
    })
  ).created.recordId;
  await f.call('declare_ending', { stageId: f.a, ending: true });
  assert.equal((await f.call('review_quest_draft', {})).technicalReady, true);
  const actions = f.workspace.compile(f.workspace.state.drafts[0]).situations[0]
    .onEnter;
  assert.deepEqual(actions[1].arguments.target, {
    $result: { situationRef: f.a, actionId: producer, path: ['ticket', 'id'] },
  });
  assert.equal(
    (
      await f.call('edit_record', {
        recordId: producer,
        change: { operation: 'remove' },
      })
    ).status,
    'rejected',
  );
  const wrong = (
    await f.call('from_action_result', {
      recordId: producer,
      path: ['ticket', 'amount'],
    })
  ).argument;
  await f.call('edit_record', {
    recordId: consumer,
    change: {
      operation: 'replace',
      kind: 'consequence',
      value: {
        stageId: f.a,
        capability: 'consume',
        arguments: { target: wrong, note: 'Wrong type' },
      },
    },
  });
  assert.equal((await f.call('review_quest_draft', {})).technicalReady, false);
  await f.call('edit_record', {
    recordId: consumer,
    change: {
      operation: 'replace',
      kind: 'consequence',
      value: {
        stageId: f.a,
        capability: 'consume',
        arguments: { target: argument, note: 'Correct type' },
      },
    },
  });
  // Same-stage references to a later action are invalid, even with matching type.
  const later = (
    await f.call('add_entry_consequence', {
      stageId: f.a,
      capability: 'produce',
      arguments: {},
    })
  ).created.recordId;
  const forward = (
    await f.call('from_action_result', {
      recordId: later,
      path: ['ticket', 'id'],
    })
  ).argument;
  await f.call('edit_record', {
    recordId: consumer,
    change: {
      operation: 'replace',
      kind: 'consequence',
      value: {
        stageId: f.a,
        capability: 'consume',
        arguments: { target: forward, note: 'Forward' },
      },
    },
  });
  const review = await f.call('review_quest_draft', {});
  assert.ok(review.findings.some((e) => e.message.includes('forward')));
});

test('compiled builder executes acknowledged result chaining and enforces both guards with objective progress', async (t) => {
  const f = await fixture(t);
  await f.call('set_start_stage', { stageId: f.a });
  await f.call('update_stage', {
    stageId: f.a,
    title: 'A',
    purpose: 'Choose',
    dialogue: 'Choose',
  });
  const shared = (
    await f.call('create_fact_condition', {
      capability: 'inspect',
      arguments: {},
      comparison: { path: ['ready'], operator: 'equals', value: true },
    })
  ).created.conditionId;
  const own = (
    await f.call('create_fact_condition', {
      capability: 'inspect',
      arguments: {},
      comparison: { path: ['nested', 'score'], operator: 'at_least', value: 2 },
    })
  ).created.conditionId;
  await f.call('set_interaction_requirement', {
    stageId: f.a,
    conditionId: shared,
  });
  await f.call('add_choice', {
    from: f.a,
    to: f.b,
    label: 'Qualified',
    conditionId: own,
  });
  const objective = (
    await f.call('add_objective', {
      stageId: f.a,
      description: 'Score threshold',
      conditionId: own,
    })
  ).created.recordId;
  const producer = (
    await f.call('add_entry_consequence', {
      stageId: f.a,
      capability: 'produce',
      arguments: {},
    })
  ).created.recordId;
  const argument = (
    await f.call('from_action_result', {
      recordId: producer,
      path: ['ticket', 'id'],
    })
  ).argument;
  await f.call('add_entry_consequence', {
    stageId: f.a,
    capability: 'consume',
    arguments: { target: argument, note: 'Confirmed producer' },
  });
  await f.call('declare_ending', { stageId: f.b, ending: true });
  assert.equal((await f.call('review_quest_draft', {})).technicalReady, true);
  let ready = false,
    score = 2,
    revision = 0,
    produced = 0,
    consumed = 0;
  const ajv = new Ajv2020({ strict: false });
  const gameCaps = capabilities.map((c) => ({
    ...c,
    description: c.name,
    validate: (args) => ajv.compile(c.inputSchema)(args),
    execute: async (_, args) => {
      if (c.name === 'produce') {
        produced++;
        return {
          status: 'completed',
          data: { ticket: { id: 'confirmed-ticket', amount: 1 } },
        };
      }
      if (c.name === 'consume') {
        consumed++;
        assert.equal(args.target, 'confirmed-ticket');
        return { status: 'completed', data: { applied: true } };
      }
      return {
        status: 'completed',
        data: { count: 1, ready, nested: { score } },
      };
    },
  }));
  const runtime = new CharacterRuntime({
    gameId: 'builder-extended',
    capabilities: gameCaps,
    situationGame: {
      capabilities: () => gameCaps,
      scopeAvailable: () => true,
      capture: () => 0,
      observe: async (context, observations) => ({
        revision: String(revision),
        results: await Promise.all(
          observations.map((o) => o.capability.execute(context, o.arguments)),
        ),
      }),
      observationCurrent: (_, r) => r === String(revision),
      reconcile: () => ({ status: 'not_admitted' }),
      persist: () => {},
      retire: () => {},
    },
  });
  t.after(() => runtime.dispose());
  const actor = runtime.register({
    id: 'author',
    name: 'Author',
    capabilities: gameCaps.map((c) => c.name),
  });
  const handle = runtime.situations.bind(actor);
  const ticks = async () => {
    for (let i = 0; i < 30; i++) {
      runtime.advance(0);
      await setImmediate();
    }
  };
  const pump = async (promise) => {
    let done = false;
    promise.finally(() => {
      done = true;
    });
    for (let i = 0; i < 100 && !done; i++) {
      runtime.advance(0);
      await setImmediate();
    }
    assert.ok(done);
    return promise;
  };
  const fragment = f.workspace.compile(f.workspace.state.drafts[0]);
  await pump(
    handle.publish(
      {
        id: 'extended-definition',
        proposalVersion: 'cfw-situations-draft-2',
        start: fragment.entrySituation,
        situations: fragment.situations,
      },
      'publish',
    ),
  );
  const { runId } = await pump(
    handle.start('extended-definition', { kind: 'world' }, 'start'),
  );
  await ticks();
  assert.equal(handle.read(runId).choices.length, 0);
  assert.equal(
    handle.read(runId).objectives.find((o) => o.id === objective).satisfied,
    true,
  );
  ready = true;
  score = 0;
  revision++;
  await ticks();
  assert.equal(handle.read(runId).choices.length, 0);
  score = 2;
  revision++;
  await ticks();
  const view = handle.read(runId);
  assert.equal(view.choices.length, 1);
  await pump(handle.choose(runId, view.choices[0].id, view.revision, 'choose'));
  await ticks();
  assert.equal(handle.read(runId).status, 'closed');
  assert.equal(produced, 1);
  assert.equal(consumed, 1);
});
