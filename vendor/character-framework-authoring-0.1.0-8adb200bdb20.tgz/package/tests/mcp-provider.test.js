import test from 'node:test';
import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { CharacterRuntime } from '../dist/src/index.js';
import { CfwMcpProvider } from '../dist/src/mcp/index.js';

function fixture(t) {
  let effects = 0;
  const action = {
    name: 'test_commit',
    description: 'One scoped test effect.',
    kind: 'action',
    inputSchema: {
      type: 'object',
      properties: { value: { type: 'integer' } },
      required: ['value'],
      additionalProperties: false,
    },
    validate: () => true,
    execute: (context, input) => {
      assert.ok(context.mutation.id);
      effects++;
      return { status: 'completed', data: { value: input.value, effects } };
    },
  };
  const runtime = new CharacterRuntime({
    gameId: 'provider-world',
    capabilities: [action],
  });
  const actor = runtime.register({
    id: 'author',
    name: 'Author',
    binding: { id: 'stable-author', generation: 'one' },
    cai: { characterId: 'cai-author', sessionId: 'session-one' },
    capabilities: ['test_commit'],
  });
  const provider = new CfwMcpProvider({ runtime });
  const provisioned = provider.bind(
    'author-key',
    actor,
    [action],
    ['cfw', 'world'],
  );
  const headers = new Headers({
    ...provisioned,
    'X-CF-Call-Id': 'call-one',
    'X-CF-Turn-Request-Id': 'turn-one',
    'X-CF-Effect-Key': 'effect-one',
  });
  const binding = provider.resolveBinding(
    new Request('http://local/mcp', { headers }),
  );
  assert.ok(binding);
  t.after(() => {
    provider.dispose();
    runtime.dispose();
  });
  return {
    provider,
    runtime,
    actor,
    action,
    headers,
    binding,
    effects: () => effects,
  };
}

async function settle(f, promise) {
  let done = false;
  promise.then(
    () => {
      done = true;
    },
    () => {
      done = true;
    },
  );
  for (let i = 0; i < 100 && !done; i++) {
    f.provider.advance(0);
    await setImmediate();
  }
  assert.ok(done);
  return promise;
}
const context = (f, signal = new AbortController().signal) => ({
  binding: f.binding,
  headers: f.headers,
  signal,
});

test('domain-only provider exposes combined host binding and preserves effect replay/conflict receipts', async (t) => {
  const f = fixture(t);
  assert.deepEqual(f.binding.providers, ['cfw', 'world']);
  assert.deepEqual(
    f.provider.tools(f.binding).map((x) => x.name),
    ['test_commit'],
  );
  const first = await settle(
    f,
    f.provider.call('test_commit', { value: 2 }, context(f)),
  );
  assert.deepEqual(first.structuredContent, {
    status: 'completed',
    data: { value: 2, effects: 1 },
  });
  assert.deepEqual(JSON.parse(first.content[0].text), first.structuredContent);
  const replay = await f.provider.call('test_commit', { value: 2 }, context(f));
  assert.deepEqual(replay, first);
  const conflict = await f.provider.call(
    'test_commit',
    { value: 3 },
    context(f),
  );
  assert.equal(conflict.structuredContent.status, 'rejected');
  assert.equal(f.effects(), 1);
  const saved = f.provider.saveReceipts();
  assert.equal(saved.receipts.length, 1);
  assert.equal(saved.receipts[0].callId, 'call-one');
  assert.equal(saved.receipts[0].turnId, 'turn-one');
  const restored = new CfwMcpProvider({ runtime: f.runtime });
  t.after(() => restored.dispose());
  restored.restoreReceipts(saved);
  restored.bind('author-key', f.actor, [f.action]);
  const binding = restored.resolveBinding(
    new Request('http://local/mcp', { headers: f.headers }),
  );
  assert.deepEqual(
    await restored.call(
      'test_commit',
      { value: 2 },
      { ...context(f), binding },
    ),
    first,
  );
  assert.equal(f.effects(), 1, 'checkpoint replay does not execute again');
});

test('provider rejects cloned authority, mismatched headers and rebound handles before effects', async (t) => {
  const f = fixture(t);
  await assert.rejects(
    f.provider.call(
      'test_commit',
      { value: 2 },
      { ...context(f), binding: { ...f.binding } },
    ),
    /Unknown/,
  );
  const wrong = new Headers(f.headers);
  wrong.set('X-CF-CAI-Session-Id', 'other-session');
  assert.equal(
    f.provider.resolveBinding(
      new Request('http://local/mcp', { headers: wrong }),
    ),
    null,
  );
  await assert.rejects(
    f.provider.call(
      'test_commit',
      { value: 2 },
      { ...context(f), headers: wrong },
    ),
    /headers/,
  );
  f.provider.bind('author-key', f.actor, [f.action]);
  assert.equal(f.binding.isCurrent(), false);
  assert.throws(() => f.provider.tools(f.binding), /invalidated/);
  assert.equal(f.effects(), 0);
});

test('provider disposal rejects queued work without disposing the application runtime', async (t) => {
  const f = fixture(t);
  const pending = f.provider.call('test_commit', { value: 2 }, context(f));
  const rejected = assert.rejects(pending, /lane closed/);
  f.provider.dispose();
  await rejected;
  assert.equal(f.binding.isCurrent(), false);
  assert.equal(f.effects(), 0);
  assert.equal(f.actor.snapshot().id, 'author');
});
