import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DialogueDraft,
  isDialogueGraph,
} from '../dist/src/narrative/dialogue.js';
const header = {
  recipientRef: 'player-1',
  title: 'A greeting',
  start: 'greet',
};
const nodes = [
  {
    id: 'greet',
    text: 'Hello.',
    choices: [
      { id: 'ask', label: 'Tell me more.', next: 'explain' },
      { id: 'leave', label: 'Goodbye.', next: 'exit' },
    ],
  },
  {
    id: 'explain',
    text: 'The grove needs surveying.',
    choices: [{ id: 'leave', label: 'Goodbye.', next: 'exit' }],
  },
  { id: 'exit', text: 'Safe travels.', choices: [] },
];
const graph = () => structuredClone({ ...header, nodes });
test('dialogue draft finalizes forward references as detached immutable authored content', () => {
  const input = structuredClone(nodes);
  const draft = new DialogueDraft(header);
  assert.throws(() => draft.toInput());
  draft.addNode(input[0]);
  assert.throws(() => draft.toInput());
  draft.addNode(input[1]).addNode(input[2]);
  input[0].choices[0].next = 'unknown';
  const published = draft.toInput();
  assert.ok(isDialogueGraph(published));
  assert.equal(published.nodes[0].choices[0].next, 'explain');
  assert.ok(Object.isFrozen(published.nodes[0].choices));
  assert.throws(() => {
    published.nodes[0].choices[0].next = 'unknown';
  });
  assert.deepEqual(draft.toInput(), published);
});
test('dialogue graph rejects dangling, unreachable, duplicate and cyclic navigation without implicit fallback', () => {
  for (const mutate of [
    (g) => {
      g.start = 'unknown';
    },
    (g) => {
      g.nodes[0].choices[0].next = 'unknown';
    },
    (g) => {
      g.nodes.push({ id: 'unused', text: 'Unreachable.', choices: [] });
    },
    (g) => {
      g.nodes[2].id = 'greet';
    },
    (g) => {
      g.nodes[1].choices[0].next = 'greet';
    },
    (g) => {
      g.nodes[0].choices[1].id = 'ask';
    },
    (g) => {
      g.nodes[1].choices.push({ id: 'loop', label: 'Again.', next: 'explain' });
    },
  ]) {
    const candidate = graph();
    mutate(candidate);
    assert.equal(isDialogueGraph(candidate), false);
  }
  assert.equal(
    isDialogueGraph({ ...header, start: 'exit', nodes: [nodes[2]] }),
    true,
  );
});
test('dialogue authoring rejects executable extensions and enforces node, choice and text bounds', () => {
  for (const mutate of [
    (g) => {
      g.effects = [];
    },
    (g) => {
      g.nodes[0].condition = {};
    },
    (g) => {
      g.nodes[0].choices[0].effect = {};
    },
    (g) => {
      g.nodes[0].text = ' ';
    },
    (g) => {
      g.nodes[0].text = 'x'.repeat(2001);
    },
    (g) => {
      g.nodes[0].id = 'x'.repeat(81);
    },
    (g) => {
      g.nodes[0].choices[0].label = 'x'.repeat(201);
    },
    (g) => {
      g.nodes[0].choices = Array.from({ length: 5 }, (_, i) => ({
        id: String(i),
        label: 'Exit',
        next: 'exit',
      }));
    },
  ]) {
    const candidate = graph();
    mutate(candidate);
    assert.equal(isDialogueGraph(candidate), false);
  }
  const draft = new DialogueDraft(header);
  draft.addNode(nodes[0]);
  assert.throws(() => draft.addNode(nodes[0]));
  assert.throws(() => new DialogueDraft({ ...header, condition: {} }));
});
function chain(text) {
  return {
    ...header,
    start: 'n0',
    nodes: Array.from({ length: 16 }, (_, i) => ({
      id: 'n' + i,
      text,
      choices:
        i === 15
          ? []
          : [{ id: 'next', label: 'Continue', next: 'n' + (i + 1) }],
    })),
  };
}
test('dialogue authoring applies exact total UTF-8 JSON bound to multilingual maximum content', () => {
  assert.ok(isDialogueGraph(chain('x'.repeat(2000))));
  assert.equal(isDialogueGraph(chain('界'.repeat(2000))), false);
  const candidate = chain('界'.repeat(1200));
  let length = Buffer.byteLength(JSON.stringify(candidate));
  for (const node of candidate.nodes) {
    while (node.text.length < 2000 && length < 65536) {
      node.text += 'x';
      length++;
    }
  }
  assert.equal(Buffer.byteLength(JSON.stringify(candidate)), 65536);
  assert.ok(isDialogueGraph(candidate));
  const node = candidate.nodes.find((n) => n.text.length < 2000);
  node.text += 'x';
  assert.equal(isDialogueGraph(candidate), false);
});
test('dialogue authoring bounds incremental node count and rejects non-JSON graphs', () => {
  const draft = new DialogueDraft({ ...header, start: 'n0' });
  for (const node of chain('Text').nodes) draft.addNode(node);
  assert.ok(isDialogueGraph(draft.toInput()));
  assert.throws(() =>
    draft.addNode({ id: 'overflow', text: 'Text', choices: [] }),
  );
  const candidate = graph();
  candidate.nodes[0].choices[0].next = candidate;
  assert.equal(isDialogueGraph(candidate), false);
  assert.equal(isDialogueGraph(undefined), false);
});

test('dialogue authoring preserves valid Unicode and rejects lone surrogate wire strings', () => {
  const candidate = graph();
  candidate.nodes[0].text = 'Hello 🌲';
  assert.ok(isDialogueGraph(candidate));
  candidate.nodes[0].text = '\ud800';
  assert.equal(isDialogueGraph(candidate), false);
  candidate.nodes[0].text = '\udfff';
  assert.equal(isDialogueGraph(candidate), false);
});

test('dialogue identifier fields reject Unicode controls without trimming valid identifiers or multiline text', () => {
  for (const code of [
    '\n',
    '\r',
    '\t',
    '\u0000',
    '\u007f',
    '\u0085',
    '\u009f',
  ]) {
    for (const mutate of [
      (g) => {
        g.recipientRef = 'player' + code;
      },
      (g) => {
        g.start = 'greet' + code;
        g.nodes[0].id = g.start;
      },
      (g) => {
        g.nodes[0].choices[0].id = 'ask' + code;
      },
      (g) => {
        g.nodes[0].choices[0].next = 'explain' + code;
        g.nodes[1].id = 'explain' + code;
      },
    ]) {
      const candidate = graph();
      mutate(candidate);
      assert.equal(isDialogueGraph(candidate), false);
    }
  }
  const candidate = graph();
  candidate.nodes[0].text = 'Hello.\nMore detail.';
  candidate.nodes[0].choices[0].label = 'Ask\npolitely.';
  assert.ok(isDialogueGraph(candidate));
  assert.throws(() => new DialogueDraft({ ...header, start: '\nintro' }));
});

test('authored graph byte budget includes native PHP line-separator escaping without rewriting short prose', () => {
  const candidate = chain('Hi');
  for (let i = 0; i < 10; i++)
    candidate.nodes[i].text = 'Hi' + '\u2028'.repeat(1998);
  const jsBytes = Buffer.byteLength(JSON.stringify(candidate));
  const nativeBytes = Buffer.byteLength(
    JSON.stringify(candidate)
      .replaceAll('\u2028', '\\u2028')
      .replaceAll('\u2029', '\\u2029'),
  );
  assert.ok(jsBytes <= 65536);
  assert.ok(nativeBytes > 65536);
  assert.equal(isDialogueGraph(candidate), false);
  const short = graph();
  short.nodes[0].text = 'Hello\u2028grove\u2029friend.\nSafe travels.';
  assert.ok(isDialogueGraph(short));
  const draft = new DialogueDraft(header);
  for (const node of short.nodes) draft.addNode(node);
  assert.equal(draft.toInput().nodes[0].text, short.nodes[0].text);
  const paragraph = chain('Hi');
  for (let i = 0; i < 10; i++)
    paragraph.nodes[i].text = 'Hi' + '\u2029'.repeat(1998);
  assert.equal(isDialogueGraph(paragraph), false);
});
