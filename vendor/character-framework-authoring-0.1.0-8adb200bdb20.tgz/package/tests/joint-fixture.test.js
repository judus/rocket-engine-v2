import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { setImmediate } from 'node:timers/promises';
import { createJointFixture } from '../dist/examples/joint-fixture.js';
import { FakeCaiClient } from '../examples/fake-cai-client.js';

const authority = '127.0.0.1:8096';
const credential = 'disposable-fixture-test';
async function pump(fixture, promise) {
  let settled = false;
  let result;
  let failure;
  void promise.then(
    (value) => {
      result = value;
      settled = true;
    },
    (error) => {
      failure = error;
      settled = true;
    },
  );
  for (let i = 0; i < 200 && !settled; i++) {
    fixture.advance();
    await setImmediate();
  }
  assert.ok(settled, 'host operation settled');
  if (failure) throw failure;
  return result;
}
function control(fixture, path, input, key = credential) {
  return fixture.handle(
    new Request(`http://${authority}/fixture/${path}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}` },
      body: JSON.stringify(input),
    }),
  );
}
test('joint fixture authenticates and binds one real numeric CAI identity', async (t) => {
  const fixture = createJointFixture(credential, [authority]);
  t.after(() => fixture.dispose());
  assert.equal(
    (await control(fixture, 'bind', { sessionId: 12, characterId: 3 }, 'wrong'))
      .status,
    403,
  );
  const first = await (
    await control(fixture, 'bind', { sessionId: 12, characterId: 3 })
  ).json();
  const replay = await (
    await control(fixture, 'bind', { sessionId: 12, characterId: 3 })
  ).json();
  assert.deepEqual(first.headers, replay.headers);
  assert.equal(
    (await control(fixture, 'bind', { sessionId: 13, characterId: 3 })).status,
    409,
  );
});
test('actual MCP fixture loses committed create reply, replays one effect and completes via host fact', async (t) => {
  const fixture = createJointFixture(credential, [authority]);
  t.after(() => fixture.dispose());
  const bound = await (
    await control(fixture, 'bind', { sessionId: 12, characterId: 3 })
  ).json();
  const client = new FakeCaiClient(
    new URL(`http://${authority}/mcp`),
    bound.headers,
    credential,
    (target, init) => fixture.handle(new Request(target, init)),
  );
  await client.connect();
  t.after(() => client.close());
  const discovered = await client.client.listTools();
  assert.ok(discovered.tools.some((tool) => tool.name === 'create_quest'));
  assert.ok(discovered.tools.every((tool) => !tool.name.startsWith('fixture')));
  const identity = () => ({
    callId: randomUUID(),
    turnId: randomUUID(),
    effectKey: randomUUID(),
  });
  const inspected = await pump(
    fixture,
    client.call('inspect_context', { scope: 'local' }, identity()),
  );
  assert.equal(inspected.structuredContent.status, 'completed');
  await control(fixture, 'drop-create', {});
  const createIdentity = identity();
  await assert.rejects(
    pump(
      fixture,
      client.call('create_quest', bound.definition, createIdentity),
    ),
    (error) => error.code === 503,
  );
  assert.equal(fixture.state().quests.length, 1);
  assert.equal(fixture.state().droppedCreates, 1);
  const created = await pump(
    fixture,
    client.call('create_quest', bound.definition, createIdentity),
  );
  const questId = created.structuredContent.data.questId;
  assert.equal(fixture.state().quests.length, 1);
  assert.equal(fixture.state().quests[0].questId, questId);
  const offered = await pump(
    fixture,
    client.call(
      'offer_quest',
      {
        questId,
        recipientRef: 'player-1',
        dialogue: 'Please survey the grove.',
      },
      identity(),
    ),
  );
  assert.equal(offered.structuredContent.status, 'completed');
  const accepted = await pump(
    fixture,
    control(fixture, 'accept', { effectKey: randomUUID() }),
  );
  assert.equal(accepted.status, 200);
  assert.equal(fixture.state().quests[0].status, 'active');
  assert.equal((await control(fixture, 'complete', {})).status, 200);
  for (let i = 0; i < 20; i++) {
    fixture.advance();
    await setImmediate();
  }
  assert.equal(fixture.state().quests[0].status, 'completed');
  assert.ok(
    fixture.state().events.some((event) => event.type === 'quest_completed'),
  );
});

test('joint policy fixture selects redemption and retains policy evidence until host acknowledgment', async (t) => {
  const fixture = createJointFixture(credential, [authority]);
  t.after(() => fixture.dispose());
  const bound = await (
    await control(fixture, 'bind', { sessionId: 12, characterId: 3 })
  ).json();
  const client = new FakeCaiClient(
    new URL(`http://${authority}/mcp`),
    bound.headers,
    credential,
    (target, init) => fixture.handle(new Request(target, init)),
  );
  await client.connect();
  t.after(() => client.close());
  const identity = () => ({
    callId: randomUUID(),
    turnId: randomUUID(),
    effectKey: randomUUID(),
  });
  const call = (name, input) =>
    pump(fixture, client.call(name, input, identity()));
  const ordinary = (await call('create_quest', bound.definition))
    .structuredContent.data.questId;
  const redemption = (await call('create_quest', bound.definition))
    .structuredContent.data.questId;
  assert.equal(
    (
      await call('set_offering_access', {
        recipientRef: 'player-1',
        expectedRevision: 0,
        mode: 'restricted',
        allowedQuestIds: [redemption],
      })
    ).structuredContent.status,
    'completed',
  );
  const offer = (questId) =>
    call('offer_quest', {
      questId,
      recipientRef: 'player-1',
      dialogue: 'Survey the grove.',
    });
  assert.equal((await offer(ordinary)).structuredContent.status, 'rejected');
  assert.equal((await offer(redemption)).structuredContent.status, 'completed');
  assert.equal(
    (await control(fixture, 'accept', { effectKey: randomUUID() })).status,
    409,
  );
  assert.equal(
    (
      await control(fixture, 'accept', {
        questId: ordinary,
        effectKey: randomUUID(),
      })
    ).status,
    409,
  );
  assert.equal(
    (
      await pump(
        fixture,
        control(fixture, 'accept', {
          questId: redemption,
          effectKey: randomUUID(),
        }),
      )
    ).status,
    200,
  );
  assert.equal((await control(fixture, 'complete', {})).status, 409);
  assert.equal(
    (await control(fixture, 'complete', { questId: ordinary })).status,
    409,
  );
  assert.equal(
    (await control(fixture, 'complete', { questId: redemption })).status,
    200,
  );
  for (let i = 0; i < 20; i++) {
    fixture.advance();
    await setImmediate();
  }
  assert.equal(
    fixture.state().quests.find((q) => q.questId === redemption).status,
    'completed',
  );
  assert.equal(fixture.state().offeringPolicies[0].mode, 'restricted');
  const source = fixture.state().offeringEvents[0];
  assert.equal(
    source.bindingGeneration,
    bound.headers['X-CF-Binding-Generation'],
  );
  assert.equal(
    (await control(fixture, 'ack-offering', { sourceId: source.id }, 'wrong'))
      .status,
    403,
  );
  assert.equal(fixture.state().offeringEvents.length, 1);
  const transferred = JSON.parse(JSON.stringify(source));
  assert.equal(
    (await control(fixture, 'ack-offering', { sourceId: transferred.id }))
      .status,
    200,
  );
  assert.equal(
    (await control(fixture, 'ack-offering', { sourceId: transferred.id }))
      .status,
    200,
  );
  assert.equal(fixture.state().offeringEvents.length, 0);
  assert.equal(
    (
      await call('set_offering_access', {
        recipientRef: 'player-1',
        expectedRevision: 1,
        mode: 'open',
        allowedQuestIds: [],
      })
    ).structuredContent.status,
    'completed',
  );
  assert.equal((await offer(ordinary)).structuredContent.status, 'completed');
  assert.equal(fixture.state().offeringEvents[0].revision, 2);
  assert.ok(
    (await client.client.listTools()).tools.every(
      (tool) => !tool.name.startsWith('fixture'),
    ),
  );
});

async function offeringRunnerHarness(t, failTransfer = false) {
  const fixture = createJointFixture(credential, [authority]);
  t.after(() => fixture.dispose());
  const bound = await (
    await control(fixture, 'bind', { sessionId: 12, characterId: 3 })
  ).json();
  const client = new FakeCaiClient(
    new URL(`http://${authority}/mcp`),
    bound.headers,
    credential,
    (target, init) => fixture.handle(new Request(target, init)),
  );
  await client.connect();
  t.after(() => client.close());
  const call = (name, input) =>
    pump(
      fixture,
      client.call(name, input, {
        callId: randomUUID(),
        turnId: randomUUID(),
        effectKey: randomUUID(),
      }),
    );
  let ordinary,
    redemption,
    revision = 0;
  const phases = [],
    feedback = [],
    messages = [];
  const port = {
    read: () => ({ revision, messages }),
    async dispatch(command) {
      assert.equal(command.expectedRevision, revision);
      phases.push(command.message);
      if (command.message === 'offering-proof:author') {
        ordinary = (
          await call('create_quest', {
            quest: { ...bound.definition.quest, title: 'Ordinary survey' },
          })
        ).structuredContent.data.questId;
        redemption = (
          await call('create_quest', {
            quest: { ...bound.definition.quest, title: 'Redemption survey' },
          })
        ).structuredContent.data.questId;
      } else if (command.message === 'offering-proof:restrict') {
        await call('set_offering_access', {
          recipientRef: 'player-1',
          expectedRevision: 0,
          mode: 'restricted',
          allowedQuestIds: [redemption],
        });
        assert.equal(
          (
            await call('offer_quest', {
              questId: ordinary,
              recipientRef: 'player-1',
              dialogue: 'Work?',
            })
          ).structuredContent.status,
          'rejected',
        );
        await call('offer_quest', {
          questId: redemption,
          recipientRef: 'player-1',
          dialogue: 'Make amends.',
        });
      } else if (command.message === 'offering-proof:restore') {
        await call('set_offering_access', {
          recipientRef: 'player-1',
          expectedRevision: 1,
          mode: 'open',
          allowedQuestIds: [],
        });
        await call('offer_quest', {
          questId: ordinary,
          recipientRef: 'player-1',
          dialogue: 'Work?',
        });
      } else assert.equal(command.message, 'offering-proof:confirm');
      revision++;
      messages.push(command.message);
    },
  };
  const driver = {
    async persistFeedback(value) {
      if (value.type === 'offering_access_changed') {
        assert.ok(
          fixture
            .state()
            .offeringEvents.some((source) => source.id === value.sourceId),
        );
        if (failTransfer) throw new Error('checkpoint unavailable');
      }
      feedback.push(JSON.parse(JSON.stringify(value)));
    },
  };
  const { runOfferingHttpLifecycle } =
    await import('../dist/examples/offering-http-lifecycle.js');
  const run = () =>
    runOfferingHttpLifecycle({
      port,
      driver,
      generation: bound.headers['X-CF-Binding-Generation'],
      stage: () => undefined,
      control: async (operation, input) => {
        if (operation === 'state') {
          fixture.advance();
          await setImmediate();
          return fixture.state();
        }
        const response = await pump(
          fixture,
          control(fixture, operation, input),
        );
        assert.equal(response.status, 200);
        return response.json();
      },
    });
  return { run, fixture, phases, feedback };
}
test('HTTP policy runner choreography consumes generated MCP identities and transfers sources between turns', async (t) => {
  const harness = await offeringRunnerHarness(t);
  const result = await harness.run();
  assert.equal(result.policyRevision, 2);
  assert.equal(result.policySources, 2);
  assert.deepEqual(harness.phases, [
    'offering-proof:author',
    'offering-proof:restrict',
    'offering-proof:restore',
    'offering-proof:confirm',
  ]);
  assert.deepEqual(
    harness.feedback.map((event) => event.type),
    ['offering_access_changed', 'quest_completed', 'offering_access_changed'],
  );
  assert.deepEqual(harness.fixture.state().offeringEvents, []);
});
test('HTTP policy runner keeps restriction source and stops before player acceptance when transfer storage fails', async (t) => {
  const harness = await offeringRunnerHarness(t, true);
  await assert.rejects(harness.run(), /checkpoint unavailable/);
  assert.equal(harness.fixture.state().offeringEvents.length, 1);
  assert.equal(
    harness.fixture.state().quests.find((q) => q.status === 'offered')?.status,
    'offered',
  );
  assert.equal(harness.phases.length, 2);
  assert.deepEqual(harness.feedback, []);
});

async function dialogueRunnerHarness(t, failTransfer = false) {
  const fixture = createJointFixture(credential, [authority]);
  t.after(() => fixture.dispose());
  const bound = await (
    await control(fixture, 'bind', { sessionId: 12, characterId: 3 })
  ).json();
  const client = new FakeCaiClient(
    new URL(`http://${authority}/mcp`),
    bound.headers,
    credential,
    (target, init) => fixture.handle(new Request(target, init)),
  );
  await client.connect();
  t.after(() => client.close());
  const { CaiHostDriver, CharacterHostPort } =
    await import('../dist/src/host/index.js');
  const { createDialogueHttpHost, runDialogueHttpLifecycle } =
    await import('../dist/examples/dialogue-http-lifecycle.js');
  const hostControl = async (operation, input) => {
    if (operation === 'state') return fixture.state();
    if (operation === 'ack-dialogue') {
      assert.equal(
        (await control(fixture, operation, input, 'wrong')).status,
        403,
      );
      assert.equal(fixture.state().dialogueEvents.length, 1);
    }
    const response = await pump(fixture, control(fixture, operation, input));
    assert.equal(response.status, 200);
    return response.json();
  };
  assert.equal(
    (
      await control(
        fixture,
        'graph-choose',
        { choiceId: 'foreign', effectKey: 'foreign' },
        'wrong',
      )
    ).status,
    403,
  );
  const host = createDialogueHttpHost(hostControl),
    turns = [],
    events = [],
    stored = [];
  const session = {
    id: '12',
    characterId: '3',
    bindingKey: 'forester/workforce-17',
    version: 0,
    mode: 'game',
    continuityMode: 'session',
    bindingGeneration: bound.headers['X-CF-Binding-Generation'],
  };
  const backend = {
    attach: async () => session,
    event: async (_, input) => {
      events.push(structuredClone(input));
      return { eventId: input.event_id, version: input.version + 1 };
    },
    turn: async (_, input) => {
      turns.push(structuredClone(input));
      const call = (tool, args) =>
        pump(
          fixture,
          client.call(tool, args, {
            callId: randomUUID(),
            turnId: input.request_id,
            effectKey: input.request_id + '/' + tool,
          }),
        );
      if (input.message === 'dialogue-proof:author') {
        const graph = (
          await call(
            'create_dialogue_graph',
            fixture.state().dialogueDefinition,
          )
        ).structuredContent.data;
        assert.equal(
          (await call('start_dialogue_graph', { graphId: graph.graphId }))
            .structuredContent.status,
          'completed',
        );
      } else if (input.message === 'dialogue-proof:inspect') {
        const view = fixture.state().dialogueViews[0];
        assert.equal(view.nodeId, 'explain');
        assert.equal(
          (
            await call('inspect_dialogue_graph', {
              instanceId: view.instanceId,
            })
          ).structuredContent.data.nodeId,
          'explain',
        );
      } else assert.equal(input.message, 'dialogue-proof:confirm');
      return {
        requestId: input.request_id,
        message: 'Committed graph reply.',
        session: { ...session, version: input.version + 1 },
      };
    },
  };
  const driver = new CaiHostDriver({
    backend,
    saved: {
      schemaVersion: 1,
      conversation: {
        schemaVersion: 1,
        session,
        pending: null,
        feedback: [],
        reported: [],
      },
      operations: [],
    },
    current: () => undefined,
    choices: () => host.choices(),
    choose: (id, effect) => host.choose(id, effect),
    persist: (saved) => {
      if (failTransfer && saved.conversation.feedback.length)
        throw new Error('source checkpoint failed');
      stored.push(structuredClone(saved));
    },
  });
  t.after(() => driver.dispose());
  const port = new CharacterHostPort(driver, () => undefined);
  t.after(() => port.dispose());
  return {
    fixture,
    host,
    turns,
    events,
    stored,
    run: () =>
      runDialogueHttpLifecycle({
        control: hostControl,
        driver,
        port,
        host,
        generation: session.bindingGeneration,
        stage: () => undefined,
      }),
  };
}
test('dialogue proof uses actual CaiHostDriver player callbacks with real scoped MCP and exact idle source transfer', async (t) => {
  const h = await dialogueRunnerHarness(t);
  const result = await h.run();
  assert.equal(result.closed, true);
  assert.equal(result.hostChoiceCallbacks, 2);
  assert.equal(result.hostChoiceReplay, true);
  assert.equal(result.quests, 0);
  assert.equal(h.turns.length, 3);
  assert.equal(h.events.length, 3);
  assert.deepEqual(
    h.events.map((event) => event.references.source_event_id),
    result.sourceIds,
  );
  assert.deepEqual(
    h.events.map((event) => event.type),
    ['dialogue_started', 'dialogue_selected', 'dialogue_closed'],
  );
  assert.equal(h.stored.at(-1).conversation.session.version, 6);
  assert.equal(h.stored.at(-1).conversation.pending, null);
  assert.equal(
    h.stored.at(-1).operations.filter((op) => op.intent.kind === 'choice')
      .length,
    2,
  );
  assert.deepEqual(h.fixture.state().dialogueEvents, []);
});
test('dialogue proof failed source storage preserves source and stops before player selection', async (t) => {
  const h = await dialogueRunnerHarness(t, true);
  await assert.rejects(h.run(), /source checkpoint failed/);
  assert.equal(h.turns.length, 1);
  assert.equal(h.events.length, 0);
  assert.equal(h.host.choiceCalls(), 0);
  assert.equal(h.fixture.state().dialogueEvents.length, 1);
  assert.equal(h.fixture.state().dialogueViews[0].revision, 0);
});
