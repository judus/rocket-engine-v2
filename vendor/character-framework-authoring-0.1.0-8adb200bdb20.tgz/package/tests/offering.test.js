import test from 'node:test';
import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { CharacterRuntime } from '../dist/src/index.js';
import { createNarrativeScenario } from '../dist/examples/narrative-scenario.js';
function fixture(t) {
  const f = createNarrativeScenario();
  t.after(() => f.dispose());
  return f;
}
async function commit(f, promise) {
  f.advance(0);
  return promise;
}
const completed = (result) => {
  assert.equal(result.status, 'completed', JSON.stringify(result));
  return result.data;
};
const call = (f, tool, input, key, handle = f.foresterNarrative) =>
  commit(f, handle.call(tool, input, key));
async function create(f, key, handle = f.foresterNarrative) {
  return completed(
    await call(
      f,
      'create_quest',
      f.draft(key, 'grove-1').toInput(),
      key,
      handle,
    ),
  ).questId;
}
const offer = (f, questId, key) =>
  call(
    f,
    'offer_quest',
    { questId, recipientRef: 'player-1', dialogue: 'Visit the grove.' },
    key,
  );
const policy = (revision, mode = 'restricted', ids = []) => ({
  recipientRef: 'player-1',
  expectedRevision: revision,
  mode,
  allowedQuestIds: ids,
});

test('offering refusal permits explicit redemption, preserves outstanding work, and requires explicit restoration', async (t) => {
  const f = fixture(t);
  const existing = await create(f, 'existing');
  const ordinary = await create(f, 'ordinary');
  const redemption = await create(f, 'redemption');
  const outstanding = completed(await offer(f, existing, 'offer-existing'));
  const restricted = completed(
    await call(
      f,
      'set_offering_access',
      policy(0, 'restricted', [redemption]),
      'restrict',
    ),
  );
  assert.equal(restricted.revision, 1);
  assert.equal(restricted.mode, 'restricted');
  const denial = await offer(f, ordinary, 'denied');
  assert.equal(denial.code, 'offering_restricted');
  await create(f, 'create-while-restricted');
  const redeemed = completed(await offer(f, redemption, 'redemption-offer'));
  completed(
    await commit(
      f,
      f.narrative.choose(
        'player-1',
        outstanding.choices[0].id,
        'accept-existing',
      ),
    ),
  );
  completed(
    await commit(
      f,
      f.narrative.choose(
        'player-1',
        redeemed.choices[0].id,
        'accept-redemption',
      ),
    ),
  );
  f.visit('grove-1');
  for (let i = 0; i < 4; i++) {
    f.advance(0);
    await setImmediate();
  }
  assert.equal(
    completed(
      await call(f, 'inspect_quest', {
        questId: redemption,
        recipientRef: 'player-1',
      }),
    ).status,
    'completed',
  );
  assert.equal(
    completed(
      await call(f, 'inspect_offering_access', { recipientRef: 'player-1' }),
    ).mode,
    'restricted',
  );
  const open = completed(
    await call(f, 'set_offering_access', policy(1, 'open'), 'restore-access'),
  );
  assert.equal(open.revision, 2);
  assert.deepEqual(
    await offer(f, ordinary, 'denied'),
    denial,
    'known rejection replay does not become a new effect',
  );
  completed(await offer(f, ordinary, 'fresh-offer'));
  assert.equal(f.narrative.offeringEvents().length, 2);
  assert.equal(Object.isFrozen(f.narrative.offeringEvents()[0]), true);
});

test('offering policy CAS, owner exceptions, replay and checkpoint source evidence remain coherent', async (t) => {
  const f = fixture(t);
  const own = await create(f, 'own');
  const foreign = await create(f, 'foreign', f.directorNarrative);
  assert.equal(
    (
      await call(
        f,
        'set_offering_access',
        policy(0, 'restricted', [foreign]),
        'foreign-exception',
      )
    ).code,
    'invalid_offering_exception',
  );
  const first = completed(
    await call(
      f,
      'set_offering_access',
      policy(0, 'restricted', [own]),
      'first',
    ),
  );
  assert.equal(
    (await call(f, 'set_offering_access', policy(0), 'stale')).code,
    'stale_policy_revision',
  );
  assert.equal(
    (await call(f, 'set_offering_access', policy(1, 'open'), 'first')).code,
    'effect_key_conflict',
  );
  completed(await call(f, 'set_offering_access', policy(1, 'open'), 'second'));
  const save = JSON.parse(JSON.stringify(f.narrative.save()));
  f.narrative.restore(save);
  assert.deepEqual(
    completed(
      await call(
        f,
        'set_offering_access',
        policy(0, 'restricted', [own]),
        'first',
      ),
    ),
    first,
  );
  assert.equal(
    f.narrative.offeringEvents().length,
    2,
    'replay does not allocate source again',
  );
  const source = f.narrative.offeringEvents()[0];
  f.narrative.acknowledgeOfferingEvent(source.id);
  assert.equal(f.narrative.offeringEvents().length, 1);
  f.narrative.restore(JSON.parse(JSON.stringify(f.narrative.save())));
  const bad = structuredClone(save);
  bad.offeringPolicies[0].revision++;
  assert.throws(() => f.narrative.restore(bad), /checkpoint/);
  const forgedSource = structuredClone(save);
  forgedSource.offeringEvents[0].mode = 'open';
  assert.throws(() => f.narrative.restore(forgedSource), /checkpoint/);
  const crossed = structuredClone(save);
  crossed.offeringPolicies[0].allowedQuestIds = [foreign];
  assert.throws(() => f.narrative.restore(crossed), /checkpoint/);
});

test('legacy checkpoints default to open and source capacity blocks changes without dropping evidence', async (t) => {
  const f = fixture(t);
  const legacy = JSON.parse(JSON.stringify(f.narrative.save()));
  delete legacy.offeringPolicies;
  delete legacy.offeringEvents;
  f.narrative.restore(legacy);
  assert.equal(
    completed(
      await call(f, 'inspect_offering_access', { recipientRef: 'player-1' }),
    ).revision,
    0,
  );
  for (let i = 0; i < 256; i++)
    completed(await call(f, 'set_offering_access', policy(i), 'set-' + i));
  const full = await call(
    f,
    'set_offering_access',
    policy(256, 'open'),
    'full',
  );
  assert.equal(full.code, 'capacity_exceeded');
  assert.equal(f.narrative.offeringEvents().length, 256);
  assert.equal(
    completed(
      await call(f, 'inspect_offering_access', { recipientRef: 'player-1' }),
    ).revision,
    256,
  );
  f.narrative.acknowledgeOfferingEvent(f.narrative.offeringEvents()[0].id);
  completed(
    await call(f, 'set_offering_access', policy(256, 'open'), 'after-handoff'),
  );
  assert.equal(f.narrative.offeringEvents().length, 256);
  f.narrative.restore(JSON.parse(JSON.stringify(f.narrative.save())));
});

test('restriction leaves active flow branch choices valid and validates exceptions/inputs atomically', async (t) => {
  const f = fixture(t);
  const input = structuredClone(f.draft('Branching', 'grove-1').toInput());
  input.quest.objectives.push({
    ...structuredClone(input.quest.objectives[0]),
    id: 'follow-up',
  });
  input.quest.flow = {
    start: 'first',
    stages: [
      {
        id: 'first',
        objectives: ['visit'],
        choices: [{ id: 'continue', label: 'Continue', next: 'last' }],
      },
      { id: 'last', objectives: ['follow-up'] },
    ],
  };
  const id = completed(await call(f, 'create_quest', input, 'flow')).questId;
  const offered = completed(await offer(f, id, 'flow-offer'));
  completed(
    await commit(
      f,
      f.narrative.choose('player-1', offered.choices[0].id, 'accept'),
    ),
  );
  completed(await call(f, 'set_offering_access', policy(0), 'restrict'));
  f.visit('grove-1');
  for (let i = 0; i < 4; i++) {
    f.advance(0);
    await setImmediate();
  }
  const current = completed(
    await call(f, 'inspect_quest', { questId: id, recipientRef: 'player-1' }),
  );
  assert.ok(current.choices.length > 0);
  completed(
    await commit(
      f,
      f.narrative.choose('player-1', current.choices[0].id, 'branch'),
    ),
  );
  for (const invalid of [
    policy(1, 'open', [id]),
    policy(1, 'restricted', [id, id]),
    { ...policy(1), expectedRevision: -1 },
    { ...policy(1), characterRef: 'director' },
  ]) {
    assert.equal(
      (await call(f, 'set_offering_access', invalid, JSON.stringify(invalid)))
        .code,
      'invalid_arguments',
    );
  }
  assert.equal(
    completed(
      await call(f, 'inspect_offering_access', { recipientRef: 'player-1' }),
    ).revision,
    1,
  );
});

test('offering map capacity is bounded independently of acknowledged source queue', async (t) => {
  const runtime = new CharacterRuntime({
    gameId: 'policy-map',
    reasoning: { decide: () => ({ dialogue: '' }) },
    narrativeGame: {
      capabilities: () => [],
      recipientAvailable: () => true,
      referencesAvailable: () => true,
      inspectContext: () => ({ status: 'completed', data: {} }),
    },
  });
  t.after(() => runtime.dispose());
  const actor = runtime.register({
    id: 'actor',
    name: 'Actor',
    capabilities: [],
  });
  const narrative = runtime.narrative;
  const handle = narrative.bind(actor);
  for (let i = 0; i < 256; i++) {
    const request = handle.call(
      'set_offering_access',
      { ...policy(0), recipientRef: 'player-' + i },
      'policy-' + i,
    );
    runtime.advance(0);
    completed(await request);
    narrative.acknowledgeOfferingEvent(narrative.offeringEvents()[0].id);
  }
  const overflow = handle.call(
    'set_offering_access',
    { ...policy(0), recipientRef: 'overflow' },
    'overflow',
  );
  runtime.advance(0);
  assert.equal((await overflow).code, 'capacity_exceeded');
  assert.equal(narrative.save().offeringPolicies.length, 256);
  assert.equal(narrative.offeringEvents().length, 0);
  narrative.restore(JSON.parse(JSON.stringify(narrative.save())));
});

test('offering source retains original generation through explicit identity rebind and rejects old handle', async (t) => {
  const f = fixture(t);
  const prior = f.forester.snapshot();
  completed(await call(f, 'set_offering_access', policy(0), 'restrict'));
  const source = f.narrative.offeringEvents()[0];
  assert.equal(source.bindingGeneration, prior.binding.generation);
  f.forester.unregister();
  const replacement = f.runtime.register(prior);
  const handle = f.narrative.bind(replacement);
  assert.notEqual(
    replacement.snapshot().binding.generation,
    source.bindingGeneration,
  );
  assert.equal(
    (await call(f, 'set_offering_access', policy(1, 'open'), 'old-handle'))
      .code,
    'unregistered',
  );
  assert.equal(
    completed(
      await call(
        f,
        'inspect_offering_access',
        { recipientRef: 'player-1' },
        undefined,
        handle,
      ),
    ).revision,
    1,
  );
  f.narrative.restore(JSON.parse(JSON.stringify(f.narrative.save())));
  assert.equal(
    f.narrative.offeringEvents()[0].bindingGeneration,
    prior.binding.generation,
  );
});

test('restore rejects source generation reassignment and requires committed receipt provenance', async (t) => {
  const f = fixture(t);
  completed(await call(f, 'set_offering_access', policy(0), 'restriction'));
  const saved = structuredClone(f.narrative.save());
  const prior = f.forester.snapshot();
  f.forester.unregister();
  const replacement = f.runtime.register(prior);
  const generation = replacement.snapshot().binding.generation;
  f.narrative.restore(saved);
  const sourceChanged = structuredClone(saved);
  sourceChanged.offeringEvents[0].bindingGeneration = generation;
  assert.throws(() => f.narrative.restore(sourceChanged), /checkpoint/);
  const receipt = saved.receipts.find(
    (receipt) => JSON.parse(receipt.key)[1] === 'set_offering_access',
  );
  assert.equal(receipt.bindingGeneration, prior.binding.generation);
  const missing = structuredClone(saved);
  delete missing.receipts.find(
    (receipt) => JSON.parse(receipt.key)[1] === 'set_offering_access',
  ).bindingGeneration;
  assert.throws(() => f.narrative.restore(missing), /checkpoint/);
  const receiptChanged = structuredClone(saved);
  receiptChanged.receipts.find(
    (receipt) => JSON.parse(receipt.key)[1] === 'set_offering_access',
  ).bindingGeneration = generation;
  assert.throws(() => f.narrative.restore(receiptChanged), /checkpoint/);
  f.narrative.restore(saved);
  assert.equal(
    f.narrative.offeringEvents()[0].bindingGeneration,
    prior.binding.generation,
  );
  const handle = f.narrative.bind(replacement);
  completed(
    await call(
      f,
      'set_offering_access',
      policy(1, 'open'),
      'replacement-change',
      handle,
    ),
  );
  const changed = JSON.parse(JSON.stringify(f.narrative.save()));
  f.narrative.restore(changed);
  assert.equal(
    f.narrative.offeringEvents()[0].bindingGeneration,
    prior.binding.generation,
  );
  assert.equal(f.narrative.offeringEvents()[1].bindingGeneration, generation);
  const original = await call(
    f,
    'set_offering_access',
    policy(0),
    'restriction',
    handle,
  );
  assert.equal(original.status, 'completed');
  assert.equal(original.data.revision, 1);
  assert.equal(
    f.narrative.offeringEvents()[0].bindingGeneration,
    prior.binding.generation,
  );
});
