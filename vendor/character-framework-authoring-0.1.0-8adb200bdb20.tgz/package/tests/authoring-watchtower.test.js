import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { QuestAuthoringPrototype } from '../dist/src/authoring/index.js';

const example = JSON.parse(
  await readFile(
    new URL(
      '../docs/contracts/watchtower-authoring-example.json',
      import.meta.url,
    ),
    'utf8',
  ),
);

test('model guide fits CAI guide budget and embeds the exact tested complete graph', async () => {
  const guide = await readFile(
    new URL('../docs/QUEST-AUTHORING-WATCHTOWER-GUIDE.md', import.meta.url),
    'utf8',
  );
  assert.ok(
    [...guide].length <= 16000,
    'external guide maximum is16000 codepoints',
  );
  const section = guide.split('## Complete implementation value')[1];
  const embedded = section.match(/```json\n([\s\S]*?)\n```/)[1];
  assert.deepEqual(JSON.parse(embedded), example.implementation);
});

async function fixture(t) {
  const dir = await mkdtemp(join(tmpdir(), 'cfw-watchtower-authoring-'));
  const author = new QuestAuthoringPrototype({
    path: join(dir, 'draft.sqlite'),
    authorId: 'watchtower-example',
    authorize: () => true,
    capabilities: example.capabilities.map((c) => ({
      ...c,
      validate: () => true,
      execute: () => {
        throw new Error('Authoring must not execute gameplay');
      },
    })),
    references: example.references,
    referenceBindings: Object.fromEntries(
      example.capabilities.map((c) => [c.name, c.referenceBindings]),
    ),
  });
  t.after(async () => {
    author.close();
    await rm(dir, { recursive: true });
  });
  let command = 0;
  const call = async (name, args) => {
    const tool = author.tools.find((x) => x.name === name);
    assert.ok(tool);
    return tool.execute({ mutation: { id: `watchtower-${++command}` } }, args);
  };
  const created = await call('create_quest_draft', {
    intent: { title: 'Recover either watchtower seal' },
  });
  assert.equal(created.status, 'completed');
  return { author, call, draftId: created.data.draftId };
}

const edit = (draftId, revision, implementation) => ({
  draftId,
  expectedRecordRevision: revision,
  operations: [
    { kind: 'replace_beat_implementation', beatId: 'main', implementation },
  ],
});

test('worked watchtower graph publishes exact guarded branches and matching-delivery facts without executing game actions', async (t) => {
  const { author, call, draftId } = await fixture(t);
  const saved = await call(
    'edit_quest_draft',
    edit(draftId, 1, example.implementation),
  );
  assert.equal(saved.status, 'completed');
  assert.equal(saved.data.assessment.technicalReady, true);
  const read = await call('read_quest_draft', { section: 'beat', draftId });
  assert.deepEqual(read.data.implementation, example.implementation);
  const published = await call('publish_quest_draft', {
    draftId,
    expectedRecordRevision: saved.data.recordRevision,
  });
  assert.equal(published.status, 'completed');
  const definition = author.readPublishedDefinition(
    published.data.definitionId,
  );
  assert.deepEqual(definition.situations, example.implementation.situations);
  for (const color of ['blue', 'red']) {
    const condition = definition.situations.find(
      (s) => s.id === `${color}-delivery`,
    ).routes[0].when;
    assert.deepEqual(condition.evidence, { mode: 'fact' });
    assert.deepEqual(condition.expect, {
      path: ['delivered'],
      operator: 'equals',
      value: true,
    });
    const pickup = definition.situations.find(
      (s) => s.id === `${color}-pickup`,
    );
    assert.equal(pickup.routes[0].when.evidence.mode, 'events');
  }
});

test('worked watchtower authoring blocks invented references, then repairs through the current revision', async (t) => {
  const { call, draftId } = await fixture(t);
  const broken = structuredClone(example.implementation);
  broken.situations.find(
    (s) => s.id === 'blue-delivery',
  ).routes[0].when.arguments.destinationRef = 'invented-beacon';
  const saved = await call('edit_quest_draft', edit(draftId, 1, broken));
  assert.equal(saved.status, 'completed');
  assert.equal(saved.data.assessment.technicalReady, false);
  assert.ok(
    saved.data.assessment.findings.some((x) =>
      /reference is not permitted/.test(x.message),
    ),
  );
  const blocked = await call('publish_quest_draft', {
    draftId,
    expectedRecordRevision: saved.data.recordRevision,
  });
  assert.equal(blocked.status, 'rejected');
  const repaired = await call(
    'edit_quest_draft',
    edit(draftId, saved.data.recordRevision, example.implementation),
  );
  assert.equal(repaired.data.assessment.technicalReady, true);
  const published = await call('publish_quest_draft', {
    draftId,
    expectedRecordRevision: repaired.data.recordRevision,
  });
  assert.equal(published.status, 'completed');
});
