import test from 'node:test';
import assert from 'node:assert/strict';
import { createNarrativeScenario } from '../dist/examples/narrative-scenario.js';
const definition = {
  recipientRef: 'player-1',
  title: 'Greeting',
  start: 'greet',
  nodes: [
    {
      id: 'greet',
      text: 'Hello.',
      choices: [
        { id: 'ask', label: 'Explain.', next: 'explain' },
        { id: 'leave', label: 'Goodbye.', next: 'exit' },
      ],
    },
    {
      id: 'explain',
      text: 'A peaceful grove.',
      choices: [{ id: 'leave', label: 'Goodbye.', next: 'exit' }],
    },
    { id: 'exit', text: 'Safe travels.', choices: [] },
  ],
};
const terminal = { ...definition, start: 'exit', nodes: [definition.nodes[2]] };
function fixture(t) {
  const f = createNarrativeScenario();
  t.after(() => f.dispose());
  return f;
}
async function call(f, name, input, effect, handle = f.foresterNarrative) {
  const pending = handle.call(name, input, effect);
  f.advance(0);
  return pending;
}
async function choose(f, id, effect, recipient = 'player-1') {
  const pending = f.narrative.choose(recipient, id, effect);
  f.advance(0);
  return pending;
}
function data(result) {
  assert.equal(result.status, 'completed', JSON.stringify(result));
  return result.data;
}
const checkpoint = (f) => JSON.parse(JSON.stringify(f.narrative.save()));
test('shared graph lifecycle keeps quest/game state separate and replays exact player transitions after closure and restart', async (t) => {
  const f = fixture(t);
  const graph = data(
    await call(f, 'create_dialogue_graph', definition, 'author'),
  );
  const start = data(
    await call(f, 'start_dialogue_graph', { graphId: graph.graphId }, 'start'),
  );
  assert.equal(start.revision, 0);
  assert.equal(start.closed, false);
  assert.ok(start.choices.every((c) => c.id.length <= 160));
  assert.equal(
    (await call(f, 'start_dialogue_graph', { graphId: graph.graphId }, 'busy'))
      .code,
    'dialogue_busy',
  );
  assert.equal(
    (await choose(f, start.choices[0].id, 'foreign', 'other-player')).code,
    'choice_unavailable',
  );
  const selected = data(await choose(f, start.choices[0].id, 'selected'));
  assert.equal(selected.nodeId, 'explain');
  assert.equal(selected.revision, 1);
  assert.equal(
    (await choose(f, start.choices[1].id, 'stale')).code,
    'choice_unavailable',
  );
  assert.deepEqual(
    data(await choose(f, start.choices[0].id, 'selected')),
    selected,
  );
  assert.equal(
    (await choose(f, start.choices[1].id, 'selected')).code,
    'effect_key_conflict',
  );
  const closed = data(await choose(f, selected.choices[0].id, 'close'));
  assert.equal(closed.closed, true);
  assert.deepEqual(closed.choices, []);
  assert.deepEqual(
    data(
      await call(
        f,
        'start_dialogue_graph',
        { graphId: graph.graphId },
        'start',
      ),
    ),
    start,
  );
  const fresh = data(
    await call(f, 'start_dialogue_graph', { graphId: graph.graphId }, 'fresh'),
  );
  assert.notEqual(fresh.instanceId, start.instanceId);
  assert.deepEqual(
    data(await choose(f, start.choices[0].id, 'selected')),
    selected,
  );
  assert.equal(f.narrative.save().quests.length, 0);
  assert.equal(f.narrative.dialogueEvents().length, 4);
  f.narrative.restore(checkpoint(f));
  assert.deepEqual(
    data(
      await call(f, 'inspect_dialogue_graph', { instanceId: fresh.instanceId }),
    ),
    fresh,
  );
  assert.equal(
    (
      await call(
        f,
        'inspect_dialogue_graph',
        { instanceId: fresh.instanceId },
        undefined,
        f.directorNarrative,
      )
    ).code,
    'dialogue_unavailable',
  );
});
test('graph scopes isolate concurrent authors and old handles while exact receipts preserve source generation through rebind', async (t) => {
  const f = fixture(t),
    prior = f.forester.snapshot();
  const graph = data(
    await call(f, 'create_dialogue_graph', definition, 'author'),
  );
  const start = data(
    await call(f, 'start_dialogue_graph', { graphId: graph.graphId }, 'start'),
  );
  const directorGraph = data(
    await call(
      f,
      'create_dialogue_graph',
      definition,
      'author',
      f.directorNarrative,
    ),
  );
  const directorStart = data(
    await call(
      f,
      'start_dialogue_graph',
      { graphId: directorGraph.graphId },
      'start',
      f.directorNarrative,
    ),
  );
  assert.notEqual(start.instanceId, directorStart.instanceId);
  f.forester.unregister();
  assert.equal(
    (await choose(f, start.choices[0].id, 'retired')).code,
    'recipient_unavailable',
  );
  const replacement = f.runtime.register(prior),
    handle = f.narrative.bind(replacement);
  assert.equal(
    (await call(f, 'inspect_dialogue_graph', { instanceId: start.instanceId }))
      .code,
    'unregistered',
  );
  assert.deepEqual(
    data(await call(f, 'create_dialogue_graph', definition, 'author', handle)),
    graph,
  );
  assert.deepEqual(
    data(
      await call(
        f,
        'start_dialogue_graph',
        { graphId: graph.graphId },
        'start',
        handle,
      ),
    ),
    start,
  );
  const next = data(await choose(f, start.choices[0].id, 'new-generation'));
  assert.equal(next.revision, 1);
  const sources = f.narrative
    .dialogueEvents()
    .filter((e) => e.instanceId === start.instanceId);
  assert.equal(sources[0].bindingGeneration, prior.binding.generation);
  assert.equal(
    sources[1].bindingGeneration,
    replacement.snapshot().binding.generation,
  );
  f.narrative.restore(checkpoint(f));
  assert.deepEqual(
    data(await choose(f, start.choices[0].id, 'new-generation')),
    next,
  );
});
test('graph restore rejects reassigned source generation, forged cursor path and missing committed provenance; legacy saves remain valid', async (t) => {
  const f = fixture(t),
    graph = data(await call(f, 'create_dialogue_graph', definition, 'author'));
  const start = data(
    await call(f, 'start_dialogue_graph', { graphId: graph.graphId }, 'start'),
  );
  data(await choose(f, start.choices[0].id, 'choice'));
  const saved = checkpoint(f);
  for (const mutate of [
    (s) => {
      s.dialogue.sources[0].bindingGeneration = 'forged';
    },
    (s) => {
      delete s.dialogue.receipts.find((r) => r.result.data?.instanceId)
        .bindingGeneration;
    },
    (s) => {
      s.dialogue.instances[0].path[1] = 'exit';
    },
    (s) => {
      s.dialogue.receipts = s.dialogue.receipts.filter(
        (r) => r.result.data?.revision !== 1,
      );
    },
    (s) => {
      s.dialogue.graphs[0].ownerKey = s.dialogue.graphs[0].ownerKey.replace(
        'forester',
        'director',
      );
    },
  ]) {
    const bad = structuredClone(saved);
    mutate(bad);
    assert.throws(() => f.narrative.restore(bad));
  }
  f.narrative.restore(saved);
  const source = f.narrative.dialogueEvents()[0];
  f.narrative.acknowledgeDialogueEvent(source.id);
  f.narrative.acknowledgeDialogueEvent(source.id);
  assert.equal(f.narrative.dialogueEvents().length, 1);
  f.narrative.restore(checkpoint(f));
  const old = checkpoint(f);
  delete old.dialogue;
  f.narrative.restore(old);
  assert.deepEqual(f.narrative.dialogueEvents(), []);
});
test('graph retained source capacity gates transitions without eviction and acknowledgment enables one fresh commit', async (t) => {
  const f = fixture(t),
    terminalGraph = data(
      await call(f, 'create_dialogue_graph', terminal, 'terminal'),
    );
  for (let i = 0; i < 254; i++)
    data(
      await call(
        f,
        'start_dialogue_graph',
        { graphId: terminalGraph.graphId },
        'start-' + i,
      ),
    );
  const graph = data(
    await call(f, 'create_dialogue_graph', definition, 'author'),
  );
  const start = data(
    await call(f, 'start_dialogue_graph', { graphId: graph.graphId }, 'start'),
  );
  const next = data(await choose(f, start.choices[0].id, 'next'));
  assert.equal(f.narrative.dialogueEvents().length, 256);
  assert.equal(
    (await choose(f, next.choices[0].id, 'full')).code,
    'capacity_exceeded',
  );
  assert.equal(
    data(
      await call(f, 'inspect_dialogue_graph', { instanceId: start.instanceId }),
    ).revision,
    1,
  );
  f.narrative.acknowledgeDialogueEvent(f.narrative.dialogueEvents()[0].id);
  assert.equal(data(await choose(f, next.choices[0].id, 'close')).closed, true);
  assert.equal(f.narrative.dialogueEvents().length, 256);
  f.narrative.restore(checkpoint(f));
});
test('graph instance/definition limits and shared receipt capacity reject before allocating, retaining exact replay', async (t) => {
  const f = fixture(t),
    graph = data(await call(f, 'create_dialogue_graph', terminal, 'author'));
  for (let i = 0; i < 256; i++) {
    data(
      await call(
        f,
        'start_dialogue_graph',
        { graphId: graph.graphId },
        'instance-' + i,
      ),
    );
    f.narrative.acknowledgeDialogueEvent(f.narrative.dialogueEvents()[0].id);
  }
  assert.equal(
    (
      await call(
        f,
        'start_dialogue_graph',
        { graphId: graph.graphId },
        'overflow',
      )
    ).code,
    'capacity_exceeded',
  );
  for (let i = 1; i < 256; i++)
    data(await call(f, 'create_dialogue_graph', terminal, 'graph-' + i));
  assert.equal(
    (await call(f, 'create_dialogue_graph', terminal, 'graph-overflow')).code,
    'capacity_exceeded',
  );
  const retained = f.narrative.save();
  const remaining =
    4096 - retained.receipts.length - retained.dialogue.receipts.length;
  for (let i = 0; i < remaining; i++)
    await call(f, 'create_dialogue_graph', terminal, 'full-' + i);
  assert.equal(
    (
      await call(
        f,
        'create_quest',
        f.draft('Quest', 'grove-1').toInput(),
        'full',
      )
    ).code,
    'capacity_exceeded',
  );
  assert.equal(
    (await call(f, 'create_dialogue_graph', terminal, 'full-overflow')).code,
    'capacity_exceeded',
  );
  assert.deepEqual(
    data(await call(f, 'create_dialogue_graph', terminal, 'author')),
    graph,
  );
  assert.equal(f.narrative.save().quests.length, 0);
  f.narrative.restore(checkpoint(f));
});

test('trusted graph projection publishes stable choices through the existing host port without changing CAI or quest identities', async (t) => {
  const { CharacterHostPort } =
    await import('../dist/src/host/CharacterHostPort.js');
  const f = fixture(t),
    graph = data(await call(f, 'create_dialogue_graph', definition, 'author'));
  const start = data(
    await call(f, 'start_dialogue_graph', { graphId: graph.graphId }, 'start'),
  );
  let runs = 0;
  const driver = {
    current: () => {
      f.forester.snapshot();
    },
    choices: () =>
      data(f.narrative.dialogueView(f.forester, start.instanceId)).choices,
    run: async (_id, effect, intent) => {
      assert.equal(intent.kind, 'choice');
      runs++;
      const result = await f.narrative.choose(
        'player-1',
        intent.choiceId,
        effect,
      );
      assert.equal(result.status, 'completed');
      return result.data.text;
    },
  };
  const port = new CharacterHostPort(driver, () => undefined);
  t.after(() => port.dispose());
  await port.publishAuthority();
  const before = port.read();
  assert.deepEqual(before.choices, start.choices);
  const pending = port.dispatch({
    kind: 'choice',
    requestId: 'player-delivery',
    expectedRevision: before.revision,
    choiceId: start.choices[0].id,
  });
  for (let i = 0; i < 10; i++) {
    f.advance(0);
    await new Promise((resolve) => setImmediate(resolve));
  }
  await pending;
  const after = port.read();
  assert.equal(runs, 1);
  assert.equal(after.choices[0].label, 'Goodbye.');
  await port.dispatch({
    kind: 'choice',
    requestId: 'player-delivery',
    expectedRevision: before.revision,
    choiceId: start.choices[0].id,
  });
  assert.equal(runs, 1);
  assert.equal(
    f.narrative.dialogueView(f.director, start.instanceId).status,
    'rejected',
  );
  f.forester.unregister();
  assert.throws(() => f.narrative.dialogueView(f.forester, start.instanceId));
});

test('authored identifiers cannot create undeliverable typed source references while multiline prose remains exact', async (t) => {
  const f = fixture(t);
  const bad = {
    recipientRef: 'player-1',
    title: 'Greeting',
    start: '\nintro',
    nodes: [{ id: '\nintro', text: 'Hello.\nSafe travels.', choices: [] }],
  };
  assert.equal(
    (await call(f, 'create_dialogue_graph', bad, 'bad-source')).status,
    'rejected',
  );
  assert.equal(f.narrative.save().dialogue.graphs.length, 0);
  assert.deepEqual(f.narrative.dialogueEvents(), []);
  const good = {
    ...bad,
    start: ' intro ',
    nodes: [{ ...bad.nodes[0], id: ' intro ' }],
  };
  const graph = data(
    await call(f, 'create_dialogue_graph', good, 'good-source'),
  );
  const started = data(
    await call(f, 'start_dialogue_graph', { graphId: graph.graphId }, 'start'),
  );
  assert.equal(started.nodeId, ' intro ');
  assert.equal(started.text, bad.nodes[0].text);
  const source = f.narrative.dialogueEvents()[0];
  for (const ref of [
    source.characterRef,
    source.recipientRef,
    source.nodeId,
    source.instanceId,
    source.graphId,
    source.id,
  ])
    assert.doesNotMatch(ref, /\p{Cc}/u);
  f.narrative.restore(checkpoint(f));
});

test('native-encoded oversized graph is rejected before author/source state and cannot pass checkpoint restore', async (t) => {
  const f = fixture(t);
  const oversized = {
    recipientRef: 'player-1',
    title: 'Greeting',
    start: 'n0',
    nodes: Array.from({ length: 16 }, (_, i) => ({
      id: 'n' + i,
      text: i < 10 ? 'Hi' + '\u2028'.repeat(1998) : 'Hi',
      choices:
        i === 15
          ? []
          : [{ id: 'continue', label: 'Continue', next: 'n' + (i + 1) }],
    })),
  };
  assert.ok(Buffer.byteLength(JSON.stringify(oversized)) <= 65536);
  assert.equal(
    (await call(f, 'create_dialogue_graph', oversized, 'oversized')).code,
    'invalid_arguments',
  );
  assert.equal(f.narrative.save().dialogue.graphs.length, 0);
  assert.deepEqual(f.narrative.dialogueEvents(), []);
  const graph = data(
    await call(f, 'create_dialogue_graph', definition, 'normal'),
  );
  const saved = checkpoint(f);
  saved.dialogue.graphs[0].definition = oversized;
  const { canonical } = await import('../dist/src/narrative/validation.js');
  const receipt = saved.dialogue.receipts.find(
    (r) => r.result.data?.graphId === graph.graphId && r.result.data?.nodeCount,
  );
  receipt.digest = canonical(oversized);
  receipt.result.data.nodeCount = 16;
  assert.throws(() => f.narrative.restore(saved));
});
