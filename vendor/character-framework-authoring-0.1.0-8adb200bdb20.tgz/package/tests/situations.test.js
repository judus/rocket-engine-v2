import test from 'node:test';
import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { readFile } from 'node:fs/promises';
import { createSituationScenario } from '../dist/examples/situation-scenario.js';
import { validateSituationDefinition } from '../dist/src/index.js';
const examples = JSON.parse(
  await readFile(
    new URL('../docs/contracts/situation-examples.json', import.meta.url),
    'utf8',
  ),
);
function fixture(t) {
  const f = createSituationScenario();
  t.after(() => f.dispose());
  return f;
}
async function ticks(f, count = 4) {
  for (let i = 0; i < count; i++) {
    f.runtime.advance(0);
    await setImmediate();
  }
}
async function pump(f, promise) {
  let done = false;
  let value, error;
  promise.then(
    (v) => {
      done = true;
      value = v;
    },
    (e) => {
      done = true;
      error = e;
    },
  );
  for (let i = 0; i < 300 && !done; i++) await ticks(f, 1);
  assert.ok(done, 'command must settle');
  if (error) throw error;
  return value;
}
async function start(f, index) {
  await pump(f, f.handle.publish(examples[index], 'publish'));
  return (
    await pump(
      f,
      f.handle.start(
        examples[index].id,
        { kind: 'player', ref: 'player-1' },
        'start',
      ),
    )
  ).runId;
}
async function until(f, id, predicate) {
  for (let i = 0; i < 300; i++) {
    const v = f.handle.read(id);
    if (predicate(v)) return v;
    await ticks(f, 1);
  }
  assert.fail(JSON.stringify(f.handle.read(id)));
}
async function choose(f, id, label, key = 'choose') {
  const v = await until(f, id, (v) => v.choices.some((c) => c.label === label));
  const c = v.choices.find((c) => c.label === label);
  return pump(f, f.handle.choose(id, c.id, v.revision, key));
}

test('situation authoring rejects unknown/cyclic/bypassed boundaries and forward results before publication', (t) => {
  const f = fixture(t);
  for (const e of examples)
    assert.deepEqual(validateSituationDefinition(e, f.capabilities), []);
  const bad = structuredClone(examples[1]);
  bad.situations[0].routes[0].next = 'reward';
  assert.match(
    validateSituationDefinition(bad, f.capabilities).join(';'),
    /Unreachable/,
  );
  const bypass = structuredClone(examples[1]);
  bypass.situations[0].choices = [
    { id: 'skip', label: 'Skip', next: 'return' },
  ];
  bypass.situations[3].dialogue.requires.evidence = {
    mode: 'events',
    after: { kind: 'situation-entry', situationRef: 'fight' },
  };
  assert.ok(validateSituationDefinition(bypass, f.capabilities).length);
  const cycle = structuredClone(examples[0]);
  cycle.situations[1].choices[0].next = 'meeting';
  assert.match(
    validateSituationDefinition(cycle, f.capabilities).join(';'),
    /Cycle/,
  );
  const forward = structuredClone(examples[1]);
  forward.situations[1].onEnter[0].arguments.locationRef = {
    $result: {
      situationRef: 'fight',
      actionId: 'ensure-patrol',
      path: ['encounterId'],
    },
  };
  assert.match(
    validateSituationDefinition(forward, f.capabilities).join(';'),
    /forward|unavailable/i,
  );
});

test('no AI: conditional neutral choices converge; interaction gates all choices and revalidates at commit', async (t) => {
  const f = fixture(t);
  f.enter();
  const id = await start(f, 0);
  let v = await until(f, id, (v) => v.choices.length === 3);
  f.trust(0);
  await ticks(f, 6);
  assert.equal(f.handle.read(id).choices.length, 2);
  f.interaction(false);
  await assert.rejects(
    pump(
      f,
      f.handle.choose(id, v.choices[1].id, v.revision, 'bad-interaction'),
    ),
    /Interaction/,
  );
  await ticks(f, 6);
  assert.equal(f.handle.read(id).choices.length, 0);
  assert.equal(f.handle.read(id).status, 'waiting');
  f.interaction(true);
  await choose(f, id, 'Ask for details', 'ask');
  await choose(f, id, 'Agree', 'agree');
  await until(f, id, (v) => v.status === 'closed');
  assert.equal(f.handle.read(id).situationId, 'agreement');
  assert.equal(f.stats().rewards, 0);
});

test('location event -> exact designated deaths -> reveal -> later claim -> reward once; checkpoints and delivery replay retained', async (t) => {
  const f = fixture(t);
  const id = await start(f, 1);
  await ticks(f, 8);
  assert.equal(f.handle.read(id).situationId, 'watch');
  f.enter();
  await until(f, id, (v) => v.situationId === 'fight');
  await until(f, id, () => f.stats().encounters === 1);
  await ticks(f, 8);
  f.death('other');
  f.death('encounter-1', 'guard-1', 'cemetery');
  f.death('encounter-1', 'guard-1', 'grove', 'retired-incarnation');
  await ticks(f, 8);
  assert.equal(f.handle.read(id).situationId, 'fight');
  f.death('encounter-1', 'guard-1', 'grove', 'encounter-1-1', 'same-death');
  f.death('encounter-1', 'guard-1', 'grove', 'encounter-1-1', 'same-death');
  await ticks(f, 8);
  assert.equal(f.handle.read(id).situationId, 'fight');
  f.death('encounter-1', 'guard-2');
  await until(f, id, (v) => v.choices.length === 2);
  assert.equal(f.stats().reveals, 1);
  await choose(f, id, 'Later', 'later');
  let view = await until(f, id, (v) => v.choices.length === 1);
  const command = [id, view.choices[0].id, view.revision, 'claim'];
  await pump(f, f.handle.choose(...command));
  await until(f, id, (v) => v.status === 'closed');
  assert.equal(f.stats().rewards, 1);
  await pump(f, f.handle.choose(...command));
  assert.equal(f.stats().rewards, 1);
  assert.equal(f.handle.read(id).situationId, 'reward');
});

test('same definition counts existing location fact but only a new item pickup after named boundary; ending grants no second sword', async (t) => {
  const f = fixture(t);
  f.enter();
  f.pickup();
  const id = await start(f, 2);
  await until(f, id, () => f.stats().encounters === 1);
  await ticks(f, 8);
  f.death('encounter-1', 'guard-1');
  f.death('encounter-1', 'guard-2');
  await until(f, id, (v) => v.situationId === 'pickup');
  await ticks(f, 8);
  assert.equal(f.handle.read(id).status, 'waiting');
  assert.equal(f.stats().rewards, 0);
  f.pickup();
  await until(f, id, (v) => v.status === 'closed');
  assert.equal(f.handle.read(id).situationId, 'found');
  assert.equal(f.stats().rewards, 0);
  assert.equal(f.stats().flags, 0);
});

test('unknown higher-priority evidence waits; simultaneous collection and departure selects explicit priority without world effect', async (t) => {
  const f = fixture(t);
  f.enter();
  const id = await start(f, 2);
  await until(f, id, () => f.stats().encounters === 1);
  await ticks(f, 8);
  f.death('encounter-1', 'guard-1');
  f.death('encounter-1', 'guard-2');
  await until(f, id, (v) => v.situationId === 'pickup');
  await ticks(f, 8);
  f.unknown(true);
  f.leave();
  await ticks(f, 8);
  assert.equal(f.handle.read(id).situationId, 'pickup');
  assert.equal(f.handle.read(id).status, 'blocked');
  f.pickup();
  f.unknown(false);
  await until(f, id, (v) => v.status === 'closed');
  assert.equal(f.handle.read(id).situationId, 'found');
  assert.equal(f.stats().flags, 0);
});

test('entry journal storage failure blocks admission; lost committed action reply reconciles original effect once', async (t) => {
  const f = fixture(t);
  const id = await start(f, 1);
  f.failStorage((save) =>
    save.runs.some((r) =>
      r.entries.some((e) => e.actions.some((a) => a.state === 'prepared')),
    ),
  );
  f.enter();
  await ticks(f, 20);
  assert.equal(f.stats().encounters, 0);
  assert.equal(f.handle.read(id).status, 'blocked');
  f.failStorage();
  f.loseReply();
  await until(f, id, () => f.stats().encounters === 1);
  await ticks(f, 14);
  assert.equal(f.stats().encounters, 1);
  assert.equal(f.handle.read(id).situationId, 'fight');
  assert.equal(f.checkpoint().runs[0].entries[1].actions[0].state, 'completed');
});

test('ordered entry action chaining uses acknowledged typed result before exposing next situation', async (t) => {
  const f = fixture(t);
  const e = {
    proposalVersion: 'cfw-situations-draft-2',
    id: 'chain',
    start: 'entry',
    situations: [
      {
        id: 'entry',
        onEnter: [
          {
            id: 'spawn',
            tool: 'game_ensure_encounter',
            arguments: { locationRef: 'grove', presetRef: 'patrol' },
          },
          {
            id: 'flag',
            tool: 'game_set_world_flag',
            arguments: {
              flagRef: {
                $result: {
                  situationRef: 'entry',
                  actionId: 'spawn',
                  path: ['encounterId'],
                },
              },
              value: true,
            },
          },
        ],
      },
    ],
  };
  await pump(f, f.handle.publish(e, 'publish'));
  const id = (
    await pump(f, f.handle.start('chain', { kind: 'world' }, 'start'))
  ).runId;
  await until(f, id, (v) => v.status === 'closed');
  assert.equal(f.stats().encounters, 1);
  assert.equal(f.stats().flags, 1);
  assert.equal(
    f.checkpoint().runs[0].entries[0].actions[1].arguments.flagRef,
    'encounter-1',
  );
});

test('retirement cleanup is acknowledged and idempotent, while stale actor handles cannot publish or choose', async (t) => {
  const f = fixture(t);
  f.enter();
  const id = await start(f, 2);
  await until(f, id, () => f.stats().encounters === 1);
  await pump(f, f.handle.retire(id, 'retire'));
  await until(f, id, (v) => v.status === 'retired');
  await pump(f, f.handle.retire(id, 'retire'));
  assert.equal(f.stats().retirements, 1);
  f.actor.unregister();
  assert.throws(() => f.handle.read(id));
  await assert.rejects(f.handle.publish(examples[0], 'new'));
});

test('run-start and situation-entry cursors are established before the command/transition is exposed', async (t) => {
  const f = fixture(t);
  const id = await start(f, 1);
  f.enter();
  await until(f, id, () => f.stats().encounters === 1);
  await ticks(f, 8);
  f.death('encounter-1', 'guard-1');
  f.death('encounter-1', 'guard-2');
  await until(f, id, (v) => v.choices.length === 2);
  assert.equal(f.stats().reveals, 1);
});

test('restore reconciles an original prepared action after lost acknowledgement without another encounter', async (t) => {
  const f = fixture(t);
  const id = await start(f, 1);
  f.failStorage((save) =>
    save.runs.some((r) =>
      r.entries.some((e) => e.actions.some((a) => a.state === 'completed')),
    ),
  );
  f.enter();
  await until(f, id, () => f.stats().encounters === 1);
  await ticks(f, 5);
  f.system.setPaused(true);
  await ticks(f, 2);
  assert.equal(f.system.stats.busy, false);
  const journal = f.checkpoint();
  assert.equal(journal.runs[0].entries.at(-1).actions[0].state, 'prepared');
  f.system.restore(journal);
  f.failStorage();
  f.system.setPaused(false);
  await ticks(f, 10);
  assert.equal(f.stats().encounters, 1);
  assert.equal(
    f.checkpoint().runs[0].entries.at(-1).actions[0].state,
    'completed',
  );
  assert.equal(f.handle.read(id).situationId, 'fight');
});

test('malformed checkpoint restore is atomic and cannot skip entry acknowledgement or invent an event boundary', async (t) => {
  const f = fixture(t);
  const id = await start(f, 1);
  f.enter();
  await until(f, id, () => f.stats().encounters === 1);
  await ticks(f, 8);
  f.system.setPaused(true);
  await ticks(f, 2);
  const saved = f.system.save();
  const bad = structuredClone(saved);
  bad.runs[0].cursors[0].boundary = 'entry:reward';
  assert.throws(() => f.system.restore(bad), /cursor/);
  assert.deepEqual(f.system.save(), saved);
  const premature = structuredClone(saved);
  premature.runs[0].status = 'closed';
  assert.throws(() => f.system.restore(premature), /closed/);
  assert.deepEqual(f.system.save(), saved);
  const action = structuredClone(saved);
  action.runs[0].entries.at(-1).actions[0].arguments.locationRef = 'cemetery';
  assert.throws(() => f.system.restore(action), /action/);
  assert.deepEqual(f.system.save(), saved);
});

test('same-entry output types must match receiver input contract before publication', (t) => {
  const f = fixture(t);
  const definition = {
    proposalVersion: 'cfw-situations-draft-2',
    id: 'wrong-type',
    start: 'entry',
    situations: [
      {
        id: 'entry',
        onEnter: [
          {
            id: 'spawn',
            tool: 'game_ensure_encounter',
            arguments: { locationRef: 'grove', presetRef: 'patrol' },
          },
          {
            id: 'flag',
            tool: 'game_set_world_flag',
            arguments: {
              flagRef: 'flag',
              value: {
                $result: {
                  situationRef: 'entry',
                  actionId: 'spawn',
                  path: ['encounterId'],
                },
              },
            },
          },
        ],
      },
    ],
  };
  assert.match(
    validateSituationDefinition(definition, f.capabilities).join(';'),
    /Incompatible/,
  );
});

test('choice observation revision changing during persistence rejects transition before any reward', async (t) => {
  const f = fixture(t);
  f.enter();
  const id = await start(f, 0);
  const view = await until(f, id, (v) => v.choices.length === 3);
  const original = f.game.persist;
  let changed = false;
  f.game.persist = (save) => {
    original(save);
    if (
      !changed &&
      save.receipts.some((r) => r.digest.includes('"kind":"choose"'))
    ) {
      changed = true;
      f.interaction(false);
    }
  };
  await assert.rejects(
    pump(
      f,
      f.handle.choose(id, view.choices[0].id, view.revision, 'race-choice'),
    ),
    /revision stale/,
  );
  assert.equal(f.handle.read(id).situationId, 'meeting');
  assert.equal(f.stats().rewards, 0);
  assert.equal(f.checkpoint().runs[0].path.length, 1);
});

test('fresh registration restore requires explicit host approval and retains original run/effect/capture identities', async (t) => {
  const f = fixture(t);
  const id = await start(f, 1);
  f.enter();
  await until(f, id, () => f.stats().encounters === 1);
  await ticks(f, 8);
  f.system.setPaused(true);
  await ticks(f, 2);
  const saved = f.system.save(),
    previous = f.actor.snapshot();
  f.actor.unregister();
  const rebound = f.runtime.register({
    id: 'director',
    name: 'Rebound director',
    capabilities: f.capabilities.map((c) => c.name),
    binding: previous.binding,
  });
  const handle = f.system.bind(rebound);
  assert.throws(() => f.system.restore(saved), /explicit host/);
  f.game.authorizeRestore = (_, generation, scope, runId) =>
    generation === previous.binding.generation &&
    scope.kind === 'player' &&
    runId === id;
  f.system.restore(saved);
  assert.equal(handle.read(id).runId, id);
  assert.equal(
    f.system.save().runs[0].originGeneration,
    previous.binding.generation,
  );
  f.system.setPaused(false);
  await ticks(f, 10);
  assert.equal(f.stats().encounters, 1);
  assert.equal(
    f.checkpoint().runs[0].generation,
    rebound.snapshot().binding.generation,
  );
});

test('removal during asynchronous reconciliation prevents late action admission', async (t) => {
  const f = fixture(t);
  const id = await start(f, 1);
  let release;
  f.game.reconcile = () =>
    new Promise((resolve) => {
      release = () => resolve({ status: 'not_admitted' });
    });
  f.enter();
  for (let i = 0; i < 100 && !release; i++) await ticks(f, 1);
  assert.ok(release);
  f.actor.unregister();
  release();
  await ticks(f, 3);
  assert.equal(f.stats().encounters, 0);
  assert.throws(() => f.handle.read(id));
});

test('disposing during persistence rejects pending API command and aborts its execution context', async (t) => {
  const f = fixture(t);
  let release;
  f.game.persist = () =>
    new Promise((resolve) => {
      release = resolve;
    });
  const pending = f.handle.publish(examples[0], 'publish');
  const rejected = assert.rejects(pending, /Disposed/);
  await ticks(f, 1);
  f.dispose();
  await rejected;
  release();
  await setImmediate();
  assert.equal(f.stats().encounters, 0);
});

test('failed retirement remains cleanup-only and cannot resume authored actions or rewards', async (t) => {
  const f = fixture(t);
  const id = await start(f, 1);
  f.enter();
  await until(f, id, () => f.stats().encounters === 1);
  const original = f.game.retire;
  let attempts = 0;
  f.game.retire = (context) => {
    attempts++;
    if (attempts === 1) throw Error('cleanup unavailable');
    return original(context);
  };
  await pump(f, f.handle.retire(id, 'retire'));
  await until(f, id, (v) => v.status === 'retired');
  assert.ok(attempts >= 2);
  assert.equal(f.stats().reveals, 0);
  assert.equal(f.stats().rewards, 0);
  assert.equal(f.stats().retirements, 1);
});

test('waiting on unchanged facts does not repeatedly write the journal', async (t) => {
  const f = fixture(t);
  let writes = 0;
  const original = f.game.persist;
  f.game.persist = (save) => {
    writes++;
    original(save);
  };
  const id = await start(f, 1);
  await until(f, id, (v) => v.status === 'waiting');
  await ticks(f, 4);
  const before = writes;
  await ticks(f, 20);
  assert.equal(writes, before);
  assert.equal(f.handle.read(id).situationId, 'watch');
});

test('publication and arming execute the same detached input used by their replay receipts', async (t) => {
  const f = fixture(t);
  const definition = {
    proposalVersion: 'cfw-situations-draft-2',
    id: 'captured-definition',
    start: 'end',
    situations: [{ id: 'end' }],
  };
  const original = structuredClone(definition);
  const pending = f.handle.publish(definition, 'captured-publication');
  definition.id = 'caller-mutated';
  definition.situations[0].dialogue = { text: 'Caller mutation' };
  assert.deepEqual(await pump(f, pending), { definitionId: original.id });
  assert.deepEqual(
    await pump(f, f.handle.publish(original, 'captured-publication')),
    { definitionId: original.id },
  );
  const scope = { kind: 'player', ref: 'player-1' };
  const arming = f.handle.start(original.id, scope, 'captured-start');
  scope.kind = 'world';
  delete scope.ref;
  const run = await pump(f, arming);
  assert.deepEqual(f.system.save().runs.find((r) => r.id === run.runId).scope, {
    kind: 'player',
    ref: 'player-1',
  });
  const replay = await pump(
    f,
    f.handle.start(
      original.id,
      { kind: 'player', ref: 'player-1' },
      'captured-start',
    ),
  );
  assert.deepEqual(replay, run);
  assert.equal(
    f.system.save().definitions[0].definition.situations[0].dialogue,
    undefined,
  );
});
