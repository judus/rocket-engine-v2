import test from 'node:test';
import assert from 'node:assert/strict';
import { CaiHttpBackend, CaiHttpError } from '../dist/src/cai/index.js';

const requestId = '4de76355-254c-425a-9d86-e020223d28c9';
const jobId = 'e8b4a579-3921-47d9-9634-903097202c20';
const signal = () => new AbortController().signal;
function wire(status = 'queued') {
  return {
    id: jobId,
    request_id: requestId,
    session_id: 81,
    version: 0,
    binding_generation: 'author-generation',
    status,
    report:
      status === 'finished'
        ? 'Published a task; gameplay has not started.'
        : null,
    failure_code: status === 'failed' ? 'execution_interrupted' : null,
    attempt_request_id: status === 'queued' ? null : jobId,
    created_at: '2026-10-14T02:00:00.000000Z',
    started_at: status === 'queued' ? null : '2026-10-14T02:00:01.000000Z',
    finished_at: ['finished', 'failed'].includes(status)
      ? '2026-10-14T02:00:02.000000Z'
      : null,
  };
}
function backend(fetch) {
  return new CaiHttpBackend({
    origin: 'http://cai.test',
    token: 'server-private-token',
    enableGameDraft: true,
    fetch,
  });
}

test('authoring HTTP retains exact submission after lost acknowledgment and reads server job/attempt identity without activation', async () => {
  const calls = [];
  let lose = true;
  let current = wire();
  const http = backend(async (url, init) => {
    calls.push({ url, init });
    if (init.method === 'POST' && lose) {
      lose = false;
      throw new Error('Lost response after queued acceptance');
    }
    return Response.json({ data: current }, { status: 200 });
  });
  const saved = JSON.parse(
    JSON.stringify({
      request_id: requestId,
      version: 0,
      brief: ' Make a NEW visit. ',
      authoring_guide: 'External guide',
    }),
  );
  await assert.rejects(
    http.submitAuthoring('81', saved, signal()),
    /Lost response/,
  );
  assert.equal(
    calls.length,
    1,
    'No automatic retry or fresh request allocation',
  );
  const accepted = await http.submitAuthoring('81', saved, signal());
  assert.equal(accepted.id, jobId);
  assert.equal(accepted.requestId, requestId);
  assert.equal(accepted.attemptRequestId, null);
  assert.deepEqual(JSON.parse(calls[0].init.body), saved);
  assert.equal(calls[1].init.body, calls[0].init.body);
  assert.equal(
    calls[0].url,
    'http://cai.test/api/v1/companion/sessions/81/quest-authoring-jobs',
  );
  assert.equal(calls[0].init.redirect, 'error');
  for (const status of ['running', 'finished', 'failed']) {
    current = wire(status);
    const result = await http.readAuthoringJob('81', jobId, signal());
    assert.equal(result.status, status);
    assert.equal(result.attemptRequestId, jobId);
    assert.notEqual(result.attemptRequestId, requestId);
    assert.equal(result.version, 0);
    assert.equal(Object.isFrozen(result), true);
    assert.equal(Object.hasOwn(result, 'publication'), false);
  }
  assert.ok(
    calls
      .slice(2)
      .every(
        (x) =>
          x.init.method === 'GET' &&
          x.init.body === undefined &&
          x.url.endsWith('/quest-authoring-jobs/' + jobId),
      ),
  );
});

test('authoring HTTP checks captured identity, rejects malformed inputs/results and keeps credentials out of conflict errors', async () => {
  let current = wire();
  let input;
  let sends = 0;
  const http = backend(async () => {
    sends++;
    if (input) input.request_id = jobId;
    return Response.json({ data: current }, { status: 201 });
  });
  input = { request_id: requestId, version: 0, brief: 'Original request' };
  const received = await http.submitAuthoring('81', input, signal());
  assert.equal(
    received.requestId,
    requestId,
    'Post-call input mutation cannot alter response correlation',
  );
  input = undefined;
  for (const bad of [
    { request_id: 'not-a-uuid', version: 0, brief: 'Task' },
    { request_id: requestId, version: 0, brief: '   ' },
    { request_id: requestId, version: -1, brief: 'Task' },
    { request_id: requestId, version: 0, brief: 'Task', unexpected: true },
    {
      request_id: requestId,
      version: 0,
      brief: 'Task',
      authoring_guide: 'x'.repeat(16001),
    },
  ])
    await assert.rejects(
      http.submitAuthoring('81', bad, signal()),
      /Invalid CAI authoring/,
    );
  assert.equal(sends, 1);
  await assert.rejects(
    http.readAuthoringJob('../81', jobId, signal()),
    /selector/,
  );
  await assert.rejects(
    http.readAuthoringJob('81', 'not-a-job', signal()),
    /selector/,
  );
  for (const changed of [
    { id: requestId },
    { session_id: 82 },
    { status: 'approved' },
    { attempt_request_id: requestId },
    { report: {} },
    { binding_generation: null },
  ]) {
    current = { ...wire('finished'), ...changed };
    await assert.rejects(
      http.readAuthoringJob('81', jobId, signal()),
      /uncorrelated/,
    );
  }
  current = { ...wire(), request_id: jobId };
  await assert.rejects(
    http.submitAuthoring(
      '81',
      { request_id: requestId, version: 0, brief: 'Task' },
      signal(),
    ),
    /uncorrelated/,
  );
  const conflict = backend(async () =>
    Response.json(
      { error: { code: 'authoring_busy', message: 'server-private-token' } },
      { status: 409 },
    ),
  );
  await assert.rejects(
    conflict.submitAuthoring(
      '81',
      { request_id: requestId, version: 0, brief: 'Task' },
      signal(),
    ),
    (error) =>
      error instanceof CaiHttpError &&
      error.status === 409 &&
      !error.message.includes('server-private-token'),
  );
});
