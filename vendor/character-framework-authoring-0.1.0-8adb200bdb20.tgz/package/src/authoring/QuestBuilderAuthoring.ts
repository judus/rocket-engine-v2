import { DatabaseSync } from 'node:sqlite';
import { createHash, randomUUID } from 'node:crypto';
import { Ajv2020 } from 'ajv/dist/2020.js';
import { immutable, isJson } from '../json.js';
import {
  boundedJson,
  canonical,
  record,
  reject,
} from '../narrative/validation.js';
import {
  conditions,
  field,
  outputField,
  validateSituationDefinition,
} from '../situations/validation.js';
import type { SituationDefinition } from '../situations/types.js';
import type {
  Capability,
  CapabilityResult,
  Invocation,
  Json,
} from '../types.js';
import type { AuthoringPrototypeOptions } from './QuestAuthoringPrototype.js';
import {
  QuestBuilderWorkspace,
  builderSchemas,
} from './QuestBuilderWorkspace.js';

type ObjectJson = Record<string, Json>;
interface Receipt {
  id: string;
  digest: string;
  result: CapabilityResult;
}
interface State {
  workspace: Json;
  receipts: Receipt[];
  publications: SituationDefinition[];
}
interface WorkspaceConstructor {
  new (options: {
    capabilities: AuthoringPrototypeOptions['capabilities'];
    storage: { read(): Json; write(state: Json): void };
    host(name: string, fragment: unknown): Json;
  }): { call(name: string, args: Json): Promise<unknown> };
}
const Workspace = QuestBuilderWorkspace as unknown as WorkspaceConstructor;
const schemas = builderSchemas as unknown as Readonly<Record<string, Json>>;
const reads = new Set([
  'list_quest_drafts',
  'inspect_quest_draft',
  'review_quest_draft',
  'from_action_result',
  'read_quest_draft',
  'get_authoring_command_outcome',
]);
const object = (value: unknown): ObjectJson => {
  if (!isJson(value) || !record(value))
    throw new Error('Expected bounded JSON object');
  return value;
};
const json = (value: unknown): Json => {
  const result: unknown = JSON.parse(JSON.stringify(value));
  if (!boundedJson(result)) throw new Error('Invalid or oversized result');
  return result;
};
const storageJson = (value: unknown): Json => {
  if (
    !isJson(value) ||
    Buffer.byteLength(JSON.stringify(value)) > 4 * 1024 * 1024
  )
    throw new Error('Builder storage capacity exceeded');
  return structuredClone(value);
};
const descriptions: Record<string, string> = {
  create_quest_draft:
    'Create persistent quest intent without an implicit stage. Return draft ID and revision.',
  update_quest_intent:
    'Revise title and premise before publication. Requires the latest draft revision.',
  add_stage:
    'Add purpose/title and optional dialogue; return a stable stage ID. Incomplete drafts are saveable.',
  create_fact_condition:
    'Create a typed current-fact condition from a granted inspection. Return condition ID; use comparison.path for nested output.',
  create_event_condition:
    'Create a typed event condition since quest_start or a named stage entry. Final validation requires that boundary on every consuming path.',
  add_transition:
    'Connect existing stages automatically using a condition ID and explicit ascending priority. Return stable record ID.',
  add_choice:
    'Add a player-selected destination and optional condition. Shared stage interaction requirements also apply.',
  add_entry_consequence:
    'Append a granted action to stage entry, in order. Authoring does not execute it.',
  from_action_result:
    'Read a typed authoring argument reference to an entry consequence output. No mutation; producer availability/types validated before publication.',
  add_objective:
    'Add observed progress text and condition to a stage. Objectives do not implicitly gate routes or endings.',
  edit_record:
    'Replace/remove a transition, choice, consequence or objective by stable ID. Replacement retains identity/order; never leaves old behavior attached.',
  update_condition:
    'Replace a condition and explicitly acknowledge its complete affectedRecordIds from inspection, including shared interaction users.',
  remove_condition:
    'Remove an unused condition. Referenced conditions reject with their users; no silent cascade.',
  remove_stage:
    'Remove an unreferenced stage. References reject with IDs; no silent cascade or retarget.',
  update_stage:
    'Replace stage title/purpose/dialogue, retaining identity/connections. Null dialogue removes prose.',
  set_start_stage: 'Select an existing entry stage explicitly.',
  set_interaction_requirement:
    'Set/remove a fact or event requirement shared by stage dialogue and every choice; distinct choice guards must also pass.',
  declare_ending:
    'Mark/unmark intentional terminal authoring intent. Ending stages cannot have outgoing connections.',
  inspect_quest_draft:
    'Read exact saved authoring logic, condition users, publication marker and semantic Mermaid at one revision; never runtime JSON.',
  list_quest_drafts:
    'Read draft IDs/revisions/titles and recent durable command identities for recovery.',
  review_quest_draft:
    'Read readiness and actionable findings, including event/result provenance. Does not mutate or assess narrative quality.',
  publish_quest_draft:
    'Atomically save an immutable definition, frozen draft marker and original command receipt. Does not activate gameplay.',
  read_quest_draft:
    'Read ONLY the currently granted game capability catalogue/reference vocabulary. Other sections are unavailable to this provider.',
  get_authoring_command_outcome:
    'Read an original durable command outcome by trusted commandId, without retrying a mutation.',
};

/** Optional Node authoring domain, granted through the existing CFW MCP provider. */
export class QuestBuilderAuthoring {
  readonly tools: readonly Capability[];
  readonly #db: DatabaseSync;
  readonly #options: AuthoringPrototypeOptions;
  #tail: Promise<unknown> = Promise.resolve();
  #closed = false;
  constructor(options: AuthoringPrototypeOptions) {
    if (!options.authorId.trim())
      throw new Error('Trusted author namespace required');
    this.#options = {
      ...options,
      capabilities: options.capabilities.map((c) => ({
        ...c,
        inputSchema: immutable(c.inputSchema),
        outputSchema: immutable(c.outputSchema),
        ...(c.evidenceStream
          ? { evidenceStream: immutable(c.evidenceStream) }
          : {}),
      })),
      references: immutable(options.references),
      referenceBindings: immutable(options.referenceBindings),
    };
    this.#db = new DatabaseSync(options.path);
    this.#db.exec(
      'PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; CREATE TABLE IF NOT EXISTS quest_builder_authoring (author TEXT PRIMARY KEY, state TEXT NOT NULL)',
    );
    this.#db
      .prepare('INSERT OR IGNORE INTO quest_builder_authoring VALUES (?,?)')
      .run(
        options.authorId,
        JSON.stringify({
          workspace: { version: 1, drafts: [] },
          receipts: [],
          publications: [],
        }),
      );
    const all = {
      ...schemas,
      read_quest_draft: {
        type: 'object',
        properties: { section: { const: 'catalogue' } },
        required: ['section'],
        additionalProperties: false,
      },
      get_authoring_command_outcome: {
        type: 'object',
        properties: {
          commandId: { type: 'string', minLength: 1, maxLength: 160 },
        },
        required: ['commandId'],
        additionalProperties: false,
      },
    };
    const ajv = new Ajv2020({
      strict: true,
      allErrors: true,
      allowUnionTypes: true,
    });
    this.tools = Object.entries(all).map(([name, inputSchema]) => {
      const validate = ajv.compile(inputSchema);
      return {
        name,
        description: descriptions[name] ?? name,
        kind: reads.has(name) ? 'inspection' : 'action',
        inputSchema: immutable(inputSchema),
        validate: (args: Json) => boundedJson(args) && validate(args),
        execute: (context: Invocation, args: Json) => {
          const run = this.#tail.then(async () => {
            if (
              this.#closed ||
              context.signal.aborted ||
              !this.#options.authorize(context)
            )
              return reject(
                'permission_denied',
                'Authoring session is not currently authorized.',
              );
            if (!boundedJson(args) || !validate(args))
              return reject(
                'invalid_arguments',
                'Arguments do not match the discovered builder schema.',
              );
            return this.#call(name, context, object(args));
          });
          this.#tail = run.catch(() => undefined);
          return run;
        },
      } satisfies Capability;
    });
  }
  async close(): Promise<void> {
    await this.#tail;
    if (!this.#closed) {
      this.#closed = true;
      this.#db.close();
    }
  }
  readPublishedDefinition(id: string): SituationDefinition {
    const definition = this.#read().publications.find((d) => d.id === id);
    if (!definition) throw new Error('Unknown published definition');
    return immutable(definition);
  }
  #read(): State {
    const row = this.#db
      .prepare('SELECT state FROM quest_builder_authoring WHERE author=?')
      .get(this.#options.authorId);
    if (!row || typeof row['state'] !== 'string')
      throw new Error('Authoring store unavailable');
    return JSON.parse(row['state']) as State;
  }
  #catalogue(): CapabilityResult {
    return {
      status: 'completed',
      data: json({
        contractVersion: 'cfw-quest-builder-1',
        capabilities: this.#options.capabilities.map((c) => ({
          name: c.name,
          description: c.description,
          kind: c.kind,
          inputSchema: c.inputSchema,
          outputSchema: c.outputSchema,
          ...(c.evidenceStream ? { evidenceStream: c.evidenceStream } : {}),
          referenceBindings: this.#options.referenceBindings[c.name] ?? [],
        })),
        references: this.#options.references,
        workflow:
          'Create intent; add stages/conditions/routes/choices/actions/objectives; inspect Mermaid; repair; review; publish. Publication freezes the draft and does not activate gameplay.',
      }),
    };
  }
  #host(name: string, fragment: unknown, state: State): Json {
    const f = object(fragment);
    const definition = json({
      proposalVersion: 'cfw-situations-draft-2',
      id: 'definition-' + randomUUID(),
      start: f['entrySituation'],
      situations: f['situations'],
    }) as unknown as SituationDefinition;
    const issues = [
      ...validateSituationDefinition(definition, this.#options.capabilities),
    ];
    if (Buffer.byteLength(JSON.stringify(f)) > 12 * 1024)
      issues.push('Builder publication exceeds the 12KiB fragment budget');
    for (const invocation of [
      ...conditions(definition).map((c) => ({
        tool: c.condition.tool,
        arguments: c.condition.arguments,
      })),
      ...definition.situations.flatMap((s) =>
        (s.onEnter ?? []).map((a) => ({
          tool: a.tool,
          arguments: a.arguments,
        })),
      ),
    ]) {
      for (const binding of this.#options.referenceBindings[invocation.tool] ??
        []) {
        const value = field(invocation.arguments, binding.path);
        const allowed = this.#options.references[binding.category] ?? [];
        if (typeof value === 'string' && allowed.includes(value)) continue;
        // A dynamic world reference is allowed only through a declared enum
        // bounded to granted refs; runtime validates the resolved argument.
        const cap = this.#options.capabilities.find(
          (c) => c.name === invocation.tool,
        );
        const input = cap
          ? outputField(cap.inputSchema, binding.path)
          : undefined;
        const enumeration =
          record(input) && Array.isArray(input['enum']) ? input['enum'] : [];
        if (
          record(value) &&
          record(value['$result']) &&
          enumeration.length &&
          enumeration.every((v) => typeof v === 'string' && allowed.includes(v))
        )
          continue;
        issues.push(
          `Unpermitted reference: ${invocation.tool}/${binding.path.join('/')}`,
        );
      }
    }
    if (issues.length)
      return json({
        status: name === 'review_quest_draft' ? 'completed' : 'rejected',
        code: 'draft_not_ready',
        technicalReady: false,
        findings: issues.map((message) => ({ code: 'draft_issue', message })),
      });
    if (name === 'review_quest_draft')
      return { status: 'completed', technicalReady: true, findings: [] };
    state.publications.push(definition);
    return {
      status: 'completed',
      publication: {
        definitionId: definition.id,
        digest: createHash('sha256')
          .update(canonical(definition as unknown as Json))
          .digest('hex'),
      },
    };
  }
  async #call(
    name: string,
    context: Invocation,
    args: ObjectJson,
  ): Promise<CapabilityResult> {
    if (name === 'read_quest_draft') return this.#catalogue();
    const mutation = !reads.has(name);
    const commandId = context.mutation?.id;
    if (mutation && !commandId)
      return reject(
        'trusted_command_required',
        'Use the trusted MCP mutation path.',
      );
    const digest = createHash('sha256')
      .update(canonical({ name, args }))
      .digest('hex');
    if (mutation) this.#db.exec('BEGIN IMMEDIATE');
    try {
      const state = this.#read();
      if (name === 'get_authoring_command_outcome') {
        const receipt = state.receipts.find((r) => r.id === args['commandId']);
        return receipt
          ? { status: 'completed', data: json(receipt) }
          : reject('unknown_command', 'Command outcome is not retained.');
      }
      const receipt = mutation
        ? state.receipts.find((r) => r.id === commandId)
        : undefined;
      if (receipt) {
        this.#db.exec('ROLLBACK');
        return receipt.digest === digest
          ? immutable(receipt.result)
          : reject(
              'effect_key_conflict',
              'Original command has different arguments.',
            );
      }
      if (mutation && state.receipts.length >= 512) {
        this.#db.exec('ROLLBACK');
        return reject(
          'capacity_exceeded',
          'Builder command receipt capacity reached.',
        );
      }
      const before = structuredClone(state);
      const engine = new Workspace({
        capabilities: this.#options.capabilities,
        storage: {
          read: () => structuredClone(state.workspace),
          write: (value) => {
            state.workspace = storageJson(value);
          },
        },
        host: (tool, fragment) => this.#host(tool, fragment, state),
      });
      const draftCapacityReached =
        name === 'create_quest_draft' &&
        Array.isArray(object(state.workspace)['drafts']) &&
        (object(state.workspace)['drafts'] as Json[]).length >= 16;
      const raw = draftCapacityReached
        ? {
            status: 'rejected',
            code: 'capacity_exceeded',
            message: 'Builder draft capacity reached',
          }
        : object(json(await engine.call(name, args)));
      let result: CapabilityResult;
      if (raw['status'] === 'rejected')
        result = {
          ...raw,
          status: 'rejected',
          code:
            typeof raw['code'] === 'string' ? raw['code'] : 'draft_not_ready',
          message:
            typeof raw['message'] === 'string'
              ? raw['message'].slice(0, 1000)
              : 'Builder operation rejected; inspect findings and current revision.',
        };
      else {
        const data = { ...raw };
        delete data['status'];
        const payload = Object.hasOwn(data, 'data')
          ? (data['data'] ?? null)
          : data;
        result = {
          status: 'completed',
          data:
            name === 'list_quest_drafts'
              ? json({
                  items: payload,
                  recentCommands: state.receipts
                    .slice(-16)
                    .map((r) => ({ commandId: r.id, digest: r.digest })),
                })
              : json(payload),
        };
      }
      if (!mutation) return immutable(result);
      const committed = result.status === 'completed' ? state : before;
      if (result.status === 'completed')
        result = {
          status: 'completed',
          data: json({ ...object(result.data), commandId }),
        };
      committed.receipts.push({ id: commandId ?? '', digest, result });
      if (context.signal.aborted || !this.#options.authorize(context))
        throw new Error('Authoring authorization ended before commit');
      const encoded = JSON.stringify(committed);
      if (Buffer.byteLength(encoded) > 4 * 1024 * 1024)
        throw new Error('Builder store capacity exceeded');
      this.#db
        .prepare('UPDATE quest_builder_authoring SET state=? WHERE author=?')
        .run(encoded, this.#options.authorId);
      this.#db.exec('COMMIT');
      return immutable(result);
    } catch (error: unknown) {
      if (mutation) this.#db.exec('ROLLBACK');
      throw error;
    }
  }
}
