import { DatabaseSync } from 'node:sqlite';
import { createHash, randomUUID } from 'node:crypto';
import { Ajv2020 } from 'ajv/dist/2020.js';
import { immutable, isJson } from '../json.js';
import { boundedJson, canonical, record } from '../narrative/validation.js';
import {
  conditions,
  field,
  validateSituationDefinition,
} from '../situations/validation.js';
import type {
  Capability,
  CapabilityResult,
  Invocation,
  Json,
} from '../types.js';
import type {
  SituationCapability,
  SituationDefinition,
} from '../situations/types.js';
import situationSchema from '../../docs/contracts/situations.schema.json' with { type: 'json' };

type ObjectJson = Record<string, Json>;
interface Draft {
  id: string;
  revision: number;
  contentRevision: number;
  intent: ObjectJson;
  implementation: ObjectJson | null;
  review: ObjectJson | null;
  publication: {
    definition: SituationDefinition;
    digest: string;
    sourceRevision: number;
  } | null;
}
interface Receipt {
  id: string;
  tool: string;
  digest: string;
  result: CapabilityResult;
}
interface State {
  drafts: Draft[];
  receipts: Receipt[];
}
export interface AuthoringPrototypeOptions {
  path: string;
  /** Trusted host-provisioned namespace, never accepted from tool arguments. */
  authorId: string;
  authorize(context: Invocation): boolean;
  capabilities: readonly SituationCapability[];
  references: Readonly<Record<string, readonly string[]>>;
  referenceBindings: Readonly<
    Record<string, readonly { path: readonly string[]; category: string }[]>
  >;
}

const id: Json = { type: 'string', minLength: 1, maxLength: 160 };
const object = (
  properties: Record<string, Json>,
  required = Object.keys(properties),
): Json => ({
  type: 'object',
  properties,
  required,
  additionalProperties: false,
});
const intentSchema = object(
  {
    title: { ...id, maxLength: 160 },
    premise: { type: 'string', maxLength: 2000 },
    presentation: { enum: ['task', 'quest'] },
  },
  ['title'],
);
const fragmentSchema = object({
  entrySituation: id,
  situations: {
    type: 'array',
    minItems: 1,
    maxItems: 16,
    items: { $ref: '#/$defs/situation' },
  },
  outcomeBindings: { type: 'array', maxItems: 0 },
});
const operationsSchema: Json = {
  type: 'array',
  minItems: 1,
  maxItems: 4,
  items: {
    oneOf: [
      object({ kind: { const: 'set_intent' }, intent: intentSchema }),
      object({
        kind: { const: 'replace_beat_implementation' },
        beatId: { const: 'main' },
        implementation: fragmentSchema,
      }),
      object({
        kind: { const: 'record_narrative_review' },
        review: object({
          contentDigest: id,
          summary: { type: 'string', maxLength: 2000 },
        }),
      }),
    ],
  },
};
const schemas: Readonly<Record<string, Json>> = {
  create_quest_draft: object({ intent: intentSchema }),
  list_quest_drafts: object({}),
  read_quest_draft: object(
    {
      section: { enum: ['catalogue', 'overview', 'beat', 'publications'] },
      draftId: id,
      recordRevision: { type: 'integer', minimum: 1 },
    },
    ['section'],
  ),
  edit_quest_draft: {
    ...(object({
      draftId: id,
      expectedRecordRevision: { type: 'integer', minimum: 1 },
      operations: operationsSchema,
    }) as ObjectJson),
    $defs: situationSchema.$defs as unknown as Json,
  },
  review_quest_draft: object({
    draftId: id,
    recordRevision: { type: 'integer', minimum: 1 },
  }),
  publish_quest_draft: object({
    draftId: id,
    expectedRecordRevision: { type: 'integer', minimum: 1 },
  }),
  get_authoring_command_outcome: object({ commandId: id }),
};
const descriptions: Readonly<Record<string, string>> = {
  create_quest_draft:
    'Prototype: persist a single-beat task/quest draft. Read the catalogue first. Does not activate gameplay.',
  list_quest_drafts:
    'Prototype: list saved drafts and recent committed command IDs for the trusted author, including after restart.',
  read_quest_draft:
    'Prototype: call section=catalogue without a draft ID to discover permitted capabilities, schemas, reference paths and references in a normal model-visible tool result. Other sections read a saved draft.',
  edit_quest_draft:
    'Prototype: atomically edit intent, replace the main beat fragment, or record advisory narrative review. Incomplete graphs can be saved.',
  review_quest_draft:
    'Prototype: validate the complete saved graph under the supplied host capabilities; return separate technical and narrative status. No world effects.',
  publish_quest_draft:
    'Prototype: validate and persist one immutable definition, source revision and receipt in SQLite. Does not import/start a runtime run.',
  get_authoring_command_outcome:
    'Prototype: inspect a committed original command by its opaque trusted commandId. list_quest_drafts exposes recent IDs if a reply was lost. Not a new mutation identity.',
};
const complete = (data: Json): CapabilityResult => ({
  status: 'completed',
  data,
});
const reject = (code: string, message: string): CapabilityResult => ({
  status: 'rejected',
  code,
  message,
});
function json(value: unknown): Json {
  if (!isJson(value)) throw new Error('Expected finite bounded-depth JSON');
  return value;
}
function obj(value: unknown): ObjectJson {
  if (!record(value) || !isJson(value)) throw new Error('Expected JSON object');
  return value;
}
function string(value: Json | undefined): string {
  if (typeof value !== 'string') throw new Error('Expected string');
  return value;
}
const digest = (value: unknown): string =>
  createHash('sha256')
    .update(canonical(json(value)))
    .digest('hex');

/** Working host-side prototype. Persistent ordinary edits/replay; no hardened lease/crash protocol. */
export class QuestAuthoringPrototype {
  readonly #db: DatabaseSync;
  readonly #options: AuthoringPrototypeOptions;
  readonly tools: readonly Capability[];
  #closed = false;
  constructor(options: AuthoringPrototypeOptions) {
    if (!options.authorId.trim())
      throw new Error('Trusted author namespace required');
    this.#options = {
      ...options,
      capabilities: [...options.capabilities],
      references: immutable(options.references),
      referenceBindings: immutable(options.referenceBindings),
    };
    this.#db = new DatabaseSync(options.path);
    this.#db.exec(
      'PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; CREATE TABLE IF NOT EXISTS authoring_prototype (author TEXT PRIMARY KEY, state TEXT NOT NULL)',
    );
    this.#db
      .prepare('INSERT OR IGNORE INTO authoring_prototype VALUES (?, ?)')
      .run(options.authorId, JSON.stringify({ drafts: [], receipts: [] }));
    const ajv = new Ajv2020({ strict: true, allErrors: true });
    this.tools = Object.entries(schemas).map(([name, inputSchema]) => {
      const validate = ajv.compile(obj(inputSchema));
      return {
        name,
        description: descriptions[name] ?? name,
        kind: [
          'create_quest_draft',
          'edit_quest_draft',
          'publish_quest_draft',
        ].includes(name)
          ? 'action'
          : 'inspection',
        inputSchema: immutable(inputSchema),
        validate: (args: Json) => boundedJson(args) && validate(args),
        execute: (context: Invocation, args: Json) => {
          if (this.#closed || !options.authorize(context))
            return reject(
              'permission_denied',
              'Authoring session is not currently authorized.',
            );
          if (!boundedJson(args) || !validate(args))
            return reject(
              'invalid_arguments',
              'Arguments do not match the discovered prototype schema.',
            );
          return this.#call(name, context, obj(args));
        },
      } satisfies Capability;
    });
  }
  close(): void {
    if (!this.#closed) {
      this.#closed = true;
      this.#db.close();
    }
  }
  readPublishedDefinition(definitionId: string): SituationDefinition {
    const publication = this.#read().drafts.find(
      (d) => d.publication?.definition.id === definitionId,
    )?.publication;
    if (!publication) throw new Error('Unknown published definition');
    return immutable(publication.definition);
  }
  #read(): State {
    const row = this.#db
      .prepare('SELECT state FROM authoring_prototype WHERE author=?')
      .get(this.#options.authorId);
    if (!row || typeof row['state'] !== 'string')
      throw new Error('Authoring state unavailable');
    return JSON.parse(row['state']) as State;
  }
  #content(d: Draft): string {
    return digest({ intent: d.intent, implementation: d.implementation });
  }
  #summary(d: Draft): ObjectJson {
    return {
      draftId: d.id,
      recordRevision: d.revision,
      contentRevision: d.contentRevision,
      contentDigest: this.#content(d),
      title: string(d.intent['title']),
      startBeat: 'main',
      published: d.publication !== null,
    };
  }
  #definition(
    d: Draft,
    definitionId = 'prototype-validation',
  ): SituationDefinition | null {
    if (!d.implementation) return null;
    return {
      proposalVersion: 'cfw-situations-draft-2',
      id: definitionId,
      start: string(d.implementation['entrySituation']),
      situations: d.implementation[
        'situations'
      ] as unknown as SituationDefinition['situations'],
    };
  }
  #assessment(d: Draft): ObjectJson {
    const definition = this.#definition(d);
    const issues = definition
      ? [...validateSituationDefinition(definition, this.#options.capabilities)]
      : ['The main beat has no implementation.'];
    if (definition) {
      const invocations = [
        ...conditions(definition).map((x) => ({
          situationId: x.situationId,
          tool: x.condition.tool,
          arguments: x.condition.arguments,
        })),
        ...definition.situations.flatMap((s) =>
          (s.onEnter ?? []).map((a) => ({
            situationId: s.id,
            tool: a.tool,
            arguments: a.arguments,
          })),
        ),
      ];
      for (const invocation of invocations)
        for (const binding of this.#options.referenceBindings[
          invocation.tool
        ] ?? []) {
          const ref = field(invocation.arguments, binding.path);
          if (
            typeof ref === 'string' &&
            !this.#options.references[binding.category]?.includes(ref)
          )
            issues.push(
              `${invocation.situationId}/${invocation.tool}/${binding.path.join('/')}: reference is not permitted (${ref})`,
            );
          else if (typeof ref !== 'string')
            issues.push(
              `${invocation.situationId}/${invocation.tool}/${binding.path.join('/')}: prototype requires a literal reference`,
            );
        }
    }
    return {
      technicalReady: issues.length === 0,
      planCoverage: d.implementation ? 'complete' : 'incomplete',
      narrativeReview: {
        status: !d.review
          ? 'not_reviewed'
          : d.review['contentDigest'] === this.#content(d)
            ? 'current'
            : 'stale',
      },
      findings: issues.map((message) => ({
        code: 'draft_issue',
        path: message.startsWith('/situations/')
          ? '/implementation' + (message.split(':')[0] ?? '')
          : '/implementation',
        message,
      })),
    };
  }
  #call(name: string, context: Invocation, args: ObjectJson): CapabilityResult {
    const mutation = [
      'create_quest_draft',
      'edit_quest_draft',
      'publish_quest_draft',
    ].includes(name);
    if (!mutation) return this.#apply(name, this.#read(), args);
    const commandId = context.mutation?.id;
    if (!commandId)
      return reject(
        'trusted_command_required',
        'Use the trusted MCP mutation path.',
      );
    const argumentDigest = digest({ name, arguments: args });
    this.#db.exec('BEGIN IMMEDIATE');
    try {
      const state = this.#read();
      const existing = state.receipts.find((r) => r.id === commandId);
      if (existing) {
        this.#db.exec('ROLLBACK');
        return existing.digest === argumentDigest
          ? immutable(existing.result)
          : reject(
              'effect_key_conflict',
              'Original command has different arguments.',
            );
      }
      if (state.receipts.length >= 512) {
        this.#db.exec('ROLLBACK');
        return reject(
          'capacity_exceeded',
          'Prototype receipt capacity reached.',
        );
      }
      const candidate = structuredClone(state);
      let result = this.#apply(name, candidate, args);
      const committed = result.status === 'completed' ? candidate : state;
      if (result.status === 'completed')
        result = complete({ ...obj(result.data), commandId });
      committed.receipts.push({
        id: commandId,
        tool: name,
        digest: argumentDigest,
        result,
      });
      const encoded = JSON.stringify(committed);
      if (Buffer.byteLength(encoded) > 4 * 1024 * 1024)
        throw new Error('Prototype store capacity exceeded');
      this.#db
        .prepare('UPDATE authoring_prototype SET state=? WHERE author=?')
        .run(encoded, this.#options.authorId);
      this.#db.exec('COMMIT');
      return immutable(result);
    } catch (error: unknown) {
      this.#db.exec('ROLLBACK');
      throw error;
    }
  }
  #apply(name: string, state: State, args: ObjectJson): CapabilityResult {
    if (name === 'read_quest_draft' && args['section'] === 'catalogue')
      return complete({
        contractVersion: 'cfw-authoring-prototype-1',
        capabilities: json(
          this.#options.capabilities.map((c) => ({
            name: c.name,
            description: c.description,
            kind: c.kind,
            inputSchema: c.inputSchema,
            outputSchema: c.outputSchema,
            ...(c.evidenceStream ? { evidenceStream: c.evidenceStream } : {}),
            referenceBindings: this.#options.referenceBindings[c.name] ?? [],
          })),
        ),
        references: json(this.#options.references),
        workflow:
          'Create main beat, save/edit, review, publish. Publication does not activate a run.',
      });
    if (name === 'list_quest_drafts')
      return complete({
        items: state.drafts.map((d) => this.#summary(d)),
        recentCommands: state.receipts.slice(-16).map((r) => ({
          commandId: r.id,
          tool: r.tool,
          argumentDigest: r.digest,
        })),
      });
    if (name === 'get_authoring_command_outcome') {
      const receipt = state.receipts.find((r) => r.id === args['commandId']);
      return receipt
        ? complete(
            json({
              state: 'terminal',
              tool: receipt.tool,
              argumentDigest: receipt.digest,
              result: receipt.result,
            }),
          )
        : reject(
            'command_not_found',
            'No committed prototype receipt. This does not prove not-admitted across failure.',
          );
    }
    if (name === 'create_quest_draft') {
      if (state.drafts.length >= 16)
        return reject('capacity_exceeded', 'Prototype draft capacity reached.');
      const d: Draft = {
        id: 'draft-' + randomUUID(),
        revision: 1,
        contentRevision: 1,
        intent: immutable(obj(args['intent'])),
        implementation: null,
        review: null,
        publication: null,
      };
      state.drafts.push(d);
      return complete(this.#summary(d));
    }
    const d = state.drafts.find((x) => x.id === args['draftId']);
    if (!d)
      return reject(
        'draft_not_found',
        'Saved draft not found for this author.',
      );
    const expected = args['expectedRecordRevision'] ?? args['recordRevision'];
    if (expected !== undefined && expected !== d.revision)
      return reject(
        'revision_conflict',
        `Expected ${JSON.stringify(expected)}, current ${String(d.revision)}. Read the current draft before editing.`,
      );
    if (name === 'read_quest_draft') {
      if (args['section'] === 'overview')
        return complete({
          ...this.#summary(d),
          intent: d.intent,
          assessment: this.#assessment(d),
        });
      if (args['section'] === 'beat')
        return complete({
          ...this.#summary(d),
          beat: { id: 'main', title: string(d.intent['title']) },
          implementation: d.implementation,
        });
      return complete({
        ...this.#summary(d),
        publication: d.publication ? json(d.publication) : null,
      });
    }
    if (name === 'review_quest_draft')
      return complete({ ...this.#summary(d), ...this.#assessment(d) });
    if (name === 'edit_quest_draft') {
      if (d.publication)
        return reject(
          'draft_published',
          'Prototype publications are immutable; create another draft to author a new version.',
        );
      const before = this.#content(d);
      for (const raw of args['operations'] as Json[]) {
        const operation = obj(raw);
        if (operation['kind'] === 'set_intent')
          d.intent = immutable(obj(operation['intent']));
        else if (operation['kind'] === 'record_narrative_review')
          d.review = immutable(obj(operation['review']));
        else {
          const fragment = obj(operation['implementation']);
          if (Buffer.byteLength(JSON.stringify(fragment)) > 12 * 1024)
            return reject(
              'fragment_too_large',
              'Prototype fragment limit is 12 KiB.',
            );
          d.implementation = immutable(fragment);
        }
      }
      d.revision++;
      if (before !== this.#content(d)) d.contentRevision++;
      return complete({ ...this.#summary(d), assessment: this.#assessment(d) });
    }
    if (name === 'publish_quest_draft') {
      const assessment = this.#assessment(d);
      if (assessment['technicalReady'] !== true)
        return reject(
          'draft_not_ready',
          JSON.stringify(assessment['findings']),
        );
      if (d.publication)
        return complete({
          ...this.#summary(d),
          definitionId: d.publication.definition.id,
          definitionDigest: d.publication.digest,
          sourceRevision: d.publication.sourceRevision,
        });
      const definition = this.#definition(d, 'definition-' + randomUUID());
      if (!definition) throw new Error('Missing implementation');
      d.publication = {
        definition,
        digest: digest(definition),
        sourceRevision: d.revision,
      };
      d.revision++;
      return complete({
        ...this.#summary(d),
        definitionId: definition.id,
        definitionDigest: d.publication.digest,
        sourceRevision: d.publication.sourceRevision,
      });
    }
    return reject('unknown_tool', 'Unknown prototype tool.');
  }
}
