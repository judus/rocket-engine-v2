// Experimental authoring surface. The host owns publication/MCP integration.
import { readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { Ajv2020 } from 'ajv/dist/2020.js';
import {
  outputField,
  validateSituationDefinition,
} from '../situations/validation.js';

const text = { type: 'string', minLength: 1, maxLength: 2000 };
const id = { type: 'string', minLength: 1, maxLength: 160 };
const object = (properties, required = Object.keys(properties)) => ({
  type: 'object',
  properties,
  required,
  additionalProperties: false,
});
const draft = object({ id, revision: { type: 'integer', minimum: 1 } });
const argumentsSchema = { type: 'object' };
const path = { type: 'array', items: id, minItems: 1, maxItems: 8 };
const resultReference = object({
  fromActionResult: object({ recordId: id, path }),
});
const comparison = {
  oneOf: [
    object({
      field: id,
      operator: { enum: ['equals', 'at_least'] },
      value: { type: ['string', 'number', 'boolean', 'null'] },
    }),
    object({
      path,
      operator: { enum: ['equals', 'at_least'] },
      value: { type: ['string', 'number', 'boolean', 'null'] },
    }),
  ],
};
const fact = { capability: id, arguments: argumentsSchema, comparison };
const since = { oneOf: [{ const: 'quest_start' }, object({ stageId: id })] };
const transition = object({
  from: id,
  to: id,
  conditionId: id,
  priority: { type: 'integer', minimum: 0 },
});
const choice = object({ from: id, to: id, label: text, conditionId: id }, [
  'from',
  'to',
  'label',
]);
const consequence = object({
  stageId: id,
  capability: id,
  arguments: argumentsSchema,
});
const objective = object({
  stageId: id,
  description: { ...text, maxLength: 1000 },
  conditionId: id,
});
export const builderSchemas = {
  create_quest_draft: object({ title: text, premise: text }),
  update_quest_intent: object({ draft, title: text, premise: text }),
  list_quest_drafts: object({}),
  inspect_quest_draft: object({ draftId: id }),
  add_stage: object({ draft, title: text, purpose: text, dialogue: text }, [
    'draft',
    'title',
    'purpose',
  ]),
  update_stage: object(
    {
      draft,
      stageId: id,
      title: text,
      purpose: text,
      dialogue: { type: ['string', 'null'], maxLength: 2000 },
    },
    ['draft', 'stageId', 'title', 'purpose', 'dialogue'],
  ),
  remove_stage: object({ draft, stageId: id }),
  set_start_stage: object({ draft, stageId: id }),
  create_fact_condition: object({ draft, ...fact }),
  create_event_condition: object({ draft, ...fact, since }),
  update_condition: object({
    draft,
    conditionId: id,
    replacement: {
      oneOf: [
        object({ ...fact, mode: { const: 'fact' } }),
        object({ ...fact, mode: { const: 'events' }, since }),
      ],
    },
    affectedRecordIds: { type: 'array', items: id, uniqueItems: true },
  }),
  remove_condition: object({ draft, conditionId: id }),
  add_transition: object({ draft, ...transition.properties }),
  add_choice: object({ draft, ...choice.properties }, [
    'draft',
    'from',
    'to',
    'label',
  ]),
  add_entry_consequence: object({ draft, ...consequence.properties }),
  add_objective: object({ draft, ...objective.properties }),
  from_action_result: object({ draft, recordId: id, path }),
  edit_record: object({
    draft,
    recordId: id,
    change: {
      oneOf: [
        object({ operation: { const: 'remove' } }),
        object({
          operation: { const: 'replace' },
          kind: { const: 'transition' },
          value: transition,
        }),
        object({
          operation: { const: 'replace' },
          kind: { const: 'choice' },
          value: choice,
        }),
        object({
          operation: { const: 'replace' },
          kind: { const: 'consequence' },
          value: consequence,
        }),
        object({
          operation: { const: 'replace' },
          kind: { const: 'objective' },
          value: objective,
        }),
      ],
    },
  }),
  set_interaction_requirement: object({
    draft,
    stageId: id,
    conditionId: { type: ['string', 'null'] },
  }),
  declare_ending: object({ draft, stageId: id, ending: { type: 'boolean' } }),
  review_quest_draft: object({ draft }),
  publish_quest_draft: object({ draft }),
};

export class QuestBuilderWorkspace {
  constructor({ path, capabilities, host, storage }) {
    this.storage = storage;
    this.path = path;
    this.capabilities = capabilities;
    this.host = host;
    this.ajv = new Ajv2020({ strict: false });
    this.validators = Object.fromEntries(
      Object.entries(builderSchemas).map(([name, schema]) => [
        name,
        this.ajv.compile(schema),
      ]),
    );
    this.state = storage
      ? storage.read()
      : existsSync(path)
        ? JSON.parse(readFileSync(path, 'utf8'))
        : { version: 1, drafts: [] };
  }
  save(state) {
    if (this.storage) {
      this.storage.write(state);
      this.state = state;
      return;
    }
    writeFileSync(this.path + '.next', JSON.stringify(state, null, 2) + '\n');
    renameSync(this.path + '.next', this.path);
    this.state = state;
  }
  stage(d, stageId) {
    const s = d.stages.find((s) => s.id === stageId);
    if (!s) throw new Error(`Unknown stage ${stageId}`);
    return s;
  }
  condition(d, conditionId) {
    const c = d.conditions.find((c) => c.id === conditionId);
    if (!c) throw new Error(`Unknown condition ${conditionId}`);
    return c;
  }
  uses(d, conditionId) {
    return [
      ...d.records
        .filter(
          (r) =>
            r.conditionId === conditionId ||
            (r.kind === 'choice' &&
              this.stage(d, r.from).interaction === conditionId),
        )
        .map((r) => r.id),
      ...d.stages
        .filter((s) => s.interaction === conditionId)
        .map((s) => `interaction:${s.id}`),
    ].sort();
  }
  reference(d, value) {
    if (!this.ajv.compile(resultReference)(value))
      throw new Error('Invalid action-result reference');
    const r = d.records.find(
      (r) =>
        r.id === value.fromActionResult.recordId && r.kind === 'consequence',
    );
    if (!r) throw new Error('Unknown result-producing consequence');
    const cap = this.capabilities.find(
      (c) => c.name === r.capability && c.kind === 'action',
    );
    const field =
      cap && outputField(cap.outputSchema, value.fromActionResult.path);
    if (!field) throw new Error('Undeclared action result path');
    return { r, field };
  }
  arguments(d, value) {
    if (Array.isArray(value)) return value.map((v) => this.arguments(d, v));
    if (!value || typeof value !== 'object') return value;
    if (Object.hasOwn(value, '$result'))
      throw new Error('Use from_action_result instead of runtime result JSON');
    if (Object.hasOwn(value, 'fromActionResult')) {
      const { r } = this.reference(d, value);
      return {
        $result: {
          situationRef: r.stageId,
          actionId: r.id,
          path: value.fromActionResult.path,
        },
      };
    }
    return Object.fromEntries(
      Object.entries(value).map(([k, v]) => [k, this.arguments(d, v)]),
    );
  }
  checkCapability(d, c, kind) {
    const cap = this.capabilities.find(
      (a) => a.name === c.capability && a.kind === kind,
    );
    if (!cap) throw new Error(`Unknown ${kind} capability ${c.capability}`);
    // Substitute only reference locations in a private schema copy. Literal
    // arguments retain the capability's required/type/enum/additional-field checks.
    const input = structuredClone(cap.inputSchema);
    const walk = (value, location = []) => {
      if (!value || typeof value !== 'object') return;
      if (Object.hasOwn(value, '$result'))
        throw new Error(
          'Use from_action_result instead of runtime result JSON',
        );
      if (Object.hasOwn(value, 'fromActionResult')) {
        this.reference(d, value);
        let parent = input;
        for (const key of location.slice(0, -1))
          parent = parent?.properties?.[key];
        const key = location.at(-1);
        if (!key || !parent?.properties?.[key])
          throw new Error('Undeclared result-reference input path');
        parent.properties[key] = resultReference;
        return;
      }
      for (const [key, v] of Object.entries(value)) walk(v, [...location, key]);
    };
    walk(c.arguments);
    if (!this.ajv.compile(input)(c.arguments))
      throw new Error(`Invalid arguments for ${c.capability}`);
    if (kind === 'inspection') {
      const field = outputField(
        cap.outputSchema,
        c.comparison.path ?? [c.comparison.field],
      );
      if (!field) throw new Error('Unknown comparison output path');
      if (!this.ajv.compile(field)(c.comparison.value))
        throw new Error('Comparison value has wrong type');
      if (
        c.comparison.operator === 'at_least' &&
        !['number', 'integer'].includes(field.type)
      )
        throw new Error('at_least requires numeric output');
      if (c.mode === 'events' && !cap.evidenceStream)
        throw new Error('Capability has no event stream');
    }
  }
  validate(d) {
    if (d.stages.length > 16) throw new Error('Prototype stage limit is 16');
    for (const c of d.conditions) {
      this.checkCapability(d, c, 'inspection');
      if (c.mode === 'events' && c.since !== 'quest_start')
        this.stage(d, c.since.stageId);
    }
    for (const r of d.records) {
      this.stage(d, r.from ?? r.stageId);
      if (r.to) this.stage(d, r.to);
      if (r.kind === 'consequence') this.checkCapability(d, r, 'action');
      if (r.conditionId) {
        this.condition(d, r.conditionId);
      }
    }
    for (const s of d.stages) {
      if (s.interaction) this.condition(d, s.interaction);
      if (s.interaction && !s.dialogue)
        throw new Error('Interaction requirement needs dialogue');
      if (s.ending && d.records.some((r) => r.from === s.id))
        throw new Error('Ending cannot have outgoing routes/choices');
    }
  }
  compile(d) {
    const predicate = (conditionId) => {
      const c = this.condition(d, conditionId);
      return {
        tool: c.capability,
        arguments: this.arguments(d, c.arguments),
        expect: {
          path: c.comparison.path ?? [c.comparison.field],
          operator: c.comparison.operator,
          value: c.comparison.value,
        },
        evidence:
          c.mode === 'fact'
            ? { mode: 'fact' }
            : {
                mode: 'events',
                after:
                  c.since === 'quest_start'
                    ? { kind: 'run-start' }
                    : {
                        kind: 'situation-entry',
                        situationRef: c.since.stageId,
                      },
              },
      };
    };
    return {
      entrySituation: d.start,
      outcomeBindings: [],
      situations: d.stages.map((s) => {
        const node = { id: s.id };
        if (s.dialogue)
          node.dialogue = {
            text: s.dialogue,
            ...(s.interaction ? { requires: predicate(s.interaction) } : {}),
          };
        const routes = d.records.filter(
          (r) => r.kind === 'transition' && r.from === s.id,
        );
        const objectives = d.records.filter(
          (r) => r.kind === 'objective' && r.stageId === s.id,
        );
        if (objectives.length)
          node.objectives = objectives.map((r) => ({
            id: r.id,
            description: r.description,
            condition: predicate(r.conditionId),
          }));
        if (routes.length)
          node.routes = routes.map((r) => ({
            id: r.id,
            priority: r.priority,
            when: predicate(r.conditionId),
            next: r.to,
          }));
        const choices = d.records.filter(
          (r) => r.kind === 'choice' && r.from === s.id,
        );
        if (choices.length)
          node.choices = choices.map((r) => ({
            id: r.id,
            label: r.label,
            ...((r.conditionId ?? s.interaction)
              ? { when: predicate(r.conditionId ?? s.interaction) }
              : {}),
            next: r.to,
          }));
        const actions = d.records.filter(
          (r) => r.kind === 'consequence' && r.stageId === s.id,
        );
        if (actions.length)
          node.onEnter = actions.map((r) => ({
            id: r.id,
            tool: r.capability,
            arguments: this.arguments(d, r.arguments),
          }));
        return node;
      }),
    };
  }
  findings(d) {
    return [
      ...(!d.start ? [{ code: 'start_missing' }] : []),
      ...d.stages
        .filter((s) => !s.ending && !d.records.some((r) => r.from === s.id))
        .map((s) => ({ code: 'unfinished_stage', stageId: s.id })),
    ];
  }
  view(d) {
    const gloss = (conditionId) => {
      const c = this.condition(d, conditionId);
      return `${c.id}: ${c.capability} ${JSON.stringify(c.arguments)} ${(c.comparison.path ?? [c.comparison.field]).join('.')} ${c.comparison.operator} ${JSON.stringify(c.comparison.value)}; ${c.mode === 'fact' ? 'fact now' : 'events since ' + (c.since === 'quest_start' ? 'quest start' : c.since.stageId + ' entry')}`;
    };
    const esc = (s) =>
      String(s)
        .replaceAll('&', '&amp;')
        .replaceAll('"', '&quot;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('|', '&#124;')
        .replaceAll('\n', ' ');
    const lines = ['flowchart TD'];
    for (const s of d.stages)
      lines.push(
        `  ${s.id}["${esc(
          s.id +
            ': ' +
            s.title +
            (s.ending ? ' (ending)' : '') +
            (s.interaction ? '; interaction ' + gloss(s.interaction) : '') +
            d.records
              .filter((r) => r.kind === 'objective' && r.stageId === s.id)
              .map(
                (r) =>
                  '; objective ' +
                  r.id +
                  ': ' +
                  r.description +
                  '; ' +
                  gloss(r.conditionId),
              )
              .join('') +
            d.records
              .filter((r) => r.kind === 'consequence' && r.stageId === s.id)
              .map(
                (r) =>
                  '; enter ' +
                  r.id +
                  ': ' +
                  r.capability +
                  ' ' +
                  JSON.stringify(r.arguments),
              )
              .join(''),
        )}"]`,
      );
    for (const r of d.records.filter((r) => r.to))
      lines.push(
        `  ${r.from} -->|"${esc(r.id + ': ' + (r.label ? 'choice ' + r.label + '; ' : '') + ((r.conditionId ?? this.stage(d, r.from).interaction) ? gloss(r.conditionId ?? this.stage(d, r.from).interaction) : 'unguarded') + (r.priority !== undefined ? ' priority ' + r.priority : ''))}"| ${r.to}`,
      );
    return {
      draftId: d.id,
      revision: d.revision,
      intent: d.intent,
      publication: d.publication ?? null,
      startStageId: d.start,
      stages: d.stages,
      conditions: d.conditions.map((c) => ({
        ...c,
        usedBy: this.uses(d, c.id),
      })),
      records: d.records,
      findings: this.findings(d),
      mermaid: lines.join('\n'),
    };
  }
  async call(name, args) {
    try {
      if (!this.validators[name]?.(args)) {
        const known = this.state.drafts.find((d) => d.id === args?.draft?.id);
        return {
          status: 'rejected',
          code: 'invalid_input',
          message: `Invalid input for ${name}`,
          ...(known ? { draftId: known.id, revision: known.revision } : {}),
          findings: (this.validators[name]?.errors ?? []).map((e) => ({
            path:
              e.instancePath +
              (e.params.missingProperty ? '/' + e.params.missingProperty : ''),
            message: e.message,
          })),
        };
      }
      if (name === 'list_quest_drafts')
        return {
          status: 'completed',
          data: this.state.drafts.map((d) => ({
            draftId: d.id,
            revision: d.revision,
            title: d.intent.title,
          })),
        };
      const state = structuredClone(this.state);
      if (name === 'create_quest_draft') {
        const d = {
          id: 'draft-' + randomUUID(),
          revision: 1,
          intent: { title: args.title, premise: args.premise },
          nextId: 0,
          stages: [],
          conditions: [],
          records: [],
          start: null,
        };
        state.drafts.push(d);
        this.save(state);
        return {
          status: 'completed',
          draftId: d.id,
          revision: 1,
          created: { draftId: d.id },
          progress: { stages: 0, conditions: 0, records: 0 },
        };
      }
      const d = state.drafts.find(
        (d) => d.id === (args.draft?.id ?? args.draftId),
      );
      if (!d) throw new Error('Unknown draft');
      if (name === 'inspect_quest_draft')
        return { status: 'completed', data: this.view(d) };
      if (d.revision !== args.draft.revision)
        return {
          status: 'rejected',
          code: 'revision_conflict',
          draftId: d.id,
          revision: d.revision,
        };
      if (name === 'from_action_result') {
        const argument = {
          fromActionResult: { recordId: args.recordId, path: args.path },
        };
        this.reference(d, argument);
        return {
          status: 'completed',
          draftId: d.id,
          revision: d.revision,
          argument,
        };
      }
      if (d.publication) {
        if (name === 'publish_quest_draft')
          return {
            status: 'completed',
            publication: d.publication,
            draftId: d.id,
            revision: d.revision,
          };
        if (name === 'review_quest_draft')
          return {
            status: 'completed',
            draftId: d.id,
            revision: d.revision,
            technicalReady: true,
            findings: [],
            publication: d.publication,
          };
        return {
          status: 'rejected',
          code: 'draft_published',
          draftId: d.id,
          revision: d.revision,
          publication: d.publication,
        };
      }
      if (name === 'review_quest_draft' || name === 'publish_quest_draft') {
        const findings = this.findings(d);
        if (!findings.length) {
          const fragment = this.compile(d);
          findings.push(
            ...validateSituationDefinition(
              {
                proposalVersion: 'cfw-situations-draft-2',
                id: d.id,
                start: fragment.entrySituation,
                situations: fragment.situations,
              },
              this.capabilities.map((c) => ({
                ...c,
                validate: (args) => this.ajv.compile(c.inputSchema)(args),
              })),
            ).map((message) => ({ code: 'runtime_validation', message })),
          );
        }
        if (findings.length)
          return {
            status: name === 'review_quest_draft' ? 'completed' : 'rejected',
            draftId: d.id,
            revision: d.revision,
            technicalReady: false,
            findings,
          };
        const result = await this.host(
          name,
          structuredClone(this.compile(d)),
          d,
        );
        if (name === 'publish_quest_draft' && result.status === 'completed') {
          if (!result.publication?.definitionId || !result.publication?.digest)
            throw new Error(
              'Host publication must return definition identity and digest',
            );
          d.publication = { ...result.publication, sourceRevision: d.revision };
          this.save(state);
          return {
            ...result,
            publication: d.publication,
            draftId: d.id,
            revision: d.revision,
          };
        }
        return { ...result, draftId: d.id, revision: d.revision };
      }
      const { draft: ignored, ...value } = args;
      void ignored;
      const created = {};
      const newId = (prefix) => prefix + ++d.nextId;
      switch (name) {
        case 'update_quest_intent':
          d.intent = { title: args.title, premise: args.premise };
          break;
        case 'add_stage': {
          const s = {
            id: newId('s'),
            ...value,
            ending: false,
            interaction: null,
          };
          d.stages.push(s);
          created.stageId = s.id;
          break;
        }
        case 'update_stage': {
          const s = this.stage(d, args.stageId);
          Object.assign(s, { title: args.title, purpose: args.purpose });
          if (args.dialogue === null) delete s.dialogue;
          else s.dialogue = args.dialogue;
          break;
        }
        case 'remove_stage': {
          this.stage(d, args.stageId);
          const refs = [
            ...d.records
              .filter((r) => [r.from, r.to, r.stageId].includes(args.stageId))
              .map((r) => r.id),
            ...d.conditions
              .filter((c) => c.since?.stageId === args.stageId)
              .map((c) => c.id),
            ...(d.start === args.stageId ? ['start'] : []),
          ];
          if (refs.length)
            return {
              status: 'rejected',
              code: 'stage_referenced',
              referencingIds: refs,
              draftId: d.id,
              revision: d.revision,
            };
          d.stages = d.stages.filter((s) => s.id !== args.stageId);
          break;
        }
        case 'set_start_stage':
          this.stage(d, args.stageId);
          d.start = args.stageId;
          break;
        case 'create_fact_condition':
        case 'create_event_condition': {
          const c = {
            id: newId('c'),
            mode: name === 'create_fact_condition' ? 'fact' : 'events',
            ...value,
          };
          d.conditions.push(c);
          created.conditionId = c.id;
          break;
        }
        case 'update_condition': {
          const c = this.condition(d, args.conditionId);
          const usedBy = this.uses(d, c.id);
          if (
            JSON.stringify([...args.affectedRecordIds].sort()) !==
            JSON.stringify(usedBy)
          )
            return {
              status: 'rejected',
              code: 'condition_users_changed',
              affectedRecordIds: usedBy,
              draftId: d.id,
              revision: d.revision,
            };
          d.conditions[d.conditions.indexOf(c)] = {
            id: c.id,
            ...args.replacement,
          };
          break;
        }
        case 'remove_condition': {
          this.condition(d, args.conditionId);
          const usedBy = this.uses(d, args.conditionId);
          if (usedBy.length)
            return {
              status: 'rejected',
              code: 'condition_referenced',
              draftId: d.id,
              revision: d.revision,
              referencingIds: usedBy,
            };
          d.conditions = d.conditions.filter((c) => c.id !== args.conditionId);
          break;
        }
        case 'add_transition':
        case 'add_choice':
        case 'add_entry_consequence': {
          const r = {
            id: newId('r'),
            kind:
              name === 'add_transition'
                ? 'transition'
                : name === 'add_choice'
                  ? 'choice'
                  : 'consequence',
            ...value,
          };
          d.records.push(r);
          created.recordId = r.id;
          break;
        }
        case 'add_objective': {
          const r = { id: newId('r'), kind: 'objective', ...value };
          d.records.push(r);
          created.recordId = r.id;
          break;
        }
        case 'edit_record': {
          const i = d.records.findIndex((r) => r.id === args.recordId);
          if (i < 0) throw new Error('Unknown record');
          if (args.change.operation === 'remove') d.records.splice(i, 1);
          else {
            if (d.records[i].kind !== args.change.kind)
              throw new Error('Cannot change record kind');
            d.records[i] = {
              id: args.recordId,
              kind: args.change.kind,
              ...args.change.value,
            };
          }
          break;
        }
        case 'set_interaction_requirement':
          this.stage(d, args.stageId).interaction = args.conditionId;
          break;
        case 'declare_ending':
          this.stage(d, args.stageId).ending = args.ending;
          break;
        default:
          throw new Error('Unsupported tool');
      }
      this.validate(d);
      d.revision++;
      this.save(state);
      return {
        status: 'completed',
        draftId: d.id,
        revision: d.revision,
        created,
        change: name,
        changedId:
          created.stageId ??
          created.conditionId ??
          created.recordId ??
          args.stageId ??
          args.conditionId ??
          args.recordId,
        savedMeaning: args.recordId
          ? (d.records.find((r) => r.id === args.recordId) ?? {
              removed: args.recordId,
            })
          : args.conditionId
            ? (d.conditions.find((c) => c.id === args.conditionId) ?? {
                removed: args.conditionId,
              })
            : null,
        progress: {
          stages: d.stages.length,
          conditions: d.conditions.length,
          records: d.records.length,
        },
        findings: this.findings(d),
      };
    } catch (error) {
      const known = this.state.drafts.find((d) => d.id === args?.draft?.id);
      return {
        status: 'rejected',
        code: 'invalid_edit',
        message: error.message,
        ...(known ? { draftId: known.id, revision: known.revision } : {}),
      };
    }
  }
}
