import { immutable, isJson } from '../json.js';
import { record, shape, text } from './validation.js';

/** First authored graph slice: immutable, explicit, acyclic content without effects. */
export interface DialogueNode {
  readonly id: string;
  readonly text: string;
  readonly choices: readonly {
    readonly id: string;
    readonly label: string;
    readonly next: string;
  }[];
}
export interface DialogueGraphDefinition {
  readonly recipientRef: string;
  readonly title: string;
  readonly start: string;
  readonly nodes: readonly DialogueNode[];
}
const prose = (value: unknown, max: number): value is string =>
  text(value, max) &&
  value.trim().length > 0 &&
  !/[\uD800-\uDFFF]/u.test(value);
/** Identifier values are also bounded typed-feedback string references. */
export const dialogueReference = (value: unknown, max = 160): value is string =>
  prose(value, max) && !/\p{Cc}/u.test(value);
export function isDialogueNode(value: unknown): value is DialogueNode {
  if (
    !shape(value, ['id', 'text', 'choices']) ||
    !dialogueReference(value['id'], 80) ||
    !prose(value['text'], 2000) ||
    !Array.isArray(value['choices']) ||
    value['choices'].length > 4 ||
    !value['choices'].every(
      (choice: unknown) =>
        shape(choice, ['id', 'label', 'next']) &&
        dialogueReference(choice['id'], 80) &&
        prose(choice['label'], 200) &&
        dialogueReference(choice['next'], 80),
    )
  )
    return false;
  return (
    new Set(value['choices'].map((choice: { id: string }) => choice.id))
      .size === value['choices'].length
  );
}
/** Native CAI JSON leaves Unicode unescaped except U+2028/U+2029 (six ASCII bytes). */
function authorBytes(value: unknown): number {
  const encoded = JSON.stringify(value);
  let bytes = new TextEncoder().encode(encoded).byteLength;
  for (const character of encoded) {
    const point = character.codePointAt(0);
    if (point === 0x2028 || point === 0x2029) bytes += 3;
  }
  return bytes;
}
/** Includes the entire author input, not just displayed character counts. */
export function isDialogueGraph(
  value: unknown,
): value is DialogueGraphDefinition {
  try {
    if (
      !isJson(value) ||
      !shape(value, ['recipientRef', 'title', 'start', 'nodes']) ||
      !dialogueReference(value['recipientRef']) ||
      !prose(value['title'], 160) ||
      !dialogueReference(value['start'], 80) ||
      !Array.isArray(value['nodes']) ||
      value['nodes'].length < 1 ||
      value['nodes'].length > 16 ||
      !value['nodes'].every(isDialogueNode) ||
      authorBytes(value) > 65536
    )
      return false;
    const nodes = new Map(
      (value['nodes'] as unknown as readonly DialogueNode[]).map((node) => [
        node.id,
        node,
      ]),
    );
    if (nodes.size !== value['nodes'].length || !nodes.has(value['start']))
      return false;
    const visiting = new Set<string>(),
      visited = new Set<string>();
    const visit = (id: string): boolean => {
      const node = nodes.get(id);
      if (!node || visiting.has(id)) return false;
      if (visited.has(id)) return true;
      visiting.add(id);
      for (const choice of node.choices) if (!visit(choice.next)) return false;
      visiting.delete(id);
      visited.add(id);
      return true;
    };
    return visit(value['start']) && visited.size === nodes.size;
  } catch {
    return false;
  }
}
/** Pure incremental authoring; forward references validate only at finalization. */
export class DialogueDraft {
  readonly #header: Omit<DialogueGraphDefinition, 'nodes'>;
  readonly #nodes: DialogueNode[] = [];
  constructor(header: Omit<DialogueGraphDefinition, 'nodes'>) {
    if (
      !record(header) ||
      !shape(header, ['recipientRef', 'title', 'start']) ||
      !dialogueReference(header.recipientRef) ||
      !prose(header.title, 160) ||
      !dialogueReference(header.start, 80)
    )
      throw new TypeError('Invalid dialogue header.');
    this.#header = immutable(header);
  }
  addNode(node: DialogueNode): this {
    if (
      !isDialogueNode(node) ||
      this.#nodes.length >= 16 ||
      this.#nodes.some((entry) => entry.id === node.id)
    )
      throw new TypeError('Invalid or duplicate dialogue node.');
    this.#nodes.push(immutable(node));
    return this;
  }
  toInput(): DialogueGraphDefinition {
    const graph = { ...this.#header, nodes: this.#nodes };
    if (!isDialogueGraph(graph))
      throw new TypeError(
        'Dialogue requires a reachable acyclic graph within 64 KiB UTF-8 JSON.',
      );
    return immutable(graph);
  }
}
