import { isDialogueSave } from './DialogueStore.js';
import type { DialogueSave } from './DialogueStore.js';
import { isJson } from '../json.js';
import type { Json } from '../types.js';
import { destinations } from './flow.js';
import type {
  NarrativeEvent,
  NarrativeResult,
  OfferingPolicy,
  OfferingEvent,
  ObjectiveProgress,
  QuestDefinition,
} from './types.js';
import {
  canonical,
  validInput,
  integer,
  isQuest,
  isResult,
  record,
  shape,
  text,
} from './validation.js';

function validOwner(
  key: string,
  associationId: string,
  authorRef?: string,
): boolean {
  try {
    const value: unknown = JSON.parse(key);
    return (
      Array.isArray(value) &&
      value.length === 4 &&
      value[0] === associationId &&
      text(value[1]) &&
      text(value[2]) &&
      (authorRef === undefined || value[2] === authorRef) &&
      (value[3] === null ||
        (shape(value[3], ['characterId', 'sessionId']) &&
          text(value[3]['characterId']) &&
          text(value[3]['sessionId'])))
    );
  } catch {
    return false;
  }
}
function validReceipt(
  value: unknown,
  quests: readonly QuestRecord[],
  associationId: string,
  policies: readonly OfferingPolicy[] = [],
): value is Receipt {
  if (
    !shape(
      value,
      ['key', 'digest', 'result', 'bindingGeneration'],
      ['key', 'digest', 'result'],
    ) ||
    !text(value['key'], 1600) ||
    typeof value['digest'] !== 'string' ||
    !isResult(value['result'])
  )
    return false;
  try {
    const key: unknown = JSON.parse(value['key']),
      input: unknown = JSON.parse(value['digest']);
    if (
      !Array.isArray(key) ||
      key.length !== 3 ||
      !text(key[0], 1024) ||
      ![
        'create_quest',
        'offer_quest',
        'choose',
        'set_offering_access',
      ].includes(String(key[1])) ||
      !text(key[2]) ||
      !isJson(input) ||
      canonical(input) !== value['digest']
    )
      return false;
    const scope = key[0],
      tool: unknown = key[1];
    if (tool === 'choose') {
      const player: unknown = JSON.parse(scope);
      if (
        !Array.isArray(player) ||
        player.length !== 3 ||
        player[0] !== associationId ||
        player[1] !== 'player' ||
        !text(player[2])
      )
        return false;
    } else if (!validOwner(scope, associationId)) return false;
    if (
      tool === 'set_offering_access' &&
      !validInput('set_offering_access', input)
    )
      return false;
    if (
      tool !== 'set_offering_access' &&
      value['bindingGeneration'] !== undefined
    )
      return false;
    if (value['result'].status === 'rejected')
      return value['bindingGeneration'] === undefined;
    if (tool === 'set_offering_access' && !text(value['bindingGeneration']))
      return false;
    const data = value['result'].data;
    if (tool === 'set_offering_access') {
      if (
        !record(input) ||
        !shape(data, [
          'policyId',
          'characterRef',
          'recipientRef',
          'revision',
          'mode',
          'allowedQuestIds',
        ])
      )
        return false;
      const policy = policies.find((entry) => entry.id === data['policyId']);
      return Boolean(
        policy &&
        policy.ownerKey === scope &&
        data['characterRef'] === policy.characterRef &&
        data['recipientRef'] === policy.recipientRef &&
        input['recipientRef'] === policy.recipientRef &&
        integer(data['revision']) &&
        data['revision'] >= 1 &&
        data['revision'] <= policy.revision &&
        Array.isArray(data['allowedQuestIds']) &&
        data['allowedQuestIds'].every((id: unknown) =>
          quests.some(
            (quest) =>
              quest.id === id &&
              quest.ownerKey === scope &&
              quest.definition.recipientRef === policy.recipientRef,
          ),
        ) &&
        data['revision'] === Number(input['expectedRevision']) + 1 &&
        data['mode'] === input['mode'] &&
        Array.isArray(input['allowedQuestIds']) &&
        canonical(data['allowedQuestIds'] as Json) ===
          canonical([...input['allowedQuestIds']].sort()),
      );
    }
    if (!record(data) || !text(data['questId']) || !integer(data['revision']))
      return false;
    const quest = quests.find((entry) => entry.id === data['questId']);
    if (!quest || data['revision'] < 1 || data['revision'] > quest.revision)
      return false;
    if (tool === 'choose')
      return (
        record(input) &&
        input['recipientRef'] === quest.definition.recipientRef &&
        data['offerId'] === quest.offer?.id &&
        (data['status'] === 'active' || data['status'] === 'declined')
      );
    if (quest.ownerKey !== scope) return false;
    return tool === 'create_quest'
      ? data['authorRef'] === quest.authorRef && data['status'] === 'registered'
      : data['offerId'] === quest.offer?.id &&
          data['status'] === 'offered' &&
          data['recipientRef'] === quest.definition.recipientRef;
  } catch {
    return false;
  }
}

export interface QuestRecord {
  readonly id: string;
  readonly ownerKey: string;
  readonly authorRef: string;
  readonly definition: QuestDefinition;
  revision: number;
  offer: {
    id: string;
    dialogue: string;
    status: 'offered' | 'active' | 'completed' | 'declined';
  } | null;
  progress: ObjectiveProgress[];
  flowState?: { current: string; visited: string[] };
}
export interface Receipt {
  readonly key: string;
  readonly digest: string;
  readonly result: NarrativeResult;
  /** Original committed policy mutation generation, separate from replay authority. */
  readonly bindingGeneration?: string;
}
export interface NarrativeSave {
  readonly schemaVersion: 1;
  readonly associationId: string;
  readonly questSequence: number;
  readonly offerSequence: number;
  readonly eventSequence: number;
  readonly time: number;
  readonly quests: readonly QuestRecord[];
  readonly receipts: readonly Receipt[];
  readonly offeringPolicies?: readonly OfferingPolicy[];
  readonly offeringEvents?: readonly OfferingEvent[];
  readonly dialogue?: DialogueSave;
  readonly events: readonly NarrativeEvent[];
  readonly droppedEvents: number;
}
function questRecord(value: unknown): value is QuestRecord {
  if (
    !shape(
      value,
      [
        'id',
        'ownerKey',
        'authorRef',
        'definition',
        'revision',
        'offer',
        'progress',
        'flowState',
      ],
      [
        'id',
        'ownerKey',
        'authorRef',
        'definition',
        'revision',
        'offer',
        'progress',
      ],
    ) ||
    !text(value['id']) ||
    !text(value['ownerKey'], 1024) ||
    !text(value['authorRef']) ||
    !isQuest(value['definition']) ||
    !integer(value['revision']) ||
    value['revision'] < 1 ||
    !Array.isArray(value['progress'])
  )
    return false;
  const definition = value['definition'];
  if (
    new Set(definition.objectives.map((objective) => objective.id)).size !==
    definition.objectives.length
  )
    return false;
  const progress = value['progress'];
  if (
    progress.length !== definition.objectives.length ||
    !progress.every(
      (item: unknown, index) =>
        shape(item, ['id', 'status', 'observed']) &&
        item['id'] === definition.objectives[index]?.id &&
        ['pending', 'satisfied', 'unknown'].includes(String(item['status'])) &&
        isJson(item['observed']),
    )
  )
    return false;
  const offer = value['offer'];
  const flow = definition.flow;
  const flowState = value['flowState'];
  if (!flow && flowState !== undefined) return false;
  if (flow) {
    if (
      !shape(flowState, ['current', 'visited']) ||
      !text(flowState['current']) ||
      !Array.isArray(flowState['visited']) ||
      flowState['visited'].length < 1 ||
      flowState['visited'].length > flow.stages.length ||
      !flowState['visited'].every((id: unknown) => text(id)) ||
      new Set(flowState['visited']).size !== flowState['visited'].length ||
      flowState['visited'][0] !== flow.start ||
      flowState['visited'].at(-1) !== flowState['current']
    )
      return false;
    const path = flowState['visited'];
    for (const [index, id] of path.entries()) {
      const stage = flow.stages.find((entry) => entry.id === id);
      if (
        !stage ||
        (index > 0 &&
          !destinations(
            flow.stages.find((entry) => entry.id === path[index - 1]) ?? stage,
          ).includes(id))
      )
        return false;
      if (
        index < path.length - 1 &&
        !stage.objectives.every((objectiveId) =>
          progress.some(
            (entry: unknown) =>
              record(entry) &&
              entry['id'] === objectiveId &&
              entry['status'] === 'satisfied',
          ),
        )
      )
        return false;
    }
    const visitedObjectives = flow.stages
      .filter((entry) => path.includes(entry.id))
      .flatMap((entry) => [...entry.objectives]);
    if (
      progress.some(
        (entry: unknown) =>
          record(entry) &&
          !visitedObjectives.includes(String(entry['id'])) &&
          (entry['status'] !== 'pending' || entry['observed'] !== null),
      )
    )
      return false;
    if (
      (offer === null ||
        (record(offer) &&
          ['offered', 'declined'].includes(String(offer['status'])))) &&
      path.length !== 1
    )
      return false;
  }
  if (offer === null)
    return progress.every(
      (item: unknown) =>
        record(item) &&
        item['status'] === 'pending' &&
        item['observed'] === null,
    );
  if (
    !shape(offer, ['id', 'dialogue', 'status']) ||
    !text(offer['id']) ||
    !text(offer['dialogue'], 2000) ||
    !['offered', 'active', 'completed', 'declined'].includes(
      String(offer['status']),
    )
  )
    return false;
  if (offer['status'] === 'offered' || offer['status'] === 'declined')
    return progress.every(
      (item: unknown) =>
        record(item) &&
        item['status'] === 'pending' &&
        item['observed'] === null,
    );
  const allSatisfied = progress.every(
    (item: unknown) => record(item) && item['status'] === 'satisfied',
  );
  if (flow && record(flowState)) {
    const current = flow.stages.find(
      (entry) => entry.id === flowState['current'],
    );
    if (!current) return false;
    const stageSatisfied = current.objectives.every((id) =>
      progress.some(
        (entry: unknown) =>
          record(entry) &&
          entry['id'] === id &&
          entry['status'] === 'satisfied',
      ),
    );
    return offer['status'] === 'completed'
      ? stageSatisfied && destinations(current).length === 0
      : !stageSatisfied || Boolean(current.choices);
  }
  return offer['status'] === 'completed' ? allSatisfied : !allSatisfied;
}
export function isNarrativeSave(value: unknown): value is NarrativeSave {
  if (
    record(value) &&
    value['dialogue'] !== undefined &&
    (!text(value['associationId']) ||
      !isDialogueSave(value['dialogue'], value['associationId']) ||
      !Array.isArray(value['receipts']) ||
      value['receipts'].length + value['dialogue'].receipts.length > 4096)
  )
    return false;
  if (
    !shape(
      value,
      [
        'schemaVersion',
        'associationId',
        'questSequence',
        'offerSequence',
        'eventSequence',
        'time',
        'quests',
        'receipts',
        'events',
        'droppedEvents',
        'offeringPolicies',
        'offeringEvents',
        'dialogue',
      ],
      [
        'schemaVersion',
        'associationId',
        'questSequence',
        'offerSequence',
        'eventSequence',
        'time',
        'quests',
        'receipts',
        'events',
        'droppedEvents',
      ],
    ) ||
    value['schemaVersion'] !== 1 ||
    !text(value['associationId']) ||
    !integer(value['questSequence']) ||
    !integer(value['offerSequence']) ||
    !integer(value['eventSequence']) ||
    !integer(value['droppedEvents']) ||
    typeof value['time'] !== 'number' ||
    !Number.isFinite(value['time']) ||
    value['time'] < 0
  )
    return false;
  const associationId = value['associationId'];
  const quests = value['quests'];
  if (
    !Array.isArray(quests) ||
    quests.length > 256 ||
    !quests.every(questRecord)
  )
    return false;
  if (
    !quests.every((quest) =>
      validOwner(quest.ownerKey, associationId, quest.authorRef),
    )
  )
    return false;
  if (new Set(quests.map((quest) => quest.id)).size !== quests.length)
    return false;
  const offers = quests.flatMap((quest) =>
    quest.offer ? [quest.offer.id] : [],
  );
  if (new Set(offers).size !== offers.length) return false;
  if (
    !quests.every(
      (quest) =>
        /^quest-[1-9][0-9]*$/.test(quest.id) &&
        Number(quest.id.slice(6)) <= Number(value['questSequence']) &&
        (!quest.offer ||
          (/^offer-[1-9][0-9]*$/.test(quest.offer.id) &&
            Number(quest.offer.id.slice(6)) <= Number(value['offerSequence']))),
    )
  )
    return false;
  const policies = value['offeringPolicies'] ?? [];
  if (
    !Array.isArray(policies) ||
    policies.length > 256 ||
    !policies.every((policy: unknown) => {
      if (
        !shape(policy, [
          'id',
          'ownerKey',
          'characterRef',
          'recipientRef',
          'revision',
          'mode',
          'allowedQuestIds',
        ]) ||
        !text(policy['id']) ||
        !text(policy['ownerKey'], 1024) ||
        !text(policy['characterRef']) ||
        !text(policy['recipientRef']) ||
        !integer(policy['revision']) ||
        policy['revision'] < 1 ||
        !['open', 'restricted'].includes(String(policy['mode'])) ||
        !Array.isArray(policy['allowedQuestIds']) ||
        policy['allowedQuestIds'].length > 16 ||
        new Set(policy['allowedQuestIds']).size !==
          policy['allowedQuestIds'].length ||
        (policy['mode'] === 'open' && policy['allowedQuestIds'].length !== 0) ||
        !validOwner(policy['ownerKey'], associationId, policy['characterRef'])
      )
        return false;
      return policy['allowedQuestIds'].every(
        (id: unknown) =>
          text(id) &&
          quests.some(
            (quest) =>
              quest.id === id &&
              quest.ownerKey === policy['ownerKey'] &&
              quest.definition.recipientRef === policy['recipientRef'],
          ),
      );
    })
  )
    return false;
  const typedPolicies = policies as OfferingPolicy[];
  if (
    new Set(typedPolicies.map((policy) => policy.id)).size !==
      typedPolicies.length ||
    new Set(
      typedPolicies.map((policy) =>
        canonical([policy.ownerKey, policy.recipientRef]),
      ),
    ).size !== typedPolicies.length
  )
    return false;
  if (
    !Array.isArray(value['receipts']) ||
    value['receipts'].length > 4096 ||
    !value['receipts'].every((receipt: unknown) =>
      validReceipt(receipt, quests, associationId, typedPolicies),
    )
  )
    return false;
  if (
    new Set(value['receipts'].map((receipt) => receipt.key)).size !==
    value['receipts'].length
  )
    return false;
  if (
    !typedPolicies.every((policy) =>
      (value['receipts'] as Receipt[]).some((receipt) => {
        if (
          receipt.result.status !== 'completed' ||
          !record(receipt.result.data)
        )
          return false;
        const key: unknown = JSON.parse(receipt.key),
          data = receipt.result.data;
        return (
          Array.isArray(key) &&
          key[0] === policy.ownerKey &&
          key[1] === 'set_offering_access' &&
          data['policyId'] === policy.id &&
          data['revision'] === policy.revision &&
          data['mode'] === policy.mode &&
          canonical(data['allowedQuestIds'] as Json) ===
            canonical([...policy.allowedQuestIds])
        );
      }),
    )
  )
    return false;
  const committedPolicies = value['receipts']
    .filter((receipt) => {
      const key: unknown = JSON.parse(receipt.key);
      return (
        Array.isArray(key) &&
        key[1] === 'set_offering_access' &&
        receipt.result.status === 'completed'
      );
    })
    .map((receipt) =>
      receipt.result.status === 'completed' ? receipt.result.data : null,
    );
  const committedKeys = committedPolicies.map((data) =>
    record(data)
      ? canonical([data['policyId'] ?? null, data['revision'] ?? null])
      : 'invalid',
  );
  if (
    new Set(committedKeys).size !== committedKeys.length ||
    typedPolicies.some(
      (policy) =>
        committedPolicies.filter(
          (data) => record(data) && data['policyId'] === policy.id,
        ).length !== policy.revision,
    )
  )
    return false;
  const sources = value['offeringEvents'] ?? [];
  if (
    !Array.isArray(sources) ||
    sources.length > 256 ||
    !sources.every((event: unknown) => {
      if (
        !shape(event, [
          'id',
          'bindingGeneration',
          'policyId',
          'ownerKey',
          'characterRef',
          'recipientRef',
          'revision',
          'mode',
        ]) ||
        !text(event['id']) ||
        !text(event['bindingGeneration']) ||
        !integer(event['revision']) ||
        event['revision'] < 1
      )
        return false;
      const policy = typedPolicies.find(
        (entry) => entry.id === event['policyId'],
      );
      if (
        !policy ||
        event['id'] !== policy.id + '/' + String(event['revision']) ||
        event['revision'] > policy.revision ||
        event['ownerKey'] !== policy.ownerKey ||
        event['characterRef'] !== policy.characterRef ||
        event['recipientRef'] !== policy.recipientRef
      )
        return false;
      return (value['receipts'] as Receipt[]).some((receipt) => {
        const key: unknown = JSON.parse(receipt.key);
        if (
          !Array.isArray(key) ||
          key[1] !== 'set_offering_access' ||
          receipt.result.status !== 'completed' ||
          !record(receipt.result.data)
        )
          return false;
        const data = receipt.result.data;
        return (
          key[0] === policy.ownerKey &&
          data['policyId'] === policy.id &&
          data['revision'] === event['revision'] &&
          data['mode'] === event['mode'] &&
          receipt.bindingGeneration === event['bindingGeneration']
        );
      });
    }) ||
    new Set(sources.map((event: OfferingEvent) => event.id)).size !==
      sources.length
  )
    return false;
  if (
    !Array.isArray(value['events']) ||
    value['events'].length > 512 ||
    !value['events'].every(
      (event: unknown) =>
        shape(
          event,
          [
            'id',
            'origin',
            'type',
            'characterRef',
            'questId',
            'recipientRef',
            'revision',
            'stageId',
            'choiceId',
          ],
          [
            'id',
            'origin',
            'type',
            'characterRef',
            'questId',
            'recipientRef',
            'revision',
          ],
        ) &&
        text(event['id'], 220) &&
        event['origin'] === 'framework_narrative' &&
        [
          'quest_created',
          'quest_offered',
          'quest_accepted',
          'quest_declined',
          'quest_progressed',
          'quest_stage_entered',
          'quest_branch_selected',
          'quest_completed',
        ].includes(String(event['type'])) &&
        text(event['characterRef']) &&
        text(event['questId']) &&
        text(event['recipientRef']) &&
        integer(event['revision']) &&
        event['revision'] >= 1 &&
        quests.some(
          (quest) =>
            quest.id === event['questId'] &&
            quest.authorRef === event['characterRef'] &&
            quest.definition.recipientRef === event['recipientRef'] &&
            quest.revision >= Number(event['revision']) &&
            (event['stageId'] === undefined ||
              quest.definition.flow?.stages.some(
                (stage) => stage.id === event['stageId'],
              )) &&
            (event['choiceId'] === undefined ||
              (event['type'] === 'quest_branch_selected' &&
                quest.definition.flow?.stages.some(
                  (stage) =>
                    stage.id === event['stageId'] &&
                    stage.choices?.some(
                      (choice) =>
                        `${quest.id}/stage/${encodeURIComponent(stage.id)}/${encodeURIComponent(choice.id)}` ===
                        event['choiceId'],
                    ),
                ))),
        ),
    )
  )
    return false;
  return (
    new Set(
      value['events'].map((event: Record<string, unknown>) => event['id']),
    ).size === value['events'].length &&
    value['events'].every(
      (event: Record<string, unknown>) =>
        typeof event['id'] === 'string' &&
        event['id'].startsWith(
          String(value['associationId']) + '/narrative-event-',
        ) &&
        /^[1-9][0-9]*$/.test(event['id'].split('/narrative-event-')[1] ?? '') &&
        Number(event['id'].split('/narrative-event-')[1]) <=
          Number(value['eventSequence']),
    )
  );
}
