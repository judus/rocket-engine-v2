import { immutable, isJson } from '../json.js';
import type { CharacterDefinition, Json } from '../types.js';
import type { NarrativeResult } from './types.js';
import { dialogueReference, isDialogueGraph } from './dialogue.js';
import type { DialogueGraphDefinition } from './dialogue.js';
import {
  canonical,
  complete,
  integer,
  isResult,
  record,
  reject,
  shape,
  text,
} from './validation.js';
export type DialogueTool =
  'create_dialogue_graph' | 'start_dialogue_graph' | 'inspect_dialogue_graph';
interface Graph {
  readonly id: string;
  readonly ownerKey: string;
  readonly characterRef: string;
  readonly definition: DialogueGraphDefinition;
}
interface Instance {
  readonly id: string;
  readonly graphId: string;
  path: string[];
}
interface Receipt {
  readonly key: string;
  readonly digest: string;
  readonly result: NarrativeResult;
  readonly bindingGeneration?: string;
}
export interface DialogueSource {
  readonly id: string;
  readonly ownerKey: string;
  readonly bindingGeneration: string;
  readonly characterRef: string;
  readonly recipientRef: string;
  readonly graphId: string;
  readonly instanceId: string;
  readonly revision: number;
  readonly nodeId: string;
  readonly type: 'dialogue_started' | 'dialogue_selected' | 'dialogue_closed';
}
export interface DialogueSave {
  readonly graphs: readonly Graph[];
  readonly instances: readonly Instance[];
  readonly receipts: readonly Receipt[];
  readonly sources: readonly DialogueSource[];
}
function ownerValid(
  key: string,
  associationId: string,
  actor: string,
): boolean {
  try {
    const v: unknown = JSON.parse(key);
    return (
      Array.isArray(v) &&
      v.length === 4 &&
      v[0] === associationId &&
      text(v[1]) &&
      v[2] === actor &&
      (v[3] === null ||
        (shape(v[3], ['characterId', 'sessionId']) &&
          text(v[3]['characterId']) &&
          text(v[3]['sessionId'])))
    );
  } catch {
    return false;
  }
}
function uuid(value: unknown): value is string {
  return (
    typeof value === 'string' &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u.test(
      value,
    )
  );
}
function nodeAt(
  graph: Graph,
  instance: Instance,
  revision = instance.path.length - 1,
) {
  const node = graph.definition.nodes.find(
    (n) => n.id === instance.path[revision],
  );
  if (!node) throw new TypeError('Dialogue node missing.');
  return node;
}
function view(
  graph: Graph,
  instance: Instance,
  revision = instance.path.length - 1,
): Json {
  const node = nodeAt(graph, instance, revision);
  return {
    graphId: graph.id,
    instanceId: instance.id,
    characterRef: graph.characterRef,
    recipientRef: graph.definition.recipientRef,
    revision,
    nodeId: node.id,
    text: node.text,
    closed: node.choices.length === 0,
    choices: node.choices.map((choice, index) => ({
      id: `dlg/${instance.id}/${String(revision)}/${String(index)}`,
      label: choice.label,
    })),
  };
}
function source(
  graph: Graph,
  instance: Instance,
  generation: string,
  revision = instance.path.length - 1,
): DialogueSource {
  const node = nodeAt(graph, instance, revision);
  return {
    id: `${instance.id}/${String(revision)}`,
    ownerKey: graph.ownerKey,
    bindingGeneration: generation,
    characterRef: graph.characterRef,
    recipientRef: graph.definition.recipientRef,
    graphId: graph.id,
    instanceId: instance.id,
    revision,
    nodeId: node.id,
    type:
      node.choices.length === 0
        ? 'dialogue_closed'
        : revision === 0
          ? 'dialogue_started'
          : 'dialogue_selected',
  };
}
export function validDialogueInput(
  tool: DialogueTool,
  input: unknown,
): boolean {
  return tool === 'create_dialogue_graph'
    ? isDialogueGraph(input)
    : tool === 'start_dialogue_graph'
      ? shape(input, ['graphId']) && uuid(input['graphId'])
      : shape(input, ['instanceId']) && uuid(input['instanceId']);
}
/** Validate all retained successful commits against immutable definitions and path history. */
export function isDialogueSave(
  value: unknown,
  associationId: string,
): value is DialogueSave {
  try {
    if (
      !isJson(value) ||
      !shape(value, ['graphs', 'instances', 'receipts', 'sources']) ||
      !Array.isArray(value['graphs']) ||
      value['graphs'].length > 256 ||
      !Array.isArray(value['instances']) ||
      value['instances'].length > 256 ||
      !Array.isArray(value['receipts']) ||
      value['receipts'].length > 4096 ||
      !Array.isArray(value['sources']) ||
      value['sources'].length > 256
    )
      return false;
    const graphs = value['graphs'] as unknown as Graph[],
      instances = value['instances'] as unknown as Instance[],
      receipts = value['receipts'] as unknown as Receipt[],
      sources = value['sources'] as unknown as DialogueSource[];
    if (
      !graphs.every(
        (g) =>
          shape(g, ['id', 'ownerKey', 'characterRef', 'definition']) &&
          uuid(g.id) &&
          text(g.ownerKey, 1024) &&
          dialogueReference(g.characterRef) &&
          ownerValid(g.ownerKey, associationId, g.characterRef) &&
          isDialogueGraph(g.definition),
      ) ||
      new Set(graphs.map((g) => g.id)).size !== graphs.length
    )
      return false;
    const active = new Set<string>();
    for (const instance of instances) {
      if (
        !shape(instance, ['id', 'graphId', 'path']) ||
        !uuid(instance.id) ||
        !uuid(instance.graphId) ||
        !Array.isArray(instance.path) ||
        instance.path.length < 1 ||
        instance.path.length > 16 ||
        !instance.path.every((id) => text(id, 80))
      )
        return false;
      const graph = graphs.find((g) => g.id === instance.graphId);
      if (
        !graph ||
        instance.path[0] !== graph.definition.start ||
        new Set(instance.path).size !== instance.path.length
      )
        return false;
      for (let i = 0; i < instance.path.length; i++) {
        const node = nodeAt(graph, instance, i);
        if (
          i + 1 < instance.path.length &&
          !node.choices.some((c) => c.next === instance.path[i + 1])
        )
          return false;
      }
      if (nodeAt(graph, instance).choices.length) {
        const scope = canonical([
          graph.ownerKey,
          graph.definition.recipientRef,
        ]);
        if (active.has(scope)) return false;
        active.add(scope);
      }
    }
    if (new Set(instances.map((i) => i.id)).size !== instances.length)
      return false;
    const graphCommits = new Set<string>(),
      instanceCommits = new Set<string>(),
      revisionCommits = new Map<string, Receipt>(),
      keys = new Set<string>();
    for (const receipt of receipts) {
      if (
        !shape(
          receipt,
          ['key', 'digest', 'result', 'bindingGeneration'],
          ['key', 'digest', 'result'],
        ) ||
        !text(receipt.key, 1600) ||
        typeof receipt.digest !== 'string' ||
        !isResult(receipt.result) ||
        keys.has(receipt.key)
      )
        return false;
      keys.add(receipt.key);
      const key: unknown = JSON.parse(receipt.key),
        input: unknown = JSON.parse(receipt.digest);
      if (
        !Array.isArray(key) ||
        key.length !== 3 ||
        !text(key[0], 1024) ||
        !text(key[2]) ||
        !isJson(input) ||
        canonical(input) !== receipt.digest ||
        ![
          'create_dialogue_graph',
          'start_dialogue_graph',
          'dialogue_choose',
        ].includes(String(key[1]))
      )
        return false;
      const tool = String(key[1]),
        scope = key[0];
      if (tool === 'dialogue_choose') {
        const player: unknown = JSON.parse(scope);
        if (
          !Array.isArray(player) ||
          player.length !== 3 ||
          player[0] !== associationId ||
          player[1] !== 'player' ||
          !text(player[2]) ||
          !shape(input, ['recipientRef', 'choiceId']) ||
          input['recipientRef'] !== player[2] ||
          !text(input['choiceId'])
        )
          return false;
      } else if (
        !ownerValid(
          scope,
          associationId,
          String((JSON.parse(scope) as unknown[])[2]),
        )
      )
        return false;
      if (receipt.result.status === 'rejected') {
        if (receipt.bindingGeneration !== undefined) return false;
        continue;
      }
      if (!text(receipt.bindingGeneration) || !record(receipt.result.data))
        return false;
      const data = receipt.result.data;
      if (tool === 'create_dialogue_graph') {
        const graph = graphs.find((g) => g.id === data['graphId']);
        if (
          !graph ||
          graph.ownerKey !== scope ||
          !isDialogueGraph(input) ||
          canonical(input) !== canonical(graph.definition as unknown as Json) ||
          graphCommits.has(graph.id) ||
          canonical(data) !==
            canonical({
              graphId: graph.id,
              characterRef: graph.characterRef,
              recipientRef: graph.definition.recipientRef,
              nodeCount: graph.definition.nodes.length,
            })
        )
          return false;
        graphCommits.add(graph.id);
        continue;
      }
      const instance = instances.find((i) => i.id === data['instanceId']);
      const graph = graphs.find((g) => g.id === instance?.graphId);
      if (
        !instance ||
        !graph ||
        !integer(data['revision']) ||
        data['revision'] >= instance.path.length ||
        canonical(data) !== canonical(view(graph, instance, data['revision']))
      )
        return false;
      const rev = data['revision'],
        revisionKey = `${instance.id}/${String(rev)}`;
      if (revisionCommits.has(revisionKey)) return false;
      if (tool === 'start_dialogue_graph') {
        if (
          scope !== graph.ownerKey ||
          !shape(input, ['graphId']) ||
          input['graphId'] !== graph.id ||
          rev !== 0 ||
          instanceCommits.has(instance.id)
        )
          return false;
        instanceCommits.add(instance.id);
      } else {
        if (
          !shape(input, ['recipientRef', 'choiceId']) ||
          input['recipientRef'] !== graph.definition.recipientRef ||
          rev < 1
        )
          return false;
        const before = nodeAt(graph, instance, rev - 1),
          index = before.choices.findIndex(
            (c) =>
              c.next === instance.path[rev] &&
              input['choiceId'] ===
                `dlg/${instance.id}/${String(rev - 1)}/${String(before.choices.indexOf(c))}`,
          );
        if (index < 0) return false;
      }
      revisionCommits.set(revisionKey, receipt);
    }
    if (
      graphCommits.size !== graphs.length ||
      instanceCommits.size !== instances.length ||
      instances.some((i) =>
        i.path.some((_, rev) => !revisionCommits.has(`${i.id}/${String(rev)}`)),
      )
    )
      return false;
    const sourceIds = new Set<string>();
    for (const event of sources) {
      if (
        !shape(event, [
          'id',
          'ownerKey',
          'bindingGeneration',
          'characterRef',
          'recipientRef',
          'graphId',
          'instanceId',
          'revision',
          'nodeId',
          'type',
        ]) ||
        !integer(event.revision) ||
        sourceIds.has(event.id)
      )
        return false;
      sourceIds.add(event.id);
      const instance = instances.find((i) => i.id === event.instanceId),
        graph = graphs.find((g) => g.id === instance?.graphId),
        receipt = revisionCommits.get(event.id);
      if (
        !instance ||
        !graph ||
        !receipt?.bindingGeneration ||
        canonical(event as unknown as Json) !==
          canonical(
            source(
              graph,
              instance,
              receipt.bindingGeneration,
              event.revision,
            ) as unknown as Json,
          )
      )
        return false;
    }
    return true;
  } catch {
    return false;
  }
}
/** Internal component owned and advanced exclusively by the shared NarrativeSystem. */
export class DialogueStore {
  #graphs: Graph[] = [];
  #instances: Instance[] = [];
  #receipts = new Map<string, Receipt>();
  #sources: DialogueSource[] = [];
  constructor(readonly associationId: string) {}
  get receiptCount() {
    return this.#receipts.size;
  }
  save(): DialogueSave {
    return immutable({
      graphs: this.#graphs,
      instances: this.#instances,
      receipts: [...this.#receipts.values()],
      sources: this.#sources,
    });
  }
  restore(saved: DialogueSave | undefined) {
    this.#graphs = structuredClone([...(saved?.graphs ?? [])]);
    this.#instances = structuredClone([...(saved?.instances ?? [])]);
    this.#receipts = new Map(
      (saved?.receipts ?? []).map((r) => [r.key, immutable(r)]),
    );
    this.#sources = structuredClone([...(saved?.sources ?? [])]);
  }
  sources() {
    return immutable(this.#sources);
  }
  acknowledge(id: string) {
    this.#sources = this.#sources.filter((s) => s.id !== id);
  }
  #mutate(
    scope: string,
    tool: string,
    effect: string | undefined,
    input: Json,
    generation: () => string | undefined,
    externalReceipts: number,
    run: () => NarrativeResult,
  ): NarrativeResult {
    if (!text(effect))
      return reject('missing_effect_key', 'A stable effect key is required.');
    const key = JSON.stringify([scope, tool, effect]),
      digest = canonical(input),
      old = this.#receipts.get(key);
    if (old)
      return old.digest === digest
        ? immutable(old.result)
        : reject(
            'effect_key_conflict',
            'Effect key reused with different arguments.',
          );
    if (this.#receipts.size + externalReceipts >= 4096)
      return reject('capacity_exceeded', 'Narrative receipt capacity reached.');
    const witness = generation();
    const result = immutable(run());
    if (result.status === 'completed' && !text(witness))
      throw new Error('Missing current generation.');
    this.#receipts.set(
      key,
      immutable({
        key,
        digest,
        result,
        ...(result.status === 'completed' && text(witness)
          ? { bindingGeneration: witness }
          : {}),
      }),
    );
    return result;
  }
  call(
    tool: DialogueTool,
    input: Json,
    character: CharacterDefinition,
    ownerKey: string,
    effect: string | undefined,
    externalReceipts: number,
    available: () => boolean,
  ): NarrativeResult {
    const run = () => {
      if (!validDialogueInput(tool, input) || !record(input))
        return reject('invalid_arguments', 'Invalid bounded dialogue input.');
      if (tool === 'create_dialogue_graph') {
        if (!dialogueReference(character.id))
          return reject(
            'invalid_author',
            'Character reference cannot be delivered as typed feedback.',
          );
        if (!available())
          return reject('recipient_unavailable', 'Recipient unavailable.');
        if (this.#graphs.length >= 256)
          return reject(
            'capacity_exceeded',
            'Dialogue definition capacity reached.',
          );
        const graph: Graph = immutable({
          id: crypto.randomUUID(),
          ownerKey,
          characterRef: character.id,
          definition: input as unknown as DialogueGraphDefinition,
        });
        this.#graphs.push(graph);
        return complete({
          graphId: graph.id,
          characterRef: graph.characterRef,
          recipientRef: graph.definition.recipientRef,
          nodeCount: graph.definition.nodes.length,
        });
      }
      if (tool === 'inspect_dialogue_graph') {
        const instance = this.#instances.find(
            (i) => i.id === input['instanceId'],
          ),
          graph = this.#graphs.find(
            (g) => g.id === instance?.graphId && g.ownerKey === ownerKey,
          );
        return instance && graph
          ? complete(view(graph, instance))
          : reject('dialogue_unavailable', 'Dialogue instance unavailable.');
      }
      const graph = this.#graphs.find(
        (g) => g.id === input['graphId'] && g.ownerKey === ownerKey,
      );
      if (!graph)
        return reject('dialogue_unavailable', 'Dialogue graph unavailable.');
      if (!available())
        return reject('recipient_unavailable', 'Recipient unavailable.');
      if (
        this.#instances.some((i) => {
          const g = this.#graphs.find((entry) => entry.id === i.graphId);
          return (
            g?.ownerKey === ownerKey &&
            g.definition.recipientRef === graph.definition.recipientRef &&
            nodeAt(g, i).choices.length > 0
          );
        })
      )
        return reject(
          'dialogue_busy',
          'An authored dialogue is already active.',
        );
      if (this.#instances.length >= 256 || this.#sources.length >= 256)
        return reject(
          'capacity_exceeded',
          'Dialogue instance or source capacity reached.',
        );
      const generation = character.binding?.generation;
      if (!text(generation))
        return reject('unregistered', 'Current generation required.');
      const instance: Instance = {
        id: crypto.randomUUID(),
        graphId: graph.id,
        path: [graph.definition.start],
      };
      this.#instances.push(instance);
      this.#sources.push(immutable(source(graph, instance, generation)));
      return complete(view(graph, instance));
    };
    return tool === 'inspect_dialogue_graph'
      ? run()
      : this.#mutate(
          ownerKey,
          tool,
          effect,
          input,
          () => character.binding?.generation,
          externalReceipts,
          run,
        );
  }
  recipient(tool: DialogueTool, input: Json): string | undefined {
    if (!record(input)) return undefined;
    return tool === 'create_dialogue_graph'
      ? typeof input['recipientRef'] === 'string'
        ? input['recipientRef']
        : undefined
      : this.#graphs.find((g) => g.id === input['graphId'])?.definition
          .recipientRef;
  }
  choose(
    recipient: string,
    choiceId: string,
    effect: string,
    externalReceipts: number,
    owner: (key: string) => CharacterDefinition | null,
    available: (character: CharacterDefinition) => boolean,
  ): NarrativeResult {
    if (!text(recipient) || !text(choiceId))
      return reject(
        'invalid_arguments',
        'Bounded player/choice references required.',
      );
    const parts = /^dlg\/([0-9a-f-]{36})\/(\d+)\/(\d+)$/u.exec(choiceId),
      instance = this.#instances.find((i) => i.id === parts?.[1]),
      graph = this.#graphs.find((g) => g.id === instance?.graphId);
    const current = () => (graph ? owner(graph.ownerKey) : null);
    return this.#mutate(
      JSON.stringify([this.associationId, 'player', recipient]),
      'dialogue_choose',
      effect,
      { recipientRef: recipient, choiceId },
      () => current()?.binding?.generation,
      externalReceipts,
      () => {
        if (
          !instance ||
          !graph ||
          !parts ||
          graph.definition.recipientRef !== recipient ||
          Number(parts[2]) !== instance.path.length - 1
        )
          return reject(
            'choice_unavailable',
            'Dialogue choice is stale or foreign.',
          );
        const character = current();
        if (!character || !available(character))
          return reject(
            'recipient_unavailable',
            'Current dialogue authority unavailable.',
          );
        const node = nodeAt(graph, instance),
          index = Number(parts[3]),
          choice = node.choices[index];
        if (
          !choice ||
          choiceId !==
            `dlg/${instance.id}/${String(instance.path.length - 1)}/${String(index)}`
        )
          return reject('choice_unavailable', 'Dialogue choice unavailable.');
        if (this.#sources.length >= 256)
          return reject(
            'capacity_exceeded',
            'Dialogue source capacity reached.',
          );
        const generation = character.binding?.generation;
        if (!text(generation))
          return reject('unregistered', 'Current generation required.');
        instance.path.push(choice.next);
        this.#sources.push(immutable(source(graph, instance, generation)));
        return complete(view(graph, instance));
      },
    );
  }
}
