import { isDialogueGraph } from './dialogue.js';
import { immutable, isJson } from '../json.js';
import { isFlow, isFlowShape } from './flow.js';
import type { Json } from '../types.js';
import type {
  Condition,
  NarrativeResult,
  Objective,
  QuestDefinition,
  Rejection,
  ToolName,
} from './types.js';

export const record = (value: unknown): value is Record<string, unknown> =>
  value !== null &&
  typeof value === 'object' &&
  !Array.isArray(value) &&
  Object.getPrototypeOf(value) === Object.prototype;
export const text = (value: unknown, max = 160): value is string =>
  typeof value === 'string' && value.length > 0 && value.length <= max;
export const integer = (value: unknown): value is number =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 0;
export function shape(
  value: unknown,
  keys: readonly string[],
  required = keys,
): value is Record<string, unknown> {
  return (
    record(value) &&
    Object.keys(value).every((key) => keys.includes(key)) &&
    required.every((key) => Object.hasOwn(value, key))
  );
}
export function isCondition(value: unknown): value is Condition {
  if (
    !shape(value, ['tool', 'arguments', 'expect']) ||
    !text(value['tool']) ||
    !record(value['arguments']) ||
    Object.keys(value['arguments']).length > 16 ||
    !isJson(value['arguments'])
  )
    return false;
  const expectation = value['expect'];
  if (!shape(expectation, ['path', 'operator', 'value'])) return false;
  return (
    Array.isArray(expectation['path']) &&
    expectation['path'].length >= 1 &&
    expectation['path'].length <= 8 &&
    expectation['path'].every((part: unknown) => text(part, 80)) &&
    (expectation['operator'] === 'equals' ||
      expectation['operator'] === 'at_least') &&
    (expectation['value'] === null ||
      typeof expectation['value'] === 'boolean' ||
      typeof expectation['value'] === 'string' ||
      (typeof expectation['value'] === 'number' &&
        Number.isFinite(expectation['value'])))
  );
}
export function isObjective(value: unknown): value is Objective {
  return (
    shape(value, ['id', 'description', 'condition']) &&
    text(value['id']) &&
    text(value['description'], 1000) &&
    isCondition(value['condition'])
  );
}
export function isQuest(value: unknown): value is QuestDefinition {
  return (
    shape(
      value,
      ['recipientRef', 'title', 'summary', 'objectives', 'flow'],
      ['recipientRef', 'title', 'summary', 'objectives'],
    ) &&
    text(value['recipientRef']) &&
    text(value['title']) &&
    text(value['summary'], 2000) &&
    Array.isArray(value['objectives']) &&
    value['objectives'].length >= 1 &&
    value['objectives'].length <= 8 &&
    value['objectives'].every(isObjective) &&
    (value['flow'] === undefined ||
      isFlow(
        value['flow'],
        value['objectives'].map((objective: Objective) => objective.id),
      ))
  );
}
export function isDraftDefinition(value: unknown): value is QuestDefinition {
  return (
    shape(
      value,
      ['recipientRef', 'title', 'summary', 'objectives', 'flow'],
      ['recipientRef', 'title', 'summary', 'objectives'],
    ) &&
    text(value['recipientRef']) &&
    text(value['title']) &&
    text(value['summary'], 2000) &&
    Array.isArray(value['objectives']) &&
    value['objectives'].length <= 8 &&
    value['objectives'].every(isObjective) &&
    (value['flow'] === undefined || isFlowShape(value['flow']))
  );
}
function validDraftChange(value: unknown): boolean {
  if (!record(value)) return false;
  switch (value['kind']) {
    case 'validate':
      return shape(value, ['kind']);
    case 'append_objective':
    case 'replace_objective':
      return (
        shape(value, ['kind', 'objective']) && isObjective(value['objective'])
      );
    case 'remove_objective':
      return shape(value, ['kind', 'id']) && text(value['id']);
    case 'append_step':
      return (
        shape(value, ['kind', 'template', 'arguments']) &&
        text(value['template']) &&
        record(value['arguments']) &&
        Object.keys(value['arguments']).length <= 16
      );
    case 'set_flow':
      return (
        shape(value, ['kind', 'flow']) &&
        (value['flow'] === null || isFlowShape(value['flow']))
      );
    case 'append_stage':
      return (
        shape(value, ['kind', 'stage']) &&
        record(value['stage']) &&
        isFlowShape({ start: value['stage']['id'], stages: [value['stage']] })
      );
    default:
      return false;
  }
}
export function validInput(tool: ToolName, input: unknown): boolean {
  if (!isJson(input)) return false;
  switch (tool) {
    case 'create_dialogue_graph':
      return isDialogueGraph(input);
    case 'start_dialogue_graph':
      return shape(input, ['graphId']) && text(input['graphId']);
    case 'inspect_dialogue_graph':
      return shape(input, ['instanceId']) && text(input['instanceId']);
    case 'inspect_offering_access':
      return shape(input, ['recipientRef']) && text(input['recipientRef']);
    case 'set_offering_access':
      return (
        shape(input, [
          'recipientRef',
          'expectedRevision',
          'mode',
          'allowedQuestIds',
        ]) &&
        text(input['recipientRef']) &&
        integer(input['expectedRevision']) &&
        (input['mode'] === 'open' || input['mode'] === 'restricted') &&
        Array.isArray(input['allowedQuestIds']) &&
        input['allowedQuestIds'].length <= 16 &&
        input['allowedQuestIds'].every((id: unknown) => text(id)) &&
        new Set(input['allowedQuestIds']).size ===
          input['allowedQuestIds'].length &&
        (input['mode'] !== 'open' || input['allowedQuestIds'].length === 0)
      );
    case 'inspect_quest_templates':
      return shape(input, []);
    case 'compose_quest_draft':
      return (
        shape(input, ['draft', 'change']) &&
        isDraftDefinition(input['draft']) &&
        validDraftChange(input['change'])
      );
    case 'create_quest':
      return shape(input, ['quest']) && isQuest(input['quest']);
    case 'offer_quest':
      return (
        shape(input, ['questId', 'recipientRef', 'dialogue']) &&
        text(input['questId']) &&
        text(input['recipientRef']) &&
        text(input['dialogue'], 2000)
      );
    case 'inspect_quest':
      return (
        shape(input, ['questId', 'recipientRef'], ['questId']) &&
        text(input['questId']) &&
        (input['recipientRef'] === undefined || text(input['recipientRef']))
      );
    case 'inspect_context':
      return (
        shape(input, ['scope', 'entityRefs'], ['scope']) &&
        (input['scope'] === 'local' || input['scope'] === 'world') &&
        (input['entityRefs'] === undefined ||
          (Array.isArray(input['entityRefs']) &&
            input['entityRefs'].length <= 16 &&
            input['entityRefs'].every((ref: unknown) => text(ref))))
      );
  }
}
export function reject(
  code: string,
  message: string,
  path?: string,
): Rejection {
  return immutable({
    status: 'rejected',
    code,
    message,
    issues: path === undefined ? [] : [{ path, code, message }],
  });
}
export function complete(data: unknown): NarrativeResult {
  if (!isJson(data)) throw new TypeError('Narrative result must be JSON');
  return immutable({ status: 'completed', data });
}
export function canonical(value: Json): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value !== null && typeof value === 'object')
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${canonical(value[key] ?? null)}`)
      .join(',')}}`;
  return JSON.stringify(value);
}
export function isResult(value: unknown): value is NarrativeResult {
  if (!record(value) || !isJson(value)) return false;
  return value['status'] === 'completed'
    ? Object.hasOwn(value, 'data')
    : value['status'] === 'rejected' &&
        text(value['code']) &&
        text(value['message'], 1000) &&
        Array.isArray(value['issues']) &&
        value['issues'].every(
          (issue: unknown) =>
            record(issue) &&
            typeof issue['path'] === 'string' &&
            text(issue['code']) &&
            text(issue['message'], 1000),
        );
}

export function boundedJson(value: unknown): value is Json {
  if (!isJson(value)) return false;
  const encoded = JSON.stringify(value);
  return (
    encoded.length <= 65536 &&
    new TextEncoder().encode(encoded).byteLength <= 65536
  );
}
