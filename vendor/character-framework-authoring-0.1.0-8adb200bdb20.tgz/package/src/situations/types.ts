import type {
  Capability,
  CapabilityResult,
  CharacterDefinition,
  Invocation,
  Json,
} from '../types.js';

export type SituationScope =
  | { readonly kind: 'world' }
  | { readonly kind: 'player'; readonly ref: string };
export interface ResultReference {
  readonly $result: {
    readonly situationRef: string;
    readonly actionId: string;
    readonly path: readonly string[];
  };
}
export type Argument = Json | ResultReference;
export interface SituationCondition {
  readonly tool: string;
  readonly arguments: Readonly<Record<string, Argument>>;
  readonly expect: {
    readonly path: readonly string[];
    readonly operator: 'equals' | 'at_least';
    readonly value: string | number | boolean | null;
  };
  readonly evidence:
    | { readonly mode: 'fact' }
    | {
        readonly mode: 'events';
        readonly after:
          | { readonly kind: 'run-start' }
          | { readonly kind: 'situation-entry'; readonly situationRef: string };
      };
}
export interface SituationAction {
  readonly id: string;
  readonly tool: string;
  readonly arguments: Readonly<Record<string, Argument>>;
}
export interface Situation {
  readonly id: string;
  readonly objectives?: readonly {
    readonly id: string;
    readonly description: string;
    readonly condition: SituationCondition;
  }[];
  readonly dialogue?: {
    readonly text: string;
    readonly requires?: SituationCondition;
  };
  readonly choices?: readonly {
    readonly id: string;
    readonly label: string;
    readonly when?: SituationCondition;
    readonly next: string;
  }[];
  readonly routes?: readonly {
    readonly id: string;
    readonly priority: number;
    readonly when: SituationCondition;
    readonly next: string;
  }[];
  readonly onEnter?: readonly SituationAction[];
}
export interface SituationDefinition {
  readonly proposalVersion: 'cfw-situations-draft-2';
  readonly id: string;
  readonly start: string;
  readonly situations: readonly Situation[];
}
export interface SituationCapability extends Capability {
  /** Required typed completed(data) contract, including inspection results. */
  readonly outputSchema: Json;
  /** Capture scope uses known authored arguments BEFORE entry actions, never future results. */
  readonly evidenceStream?: {
    readonly ref: string;
    readonly captureKeys: readonly string[];
  };
}
export interface NarrativeExecutionContext {
  readonly runId: string;
  readonly scope: SituationScope;
  readonly entryId: string;
  readonly originGeneration: string;
  readonly effectId?: string;
  readonly argumentDigest?: string;
  readonly evidence?: {
    readonly streamRef: string;
    readonly cursor: Json;
    readonly arguments: Readonly<Record<string, Json>>;
  };
}
export interface SituationInvocation extends Invocation {
  readonly narrative: NarrativeExecutionContext;
}
export interface SituationObservation {
  readonly capability: SituationCapability;
  readonly arguments: Readonly<Record<string, Json>>;
  readonly evidence?: NonNullable<NarrativeExecutionContext['evidence']>;
}
export interface SituationGame {
  capabilities(character: CharacterDefinition): readonly SituationCapability[];
  scopeAvailable(
    character: CharacterDefinition,
    scope: SituationScope,
  ): boolean;
  /** Return opaque authoritative stream cursor; absent/truncated history must throw or be unknown. */
  capture(
    context: SituationInvocation,
    streamRef: string,
    arguments_: Readonly<Record<string, Json>>,
  ): Json | Promise<Json>;
  /** One coherent revision; adapters reuse registered inspection implementations on that revision. */
  observe(
    context: SituationInvocation,
    observations: readonly SituationObservation[],
  ):
    | {
        readonly revision: string;
        readonly results: readonly CapabilityResult[];
      }
    | Promise<{
        readonly revision: string;
        readonly results: readonly CapabilityResult[];
      }>;
  /** Pure synchronous guard, used again at the journal/choice commit boundary. */
  observationCurrent(context: SituationInvocation, revision: string): boolean;
  /** Reconcile original identity. not_admitted alone permits executing the original action. */
  reconcile(
    context: SituationInvocation,
    capability: SituationCapability,
    arguments_: Readonly<Record<string, Json>>,
    operationId?: string,
  ):
    | CapabilityResult
    | { readonly status: 'not_admitted' | 'unknown' }
    | Promise<
        CapabilityResult | { readonly status: 'not_admitted' | 'unknown' }
      >;
  /** Explicit host reconciliation approval for a fresh registration of the same stable owner/run. */
  authorizeRestore?(
    character: CharacterDefinition,
    previousGeneration: string,
    scope: SituationScope,
    runId: string,
  ): boolean;
  /** Host must store this journal before dispatch/ack. Atomic game+CFW durability remains host-owned. */
  persist(save: SituationSave): void | Promise<void>;
  /** Idempotent run-owned cleanup/reconciliation; never implicit reward rollback/shared-entity deletion. */
  retire(context: SituationInvocation): void | Promise<void>;
}
export interface SituationActionRecord {
  id: string;
  effectId: string;
  arguments: Record<string, Json>;
  state: 'prepared' | 'running' | 'completed' | 'rejected';
  result?: Json;
  operationId?: string;
  code?: string;
}
export interface SituationCursor {
  key: string;
  boundary: string;
  streamRef: string;
  arguments: Record<string, Json>;
  effectId: string;
  cursor?: Json;
}
export interface SituationRun {
  id: string;
  definitionId: string;
  ownerKey: string;
  generation: string;
  originGeneration: string;
  scope: SituationScope;
  revision: number;
  path: string[];
  entries: { situationId: string; actions: SituationActionRecord[] }[];
  cursors: SituationCursor[];
  status:
    'entering' | 'waiting' | 'blocked' | 'closed' | 'retiring' | 'retired';
  error?: string;
  retirementRequested?: boolean;
}
export interface SituationReceipt {
  key: string;
  digest: string;
  result: Json;
}
export interface SituationSave {
  readonly schemaVersion: 1;
  readonly associationId: string;
  readonly definitions: readonly {
    readonly ownerKey: string;
    readonly definition: SituationDefinition;
  }[];
  readonly runs: readonly SituationRun[];
  readonly receipts: readonly SituationReceipt[];
}
export interface SituationView {
  readonly runId: string;
  readonly definitionId: string;
  readonly revision: number;
  readonly situationId: string;
  readonly status: SituationRun['status'];
  readonly error?: string;
  readonly dialogue: string | null;
  readonly choices: readonly { readonly id: string; readonly label: string }[];
  readonly objectives: readonly {
    readonly id: string;
    readonly satisfied: boolean | null;
  }[];
  readonly observationRevision: string | null;
}
