import { Ajv2020 } from 'ajv/dist/2020.js';
import schema from '../../docs/contracts/situations.schema.json' with { type: 'json' };
import { isJson } from '../json.js';
import { canonical, record } from '../narrative/validation.js';
import type { Json } from '../types.js';
import type {
  SituationCapability,
  SituationCondition,
  SituationDefinition,
} from './types.js';

const ajv = new Ajv2020({ strict: true, allErrors: true });
const shape = ajv.compile<SituationDefinition>(schema);
export function conditions(definition: SituationDefinition) {
  return definition.situations.flatMap((s, i) => [
    ...(s.dialogue?.requires
      ? [
          {
            situationId: s.id,
            condition: s.dialogue.requires,
            path: `/situations/${String(i)}/dialogue/requires`,
          },
        ]
      : []),
    ...(s.choices ?? []).flatMap((c, j) =>
      c.when
        ? [
            {
              situationId: s.id,
              condition: c.when,
              path: `/situations/${String(i)}/choices/${String(j)}/when`,
            },
          ]
        : [],
    ),
    ...(s.routes ?? []).map((r, j) => ({
      situationId: s.id,
      condition: r.when,
      path: `/situations/${String(i)}/routes/${String(j)}/when`,
    })),
    ...(s.objectives ?? []).map((o, j) => ({
      situationId: s.id,
      condition: o.condition,
      path: `/situations/${String(i)}/objectives/${String(j)}/condition`,
    })),
  ]);
}
export function references(
  value: unknown,
): { situationRef: string; actionId: string; path: readonly string[] }[] {
  if (!record(value) && !Array.isArray(value)) return [];
  if (record(value) && record(value['$result']))
    return [
      value['$result'] as unknown as {
        situationRef: string;
        actionId: string;
        path: readonly string[];
      },
    ];
  return Object.values(value).flatMap(references);
}
export function field(value: unknown, path: readonly string[]): unknown {
  let current = value;
  for (const key of path) {
    if (!record(current) || !Object.hasOwn(current, key)) return undefined;
    current = current[key];
  }
  return current;
}
export function outputField(
  schema_: Json,
  path: readonly string[],
): Json | undefined {
  let current: unknown = schema_;
  for (const part of path) {
    if (!record(current) || !record(current['properties'])) return undefined;
    current = current['properties'][part];
  }
  return isJson(current) ? current : undefined;
}
function referenceLocations(
  value: unknown,
  path: readonly string[] = [],
): {
  producer: ReturnType<typeof references>[number];
  path: readonly string[];
}[] {
  if (record(value) && record(value['$result']))
    return references(value).map((producer) => ({ producer, path }));
  if (!record(value) && !Array.isArray(value)) return [];
  return Object.entries(value).flatMap(([key, item]) =>
    referenceLocations(item, [...path, key]),
  );
}
function declaredTypes(value: Json | undefined): readonly string[] {
  if (!record(value)) return [];
  if (typeof value['type'] === 'string') return [value['type']];
  if (Array.isArray(value['type']))
    return value['type'].filter((t): t is string => typeof t === 'string');
  if (Object.hasOwn(value, 'const'))
    return [value['const'] === null ? 'null' : typeof value['const']];
  if (Array.isArray(value['oneOf']))
    return value['oneOf'].flatMap((s: unknown) =>
      isJson(s) ? declaredTypes(s) : [],
    );
  return [];
}
export function validateSituationDefinition(
  value: unknown,
  capabilities: readonly SituationCapability[],
): readonly string[] {
  if (!isJson(value)) return ['Definition must be finite bounded-depth JSON'];
  const encoded = JSON.stringify(value);
  const bytes =
    new TextEncoder().encode(encoded).length +
    (encoded.match(/[\u2028\u2029]/gu)?.length ?? 0) * 3;
  if (bytes > 65536)
    return ['Definition exceeds native-compatible 65536-byte budget'];
  if (!shape(value))
    return (shape.errors ?? []).map(
      (e) => e.instancePath + ': ' + (e.message ?? 'invalid'),
    );
  const definition = value;
  const errors: string[] = [];
  const nodes = new Map(definition.situations.map((s) => [s.id, s]));
  if (
    nodes.size !== definition.situations.length ||
    !nodes.has(definition.start)
  )
    return ['Duplicate situation or missing start'];
  const predecessors = new Map<string, Set<string>>();
  const visiting = new Set<string>(),
    visited = new Set<string>(),
    order: string[] = [];
  const visit = (id: string): void => {
    if (visiting.has(id)) {
      errors.push('Cycle at ' + id);
      return;
    }
    if (visited.has(id)) return;
    const node = nodes.get(id);
    if (!node) {
      errors.push('Unknown destination ' + id);
      return;
    }
    visiting.add(id);
    for (const route of [...(node.routes ?? []), ...(node.choices ?? [])]) {
      const parents = predecessors.get(route.next) ?? new Set<string>();
      parents.add(id);
      predecessors.set(route.next, parents);
      visit(route.next);
    }
    visiting.delete(id);
    visited.add(id);
    order.unshift(id);
  };
  visit(definition.start);
  if (visited.size !== nodes.size) errors.push('Unreachable situation');
  if (errors.length) return errors;
  const dominators = new Map<string, Set<string>>();
  for (const id of order) {
    const parents = [...(predecessors.get(id) ?? [])];
    const shared = parents.length
      ? [...(dominators.get(parents[0] ?? '') ?? [])].filter((x) =>
          parents.every((p) => dominators.get(p)?.has(x)),
        )
      : [];
    dominators.set(id, new Set([...shared, id]));
  }
  const cap = (name: string, kind: 'action' | 'inspection') => {
    const c = capabilities.find((c) => c.name === name && c.kind === kind);
    if (!c) {
      errors.push('Unavailable ' + kind + ' ' + name);
      return undefined;
    }
    try {
      if (!record(c.inputSchema) && typeof c.inputSchema !== 'boolean')
        throw new Error('Input schema required');
      ajv.compile(c.inputSchema);
      if (!record(c.outputSchema) && typeof c.outputSchema !== 'boolean')
        throw new Error('Output schema must be object or boolean');
      ajv.compile(c.outputSchema);
    } catch {
      errors.push('Invalid output schema ' + name);
    }
    return c;
  };
  const checkRefs = (
    args: unknown,
    consumer: string,
    receiver: SituationCapability | undefined,
    actionIndex?: number,
  ) => {
    for (const location of referenceLocations(args)) {
      const r = location.producer;
      const producer = nodes.get(r.situationRef),
        index = producer?.onEnter?.findIndex((a) => a.id === r.actionId) ?? -1;
      if (
        index < 0 ||
        !dominators.get(consumer)?.has(r.situationRef) ||
        (r.situationRef === consumer &&
          actionIndex !== undefined &&
          index >= actionIndex)
      ) {
        errors.push(
          'Unavailable/forward/bypassed result producer at ' + consumer,
        );
        continue;
      }
      const action = producer?.onEnter?.[index];
      const capability = capabilities.find((c) => c.name === action?.tool);
      const output = capability
        ? outputField(capability.outputSchema, r.path)
        : undefined;
      if (!output) errors.push('Undeclared output path at ' + consumer);
      const input = receiver
        ? outputField(receiver.inputSchema, location.path)
        : undefined;
      const produced = declaredTypes(output),
        accepted = declaredTypes(input);
      if (
        !produced.length ||
        !accepted.length ||
        produced.some(
          (t) =>
            !accepted.includes(t) &&
            !(t === 'integer' && accepted.includes('number')),
        )
      )
        errors.push(
          'Incompatible or undeclared result/input types at ' + consumer,
        );
    }
  };
  for (const node of definition.situations) {
    for (const list of [
      node.choices ?? [],
      node.routes ?? [],
      node.onEnter ?? [],
      node.objectives ?? [],
    ])
      if (new Set(list.map((x) => x.id)).size !== list.length)
        errors.push('Duplicate authored IDs at ' + node.id);
    const priorities = (node.routes ?? []).map((r) => r.priority);
    if (priorities.some((p, i) => i > 0 && p <= (priorities[i - 1] ?? -1)))
      errors.push('Priorities must be unique ascending at ' + node.id);
    (node.onEnter ?? []).forEach((a, i) => {
      const c = cap(a.tool, 'action');
      checkRefs(a.arguments, node.id, c, i);
      if (c && !references(a.arguments).length)
        try {
          if (!c.validate(a.arguments as Json))
            errors.push('Invalid action input ' + a.id);
        } catch {
          errors.push('Invalid action input ' + a.id);
        }
    });
  }
  for (const { situationId, condition, path } of conditions(definition)) {
    const c = cap(condition.tool, 'inspection');
    if (c) {
      const expected = condition.expect;
      const output = outputField(c.outputSchema, expected.path);
      const types = declaredTypes(output);
      const location = path + '/expect';
      if (output === undefined) {
        errors.push(
          `${location}: Undeclared output path ${JSON.stringify(expected.path)} for ${c.name}`,
        );
      } else if (expected.operator === 'at_least') {
        if (
          !types.length ||
          types.some((type) => type !== 'number' && type !== 'integer') ||
          typeof expected.value !== 'number'
        )
          errors.push(
            `${location}: at_least compares declared ${types.join('|') || 'unknown'} output with ${typeof expected.value} value; both must be number or integer. Select a numeric output path and numeric threshold.`,
          );
      } else {
        const valueType =
          expected.value === null ? 'null' : typeof expected.value;
        if (
          !types.length ||
          !types.some(
            (type) =>
              type === valueType ||
              (type === 'integer' && valueType === 'number'),
          )
        )
          errors.push(
            `${location}: equals value type ${valueType} is incompatible with declared output type ${types.join('|') || 'unknown'}. Match the output type.`,
          );
      }
    }
    checkRefs(condition.arguments, situationId, c);
    if (c && !references(condition.arguments).length)
      try {
        if (!c.validate(condition.arguments as Json))
          errors.push('Invalid condition input ' + condition.tool);
      } catch {
        errors.push('Invalid condition input ' + condition.tool);
      }
    if (condition.evidence.mode === 'events') {
      const boundary =
        condition.evidence.after.kind === 'run-start'
          ? definition.start
          : condition.evidence.after.situationRef;
      if (!dominators.get(situationId)?.has(boundary))
        errors.push('Unavailable event boundary at ' + situationId);
      if (
        !c?.evidenceStream ||
        !c.evidenceStream.ref ||
        new Set(c.evidenceStream.captureKeys).size !==
          c.evidenceStream.captureKeys.length
      )
        errors.push('Event stream metadata required ' + condition.tool);
      for (const key of c?.evidenceStream?.captureKeys ?? []) {
        if (!Object.hasOwn(condition.arguments, key))
          errors.push('Missing capture scope ' + key);
        for (const r of references(condition.arguments[key])) {
          if (
            r.situationRef === boundary ||
            !dominators.get(boundary)?.has(r.situationRef)
          )
            errors.push(
              'Capture depends on unavailable result at boundary ' + boundary,
            );
        }
      }
    }
  }
  return errors;
}
export function conditionKey(condition: SituationCondition): string {
  return canonical(condition as unknown as Json);
}
export const validateOutput = (
  capability: SituationCapability,
  data: unknown,
): data is Json =>
  isJson(data) &&
  (record(capability.outputSchema) ||
    typeof capability.outputSchema === 'boolean') &&
  ajv.compile(capability.outputSchema)(data);
