import { McpError, ErrorCode } from '@modelcontextprotocol/sdk/types.js';
import type { CallToolResult, Tool } from '@modelcontextprotocol/sdk/types.js';
import { createHash } from 'node:crypto';
import type { CharacterHandle, CharacterRuntime } from '../Runtime.js';
import { immutable, isJson } from '../json.js';
import type {
  Capability,
  CharacterSnapshot,
  Json,
  MutationIdentity,
} from '../types.js';
import type { NarrativeHandle } from '../narrative/NarrativeSystem.js';
import {
  boundedJson,
  canonical,
  record,
  reject,
  text,
} from '../narrative/validation.js';
import type { ToolName } from '../narrative/types.js';
import { capabilityContract, narrativeContracts } from './catalogue.js';
import type { ToolContract } from './catalogue.js';
import { HostLane, validResult } from './HostLane.js';

interface Binding {
  readonly key: string;
  readonly providerIds: readonly string[];
  readonly handle: CharacterHandle;
  readonly snapshot: CharacterSnapshot;
  readonly narrative: NarrativeHandle | undefined;
  readonly tools: ReadonlyMap<
    string,
    { contract: ToolContract; capability?: Capability }
  >;
}
export interface EffectReceipt {
  readonly scope: string;
  readonly key: string;
  readonly digest: string;
  readonly callId: string;
  readonly turnId: string;
  readonly state: 'terminal' | 'unresolved';
  readonly result?: Json;
}
export interface McpReceiptSave {
  readonly schemaVersion: 1;
  readonly associationId: string;
  readonly receipts: readonly EffectReceipt[];
}
interface PendingEffect {
  readonly digest: string;
  readonly promise: Promise<Json>;
}
export interface CfwMcpBinding {
  readonly scope: string;
  readonly providers: readonly string[];
  readonly metadata?: Readonly<Record<string, string>>;
  readonly isCurrent: () => boolean;
}
export interface CfwMcpCallContext {
  readonly binding: CfwMcpBinding;
  readonly headers: Headers;
  readonly signal: AbortSignal;
}
export interface CfwMcpProviderOptions {
  readonly runtime: CharacterRuntime;
  readonly id?: string;
}
/** CFW domain adapter only: no HTTP server, credentials, SDK sessions or transport. */
export class CfwMcpProvider {
  readonly id: string;
  readonly #options: CfwMcpProviderOptions;
  readonly #bindings = new Map<string, Binding>();
  readonly #neutral = new Map<Binding, CfwMcpBinding>();
  readonly #internal = new WeakMap<CfwMcpBinding, Binding>();
  readonly #receipts = new Map<string, EffectReceipt>();
  readonly #pending = new Map<string, PendingEffect>();
  readonly #lane: HostLane;
  #closed = false;
  constructor(options: CfwMcpProviderOptions) {
    this.id = options.id ?? 'cfw';
    if (!text(this.id)) throw new TypeError('Invalid provider ID');
    this.#options = Object.freeze({ ...options });
    this.#lane = new HostLane(options.runtime.stats.gameId);
  }
  /** Trusted host provisioning, never exposed as a model tool or public route. */
  bind(
    key: string,
    handle: CharacterHandle,
    capabilities: readonly Capability[] = [],
    providerIds: readonly string[] = [this.id],
  ): Readonly<Record<string, string>> {
    if (this.#closed || !text(key))
      throw new TypeError('Invalid or closed binding');
    if (
      !providerIds.includes(this.id) ||
      new Set(providerIds).size !== providerIds.length ||
      providerIds.some((id) => !text(id))
    )
      throw new TypeError('Invalid bound provider IDs');
    const snapshot = handle.snapshot();
    if (
      !snapshot.cai ||
      !this.#options.runtime
        .characters()
        .some(
          (character) =>
            character.binding.generation === snapshot.binding.generation,
        )
    )
      throw new TypeError(
        'Binding must belong to this runtime and have a CAI session',
      );
    for (const binding of this.#bindings.values())
      if (
        binding.key !== key &&
        binding.snapshot.binding.id === snapshot.binding.id
      )
        throw new TypeError('Character is already bound');
    const tools = new Map<
      string,
      { contract: ToolContract; capability?: Capability }
    >();
    const narrative = this.#options.runtime.narrative?.bind(handle);
    if (narrative)
      for (const [name, contract] of narrativeContracts)
        tools.set(name, { contract });
    for (const capability of capabilities) {
      if (
        !snapshot.capabilities.includes(capability.name) ||
        tools.has(capability.name)
      )
        throw new TypeError('Tool must be granted and have a unique name');
      tools.set(capability.name, {
        contract: capabilityContract(capability),
        capability: Object.freeze({
          ...capability,
          inputSchema: immutable(capability.inputSchema),
        }),
      });
    }
    const previous = this.#bindings.get(key);
    this.#bindings.set(key, {
      key,
      providerIds: Object.freeze([...providerIds]),
      handle,
      snapshot,
      narrative,
      tools,
    });
    if (previous) this.#neutral.delete(previous);
    return immutable({
      'X-CF-Binding-Key': key,
      'X-CF-CAI-Session-Id': snapshot.cai.sessionId,
      'X-CF-Binding-Generation': snapshot.binding.generation,
    });
  }
  unbind(key: string): void {
    const binding = this.#bindings.get(key);
    if (binding) {
      this.#bindings.delete(key);
      this.#neutral.delete(binding);
    }
  }
  /** Host calls this in its update boundary, alongside runtime.advance(). */
  advance(seconds: number): void {
    this.#lane.advance(seconds);
  }
  get stats() {
    return Object.freeze({
      receipts: this.#receipts.size,
      pendingEffects: this.#pending.size,
      pendingHostTools: this.#lane.pending,
    });
  }
  /** Application resolver calls after transport authentication; retain returned binding identity. */
  resolveBinding(request: Request): CfwMcpBinding | null {
    const binding = this.#bindings.get(
      request.headers.get('x-cf-binding-key') ?? '',
    );
    if (
      !binding ||
      !this.#current(binding) ||
      request.headers.get('x-cf-cai-session-id') !==
        binding.snapshot.cai?.sessionId ||
      request.headers.get('x-cf-binding-generation') !==
        binding.snapshot.binding.generation
    )
      return null;
    let neutral = this.#neutral.get(binding);
    if (!neutral) {
      neutral = Object.freeze({
        scope: canonical([
          this.#options.runtime.stats.gameId,
          binding.key,
          binding.snapshot.binding.generation,
        ]),
        providers: binding.providerIds,
        metadata: Object.freeze({
          'X-CF-Binding-Key': binding.key,
          'X-CF-CAI-Session-Id': binding.snapshot.cai.sessionId,
          'X-CF-Binding-Generation': binding.snapshot.binding.generation,
        }),
        isCurrent: () => this.#current(binding),
      });
      this.#neutral.set(binding, neutral);
      this.#internal.set(neutral, binding);
    }
    return neutral;
  }
  #domain(neutral: CfwMcpBinding): Binding {
    const binding = this.#internal.get(neutral);
    if (!binding || !neutral.isCurrent())
      throw new McpError(
        ErrorCode.InvalidRequest,
        'Unknown or invalidated CFW binding.',
      );
    this.#assertCurrent(binding);
    return binding;
  }
  tools(neutral: CfwMcpBinding): readonly Tool[] {
    const binding = this.#domain(neutral);
    return [...binding.tools.values()].map((entry) => entry.contract.tool);
  }
  async call(
    name: string,
    args: Readonly<Record<string, unknown>>,
    context: CfwMcpCallContext,
  ): Promise<CallToolResult> {
    const { headers, signal } = context;
    signal.throwIfAborted();
    const binding = this.#domain(context.binding);
    if (
      this.resolveBinding(
        new Request('http://cfw.invalid/mcp', { headers }),
      ) !== context.binding
    )
      throw new McpError(
        ErrorCode.InvalidRequest,
        'CFW call headers do not match binding.',
      );
    const callId = headers.get('x-cf-call-id');
    const turnId = headers.get('x-cf-turn-request-id');
    if (!text(callId) || !text(turnId))
      throw new McpError(
        ErrorCode.InvalidParams,
        'Trusted call and turn headers are required.',
      );
    const entry = binding.tools.get(name);
    if (!entry)
      throw new McpError(ErrorCode.InvalidParams, 'Tool is unavailable.');
    const input: unknown = args;
    if (!boundedJson(input))
      throw new McpError(
        ErrorCode.InvalidParams,
        'Arguments exceed JSON size/depth limits; invocation was not admitted.',
        { code: 'argument_limit', admitted: false },
      );
    const mutation = entry.capability
      ? entry.capability.kind === 'action'
      : name === 'create_quest' ||
        name === 'offer_quest' ||
        name === 'set_offering_access' ||
        name === 'create_dialogue_graph' ||
        name === 'start_dialogue_graph';
    const execute = async (identity?: MutationIdentity): Promise<Json> => {
      this.#assertCurrent(binding);
      if (!entry.contract.input(input))
        return jsonResult(
          reject(
            'invalid_arguments',
            'Arguments do not conform to the discovered schema.',
          ),
        );
      if (entry.capability) {
        if (!entry.capability.validate(input))
          return jsonResult(
            reject(
              'invalid_arguments',
              'Host argument validation rejected the call.',
            ),
          );
        const result = await this.#lane.call(
          () => {
            this.#assertCurrent(binding);
            signal.throwIfAborted();
            return binding.handle.snapshot();
          },
          entry.capability,
          input,
          callId,
          identity,
        );
        return { ...result };
      }
      if (!binding.narrative || !isNarrativeTool(name))
        throw new McpError(
          ErrorCode.InternalError,
          'Narrative service unavailable.',
        );
      const result = await binding.narrative.call(
        name,
        input,
        headers.get('x-cf-effect-key') ?? undefined,
      );
      return jsonResult(result);
    };
    const result = mutation
      ? await this.#effect(
          binding,
          name,
          input,
          headers.get('x-cf-effect-key'),
          callId,
          turnId,
          execute,
        )
      : await execute();
    if (entry.contract.output && !entry.contract.output(result))
      throw new McpError(
        ErrorCode.InternalError,
        'Host result failed the tool output schema; inspect the effect receipt before continuing.',
      );
    this.#assertCurrent(binding);
    signal.throwIfAborted();
    return envelope(result);
  }
  dispose(): void {
    if (this.#closed) return;
    this.#closed = true;
    this.#lane.dispose();
    this.#bindings.clear();
    this.#neutral.clear();
  }
  /** Persist with narrative/game state at a quiescent host checkpoint. Sessions are ephemeral. */
  saveReceipts(): McpReceiptSave {
    if (this.#pending.size || this.#lane.pending)
      throw new Error('MCP effects must settle before checkpoint');
    return immutable({
      schemaVersion: 1,
      associationId: this.#options.runtime.stats.gameId,
      receipts: [...this.#receipts.values()],
    });
  }
  restoreReceipts(value: unknown): void {
    if (this.#pending.size || this.#lane.pending)
      throw new Error('Restore before invoking tools');
    if (
      !record(value) ||
      value['schemaVersion'] !== 1 ||
      value['associationId'] !== this.#options.runtime.stats.gameId ||
      !Array.isArray(value['receipts']) ||
      value['receipts'].length > 4096
    )
      throw new TypeError('Invalid MCP receipts');
    const receipts = new Map<string, EffectReceipt>();
    for (const raw of value['receipts']) {
      const receipt: unknown = raw;
      if (!validReceipt(receipt))
        throw new TypeError('Invalid MCP effect receipt');
      const key = canonical([receipt.scope, receipt.key]);
      if (receipts.has(key)) throw new TypeError('Duplicate MCP receipt');
      receipts.set(key, immutable(receipt));
    }
    this.#receipts.clear();
    for (const [key, receipt] of receipts) this.#receipts.set(key, receipt);
  }
  async #effect(
    binding: Binding,
    name: string,
    input: Json,
    effectKey: string | null,
    callId: string,
    turnId: string,
    execute: (identity: MutationIdentity) => Promise<Json>,
  ): Promise<Json> {
    if (!text(effectKey))
      throw new McpError(
        ErrorCode.InvalidParams,
        'Trusted effect key required for mutations.',
      );
    const scope = canonical([
      this.#options.runtime.stats.gameId,
      binding.snapshot.binding.id,
      binding.snapshot.id,
      binding.snapshot.cai ? { ...binding.snapshot.cai } : null,
    ]);
    const key = canonical([scope, effectKey]);
    const digest = canonical({ name, arguments: input });
    const receipt = this.#receipts.get(key);
    if (receipt) {
      if (receipt.digest !== digest)
        return jsonResult(
          reject(
            'effect_key_conflict',
            'Effect key was already used with different input.',
          ),
        );
      if (receipt.state === 'unresolved' || receipt.result === undefined)
        throw new McpError(
          ErrorCode.InternalError,
          'Effect outcome unresolved; host reconciliation required.',
        );
      return receipt.result;
    }
    const pending = this.#pending.get(key);
    if (pending)
      return pending.digest === digest
        ? pending.promise
        : jsonResult(
            reject(
              'effect_key_conflict',
              'Effect key is in use with different input.',
            ),
          );
    if (this.#receipts.size + this.#pending.size >= 4096)
      throw new McpError(
        ErrorCode.InternalError,
        'Mutation receipt capacity reached; invocation was not admitted.',
        { code: 'receipt_limit', admitted: false },
      );
    const identity = { scope, key: effectKey, digest, callId, turnId };
    const promise = execute(
      immutable({
        id: createHash('sha256').update(key).digest('hex'),
      }),
    )
      .then(
        (result) => {
          this.#receipts.set(
            key,
            immutable({ ...identity, state: 'terminal', result }),
          );
          return result;
        },
        (error: unknown) => {
          this.#receipts.set(
            key,
            immutable({ ...identity, state: 'unresolved' }),
          );
          throw error;
        },
      )
      .finally(() => {
        this.#pending.delete(key);
      });
    this.#pending.set(key, { digest, promise });
    return promise;
  }
  #current(binding: Binding): boolean {
    if (this.#closed || this.#bindings.get(binding.key) !== binding)
      return false;
    try {
      return (
        binding.handle.snapshot().binding.generation ===
        binding.snapshot.binding.generation
      );
    } catch {
      return false;
    }
  }
  #assertCurrent(binding: Binding): void {
    if (!this.#current(binding))
      throw new McpError(
        ErrorCode.InvalidRequest,
        'Character binding is no longer current.',
      );
  }
}
function jsonResult(value: unknown): Json {
  if (!boundedJson(value))
    throw new McpError(ErrorCode.InternalError, 'Invalid JSON result.');
  return value;
}
function envelope(result: Json): CallToolResult {
  if (!record(result))
    throw new McpError(
      ErrorCode.InternalError,
      'Expected structured tool result.',
    );
  return {
    content: [{ type: 'text', text: JSON.stringify(result) }],
    structuredContent: result,
    isError: result['status'] === 'rejected',
  };
}
function isNarrativeTool(name: string): name is ToolName {
  return narrativeContracts.has(name);
}
function validReceipt(value: unknown): value is EffectReceipt {
  if (
    !record(value) ||
    !isJson(value) ||
    !text(value['scope'], 2000) ||
    !text(value['key']) ||
    !text(value['digest'], 131072) ||
    !text(value['callId']) ||
    !text(value['turnId'])
  )
    return false;
  return value['state'] === 'unresolved'
    ? value['result'] === undefined
    : value['state'] === 'terminal' && validResult(value['result']);
}
