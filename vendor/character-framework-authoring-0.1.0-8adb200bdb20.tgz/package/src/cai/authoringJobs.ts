import { immutable } from '../json.js';
import {
  boundedJson,
  integer,
  record,
  shape,
} from '../narrative/validation.js';
import { bindingSelector } from './validation.js';

export interface CaiAuthoringInput {
  readonly request_id: string;
  readonly version: number;
  readonly brief: string;
  readonly authoring_guide?: string;
}
/** Execution status is not evidence of publication or gameplay completion. */
export interface CaiAuthoringJob {
  readonly id: string;
  readonly requestId: string;
  readonly sessionId: string;
  readonly version: number;
  readonly bindingGeneration: string;
  readonly status: 'queued' | 'running' | 'finished' | 'failed';
  readonly report: string | null;
  readonly failureCode: string | null;
  /** Server job UUID, not the caller's request UUID. Use for private receipt reads. */
  readonly attemptRequestId: string | null;
  readonly createdAt: string;
  readonly startedAt: string | null;
  readonly finishedAt: string | null;
}
export interface CaiAuthoringBackend {
  submitAuthoring(
    sessionId: string,
    input: CaiAuthoringInput,
    signal: AbortSignal,
  ): Promise<CaiAuthoringJob>;
  readAuthoringJob(
    sessionId: string,
    jobId: string,
    signal: AbortSignal,
  ): Promise<CaiAuthoringJob>;
}

export const authoringUuid = (value: unknown): value is string =>
  typeof value === 'string' &&
  /^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/iu.test(value);
export const authoringSession = (value: string): boolean =>
  /^[1-9]\d*$/u.test(value) && Number.isSafeInteger(Number(value));
export function captureAuthoringInput(input: unknown): CaiAuthoringInput {
  if (
    !boundedJson(input) ||
    !shape(
      input,
      ['request_id', 'version', 'brief', 'authoring_guide'],
      ['request_id', 'version', 'brief'],
    ) ||
    !authoringUuid(input['request_id']) ||
    !integer(input['version']) ||
    typeof input['brief'] !== 'string' ||
    !/\S/u.test(input['brief']) ||
    Array.from(input['brief']).length > 8000 ||
    !(
      input['authoring_guide'] === undefined ||
      (typeof input['authoring_guide'] === 'string' &&
        Array.from(input['authoring_guide']).length <= 16000)
    )
  )
    throw new TypeError(
      'Invalid CAI authoring request; retain its original UUID and payload.',
    );
  return immutable({
    request_id: input['request_id'],
    version: input['version'],
    brief: input['brief'],
    ...(input['authoring_guide'] === undefined
      ? {}
      : { authoring_guide: input['authoring_guide'] }),
  });
}
const nullableText = (value: unknown, max: number): value is string | null =>
  value === null || (typeof value === 'string' && value.length <= max);

export function decodeAuthoringJob(
  body: unknown,
  sessionId: string,
  expected: { readonly jobId?: string; readonly input?: CaiAuthoringInput },
): CaiAuthoringJob {
  if (!record(body) || !record(body['data']))
    throw new Error('Invalid CAI authoring envelope');
  const data = body['data'];
  const status = data['status'];
  if (
    !authoringUuid(data['id']) ||
    !authoringUuid(data['request_id']) ||
    !integer(data['session_id']) ||
    String(data['session_id']) !== sessionId ||
    !integer(data['version']) ||
    !bindingSelector(data['binding_generation']) ||
    !(
      status === 'queued' ||
      status === 'running' ||
      status === 'finished' ||
      status === 'failed'
    ) ||
    !nullableText(data['report'], 60000) ||
    !(data['failure_code'] === null || bindingSelector(data['failure_code'])) ||
    !(
      data['attempt_request_id'] === null ||
      data['attempt_request_id'] === data['id']
    ) ||
    !bindingSelector(data['created_at']) ||
    !nullableText(data['started_at'], 160) ||
    !nullableText(data['finished_at'], 160) ||
    (expected.jobId !== undefined && data['id'] !== expected.jobId) ||
    (expected.input !== undefined &&
      (data['request_id'] !== expected.input.request_id ||
        data['version'] !== expected.input.version))
  )
    throw new Error('Invalid or uncorrelated CAI authoring job');
  return immutable({
    id: data['id'],
    requestId: data['request_id'],
    sessionId,
    version: data['version'],
    bindingGeneration: data['binding_generation'],
    status,
    report: data['report'],
    failureCode: data['failure_code'],
    attemptRequestId: data['attempt_request_id'],
    createdAt: data['created_at'],
    startedAt: data['started_at'],
    finishedAt: data['finished_at'],
  });
}
