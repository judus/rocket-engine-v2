import { record, integer, text, shape } from '../narrative/validation.js';
import { boundedJson } from '../narrative/validation.js';
import type {
  CaiBackend,
  CaiHttpDecoder,
  CaiSessionState,
  CaiTurnInput,
  CaiTurnReceipt,
  CaiEventInput,
  CaiEventReceipt,
} from './types.js';
import type { Json } from '../types.js';
import {
  authoringUuid,
  authoringSession,
  captureAuthoringInput,
  decodeAuthoringJob,
} from './authoringJobs.js';
import type {
  CaiAuthoringBackend,
  CaiAuthoringInput,
  CaiAuthoringJob,
} from './authoringJobs.js';
import { bindingSelector, decodeSession } from './validation.js';
import {
  decodeAttempt,
  decodeCall,
  receiptJson,
  receiptCursor,
} from './receipts.js';
import type {
  CaiReceiptBackend,
  CaiAttemptPage,
  CaiCallDetail,
} from './receipts.js';
import type {
  CaiBindingBackend,
  CaiBindingInput,
  CaiBindingReceipt,
} from './types.js';

export class CaiHttpError extends Error {
  constructor(
    readonly status: number,
    readonly operation: string,
  ) {
    super(
      `CAI ${operation} returned HTTP ${String(status)}; retain the original request for reconciliation.`,
    );
  }
}
/** Draft game API adapter. Keep credentials server-side; never instantiate in a player browser. */
export class CaiHttpBackend
  implements
    CaiBackend,
    CaiBindingBackend,
    CaiReceiptBackend,
    CaiAuthoringBackend
{
  readonly #origin: string;
  readonly #token: string;
  readonly #fetch: typeof fetch;
  readonly #decodeEvent: CaiHttpDecoder;
  constructor(options: {
    origin: string;
    token: string;
    enableGameDraft: boolean;
    decodeEvent?: CaiHttpDecoder;
    fetch?: typeof fetch;
  }) {
    const url = new URL(options.origin);
    if (
      !['http:', 'https:'].includes(url.protocol) ||
      url.username ||
      url.password ||
      url.pathname !== '/' ||
      url.search ||
      url.hash ||
      !text(options.token, 4096) ||
      !options.enableGameDraft
    )
      throw new TypeError(
        'Explicit game API origin, credential and draft opt-in required',
      );
    this.#origin = url.origin;
    this.#token = options.token;
    this.#fetch = options.fetch ?? fetch;
    this.#decodeEvent = options.decodeEvent ?? decodeCaiEventReceipt;
  }
  async attach(
    input: { characterId: string; bindingKey: string; sessionId?: string },
    signal: AbortSignal,
  ): Promise<CaiSessionState> {
    const body = input.sessionId
      ? await this.#request(
          `/api/v1/companion/sessions/${encodeURIComponent(input.sessionId)}`,
          undefined,
          signal,
        )
      : await this.#request(
          `/api/v1/companion/characters/${encodeURIComponent(input.characterId)}/sessions`,
          {
            mode: 'game',
            continuity_mode: 'session',
            binding_key: input.bindingKey,
          },
          signal,
        );
    if (!record(body)) throw new Error('Invalid session envelope');
    return decodeSession(body['data']);
  }
  /** Host retains this exact request before submission; no automatic retry or activation. */
  async submitAuthoring(
    sessionId: string,
    input: CaiAuthoringInput,
    signal: AbortSignal,
  ): Promise<CaiAuthoringJob> {
    if (!authoringSession(sessionId))
      throw new TypeError('Invalid authoring session');
    const captured = captureAuthoringInput(input);
    return decodeAuthoringJob(
      await this.#request(
        `/api/v1/companion/sessions/${sessionId}/quest-authoring-jobs`,
        captured,
        signal,
      ),
      sessionId,
      { input: captured },
    );
  }
  async readAuthoringJob(
    sessionId: string,
    jobId: string,
    signal: AbortSignal,
  ): Promise<CaiAuthoringJob> {
    if (!authoringSession(sessionId) || !authoringUuid(jobId))
      throw new TypeError('Invalid authoring job selector');
    return decodeAuthoringJob(
      await this.#request(
        `/api/v1/companion/sessions/${sessionId}/quest-authoring-jobs/${jobId}`,
        undefined,
        signal,
      ),
      sessionId,
      { jobId },
    );
  }
  async turn(
    sessionId: string,
    input: CaiTurnInput,
    signal: AbortSignal,
  ): Promise<CaiTurnReceipt> {
    const body = await this.#request(
      `/api/v1/companion/sessions/${encodeURIComponent(sessionId)}/turns`,
      input,
      signal,
    );
    if (!record(body) || !record(body['data']) || !record(body['data']['turn']))
      throw new Error('Invalid CAI turn envelope');
    const turn = body['data']['turn'];
    if (!text(turn['request_id']) || !text(turn['message'], 32000))
      throw new Error('Invalid CAI turn receipt');
    return {
      requestId: turn['request_id'],
      message: turn['message'],
      session: decodeSession(body['data']['session']),
    };
  }
  async event(
    sessionId: string,
    input: CaiEventInput,
    signal: AbortSignal,
  ): Promise<CaiEventReceipt> {
    // Foundation event persistence is delivered; game-executor consumption remains pending.
    return this.#decodeEvent(
      await this.#request(
        `/api/v1/companion/sessions/${encodeURIComponent(sessionId)}/events`,
        input,
        signal,
      ),
    );
  }
  async publishBinding(
    sessionId: string,
    input: CaiBindingInput,
    signal: AbortSignal,
  ): Promise<CaiBindingReceipt> {
    if (
      !shape(input, [
        'binding_key',
        'binding_generation',
        'expected_binding_generation',
      ]) ||
      !bindingSelector(input.binding_key) ||
      !bindingSelector(input.binding_generation) ||
      !(
        input.expected_binding_generation === null ||
        bindingSelector(input.expected_binding_generation)
      )
    )
      throw new TypeError('Invalid trusted binding selectors');
    const body = await this.#request(
      `/api/v1/companion/sessions/${encodeURIComponent(sessionId)}/mcp-binding`,
      input,
      signal,
      'PUT',
    );
    if (!record(body) || !record(body['data']))
      throw new Error('Invalid binding receipt');
    const data = body['data'];
    if (
      !integer(data['session_id']) ||
      data['session_id'] < 1 ||
      String(data['session_id']) !== sessionId ||
      data['binding_key'] !== input.binding_key ||
      data['binding_generation'] !== input.binding_generation ||
      !integer(data['version'])
    )
      throw new Error('Invalid binding receipt');
    return {
      sessionId,
      bindingKey: input.binding_key,
      generation: input.binding_generation,
      version: data['version'],
    };
  }
  async readAttempt(
    session: CaiSessionState,
    requestId: string,
    signal: AbortSignal,
    cursor?: string,
  ): Promise<CaiAttemptPage> {
    if (
      !bindingSelector(requestId) ||
      (cursor !== undefined && !receiptCursor(cursor))
    )
      throw new TypeError('Invalid receipt request or cursor');
    const body = await this.#request(
      `/api/v1/companion/sessions/${encodeURIComponent(session.id)}/turn-attempts/${encodeURIComponent(requestId)}${cursor === undefined ? '' : `?cursor=${encodeURIComponent(cursor)}`}`,
      undefined,
      signal,
      undefined,
      65536,
    );
    return decodeAttempt(body, session, requestId, cursor);
  }
  async readCall(
    sessionId: string,
    requestId: string,
    callId: string,
    signal: AbortSignal,
  ): Promise<CaiCallDetail> {
    if (!bindingSelector(requestId) || !bindingSelector(callId))
      throw new TypeError('Invalid receipt request or call ID');
    const body = await this.#request(
      `/api/v1/companion/sessions/${encodeURIComponent(sessionId)}/turn-attempts/${encodeURIComponent(requestId)}/calls/${encodeURIComponent(callId)}`,
      undefined,
      signal,
      undefined,
      524288,
    );
    return decodeCall(body, requestId, callId);
  }
  async #request(
    path: string,
    input: unknown,
    signal: AbortSignal,
    method?: 'PUT',
    receiptLimit?: 65536 | 524288,
  ): Promise<Json> {
    const response = await this.#fetch(this.#origin + path, {
      method: method ?? (input === undefined ? 'GET' : 'POST'),
      headers: {
        Authorization: `Bearer ${this.#token}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      ...(input === undefined ? {} : { body: JSON.stringify(input) }),
      signal,
      redirect: 'error',
    });
    if (!response.ok)
      throw new CaiHttpError(
        response.status,
        input === undefined ? 'read' : 'write',
      );
    const reader = response.body?.getReader();
    if (!reader) throw new Error('Empty CAI response');
    const decoder = new TextDecoder('utf-8', { fatal: true });
    let encoded = '',
      bytes = 0;
    try {
      for (;;) {
        const chunk = await reader.read();
        if (chunk.done) break;
        bytes += chunk.value.byteLength;
        if (bytes > (receiptLimit ?? 65536)) {
          await reader.cancel();
          throw new Error('CAI response limit exceeded');
        }
        encoded += decoder.decode(chunk.value, { stream: true });
      }
      encoded += decoder.decode();
    } finally {
      reader.releaseLock();
    }
    const body: unknown = JSON.parse(encoded);
    if (receiptLimit === undefined) {
      if (!boundedJson(body)) throw new Error('Invalid bounded CAI JSON');
      return body;
    }
    if (!receiptJson(body)) throw new Error('Invalid bounded CAI JSON');
    return body;
  }
}
/** Delivered foundation event envelope; the conversation also checks identity/version. */
export function decodeCaiEventReceipt(body: Json): CaiEventReceipt {
  if (
    !record(body) ||
    !record(body['data']) ||
    !text(body['data']['event_id']) ||
    !integer(body['data']['version'])
  )
    throw new Error('Invalid CAI feedback acknowledgment envelope');
  return {
    eventId: body['data']['event_id'],
    version: body['data']['version'],
  };
}
