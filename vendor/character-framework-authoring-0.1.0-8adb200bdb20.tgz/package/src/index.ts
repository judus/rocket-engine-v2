export { CharacterRuntime, CharacterHandle } from './Runtime.js';
export {
  NarrativeSystem,
  NarrativeHandle,
} from './narrative/NarrativeSystem.js';
export { QuestDraft } from './narrative/Draft.js';
export type {
  Condition,
  ContextInput,
  NarrativeEvent,
  OfferingEvent,
  OfferingPolicy,
  NarrativeGame,
  NarrativeResult,
  Objective,
  ObjectiveTemplate,
  QuestDefinition,
  QuestFlow,
  QuestStage,
  ToolName,
} from './narrative/types.js';
export type { NarrativeSave } from './narrative/state.js';
export type {
  Admission,
  CaiBinding,
  Capability,
  CapabilityResult,
  CharacterDefinition,
  CharacterBinding,
  CharacterSnapshot,
  Decision,
  Invocation,
  MutationIdentity,
  Json,
  ReasoningProvider,
  RuntimeEvent,
  RuntimeOptions,
} from './types.js';

export { DialogueDraft } from './narrative/dialogue.js';
export type {
  DialogueGraphDefinition,
  DialogueNode,
} from './narrative/dialogue.js';
export type { DialogueSource } from './narrative/DialogueStore.js';
export {
  SituationSystem,
  SituationHandle,
} from './situations/SituationSystem.js';
export { validateSituationDefinition } from './situations/validation.js';
export type {
  SituationDefinition,
  Situation,
  SituationCondition,
  SituationAction,
  SituationCapability,
  SituationGame,
  SituationScope,
  SituationInvocation,
  NarrativeExecutionContext,
  SituationObservation,
  SituationSave,
  SituationView,
} from './situations/types.js';
