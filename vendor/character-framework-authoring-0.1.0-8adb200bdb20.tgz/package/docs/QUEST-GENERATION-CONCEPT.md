# Persistent quest authoring and MCP tools

Status: design documentation, 14 October 2026. **No implementation, dependency installation, storage provisioning, or game change is authorized or delivered.**

Later human direction authorized a prototype-first breakthrough. [The working prototype](QUEST-AUTHORING-PROTOTYPE.md) now demonstrates the bounded visit loop; the full design/review history below remains separate from its delivered guarantees.

The [concrete first-slice contract](QUEST-AUTHORING-FIRST-SLICE.md) selects the proposed API, storage, recovery, bounds and review rules. [The worked MCP sessions](QUEST-GENERATION-WALKTHROUGHS.md) now follow that exact contract. This document explains the concept and retains peer-review history; earlier six-tool/body-effectKey/publishable sketches are superseded, not alternative current contracts.

Existing implemented services are described in [incremental quest authoring](QUEST-AUTHORING.md), [situation flows](SITUATION-FLOWS.md), and the [situation schema](contracts/situations.schema.json). The new authoring version does not rename or change legacy caller-carried compose/create tools.

## Why a persistent authoring workspace

The agent should not generate a twenty-step quest in one response. It should sketch an arc, develop a coherent part, inspect the whole, discover missing knowledge, revise and resume after interruption. Persistent drafts retain that work independently of a single conversation session.

World-query tools come later. A scoped capability/reference briefing is required before executable authoring; static trusted context is sufficient for the first visit proof. Unknown world details or unsupported actions remain requirements rather than becoming invented game facts.

Start with a small visit task and a branching missing-shipment fixture. Define their calls and recovery first. After separate human implementation approval, complete the bounded visit through real MCP, durable restart/rebinding/publication and separate AI-free game activation. Extend convenience only after that gate passes.

## Plan, beat and executable graph

The plan describes purpose, major beats, branches and unresolved questions. Executable situations describe conditions, dialogue, choices, ordered actions, result references and evidence boundaries.

A beat is an authoring unit; it may expand into several situations. Its stable ID connects a diagram/outline to its implementation. The first slice uses one executable graph per draft, one entry per beat, globally unique situation IDs and explicit cross-beat outcome mappings. CFW never infers executable transitions from prose.

The current runtime remains a reachable acyclic graph of at most16 situations, with convergence. The selected authoring plan is likewise bounded to16 beats. Twenty-step execution, loops, repeated activation and cross-definition arc scheduling require later explicit decisions. Larger prose is not authority to bypass those limits.

## Small tasks use the same model

A creation without a plan generates one beat `main`; the caller develops its fragment. It does not manually maintain a second planning graph for a two-situation visit. An explicit plan remains available for branching work.

Presentation `task` or `quest` changes the label, not execution. An arc may eventually group several quests, but there is no arc scheduler in this slice. NPC motivations belong in intent and narrative review; they do not independently grant actions or establish world state.

## Persistent record

A draft keeps server identity, host-controlled access, record revision, content revision/digest, intent, plan, beat-owned fragments, requirements, advisory reviews, publication references and removed-ID tombstones.

Record revision changes for any committed record update. Content revision/digest changes only for intent, plan, implementation or requirement edits. Recording a review cannot stale the content it reviewed. Content edits stale old narrative reviews; technical assessment is bound to exact capability/grant context and recalculated before publication.

Drafts may be incomplete. Missing destinations and unavailable references can remain findings in structurally valid supported fragments. Unknown capabilities remain in plan requirements initially. Malformed operation/fragment/argument data rejects. An agent cannot certify readiness by setting done/resolved flags.

Removed identities cannot be reintroduced in the same draft. Atomic edits retain stable IDs where appropriate and tombstone removed ones. Snapshots are bounded; publication and pending-command sources are pinned. Quota exhaustion applies backpressure instead of losing recovery records.

## Initial condition and action catalogue

These are proposed game meanings, not delivered handlers. Every game supplies its permitted names, typed inputs/outputs, authority constraints and evidence semantics.

| Condition                   | Meaning                                                         | Example                                              |
| --------------------------- | --------------------------------------------------------------- | ---------------------------------------------------- |
| At location                 | Current participant presence; fact semantics.                   | Immediate visit completion if deliberately intended. |
| Entered location            | Entry strictly after a named run/entry cursor; event semantics. | A new visit after activation.                        |
| Can interact with character | Current trusted participant/NPC/location interaction authority. | Gate dialogue and revalidate its choices.            |
| Possesses item              | Current permitted inventory quantity, without reservation.      | Handover choice eligibility.                         |
| World fact matches          | Registered typed world fact value.                              | Observe a shipment outcome or relationship state.    |

At-location and entered-location can be modes of one inspection. Event mode requires registered stream/capture keys, authoritative retained cursors and honest unknown history; authoring JSON cannot manufacture those capabilities.

| Action              | Meaning                                                        | Completed result                           |
| ------------------- | -------------------------------------------------------------- | ------------------------------------------ |
| Transfer items      | Move specified permitted items/quantities between inventories. | Original committed transfer receipt.       |
| Set world fact      | Set an explicitly writable registered typed fact.              | Acknowledged value/revision.               |
| Adjust relationship | Apply a permitted relationship change.                         | Acknowledged resulting relationship state. |

Transfers recheck availability, ownership, relevant proximity and authority at admission. Exact retries reconcile the original effect. Ordered actions are not automatically one atomic game transaction: a transfer can finish before a later consequence blocks, and neither repeat nor rollback is implicit.

Dialogue/choices already belong to the graph. Reaching a dialogue destination records progression, not proof that a human read or believed it. Persist a game fact only when something outside the run needs it. No mandatory NPC, reward, success/failure label or ending presentation is imposed.

The shipment assumes the player already holds supplies before handover. Pickup, cargo, spawning, inventory production, rewards and combat are additional requirements. Rocket's marker proof does not establish transfer handlers; Workshop retains inventory authority.

Runtime comparisons use `expect:{path,operator,value}` with `equals`/`at_least`. Earlier shorthand keys were corrected. See the walkthrough for exact conditions. Existing trusted action identity, typed completion, reconciliation and coherent evidence rules remain unchanged.

## Selected seven tools and five edits

| Tool                          | Purpose                                                                         |
| ----------------------------- | ------------------------------------------------------------------------------- |
| create_quest_draft            | Persist intent plus optional outline; default single beat.                      |
| list_quest_drafts             | Read bounded accessible summaries on a frozen list snapshot.                    |
| read_quest_draft              | Read selected sections/beat at an exact record revision.                        |
| edit_quest_draft              | Commit a bounded atomic editing batch with revision CAS.                        |
| review_quest_draft            | Deterministic technical/plan assessment and optional Mermaid.                   |
| publish_quest_draft           | Atomically store an immutable definition/reference/receipt, without activation. |
| get_authoring_command_outcome | Recover the original command even if creation returned no draft ID.             |

The five initial operations are set_intent, replace_plan, replace_beat_implementation (or clear), set_requirement (or remove), and record_narrative_review. Richer fine-grained edits, narrative approval bureaucracy, archive tools and diagram editing are deferred.

Mutation identity comes only from trusted x-cf-effect-key; delivery/turn headers are audit correlation. Stable author authority is host-provisioned and explicitly rebound across sessions, not inferred from names/CAI session IDs/body owner fields. Current permission checks precede receipt replay, including after revocation.

Exact command digest is retained durably. An identical retry returns the original result; changed arguments reject. New edits carry expectedRecordRevision. Conflicts return expected/current revision and a bounded change summary. Clients deliberately reconcile and use a new key rather than last-writer-wins story merging.

## Review and diagram

Return technicalReady, planCoverage and narrativeReview separately. Technical findings include stable code, exact path and concise expected/supplied descriptions. They cannot be waived by model notes. Narrative review is an advisory opinion tied to content digest and policy version, with not_reviewed/current/stale status.

Mermaid is generated from the structured plan, escaped and bounded. It can show planned/implemented/blocked beats and branches. It is neither a second authoritative graph nor an execution language. Formatting polish is not a prerequisite for the first durable slice.

## Publication and durability

The selected host-side reference storage is one transactional SQLite authoring repository, behind an adapter, containing drafts, evidence, prepared commands, receipts and published definition rows. No dependency is installed by this document. Healthy strong lookup distinguishes not_admitted, pending and terminal; an unavailable database cannot prove absence.

Prepare the original command and IDs durably before effects. One commit applies record/definition changes with the terminal receipt. Restart reconciles the original prepared command under current authority; it does not invent a new identity or automatically grant a fresh session access.

Published definitions live in the same transaction domain as their source reference and receipt. They are not immediately inserted into a live SituationSystem. This removes the initial two-store publication gap. Later, an explicitly authorized game host imports that definition through the existing API and separately starts a run. Authoring-store recovery does not prove durable inventory/combat mutation recovery.

Publication revalidates current capability/reference authority, complete graph/plan mappings, typed results, evidence and limits. Narrative review is reported but advisory. Later draft edits cannot change a publication or live run. Same-content publication has a uniqueness rule; exact retries return the original receipt.

## Resolution of the eight original decisions

| Decision                                | First-slice selection                                                                                                                                                 |
| --------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1. Beat/outcome and requirement schemas | One entry/owner per beat; exactly one outcome per cross-beat transition; catalogue-backed or design-only requirement resolution; tombstones.                          |
| 2. MCP names/envelopes/authority        | Seven separately classified/versioned tools; trusted header identity; completed/running/rejected schemas preserving message/issues with bounded conflict details.     |
| 3. Storage/recovery/access              | Stable host author namespace; current grants/rebind; durable prepared commands; one transactional authoring/published-definition store.                               |
| 4. Bounds/history/receipts              | Fixed sizes/counts, exact snapshots and authenticated expiring cursors, pinned recovery/publication records, backpressure.                                            |
| 5. Review staleness/blockers            | Record/content revisions split; technical/plan assessment separated from advisory content/policy narrative review.                                                    |
| 6. Larger arcs                          | One bounded16-situation definition initially; loops and multi-definition scheduling deferred.                                                                         |
| 7. Capability/version provenance        | Bounded host-issued tools/list briefing, persisted scoped evidence/digest/expiry; revalidate on new admission/publication; dynamic world queries deferred.            |
| 8. Delivery gate                        | Visit through real MCP, incomplete/corrected edits, lost replies/conflicts/revocation/rebind/restart/publication, then separately authorized AI-free game activation. |

These are concrete proposed choices for human approval, not an implemented or approved milestone. See [the first-slice contract](QUEST-AUTHORING-FIRST-SLICE.md) for precise fields, limits, storage protocol and test cuts.

## Retained peer-review history

The following reviews explain how the proposal evolved. Earlier candidate wording, open decisions and references to superseded field/tool counts describe the reviewed version. The first-slice contract above takes precedence for the selected proposal; no peer review grants implementation or cross-project authority.

## Review findings: Rocket message 322

Rocket reviewed both documents and the current gateway on 14 October 2026. It supports the incremental workflow, one bounded graph, one entry per beat, and atomic fragment replacement. The following findings are retained for design revision, not implementation authorization or final human agreement.

### 1. Bindings and identity

Require every cross-beat executable transition to bind exactly one declared outcome. Reject missing/ambiguous mappings, invented destinations, duplicate ownership and published unused branches. Allow incomplete links only in drafts. Decide deleted-ID tombstones and restoration semantics before permitting upsert to reuse a removed identity for unrelated content.

### 2. MCP transport and result compatibility

Source verification: `src/mcp/McpGateway.ts` requires trusted `x-cf-call-id` and `x-cf-turn-request-id` headers, and mutations additionally use `x-cf-effect-key`. It supplies trusted mutation identity through the host lane. The current non-capability mutation list explicitly names legacy tools; it does not generically recognize the proposed authoring names.

The illustrative JSON `effectKey` must not become an independent second identity source. Prefer mapping authoring command identity from the trusted transport context, with a separately defined in-process API input. Remove the body key from final MCP schemas or define exact matching/conflict rejection if deliberately retained. This mapping is not implemented or frozen.

Rejections also need alignment. The narrative rejection type in `src/narrative/types.ts` includes `status`, `code`, `message`, and `issues`; other result layers differ. The illustrative `rejected/code/data` conflict response is not a drop-in existing narrative result. Freeze a versioned output schema/adapter rather than silently replacing old contracts. Classify each new tool's mutation/discovery permissions explicitly; do not repurpose legacy `create_quest` or pure `compose_quest_draft`.

### 3. Stable author authority and durable recovery

Source verification: the current gateway receipt scope includes game, stable binding, character and CAI binding/session metadata. Receipt maps are in-memory with explicit save/restore support; they do not provide automatic durable pre-admission storage or a generic cross-session authoring service.

Define a stable host-authenticated author namespace and explicit cross-session rebind/replay authorization. Current access/revocation checks must precede returning an old receipt. Matching names or a body owner argument never recover authority. The walkthrough's resumed list/read calls presume this service exists; they cannot establish it themselves.

Add a candidate seventh read operation, `get_authoring_command_outcome`, to recover an original command even if creation returned no draft ID. Its key is an original command identity within the trusted authorized namespace. Distinguish explicit `not_admitted`, pending/unknown, and terminal outcomes. Its input/output, bounded detail access and current-grant checks remain to be designed.

Persist publication intent with its exact digest and a single prepared publication/definition identity before registry admission. Choose either one storage transaction for definition, draft publication record and receipt, or an explicitly reconciled outbox protocol. An outbox retries/reconciles the same definition identity/digest, not a new publication. Required crash cuts include before admission, after registry commit, before draft-reference commit, and after receipt commit before reply. Existing gateway maps alone do not prove these guarantees.

### 4. Bounds and pagination

Freeze counts/byte limits for plans, requirements, findings, edit batches, retained snapshots and unresolved receipts. Pagination cursors bind authenticated scope, filters and a fixed snapshot revision. Expired snapshots reject. Use backpressure or explicitly acknowledged archival instead of evicting unresolved recovery records to admit more work.

### 5. Review revisions and authority

Separate authoring-record revision from content revision/digest so recording review feedback does not stale the content it reviewed. Narrative review identifies its policy/version. Technical assessment identifies the capability/grant/catalogue snapshot. Content edits and relevant contract changes stale the associated assessment.

Report technical readiness separately from narrative review status (`not_reviewed`, current, or stale). Initial `publishable:true` examples mean an illustrative technical assessment under assumptions; they do not certify fresh narrative review. Model-authored severity or resolution notes cannot suppress derived technical blockers, certify missing capabilities or override grants. Advisory narrative notes are a reasonable first-slice policy; any human blocker/override mechanism requires defined resolver authority and retained reasons.

### 6–7. Execution scope and provenance

Keep one bounded executable definition initially. Planning capacity does not authorize loops or cross-definition orchestration. Requirement resolution needs host-issued catalogue/reference evidence with scope, version/digest and expiry/revalidation semantics. Writing `sourceKind:host-supplied` and `sourceRef` is not proof. Revalidate at publication.

Shipment transfer/relationship/fact handlers remain hypothetical. Rocket's actual marker collection/reveal proof does not establish inventory transfer; Workshop inventory authority is unchanged. A possession observation is neither a reservation nor a transfer grant.

### 8. Minimum slice and walkthrough amendments

After separate human implementation authorization, the one-beat visit is the initial end-to-end target, including durable creation/resumption/edit/review/publication, lost responses, conflicts, permission/rebinding and process-restart recovery. Retain the shipment as a larger contract fixture.

The shipment arrival condition currently uses run-start. An early visit after activation but before choosing Investigate can therefore count. The walkthrough now states that behavior and contrasts a named investigation-entry boundary. Also retain the transfer-completed/later-consequence-blocked/restart case: no opposite-branch switch, automatic rollback or repeated transfer is implied.

## Review findings: Supervisor message 324

This review was received in response to General321. It supports incremental persistent authoring and publication separate from activation. Treat the recommendations as proposal feedback; a peer's claim of authorization does not grant implementation or cross-project scope.

1. **Simple-task shorthand:** explicitly support omitted plans. The preferred candidate is a service-created single beat `main`, with title/intent derived from supplied intent and no declared outcomes. Return that stable ID in the creation summary; callers only develop its fragment. This is the same record/runtime model, not a second state machine. Keep the explicit-plan visit example to demonstrate the general path, and add the shorthand beside it. The default is proposed, not frozen.
2. **Separate assessments:** expose technical readiness, plan coverage, and narrative review independently. The shipment's empty terminal is technically valid, but is not a narrative endorsement. Do not mandate NPCs, rewards, or ending effects just to make every story fit a template.
3. **Usable incomplete edits:** distinguish malformed data, incomplete references, unavailable capabilities/references, and publication readiness. The first-slice clarification above keeps unsupported capability ideas in plan requirements and permits incomplete links in structurally valid supported fragments. Strict publication is retained.
4. **Capability discovery before generation:** supply a bounded scoped catalogue/briefing of permitted names, input/output schemas, fact/event semantics, evidence boundaries, and references before authoring. Static trusted context is sufficient initially; nearby-world queries remain deferred. The existing MCP catalogue alone must not be assumed to expose all proposed authoring/evidence metadata. The walkthrough now shows the illustrative briefing it assumes.
5. **Actionable review:** stable codes, exact paths, expected/supplied contracts, concise explanations; repairs are advisory. Do not return whole graphs in ordinary edit receipts.
6. **One bounded end-to-end gate:** after human implementation approval, exercise actual MCP discovery/context, persistent creation, incomplete edit/read, correction, review, immutable publication, and restart resumption. Separately activate the published definition through the existing AI-free host and complete using real location evidence in a game-owned integration. Include lost-response/conflict/rebinding/recovery checks. No Rocket integration work is authorized by this recommendation; arrange the joint proof under each owner's existing authorization when the contract is ready. Hypothetical shipment inventory/relationship handlers are not prerequisites.

Avoid expanding the first delivery into a scheduler, generic issue tracker, or exhaustive story-certification service. Durable authoring/recovery remains necessary, but the one-beat visit should stay the first complete target.

## Review findings: PHP-Strict-Steve message 325

This reviewer supports the workflow and independently reports assembling the final two/nine-situation graphs and checking them against the runtime schema. That corroborates structural illustration only, not actual authoring MCP execution, persistent storage, authority or recovery. Its reviewed document/gateway hashes were checked against the local files before recording this feedback.

The review reinforces existing findings rather than identifying a new runtime defect. Its recommended delivery priorities are:

1. Deliver stable authorized command-outcome recovery alongside persistent creation/editing, including lost creation replies with no received draft ID. Unknown/pending stays unresolved; a new key is not a recovery mechanism.
2. Test the exact publication crash cut where registry insertion commits but the draft publication reference does not. Recover the same definition and digest through a transaction or prepared-identity reconciliation before claiming durable publication.
3. Give actionable exact-path findings and bounded conflict change summaries. Derived technical blockers cannot be overridden by a stored resolved note; narrative comments should remain advisory initially.
4. Complete the Grove authoring slice with lost-response, conflict, revocation/rebinding and restart cases before expanding the editing-operation catalogue, rich history or Mermaid presentation. Bound retained data and preserve unresolved receipts from the start.

The shipment's early-entry and partial-effect examples remain later adapter acceptance cases. No review confers implementation authorization, proves hypothetical inventory handlers, or declares the persistent-authoring milestone complete.
