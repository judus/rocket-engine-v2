# Worked watchtower authoring guide

Use with `cfw-authoring-prototype-1`, the discovered authoring tool schemas, the live permitted capability catalogue and game-supplied world context. This guide explains technical composition; the quest-design prompt supplies narrative goals. The fixed [complete example](contracts/watchtower-authoring-example.json) captures Rocket's corrected baseline `32aabc76aaf1c3f0a8cc57bb6a9287ac3f55eb46334c78a3ba6086be8d0c9f9d`. Its descriptors are an example, not a replacement for the endpoint's current grants or world facts.

## Discover, ground, plan

Read `read_quest_draft({"section":"catalogue"})` before authoring. Its normal completed result contains `data.contractVersion`, `data.capabilities` and `data.references`. Each capability declares name, description, inspection/action kind, input/output schemas, optional evidence stream/capture keys and literal reference bindings. Catalogue presence describes what a graph may invoke; directly calling game inspections also requires explicit host registration and actor grants. The catalogue does not contain current world state. Read the game host's separately discovered world-summary tool; its name/schema comes from that host, not this guide.

For this fixed watchtower, the player enters the courtyard, defeats sentries activated by the quest, approaches the revealed watchkeeper, chooses Blue or Red, acquires the matching seal and delivers it to its matching beacon. The game owns movement, interaction range, gate collision, one-time custody/delivery and evidence. CFW owns authored progression. Explain hidden entities and prerequisite consequences; a coordinate or reference alone does not prove attainability. A game description may invent narrative lore while executable references and actions must come from the supplied world/catalogue.

The corrected policy is **an existing matching delivery counts**. Pickup still needs a new event after its authored stage unless the item is already collected. Do not change a brief requiring a genuinely new delivery into historical completion during repair. Such a brief requires compatible game mechanics that prevent irreversible delivery too early.

## Create and compose one main beat

Call `create_quest_draft` with `intent` containing `title` and optional `premise`/`presentation` (`task` or `quest`). Retain the returned draft ID and record revision. Plot stages are situation nodes within the supplied beat `main`; there are no attach-beat or arc tools.

Call `edit_quest_draft` with `draftId`, `expectedRecordRevision` and an `operations` array. The complete example's `implementation` can be used as the value of this operation:

Use `{ "kind": "replace_beat_implementation", "beatId": "main", "implementation": EXAMPLE_IMPLEMENTATION }`, replacing `EXAMPLE_IMPLEMENTATION` with the complete example's actual `implementation` object. Maximum sixteen situations, twelve KiB fragment and four operations per edit; `outcomeBindings` must be empty. Other operations are `set_intent` and `record_narrative_review`; use discovered schemas. Replace the graph to repair it, using the latest returned revision. Missing destinations can be saved as an incomplete supported fragment but block publication.

The complete example has twelve nodes:

| Node                         | Progress/consequence                                                |
| ---------------------------- | ------------------------------------------------------------------- |
| approach                     | New courtyard entry since run start                                 |
| encounter                    | Activate sentries on entry; three new defeats since encounter entry |
| watchkeeper                  | Reveal guide and open gate; route when near guide                   |
| offer                        | Guarded dialogue with two choices                                   |
| blue-router / red-router     | Already-collected fact skips pickup; otherwise enter pickup         |
| blue-pickup / red-pickup     | Reveal selected seal; require new pickup since this stage           |
| blue-delivery / red-delivery | Matching item/destination delivered fact                            |
| blue-complete / red-complete | Light only the matching beacon; close after action commits          |

Use `routes[].when` for automatic transitions, with unique ascending priorities. Conditions require `tool`, `arguments`, `expect` and `evidence`. `expect.path` is an array of declared output property names; `at_least` requires numeric output/value, while `equals` must match the declared scalar type. Arguments must satisfy the actual capability schema and permitted references.

## Facts, new events, choices and consequences

A new-event route captures authoritative evidence with a declared boundary; it does not count all historical actions:

```json
{
  "tool": "game_encounter",
  "arguments": { "groupRef": "sentries" },
  "expect": { "path": ["count"], "operator": "at_least", "value": 3 },
  "evidence": {
    "mode": "events",
    "after": { "kind": "situation-entry", "situationRef": "encounter" }
  }
}
```

A matching-delivery fact checks both named references. Merely visiting a beacon or delivering the other seal is insufficient:

```json
{
  "tool": "game_delivery",
  "arguments": { "itemRef": "blue-seal", "destinationRef": "beacon-a" },
  "expect": { "path": ["delivered"], "operator": "equals", "value": true },
  "evidence": { "mode": "fact" }
}
```

The `offer` node uses `dialogue.requires` to gate both prose and choices on current guide proximity. Choices have authored `id`, `label` and `next`, with optional `when`. The player host receives opaque runtime choice IDs/revisions; the author does not invent commit IDs. Choice commit rechecks guards. Automatic routes settle before choice presentation.

`onEnter` is an ordered action list (`id`, `tool`, `arguments`), such as revealing a guide, opening the gate or lighting a beacon. Use only permitted game actions. Entry actions must authoritatively finish before routes/choices proceed; admission or prose is not a committed effect. A node with no outgoing routes/choices closes only after its entry actions finish. No scene stage checks are needed. The complete example supplies actual action syntax and destinations.

## Read, review, repair, publish

Read `overview` for intent/current assessment, `beat` for the actual saved graph, and `publications` for its publication record. Use `list_quest_drafts({})` to resume a retained workspace. `review_quest_draft` returns `technicalReady`, findings with paths, plan coverage and advisory narrative review status. It does not prove a quest is coherent, attainable or faithful to the brief; `planCoverage:complete` only means an implementation is present. No Mermaid/render tool exists in this slice.

Before publication verify the saved graph against the brief: correct refs/causes, reachable terminals, guards, every branch's matching consequences and intended event/fact timing. Keep all failed initial graphs and explicit corrections. A narrative-review summary is an opinion tied to a content digest; further content edits stale it. Never silently remove a requirement to obtain readiness.

`publish_quest_draft` uses the current expected record revision. It returns authoritative `definitionId`, `definitionDigest`, `sourceRevision` and `commandId`; publication creates no gameplay run and makes the draft immutable. Preserve the exact successful receipt and correlate that definition/digest to the consumer. Do not select the latest publication or infer success from the model report. The host separately imports/starts the stored definition, then exercises each branch from reset game state through ordinary handlers with AI disconnected.

Transport call/turn/effect identities and exact retries are host/connector-owned, not tool arguments. Existing prototype recovery uses the retained binding and receipt tools; this guide adds no crash/rebinding guarantee. A fake provider proves plumbing, not generation quality. Agree the finite briefs/model/correction budget before a live batch and record validity, corrections, brief compliance and playable completion separately.

## Complete implementation value

This compact JSON is the complete `implementation` value for `replace_beat_implementation`. Use the current discovered catalogue to confirm it applies to your bound world; keep any generated candidate separate from this comparison example.

<!-- prettier-ignore -->
```json
{"entrySituation":"approach","situations":[{"id":"approach","dialogue":{"text":"Enter the courtyard to investigate the ruined watchtower."},"routes":[{"id":"new-arrival","priority":10,"when":{"tool":"game_location","arguments":{"locationRef":"courtyard"},"expect":{"path":["count"],"operator":"at_least","value":1},"evidence":{"mode":"events","after":{"kind":"run-start"}}},"next":"encounter"}]},{"id":"encounter","dialogue":{"text":"The sentries awaken. Move close to each and press E or click to defeat it."},"routes":[{"id":"three-new-defeats","priority":10,"when":{"tool":"game_encounter","arguments":{"groupRef":"sentries"},"expect":{"path":["count"],"operator":"at_least","value":3},"evidence":{"mode":"events","after":{"kind":"situation-entry","situationRef":"encounter"}}},"next":"watchkeeper"}],"onEnter":[{"id":"wake-sentries","tool":"game_activate_group","arguments":{"groupRef":"sentries"}}]},{"id":"watchkeeper","dialogue":{"text":"The watchkeeper appears. Approach to learn the route to the beacon."},"routes":[{"id":"approach-guide","priority":10,"when":{"tool":"game_entity","arguments":{"entityRef":"guide"},"expect":{"path":["near"],"operator":"equals","value":true},"evidence":{"mode":"fact"}},"next":"offer"}],"onEnter":[{"id":"show-guide","tool":"game_reveal","arguments":{"entityRef":"guide"}},{"id":"open-ridge-gate","tool":"game_open_gate","arguments":{"entityRef":"gate"}}]},{"id":"offer","dialogue":{"text":"Watchkeeper: The tower has two paths. Do you want the blue seal or the red seal? Blue belongs at Beacon Ridge A; red belongs at Beacon Ridge B.","requires":{"tool":"game_entity","arguments":{"entityRef":"guide"},"expect":{"path":["near"],"operator":"equals","value":true},"evidence":{"mode":"fact"}}},"choices":[{"id":"blue","label":"Blue seal — Beacon Ridge A","when":{"tool":"game_entity","arguments":{"entityRef":"guide"},"expect":{"path":["near"],"operator":"equals","value":true},"evidence":{"mode":"fact"}},"next":"blue-router"},{"id":"red","label":"Red seal — Beacon Ridge B","when":{"tool":"game_entity","arguments":{"entityRef":"guide"},"expect":{"path":["near"],"operator":"equals","value":true},"evidence":{"mode":"fact"}},"next":"red-router"}]},{"id":"blue-router","routes":[{"id":"prior-carried-seal","priority":10,"when":{"tool":"game_entity","arguments":{"entityRef":"blue-seal"},"expect":{"path":["collected"],"operator":"equals","value":true},"evidence":{"mode":"fact"}},"next":"blue-delivery"},{"id":"recover-seal","priority":20,"when":{"tool":"game_entity","arguments":{"entityRef":"blue-seal"},"expect":{"path":["collected"],"operator":"equals","value":false},"evidence":{"mode":"fact"}},"next":"blue-pickup"}]},{"id":"blue-pickup","dialogue":{"text":"Watchkeeper: You chose blue. Recover the blue seal, then carry it to Beacon Ridge A."},"onEnter":[{"id":"show-selected-seal","tool":"game_reveal","arguments":{"entityRef":"blue-seal"}}],"routes":[{"id":"new-pickup","priority":10,"when":{"tool":"game_entity","arguments":{"entityRef":"blue-seal"},"expect":{"path":["count"],"operator":"at_least","value":1},"evidence":{"mode":"events","after":{"kind":"situation-entry","situationRef":"blue-pickup"}}},"next":"blue-delivery"}]},{"id":"blue-delivery","dialogue":{"text":"Watchkeeper: Deliver the blue seal to Beacon Ridge A. Stand by Beacon A and press E or click it. The other beacon cannot accept this seal."},"routes":[{"id":"matching-delivery","priority":10,"when":{"tool":"game_delivery","arguments":{"itemRef":"blue-seal","destinationRef":"beacon-a"},"expect":{"path":["delivered"],"operator":"equals","value":true},"evidence":{"mode":"fact"}},"next":"blue-complete"}]},{"id":"blue-complete","dialogue":{"text":"The blue seal reached Beacon Ridge A. Beacon A is lit. Your chosen mission is complete."},"onEnter":[{"id":"light-matching-beacon","tool":"game_light_beacon","arguments":{"entityRef":"beacon-a"}}]},{"id":"red-router","routes":[{"id":"prior-carried-seal","priority":10,"when":{"tool":"game_entity","arguments":{"entityRef":"red-seal"},"expect":{"path":["collected"],"operator":"equals","value":true},"evidence":{"mode":"fact"}},"next":"red-delivery"},{"id":"recover-seal","priority":20,"when":{"tool":"game_entity","arguments":{"entityRef":"red-seal"},"expect":{"path":["collected"],"operator":"equals","value":false},"evidence":{"mode":"fact"}},"next":"red-pickup"}]},{"id":"red-pickup","dialogue":{"text":"Watchkeeper: You chose red. Recover the red seal, then carry it to Beacon Ridge B."},"onEnter":[{"id":"show-selected-seal","tool":"game_reveal","arguments":{"entityRef":"red-seal"}}],"routes":[{"id":"new-pickup","priority":10,"when":{"tool":"game_entity","arguments":{"entityRef":"red-seal"},"expect":{"path":["count"],"operator":"at_least","value":1},"evidence":{"mode":"events","after":{"kind":"situation-entry","situationRef":"red-pickup"}}},"next":"red-delivery"}]},{"id":"red-delivery","dialogue":{"text":"Watchkeeper: Deliver the red seal to Beacon Ridge B. Stand by Beacon B and press E or click it. The other beacon cannot accept this seal."},"routes":[{"id":"matching-delivery","priority":10,"when":{"tool":"game_delivery","arguments":{"itemRef":"red-seal","destinationRef":"beacon-b"},"expect":{"path":["delivered"],"operator":"equals","value":true},"evidence":{"mode":"fact"}},"next":"red-complete"}]},{"id":"red-complete","dialogue":{"text":"The red seal reached Beacon Ridge B. Beacon B is lit. Your chosen mission is complete."},"onEnter":[{"id":"light-matching-beacon","tool":"game_light_beacon","arguments":{"entityRef":"beacon-b"}}]}],"outcomeBindings":[]}
```
