# Persistent quest authoring: concrete first-slice contract

Version: `cfw-authoring-1`. Status: documentation proposal for human approval, 14 October 2026. **No implementation is authorized or delivered by this document.** It selects the first-slice design from the concept and peer reviews; it is not a claim that existing MCP/runtime APIs already implement it.

The human subsequently prioritized a working E2E prototype over completing this entire specification. [The prototype guide](QUEST-AUTHORING-PROTOTYPE.md) records what is implemented as `cfw-authoring-prototype-1`; this stricter specification and its open findings remain a hardening reference, not a claim of prototype completeness.

This document is normative for the proposed first slice. [The concept](QUEST-GENERATION-CONCEPT.md) provides rationale and retained review history. [The walkthroughs](QUEST-GENERATION-WALKTHROUGHS.md) use this exact proposal. Existing legacy quest tools and the authored situation runtime retain their contracts.

Focused reviews328–331 found unresolved contract blockers, recorded in [section13](#13-focused-review-blockers-328331). The selected design is not ready to freeze or implement until those findings are resolved. The walkthroughs illustrate the reviewed version rather than proving transport/recovery completeness.

## 1. Scope

Deliver one persistent authoring service, seven MCP tools, five edit operations, one bounded acyclic executable graph per draft, and one end-to-end visit proof. A single-beat task and a branching outline use the same record. No AI provider is necessary for authoring-tool execution, validation, publication or runtime interpretation.

Defer dynamic world queries, cross-definition arc scheduling, loops, repeatable-run policy, sharing between authors, draft deletion/archive tools, generic JSON patches, exhaustive narrative certification, and real inventory/relationship handlers. Mermaid is an optional bounded projection, not an editing language or first-delivery prerequisite.

The service accepts plans of up to 16 beats. Published graphs still obey the existing runtime's maximum 16 situations and existing schema/semantic validation. A large prose arc does not bypass execution limits.

## 2. Stable author identity and transport

The host provisions a stable `(gameId, authorId)` namespace and binds an authenticated session to it. The namespace is persisted independently of CAI session IDs and runtime registration generations. A fresh session resumes only after explicit host rebind approval. There is no public tool to choose an author, elevate grants, or impersonate an owner.

The current session must hold the relevant grants: `authoring.read`, `authoring.edit`, `authoring.publish`, and `authoring.recover`. Reads/list/review use read; create/edit use edit; publication uses publish plus read; outcome lookup uses recover and access to any identified draft/publication. Returning a historical mutation receipt also requires current recover/access checks. A revoked or unapproved session receives `permission_denied` without receipt contents. Different authors do not share drafts in this slice.

Host authority changes and authoring commits are serialized. Admission and commit both validate the current host-issued authority lease/revision. A revoked lease cannot race a queued commit. A completed pre-revocation commit is not rolled back; access to its receipt is checked separately.

All MCP calls retain trusted `x-cf-call-id` and `x-cf-turn-request-id` delivery headers. Mutations additionally require `x-cf-effect-key`, which is the canonical authoring command key. **No tool argument contains `effectKey`, `authorId`, credentials, or trusted scope.** Duplicate identity supplied in arguments rejects as an unknown property.

Command identity is `(gameId, authorId, effectKey)`. Its argument digest is SHA-256 over UTF-8 canonical JSON `{tool,arguments}`: recursively sorted object keys, array order retained, native JSON scalar serialization, finite JSON values only. Delivery/turn IDs are audit metadata and do not change command identity. A retry may use new delivery IDs but must preserve the command key and exact arguments. A changed digest under the same key returns `effect_key_conflict`.

The host resolves stable author authority before dispatch. Proposed authoring mutations are explicitly registered/classified and use the authoring repository's durable command journal. They must not also run through a second legacy session-scoped receipt authority. Existing legacy mutations continue using their existing gateway path. The adapter may supply trusted `Invocation.mutation` correlation but never derives it from model arguments.

## 3. Capability briefing before authoring

MCP `tools/list` supplies the seven tool schemas and a bounded `result._meta.cfwAuthoring` briefing:

```json
{
  "contractVersion": "cfw-authoring-1",
  "catalogueSnapshotId": "host-issued-opaque-id",
  "catalogueDigest": "sha256:<64-hex>",
  "expiresAt": "host-issued-UTC-time",
  "capabilities": [],
  "references": []
}
```

This metadata placement is the selected first-slice extension, not an existing gateway feature. A snapshot is host-issued, immutable, bound to the author namespace/current grants, persisted with its digest, and valid for at most 15 minutes. The host can revoke it earlier. The agent cannot create evidence by writing an ID. List again for fresh context; no live world inspection is performed by this briefing.

Each capability has name, description, inspection/action kind, input/output JSON Schema, permitted fact/event semantics and supported boundaries. Event-capable inspections include registered stream ref and capture keys. Each reference has a permitted opaque ref, category and author-readable description. The snapshot contains only granted entries, at most 16 capabilities and 32 references, within 32 KiB. If it cannot fit, provisioning rejects rather than silently hiding required contracts.

The visit snapshot exposes current location and post-boundary entry semantics. Shipment transfer/fact/relationship contracts are hypothetical until a game supplies them. Capability metadata is descriptive; actions and inspections still check live trusted authority at runtime.

Edit, review and publication identify a `catalogueSnapshotId`. For a newly admitted command the ID must be current, unexpired and authorized at commit. Staleness returns `catalogue_stale`; do not substitute a newer snapshot without a new command. Exact replay of a terminal receipt needs current receipt access, but does not repeat capability validation or world actions under a new catalogue.

## 4. Draft records, planning and identity

Each draft contains:

| Field              | Meaning                                                                         |
| ------------------ | ------------------------------------------------------------------------------- |
| `draftId`          | Server-issued UUID-based ID, immutable.                                         |
| `recordRevision`   | Incremented by every committed record change.                                   |
| `contentRevision`  | Incremented only when intent, plan, implementations or requirements change.     |
| `contentDigest`    | SHA-256 canonical JSON of those four content sections.                          |
| `intent`           | Title, premise, presentation (`task` or `quest`), constraints.                  |
| `plan`             | Start beat and beat/outcome declarations.                                       |
| `implementations`  | Beat-owned executable fragments.                                                |
| `requirements`     | Missing knowledge/capabilities/design decisions with typed resolution evidence. |
| `narrativeReviews` | Advisory review records referring to content digest and review policy.          |
| `publications`     | Immutable publication references and source record/content identity.            |
| `tombstones`       | Removed beat, outcome, requirement and situation identities.                    |

For content hashing, `implementations` is an object keyed by beat ID (fragment bodies omit redundant beat ID); `requirements` is an ordered array. Plans/fragments retain their authored array order.

Creation without `plan` generates beat `main`, derives its title/intent from the supplied intent, and gives it no outcomes. Return that ID explicitly. Creation with a plan preserves authored IDs. There is no second task state machine.

Plan shape: `{startBeat,beats:[{id,title,intent,outcomes:[{id,nextBeat}]}]}`. Beat IDs and situation IDs are globally unique within their respective draft categories; outcomes are scoped to their owning beat. The plan is a reachable DAG at publication. During editing, missing destinations/reachability may remain findings. Duplicate IDs and malformed structures reject immediately.

An implementation is `{beatId,entrySituation,situations,outcomeBindings}`. Each situation has exactly one owning beat; IDs are global across fragments. Its situation objects use the existing runtime schema without adding executable draft fields. A fragment's entry must belong to it. Cross-beat destinations may be absent during authoring, but never at publication.

Every outgoing cross-beat route/choice maps to exactly one outcome:

```json
{
  "outcomeId": "explanation-found",
  "transitions": [
    {
      "situationId": "witness-talk",
      "kind": "choice",
      "transitionId": "consider-options"
    }
  ]
}
```

The outcome destination's entry must equal the transition's actual `next`. Every declared outcome has at least one binding at publication. Terminal beats declare no outcomes or cross-beat exits. Every fragment node is reachable within its beat from its entry without leaving/re-entering it; cross-beat edges enter only the destination entry. Convergence is allowed; implicit multi-entry beats are not.

Removed identities become tombstones and cannot be reintroduced within that draft. Retaining an existing ID during a normal revision is allowed. There is no restore-deleted-ID operation; use a new ID. Clearing a fragment tombstones its removed situation IDs. Full record snapshots preserve history but do not override tombstones.

## 5. Five atomic editing operations

`edit_quest_draft` accepts a bounded ordered batch. Apply operations in order to a private candidate, validate the final structure/quota/authority, then commit all changes and their receipt together. Rejection preserves the previous draft. A no-op batch returns current revisions without creating a snapshot, but its command receipt is terminal.

| Operation                     | Fields and behavior                                                                                                                                                                                                 |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `set_intent`                  | `intent`: replace the complete intent.                                                                                                                                                                              |
| `replace_plan`                | `plan`: replace a bounded outline while preserving retained IDs. Removing beats is allowed only if no final fragment/requirement references them; clear/remove those in the same batch. Removed IDs are tombstoned. |
| `replace_beat_implementation` | `beatId`, `implementation`: replace one complete fragment, or `null` to clear it. Fragment shape omits redundant `beatId` and contains `entrySituation`, `situations`, `outcomeBindings`.                           |
| `set_requirement`             | `requirementId`, `requirement`: add/replace a complete requirement, or `null` to remove/tombstone it.                                                                                                               |
| `record_narrative_review`     | `review`: append advisory feedback for an exact content digest and policy version; no standalone approval/blocker machinery.                                                                                        |

Requirement shape: `{id,beatId,kind,question,resolution}`. Kinds are `capability`, `world_reference`, or `design`. Capability resolution is `{kind:"catalogue",capabilityNames:[...]}`; reference resolution is `{kind:"catalogue",referenceIds:[...]}`. These resolve against the edit's host-issued snapshot. The command/audit evidence records its issued ID/digest separately; the authored resolution and content digest are not silently augmented with server metadata. A model-provided `sourceKind` assertion is never evidence. Design resolution is `{kind:"design",decision:"..."}` and only resolves a design question. All unresolved requirements block publication in this slice. To abandon an irrelevant requirement, explicitly remove it with an authoring edit; derived executable blockers still apply.

Historical resolution evidence can outlive the earlier catalogue's admission lifetime, but cannot retain an expired grant. Publication revalidates every resolved capability/reference against the selected fresh current snapshot. Missing or incompatible entries block publication; matching currently permitted entries need not force a narrative-content edit merely to change an evidence timestamp. Retain required provenance within repository quota, separately from authored content.

Unknown capabilities belong in beat intent/requirements and cannot be stored as executable fragments initially. For known capabilities, malformed arguments reject; valid schema-shaped references that are currently unavailable may be saved as blocked fragments. Graph incompleteness is saved with findings. Missing grants cannot be marked resolved by narrative notes. Replacement and removal never execute an inspection/action.

Narrative review shape: `{reviewedContentDigest,policyVersion,summary,findings:[{beatId?,situationId?,path?,message}]}`. It records an advisory author opinion; no model severity can override technical validation. Recording it changes only record revision. This slice has no human narrative blocker/override workflow.

## 6. Seven tool contracts

All inputs are strict objects: unknown properties reject. IDs/keys are nonblank control-free strings of at most 160 characters; authored IDs retain the runtime's 80-character limit. Digest fields are `sha256:` followed by 64 lowercase hex characters. Expected revisions are positive safe integers. Missing optional fields use the documented default, not invented authority.

| Tool                            | Exact input fields                                                                                                                                                                        | Main completed output                                                                                                                                 |
| ------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| `create_quest_draft`            | `intent`, optional `plan`                                                                                                                                                                 | `draftId`, `recordRevision:1`, `contentRevision:1`, `contentDigest`, `startBeat`, `generatedBeatIds`.                                                 |
| `list_quest_drafts`             | Optional `filter.publicationState` (any, unpublished, published; default any), `limit` (default8), `cursor`                                                                               | Summaries with record/content identity, `listSnapshotId`, `nextCursor`.                                                                               |
| `read_quest_draft`              | `draftId`, `recordRevision`, `section` (`overview`, `plan`, `requirements`, `beat`, `reviews`, `publications`), optional `beatId` (required only for beat), `limit` (default 8), `cursor` | Requested section/page and exact record/content identity, `nextCursor`. Overview excludes full fragments.                                             |
| `edit_quest_draft`              | `draftId`, `expectedRecordRevision`, `catalogueSnapshotId`, `operations`                                                                                                                  | Record/content identity, changed IDs and compact assessment: technicalReady/planCoverage/narrativeReview.                                             |
| `review_quest_draft`            | `draftId`, `recordRevision`, `catalogueSnapshotId`, optional `beatId`, `includeMermaid` (default false), `limit` (default 8), `cursor`                                                    | Assessment, exact content/catalogue identity, actionable findings/page, optional Mermaid, `nextCursor`.                                               |
| `publish_quest_draft`           | `draftId`, `expectedRecordRevision`, `expectedContentDigest`, `catalogueSnapshotId`                                                                                                       | Publication/definition IDs, definition digest, source record/content identity, resulting record revision. No run ID.                                  |
| `get_authoring_command_outcome` | `commandKey`                                                                                                                                                                              | Original tool/digest and `state`: not_admitted, pending or terminal; pending reserved IDs if authorized; terminal exact result. No draft ID required. |

Create/edit/publish are mutations. The other four are read-only and idempotent against identified snapshots. Outcome lookup's `commandKey` is a read selector, not a second mutation identity. Reads do not require an effect header. Gateway admission still requires authenticated call/turn context and the relevant grant.

Creation schema validates intent: `{title,premise,presentation,constraints}` with nonblank title/premise, presentation task/quest, and at most eight constraints. Title <=160 characters; premise/beat intent/design decisions <=2000; constraint/finding/review summary <=1000. Optional plans follow section 4. Every executable condition/action is validated against the existing structural schema plus registered input schemas; no model-supplied code/builders are accepted.

## 7. Results and errors

Use compatible base field names with versioned authoring output schemas registered separately from existing narrative contracts:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-id",
    "recordRevision": 2,
    "contentRevision": 2,
    "contentDigest": "sha256:<64-hex>"
  }
}
```

Durably prepared but not yet terminal mutations return `{status:"running",operationId:"opaque-command-id"}`. Disconnect, stop-waiting or a transport timeout does not cancel admitted work. This running branch is part of the new authoring schema, not a silent change to `NarrativeResult`.

Rejections retain `status`, `code`, `message`, and `issues`. The authoring version adds optional bounded `details` for conflict/outcome context:

```json
{
  "status": "rejected",
  "code": "revision_conflict",
  "message": "The draft changed; read the current snapshot before reconciling.",
  "issues": [
    {
      "path": "/expectedRecordRevision",
      "code": "revision_conflict",
      "message": "Expected 3, current 4."
    }
  ],
  "details": {
    "expectedRecordRevision": 3,
    "currentRecordRevision": 4,
    "changedIds": ["visit"],
    "summaryComplete": true
  }
}
```

Conflict details use retained change summaries; if a full interval is unavailable, `summaryComplete:false` requires a fresh snapshot read. Do not pretend a partial summary is a merge base. A rejected new edit is terminal under its key; use a new key after reconciliation.

Codes include invalid_arguments, permission_denied, effect_key_conflict, revision_conflict, content_conflict, catalogue_stale, unknown_capability, invalid_fragment, draft_not_ready, snapshot_expired, cursor_invalid, and capacity_exceeded. Storage unavailability is a transport/operation error with outcome unknown; never mislabel it not-admitted or completed. Malformed unauthenticated/header/input requests rejected before command preparation have no admitted durable command; healthy strong outcome lookup can establish not_admitted.

Findings contain stable `code`, severity (`blocking` or `advisory`), exact JSON `path`, optional beat/situation IDs, concise message, and bounded `expected`/`supplied` descriptors where useful. Suggested repair text is advisory. Never rewrite the draft in a review response.

## 8. Technical, plan and narrative assessment

`technicalReady` means all executable structural/semantic/capability/reference/boundary/result checks pass under the selected current catalogue and complete graph. `planCoverage` is `complete` or `incomplete`, based on entry ownership, outcomes and implemented reachable beats. These are assessed globally even when a review returns findings filtered to one beat; that filtered response must not certify only part of a draft for publication.

`narrativeReview` contains status `not_reviewed`, `current`, or `stale`, plus the applicable advisory review's content digest/policy version. A record-only edit does not stale content review. A content edit does; technical context changes require a new technical review/revalidation. Technical readiness does not assert satisfying dialogue, motivation or consequences.

Publication requires technicalReady, complete planCoverage and zero unresolved requirements. Narrative review is advisory: not_reviewed/stale does not block this first slice, but the status is returned explicitly. Publication always recalculates readiness; a prior review is not an authority reservation.

## 9. Persistence, admission and recovery

Select one durable transactional repository containing drafts/snapshots, tombstones, issued catalogue evidence, prepared commands, terminal receipts and **published definition rows**. The reference first implementation is host-side SQLite with WAL and synchronous FULL, behind a transaction interface; no browser storage adapter or network database is promised. No database/dependency is installed by this proposal.

Require restart-safe atomic commits on the actual host filesystem. A JSON snapshot of an in-memory gateway is insufficient. Keep game mutation/runtime journals separate: authoring-store durability proves authoring, not combat/inventory recovery.

Mutation flow:

1. Check current stable author access and strict envelope. Under serialized admission, inspect the command key. Authorized terminal replay returns its exact receipt; digest mismatch rejects. Pending replay joins/reports the same command.
2. Strongly commit a prepared record containing exact tool/arguments/digest, original audit context, required catalogue/content revisions and reserved server IDs. Enforce quotas now, reserving enough space for the terminal receipt/state. No draft or definition effect precedes this commit.
3. Under the same authority serialization, validate current lease, catalogue and CAS. In one repository transaction apply draft changes or publication, retain the snapshot/change summary, and change the command to terminal with its exact result. A semantic rejection also becomes terminal without changing draft content. Rollback exposes neither partial changes nor a successful receipt.
4. Return the committed receipt. If acknowledgement is lost, recover by the original key. If storage acknowledgement is uncertain, query/reconcile the primary store; do not guess.

Restart reconciles prepared commands before admitting conflicting work on the same draft. Recheck current authority/catalogue: if revoked/stale, store the appropriate terminal rejection without effects; if still valid, execute the original prepared command once. Missing host provisioning leaves it pending/unknown, never automatically rebinds. Grant changes cannot resurrect original authority.

Healthy primary outcome lookup returns `not_admitted` only when no record exists after serialized admission/recovery checks. Pending covers prepared/executing or unresolved commit acknowledgment. Terminal returns the exact committed success/rejection with original tool/digest. If the primary store is unavailable, return storage_unavailable; absence in a cache is not not-admitted evidence. Receipts have no TTL and are not silently evicted.

## 10. Publication transaction and runtime boundary

Prepare one publication ID and runtime-compatible definition ID under the command key. Build the definition deterministically from plan start and owned situation fragments; calculate its canonical digest. Validate grants/references and the complete existing situation schema/semantics without invoking game handlers.

**Published definitions are rows in the same authoring repository**, not immediate insertion into a live `SituationSystem`. One transaction inserts the immutable definition, links it to the draft/source snapshot, increments record revision only, and stores the terminal command receipt. Rollback or restart cannot leave a registry row without its publication reference/receipt.

Uniqueness is `(author namespace,draftId,contentDigest,formatVersion)`. A new publication key for the same content first revalidates current publish authority/contracts, then returns the existing publication rather than a second definition; no record revision change is needed. Exact original-key replay only returns history after current receipt-access checks. Changing draft content produces a new immutable definition; at most four publications per draft.

Only after publication does a separately authorized game host load/import that stored definition through the existing situation API, under its trusted character and game scope. The repository's trusted read-only `readPublishedDefinition(namespace,definitionId)` interface returns the stored definition, digest and source identity after host access checks; it is not an extra model tool. MCP publication pages return bounded references, not automatically the entire definition. Loading/importing must preserve definition ID/content and its own existing replay/journal semantics. Activation is a separate explicit `start` call. Neither import nor start is an authoring MCP operation.

This placement resolves the earlier two-store crash window by construction. The transaction must still be tested at cuts after definition insertion but before reference/receipt writes: after restart either the whole transaction is committed or none of it is. A future external definition registry requires a new outbox contract, not an untested promise in this slice.

## 11. Fixed bounds and retention

| Bound                         | First-slice limit                                                                                            |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------ |
| Tool arguments                | 64 KiB UTF-8/native JSON; depth <=32.                                                                        |
| Tool response                 | 32 KiB, excluding tools/list briefing/schema discovery.                                                      |
| Full current draft snapshot   | 96 KiB; sections/fragments paged on reads.                                                                   |
| Plan                          | 16 beats; 4 outcomes per beat; 80-character authored IDs.                                                    |
| Executable graph              | Existing max16 situations; existing per-situation schema bounds; assembled definition <=48 KiB.              |
| One fragment/edit batch       | Fragment <=24 KiB; 8 operations; entire batch within input bound.                                            |
| Requirements/advisory reviews | 16 requirements; 8 review records; 8 findings per review.                                                    |
| Derived review findings       | 128 total; exceeding this makes technicalReady false with review_limit, never a false successful assessment. |
| Response pages                | 1–16 items (default8), also bounded by response bytes; no silent skipped items.                              |
| Drafts/publications           | 32 drafts per author; 4 publications per draft.                                                              |
| Record snapshots              | Last8 per draft, plus pinned publication/pending-command source snapshots within quota.                      |
| Commands                      | 1024 retained receipts/prepared records per author; at most16 pending; no unresolved eviction.               |
| Tombstones                    | 2048 per draft; exhaustion rejects new identity removal/replacement.                                         |
| Repository                    | 128 MiB per author, including snapshots, catalogue evidence and reserved terminal space.                     |
| Catalogue/list snapshots      | At most8 current catalogue snapshots and 8 frozen list snapshots per author; lifetime <=15 minutes.          |
| Diagram                       | <=8 KiB escaped Mermaid; omitted unless requested; limit returns a finding rather than unbounded output.     |

Pagination cursors are server-authenticated opaque selectors bound to namespace, grants, tool, filters/section, exact snapshot, catalogue where relevant, offset and expiry. Reads validate current access. Draft/review cursors expire after 15 minutes; source snapshot expiration also rejects. List pagination uses a frozen list of summary records, never live offsets over changing drafts. Old unavailable record revisions return snapshot_expired, not latest data.

Prepared-command and publication snapshots remain pinned. Quota prevents admission when state cannot be retained safely; do not prune unresolved receipts or source evidence to make room. Expired unpinned catalogue/list snapshots may be reclaimed. No implicit draft/receipt archival is exposed initially; controlled maintenance/acknowledged archival requires a future contract. This deliberately uses backpressure rather than pretending persistence is unbounded.

## 12. Acceptance gate after implementation approval

Exercise the real MCP adapter with static host-issued visit contracts: tools/list briefing → create without a plan → incomplete fragment/edit/read → corrected fragment → deterministic review → immutable publication → process restart → new explicitly rebound session reads the same draft/publication and recovers original commands.

Include lost create/edit/publish replies, original-digest conflict, stale edit with change summary, expired catalogue/cursor/revision, tombstones, quota backpressure, revoked/rebound author, concurrent/queued revocation, prepared-command restart, and transaction cuts before/after definition/reference/receipt commit. Prove an original command cannot duplicate publication.

Then separately import and activate the stored definition through the AI-free host and complete it using game-owned location evidence. A coordinated Rocket consumer proof needs its own owner authorization; CFW does not edit Rocket. Publication alone must yield no run, game actions, NPC acceptance or reward.

Keep the branching shipment as a richer **contract fixture**, including early-visit boundary choice and transfer-completed/later-consequence-blocked recovery. Its hypothetical inventory/relationship handlers are not requirements for this first visit milestone. No persistent-authoring milestone is complete until the durable/rebinding/MCP acceptance gate passes.

## 13. Focused review blockers: 328–331

Rocket328, Supervisor329 and StrictSteve330 agree that seven tools/five edits, default main beat and one transactional publication domain are a suitable bounded direction. They do not approve implementation. Rocket331 separately reports consumer exposure to the runtime snapshot defect below.

### Contract blockers to resolve

1. **Readable page units and byte accounting.** The32KiB response ceiling does not say whether it applies to structured JSON or the full duplicated/escaped MCP result. A locally reproduced schema-valid12-node fragment is22,666 bytes and its read result22,970 bytes, but the duplicated MCP result46,320 bytes. A valid3-node Unicode fragment is24,270 bytes, yet permitted beat metadata makes its structured read33,188 bytes and MCP result66,540 bytes. Both fragments fit24KiB. Define exact beat-section page items, repeated metadata, ordering, reconstruction and byte-aware selection, or lower indivisible bounds. Also reserve outcome-envelope space around a terminal receipt. Never skip an oversized item using an empty advancing page. These are serialization/schema probes, not a running authoring service.
2. **Reference-path contracts.** Input schemas permit strings, while the catalogue's reference list does not bind argument paths to categories/literal/result policy. `locationRef:"grove-does-not-exist"` can pass JSON Schema. Add host-issued machine-readable path/category policies or an equivalent pure host validator and exposed descriptors. Unknown/ungranted literals must produce exact-path blockers without calling game handlers. Symbolic `$result` objects require shape/producer-output compatibility at authoring time, with actual receiver input validation after resolution at runtime; do not treat an unresolved symbolic value as a literal string or relax literal checks.
3. **Explicit prepared-command resume authority.** Persist original authority lease/provenance and specify whether host approval for a new session explicitly permits resumption of each old prepared command. Merely matching the stable author ID cannot revive revoked work. Distinguish ordinary restart, revoked-old-lease plus approved successor, permanently revoked author, and terminal historical receipt access. Current section9's generic recheck is insufficient to select that policy.
4. **Model-visible capability briefing.** Read-only source verification in CAI's `DiscoverGameMcpTools.php`, `BuildGameMcpTools.php`, and `OpenAiMcpGateway.php` confirms discovery retains declarations/input schemas and provider names/descriptions/parameters; list-level cfwAuthoring metadata is not forwarded on the inspected path. An agent cannot rely on receiving its required catalogue ID/reference/evidence context. Select an explicit trusted consumer-context adapter or a discoverable read result using the selected tool surface, and verify the actual model-visible payload. No CAI files were modified.
5. **Recover the trusted command identity without conversation memory.** CAI's `PrepareGameToolCall.php` generates/persists effect keys server-side. The wire walkthrough knows that key, but a model losing the complete creation reply may not. Specify durable connector-owned reconciliation or bounded authorized pending-command context, so a resumed session can obtain original identity/arguments without inventing a new key. Test loss of both response and conversational memory. Do not put mutation identity back into model arguments.

### Smaller contract refinements

- Same-content publication under a new key should preserve original publication/source identity while returning the current unchanged record revision after record-only review edits. Deduplication must precede allocating another publication or checking a limit that would reject reuse of an existing one.
- Specify the host's applicable advisory review policy and deterministic selection among multiple reviews; caller-supplied policy strings are author opinions, not implicit current host policy. Advisory review remains nonblocking.
- Supply exact strict input/output schemas for all seven tools before implementation, rather than relying only on field tables/examples. The broken list-tool enum row is corrected; that formatting correction does not settle the other findings.

### Separate reproduced current-runtime defect

Current `SituationSystem.publish` queues an immutable command input for receipt identity but its apply closure validates/stores the original caller definition. `start` likewise closes over caller scope. A local offline probe called publish with `original-definition`, mutated the caller ID before host advance, and received/stored `mutated-definition`; exact replay of the original arguments returned that mutated ID. Starting with player-1 scope and mutating it to world before advance stored world scope.

Execution and receipt digest must consume the same owned admission snapshot. This is an actual existing-runtime defect, separate from the unimplemented authoring repository. Rocket reports the same closure pattern in its pinned301b7c519055 artifact and no observed failure in its immutable demo use. The probe changed only volatile fake state; no runtime sources, Rocket files or packages were changed. Fix/release work and post-call mutation/exact replay regressions remain separate from these documentation review findings.
