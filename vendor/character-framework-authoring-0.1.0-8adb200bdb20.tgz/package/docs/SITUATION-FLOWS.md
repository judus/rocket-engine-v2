# Authored situation flow API

The schema reviewed in Character-Intelligence312/313 and authorized by the human is now implemented in CFW. `docs/contracts/situations.schema.json` preserves the `cfw-situations-draft-2` format marker and agreed structural contract; its historical draft label distinguishes it from the existing quest/dialogue formats. The three reviewed definitions are in `docs/contracts/situation-examples.json`. Existing quest, offering and dialogue APIs retain their semantics. No quest-generation MCP tools have been added.

A single `CharacterRuntime.situations` service owns published definitions and scoped runs. Configure `situationGame` with the game's registered capability/evidence/persistence adapter, register a bodyless director or character, and call `runtime.situations.bind(handle)`. CAI bindings, physical NPCs and reasoning providers are optional. When reasoning is absent, reasoning requests reject explicitly; authored execution still works. The host calls `runtime.advance(seconds)` once at its existing update boundary. There is no private simulation timer or AI routing.

```ts
const flow = runtime.situations!.bind(director);
await flow.publish(definition, 'publish-definition');
const run = await flow.start(
  definition.id,
  { kind: 'world' },
  'arm-definition',
);
const view = flow.read(run.runId);
// Authenticated host input, using a current opaque choice and revision:
await flow.choose(
  run.runId,
  view.choices[0]!.id,
  view.revision,
  'player-command',
);
```

Command promises commit during later host advances; continue the normal update loop while awaiting them. `read` exposes a detached view: current situation/revision/status, eligible opaque choices, permitted dialogue, objective observations and observation revision. `retire(runId,effectKey)` asks the game to reconcile/clean up only run-owned resources; it becomes retired after acknowledgement. View disposal or stop-waiting is not this command. System disposal aborts cooperative work and rejects pending API commands; the host should retire/reconcile runs before disposing its world. Late registration results cannot authorize new actions.

A definition is immutable after publication. One run is armed per definition/owner/player-or-world scope; a sustained true activation condition cannot silently create repeated runs. Repeatable-run and loop policies are future explicit contracts. The current graph is reachable and acyclic, with convergence allowed. Bounds:256 definitions/runs,4096 retained command receipts,64 pending commands,256 cursors per run and64MiB journal. No receipt/cursor eviction breaks replay. Host I/O/journal commits are serialized; a slow adapter must return running/unknown promptly and bound its own I/O. There is no claimed multi-world parallel scheduler.

## Schema and semantic validation

Publication checks the actual JSON Schema, native-compatible65536-byte/depth budget, graph identities/destinations/reachability/cycles, ordered unique automatic priorities, capability grants/kinds/input and output schemas, event metadata, and result/boundary availability on every path. Typed result references require explicitly declared property paths/types in producer output and receiver input schemas. General schema unions/references without provable property paths are conservatively rejected for authored result binding. Resolved inputs are validated again before any execution.

A result reference is a whole `{$result:{situationRef,actionId,path}}` object, including nested argument positions; malformed reserved objects reject instead of becoming literal data. Earlier entry actions expose immutable typed results when each action completes. Later entry actions may use them; forward/self/bypassed producers reject. Routes, choices and post-entry dialogue wait for the entire action list. Optional objectives report observations and have no implicit route/terminal gate.

## Game adapter contract

`SituationCapability` extends the existing capability with a required `outputSchema` for completed data and optional `evidenceStream:{ref,captureKeys}`. Event capture keys must exist independently of unavailable future results at the authored boundary. For an encounter condition, capture a participant/location death stream first, then filter by the acknowledged encounter/roster ID. JSON names validated references; it does not supply authority, executable code, cursors or physical actor identities.

`SituationGame` supplies:

- `capabilities(character)` and `scopeAvailable(character,scope)` for grants and trusted participant/world scope.
- `capture(context,streamRef,arguments)` for immutable authoritative cursors. The host must journal capture by original narrative effect identity and retain the same boundary revision across retries/streams. Capture happens before entry effects and before the new run/transition is exposed. Unavailable/truncated history must remain unknown, with no replacement baseline.
- `observe(context,observations)` for one coherent revision and a result per registered inspection. Each observation carries resolved arguments and, for event conditions, its saved stream/cursor/capture scope. Reuse game inspection implementations against that revision. `observationCurrent(context,revision)` revalidates it at journal/choice commit; stale observation transitions roll back before gameplay dispatch.
- `reconcile(context,capability,arguments,operationId?)` for original action outcomes. Only explicit `not_admitted` permits calling the original capability's `execute`; unknown blocks, running retains the operation, rejected blocks, completed must validate its output schema. A lost result or checkpoint acknowledgement reconciles the same effect and never invents a new identity.
- `persist(save)` for the host journal, required before dispatch and before committing acknowledgements. The host owns actual durable storage and coupling/reconciliation with game mutation persistence.
- `retire(context)` for idempotent owned-resource cleanup and outstanding-effect reconciliation. Shared/preexisting entities and items are not implicitly deleted, committed rewards are not rolled back.

`Invocation.narrative` carries trusted run ID, player/world scope, entry ID, original registration generation, stable effect ID and canonical argument digest. It is separate from `Invocation.mutation` (which remains MCP-only). The game must deduplicate effects and reject conflicting identity/digest/provenance. This is the API Rocket should implement; CFW neither invents enemy/reward handlers nor interprets scene-specific node IDs.

## Persistence and recovery

`save()` returns the most recent successful host journal (or initial state). Use `setPaused(true)` and continue advancing until `stats.busy` is false before `restore`; queued commands must also settle. Restore validates the entire checkpoint atomically, including definitions, scopes, paths, ordered typed effects and boundary records, before replacement. Runtime projections are observations, not trusted persisted choice grants, and are rebuilt.

A fresh registration must restore the stable binding ID, bind its new handle, and obtain explicit `authorizeRestore(character,previousGeneration,scope,runId)` approval from the game. Without that reconciliation approval, changed-generation restore rejects. Original run/effect/capture IDs and origin generation remain intact; the adopted journal is stored before dispatch. Host approval must establish the intended actor incarnation/world scope, not merely matching display names. Replayed command receipts remain exact; obsolete handles reject.

Checkpoints are trusted host records with consistency validation, not cryptographically tamper-proof proofs of game effects. Process-crash exactly-once behavior requires the real game's mutation ledger and atomic storage/reconciliation tests. The included adapter is volatile and proves neither durable world restart nor production cleanup policy.

## Deterministic interpretation

Automatic routes use ascending priority over one committed observation revision; unknown higher-priority evidence blocks lower-priority routes. They settle before player choices. Conditions distinguish fact semantics supplied by the capability from events strictly after a named run-start/situation-entry cursor. All authored dialogue prerequisites gate its choices and revalidate with choice predicates at commit. Temporarily unavailable interaction or choices mean waiting, not ending.

No declared outgoing routes/choices means structural closure after optional entry-action acknowledgement, without implicit reward/success/failure semantics. Terminal prose prerequisites only govern presentation and cannot repeat effects. Existing facts and event-only requirements may coexist in one definition; unrelated location/encounter/entity-incarnation deaths cannot become designated completion evidence.

Run `npm run demo:situations` for the reviewed location/encounter/reveal/claim/reward sequence through this API. The fake game reports actual fake-world facts, excludes cemetery/unrelated deaths and commits one reward despite delivery replay. `tests/situations.test.js` covers the three authored flows, timing/priority/interaction, typed result chaining, journal failures, restore and lifecycle. This is headless CFW evidence, not Rocket combat/browser integration or live personality evaluation.

Native browser consumers use the bundled entry described in [the browser package contract](BROWSER-PACKAGE.md). The original validators and schemas are included; direct native imports of the unbundled Node entry are unsupported.
