# Working persistent authoring prototype

Status: working first E2E slice, 14 October 2026. The human selected **working prototype first, stabilization and polish afterwards**. This is `cfw-authoring-prototype-1`, not a claim to implement the complete reviewed `cfw-authoring-1` specification.

Run:

```sh
npm ci
npm run demo:authoring
```

The command prints its saved SQLite path and two proof results. The first authors a visit through the actual MCP SDK/Streamable HTTP transport routed into the real CFW gateway with in-process Request/Response objects. The second launches a fresh Node process, lists the saved draft, reads its publication and original command receipt, imports the definition, excludes a prior entry, and completes on a new entry. No TCP listener, provider call, CAI backend or paid model is involved. Authoring persistence is real; game location evidence is a volatile offline adapter.

To resume that saved database independently:

```sh
node examples/authoring-prototype-resume.js /absolute/path/from/the/proof/drafts.sqlite
```

A fresh authoring demo normally creates a new temporary database. Use the resume command for an existing proof database rather than replaying the entire authoring script against an already published draft.

## The complete loop

1. Discover seven tools through MCP `tools/list`.
2. Call `read_quest_draft` with `{"section":"catalogue"}`. The normal tool result contains capability input/output schemas, evidence streams, reference-path bindings and permitted references. This is model-visible ordinary output; no custom list metadata forwarding is needed.
3. Create an intent; the service supplies a single beat `main`.
4. Save a structurally valid but incomplete fragment. Its missing destination is reported and blocks publication.
5. Read and replace the fragment with a valid visit rule.
6. Review technical readiness separately from advisory narrative status.
7. Publish the immutable definition and source reference in the same SQLite transaction as the original command receipt. No game run is created.
8. Close/reopen the database and gateway; read saved state and recover committed command IDs/results. The fresh-process proof does not depend on conversational memory.
9. Separately import via the existing situation API and start under the offline world's trusted player scope. Host advance drives the interpreter. A prior entry does not satisfy a run-start event condition; a subsequent entry closes the run.

The prototype does not generate story content with an AI yet. A deterministic caller follows the same discovered tool surface an authoring agent will use. The next consumer proof can use provider-only fakes in CAI before choosing a meaningful live test.

## Seven prototype tools

Exact discovered input schemas are generated into [authoring-prototype-tools.json](contracts/authoring-prototype-tools.json). These prototype shapes are deliberately smaller than the hardened contract.

| Tool                            | Main arguments                                    | Behavior                                                                                                                                    |
| ------------------------------- | ------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| `create_quest_draft`            | `intent:{title,premise?,presentation?}`           | Persist a one-beat draft; return record/content identity and original command ID.                                                           |
| `list_quest_drafts`             | `{}`                                              | Return current saved summaries and last16 committed command descriptors.                                                                    |
| `read_quest_draft`              | `section`, optional `draftId`, `recordRevision`   | Catalogue without draftId; otherwise overview, main beat or publication. Exact revision checks are optional; no historical snapshot paging. |
| `edit_quest_draft`              | `draftId`, `expectedRecordRevision`, `operations` | Atomic intent replacement, main fragment replacement or advisory narrative review.                                                          |
| `review_quest_draft`            | `draftId`, `recordRevision`                       | Existing schema/semantic validator plus literal reference checks. No game handlers run.                                                     |
| `publish_quest_draft`           | `draftId`, `expectedRecordRevision`               | Persist one immutable publication per draft, with source and original command receipt.                                                      |
| `get_authoring_command_outcome` | `commandId`                                       | Read a committed original result. Unknown ID rejects; it is not proof of not-admitted across a failure.                                     |

Read tools have `readOnlyHint:true`; mutations have false. Mutation keys remain in trusted transport headers. The adapter receives the existing gateway's opaque `Invocation.mutation.id`, saves it with the exact argument digest and result, and returns it as `commandId`. The outcome argument is a read selector, not a model-controlled mutation identity. Recent descriptors make committed lost replies discoverable through the ordinary list tool.

The host constructs `QuestAuthoringPrototype` with a SQLite path, trusted author namespace, current authorization callback, permitted game capability descriptors, references and explicit argument-path/category bindings. None are authority selected by tool arguments. The host-only `readPublishedDefinition` returns a detached immutable definition for later runtime import.

Import the Node-only module from `character-framework/authoring-prototype`. It is separate from the root/browser entries; SQLite is not bundled into browser runtime imports. Node24's built-in SQLite currently emits an experimental-feature warning. No new database package is installed.

## Prototype edit shapes

A normal replacement operation is:

```json
{
  "kind": "replace_beat_implementation",
  "beatId": "main",
  "implementation": {
    "entrySituation": "watch",
    "situations": [
      {
        "id": "watch",
        "routes": [
          {
            "id": "entered",
            "priority": 10,
            "when": {
              "tool": "rocket_inspect_grove",
              "arguments": { "locationRef": "grove" },
              "expect": {
                "path": ["entries"],
                "operator": "at_least",
                "value": 1
              },
              "evidence": { "mode": "events", "after": { "kind": "run-start" } }
            },
            "next": "end"
          }
        ]
      },
      { "id": "end" }
    ],
    "outcomeBindings": []
  }
}
```

Other operations are `{"kind":"set_intent","intent":{...}}` and `{"kind":"record_narrative_review","review":{"contentDigest":"returned-digest","summary":"author opinion"}}`. Record-only review preserves content identity; subsequent content edits stale it. This slice does not implement branching plan edits, requirements, review policies or Mermaid.

Publication makes the prototype draft read-only; create another draft for a new version. This keeps earlier publications immutable without introducing a version-history service yet.

## CAI and Rocket coordination

CAI message335 confirms maintained source can surface catalogue-mode ordinary tool output, preserves discovered input schemas/descriptions, and supplies trusted binding/call/turn/effect headers. The prototype maps its author namespace in the host and keeps the same association/session/binding for exact mutation replay. CAI-owned interrupted-turn receipt readers retain original call/effect/arguments independently of prose. Full in-flight process-death and cross-generation recovery remain separate; no automatic rebind claim is made here.

CAI also describes a game-triggered dedicated/background authoring worker for larger quests; its ordinary character-turn budget is not an unlimited planner. That is CAI-owned future integration context, not a CFW provider/arc-scheduler implementation.

Rocket message336 confirms its existing `rocket_inspect_grove` descriptor and import/start seam suffice. The offline fixture matches its exact locationRef=grove schema, inside/visited/entries outputs and grove-entries stream, with player-only scope `{kind:"player",ref:"player"}`. Its world authority is CFW's own fake world; it is not executing Rocket movement or accessing Rocket state. Rocket's actual pose crossing and volatile ledger remain its owned consumer proof. No Rocket file or pin was changed by this prototype.

## Current guarantees and boundaries

Delivered ordinary-path behavior: SQLite save/reopen/fresh-process reads; revision-checked edits; whole-batch rollback on rejection; exact committed receipt replay under the same trusted binding identity; single immutable publication with its receipt/source in one transaction; separate AI-free activation. The published graph uses the existing structural/semantic validators and host literal-reference bindings.

Initial bounds:16 drafts,512 retained receipts per host author namespace,4MiB stored state,4 operations per batch,12KiB fragments and existing16-situation limits. This is a small bounded workspace; there is no large-record pagination or automatic receipt eviction. Before production, bound catalogue/list/rejection transport bytes as well as inputs and specify readable page units.

Deferred stabilization: prepared-command crash recovery and precise unknown/admission states; revocation-versus-commit races and cached gateway receipt access; cross-session/generation successor authorization; cursor/history/tombstone/archival policies; general result-reference bindings; full request/result schema versioning; rich plans and reviews. The prototype deliberately does not claim these completed. A missing command ID is not treated as safe permission to retry with a new key.

The existing queued publish/start snapshot bug is fixed separately: execution now consumes the same detached command input used by its receipt identity. Regression checks cover post-call definition/nested-data mutation, player-to-world scope mutation, and exact original-key replay. Rocket's older301b7c519055 package contains the previous closure pattern; CFW provides a corrected artifact for owned review, not an automatic repin.

The live CAI consuming attempt exposed a comparison-validation gap: a numeric `at_least` predicate against boolean `inside` passed review but could not execute. The corrected validator resolves literal `expect.path` through declared output properties, rejects unknown paths and incompatible comparison types, and reports the exact condition path in authoring findings. `entries >= 1` remains valid. This bounded check uses the existing explicit property/type descriptors; it does not claim a general JSON Schema reference/composition resolver. The full correction gate passes185 tests. A graph's technical readiness still does not establish compliance with a narrative brief; the separate location-completion test is required.

For concise model-facing syntax and resume guidance, supply [QUEST-AUTHORING-MODEL-GUIDE.md](QUEST-AUTHORING-MODEL-GUIDE.md) alongside the normal catalogue. CAI has a dedicated authoring agent and reports its provider-only fake TCP proof passed. Live guided completion remains pending after model mistakes and the comparison fix; CFW has made no provider call.

Authoring SQLite transactions are not proof of persistent game mutation/evidence storage. No crash/power-loss campaign, Rocket combat/cargo/inventory transfer, native personality generation, live CAI authoring run or paid provider has been performed.
