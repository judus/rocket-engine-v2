# Concrete MCP authoring walkthroughs

Contract: `cfw-authoring-1`. Status: proposed wire examples for human review, 14 October 2026. **No implementation, actual MCP invocation, publication, or game effect occurs here.**

For the subsequently authorized working E2E slice, use [the prototype guide](QUEST-AUTHORING-PROTOTYPE.md) and `npm run demo:authoring`. Its smaller delivered schemas are versioned separately; the complete proposal's examples below are not assertions that every hardening rule is implemented.

Use [the first-slice contract](QUEST-AUTHORING-FIRST-SLICE.md) for normative fields, limits and recovery semantics. [The concept](QUEST-GENERATION-CONCEPT.md) retains rationale and review history. These sessions supersede the earlier body-effectKey and publishable examples.

Every call below is a `tools/call` request with trusted HTTP delivery/turn headers. Mutations take the command key only from `x-cf-effect-key`. The authenticated host binds a stable author namespace and grants read/edit/publish/recover; no arguments can supply identity or authority. Fresh sessions need explicit host rebind approval.

Responses show `result.structuredContent`. In a real MCP result, `content` additionally contains a text block whose `text` is the identical serialized authoring result; both must validate the new authoring output schema. The transport wrapper remains JSON-RPC. This convention avoids printing the same response twice.

IDs are illustrative server-issued values. Content/definition digests below are calculated from the exact example structures. Catalogue/time/namespace authority is hypothetical host-issued context, not established by these JSON strings. Each session completes within its catalogue lifetime; on restart/new work the host issues fresh context. Terminal receipt replay does not revalidate an expired catalogue, but always checks current receipt access.

## 1. Visit the Old Grove

### Discover tools and supplied contracts

First initialize/authenticate MCP and call `tools/list` (normal MCP protocol). It exposes the seven authoring tools. The authoring metadata in `result._meta.cfwAuthoring` contains:

```json
{
  "contractVersion": "cfw-authoring-1",
  "catalogueSnapshotId": "catalogue-visit-1",
  "catalogueDigest": "sha256:6de8b233c77942ec4c78808026668777e8e8bfead501029c23d2ac0417c1eac3",
  "expiresAt": "2026-10-14T00:15:00Z",
  "capabilities": [
    {
      "name": "game_inspect_location",
      "description": "Inspect permitted current presence or post-cursor entry count.",
      "kind": "inspection",
      "inputSchema": {
        "type": "object",
        "properties": {
          "locationRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          }
        },
        "required": ["locationRef"],
        "additionalProperties": false
      },
      "outputSchema": {
        "type": "object",
        "properties": {
          "inside": {
            "type": "boolean"
          },
          "entries": {
            "type": "integer",
            "minimum": 0
          }
        },
        "required": ["inside", "entries"],
        "additionalProperties": false
      },
      "factMeaning": "inside is current participant presence",
      "eventMeaning": "entries counts entry events strictly after the authoritative cursor",
      "evidenceStream": {
        "ref": "location-entries",
        "captureKeys": ["locationRef"]
      },
      "supportedBoundaries": ["run-start", "situation-entry"]
    }
  ],
  "references": [
    {
      "id": "grove-1",
      "category": "location",
      "description": "The permitted Old Grove destination."
    }
  ]
}
```

The game registers that inspection and evidence stream for the participant. The agent receives permitted schemas/refs before drafting. The metadata is static capability context, not a nearby-world query or inventory reservation.

### Create without an explicit plan; recover a lost reply

Creation generates one beat `main`. A simple task does not need two manually maintained planning graphs.

**create_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-01",
  "x-cf-turn-request-id": "authoring-turn-1",
  "x-cf-effect-key": "grove-create-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "create_quest_draft",
    "arguments": {
      "intent": {
        "title": "Visit the Old Grove",
        "premise": "Encourage exploration of the grove.",
        "presentation": "task",
        "constraints": ["No reward", "No NPC interaction"]
      }
    }
  }
}
```

Suppose the repository commits creation and the response is lost. The client retained `grove-create-01` and the exact request. It does not invent a new key. Even without knowing the draft ID, an authorized rebound session can query the original outcome:

**get_authoring_command_outcome**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-02",
  "x-cf-turn-request-id": "authoring-turn-2"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "get_authoring_command_outcome",
    "arguments": {
      "commandKey": "grove-create-01"
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "state": "terminal",
    "tool": "create_quest_draft",
    "argumentDigest": "sha256:54e96239f9d69607e4c9a933309268276e3ff628b2b95f172ec503fd9a5aedfc",
    "result": {
      "status": "completed",
      "data": {
        "draftId": "draft-11111111-1111-4111-8111-111111111111",
        "recordRevision": 1,
        "contentRevision": 1,
        "contentDigest": "sha256:c77c2c51f071b1838e2e3fde077ae7c51afd5aeb23270a6bbbed70ceefaabd4d",
        "startBeat": "main",
        "generatedBeatIds": ["main"]
      }
    }
  }
}
```

Current recover/access grants are checked before revealing the draft. If host rebinding is not approved, return permission_denied instead. If the primary store is unavailable, return storage_unavailable rather than not_admitted.

### Save an incomplete implementation

The agent first writes a current-presence rule but has not added its ending node. The structure is valid and the inspection is known; the missing destination is an authoring finding, not a reason to discard the draft.

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-03",
  "x-cf-turn-request-id": "authoring-turn-3",
  "x-cf-effect-key": "grove-incomplete-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-11111111-1111-4111-8111-111111111111",
      "expectedRecordRevision": 1,
      "catalogueSnapshotId": "catalogue-visit-1",
      "operations": [
        {
          "kind": "replace_beat_implementation",
          "beatId": "main",
          "implementation": {
            "entrySituation": "grove-wait",
            "situations": [
              {
                "id": "grove-wait",
                "routes": [
                  {
                    "id": "arrived",
                    "priority": 10,
                    "when": {
                      "tool": "game_inspect_location",
                      "arguments": {
                        "locationRef": "grove-1"
                      },
                      "expect": {
                        "path": ["inside"],
                        "operator": "equals",
                        "value": true
                      },
                      "evidence": {
                        "mode": "fact"
                      }
                    },
                    "next": "grove-end"
                  }
                ]
              }
            ],
            "outcomeBindings": []
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-11111111-1111-4111-8111-111111111111",
    "recordRevision": 2,
    "contentRevision": 2,
    "contentDigest": "sha256:15619a594bc030fdfa5ff01335d5327d8735ac86db8b9cc44d0cf45401dd4d44",
    "changedIds": ["main", "grove-wait"],
    "assessment": {
      "technicalReady": false,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    }
  }
}
```

**read_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-04",
  "x-cf-turn-request-id": "authoring-turn-4"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 4,
  "method": "tools/call",
  "params": {
    "name": "read_quest_draft",
    "arguments": {
      "draftId": "draft-11111111-1111-4111-8111-111111111111",
      "recordRevision": 2,
      "section": "beat",
      "beatId": "main",
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-11111111-1111-4111-8111-111111111111",
    "recordRevision": 2,
    "contentRevision": 2,
    "contentDigest": "sha256:15619a594bc030fdfa5ff01335d5327d8735ac86db8b9cc44d0cf45401dd4d44",
    "beat": {
      "id": "main",
      "title": "Visit the Old Grove",
      "intent": "Encourage exploration of the grove.",
      "outcomes": []
    },
    "implementation": {
      "entrySituation": "grove-wait",
      "situations": [
        {
          "id": "grove-wait",
          "routes": [
            {
              "id": "arrived",
              "priority": 10,
              "when": {
                "tool": "game_inspect_location",
                "arguments": {
                  "locationRef": "grove-1"
                },
                "expect": {
                  "path": ["inside"],
                  "operator": "equals",
                  "value": true
                },
                "evidence": {
                  "mode": "fact"
                }
              },
              "next": "grove-end"
            }
          ]
        }
      ],
      "outcomeBindings": []
    },
    "nextCursor": null
  }
}
```

**review_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-05",
  "x-cf-turn-request-id": "authoring-turn-5"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 5,
  "method": "tools/call",
  "params": {
    "name": "review_quest_draft",
    "arguments": {
      "draftId": "draft-11111111-1111-4111-8111-111111111111",
      "recordRevision": 2,
      "catalogueSnapshotId": "catalogue-visit-1",
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-11111111-1111-4111-8111-111111111111",
    "recordRevision": 2,
    "contentRevision": 2,
    "contentDigest": "sha256:15619a594bc030fdfa5ff01335d5327d8735ac86db8b9cc44d0cf45401dd4d44",
    "catalogueSnapshotId": "catalogue-visit-1",
    "catalogueDigest": "sha256:6de8b233c77942ec4c78808026668777e8e8bfead501029c23d2ac0417c1eac3",
    "assessment": {
      "technicalReady": false,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    },
    "findings": [
      {
        "code": "missing_destination",
        "severity": "blocking",
        "beatId": "main",
        "situationId": "grove-wait",
        "path": "/implementations/main/situations/0/routes/0/next",
        "message": "grove-end has no owned situation.",
        "expected": "An existing situation destination.",
        "supplied": "grove-end"
      }
    ],
    "nextCursor": null
  }
}
```

Plan coverage and technical readiness are separate: the single beat has an entry and no planned cross-beat outcomes, but its executable destination is missing.

### Correct the fragment and require a fresh visit

During narrative review the agent notices that current presence would count immediately. It chooses an entry strictly after activation instead, retaining existing IDs and adding the ending.

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-06",
  "x-cf-turn-request-id": "authoring-turn-6",
  "x-cf-effect-key": "grove-correct-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 6,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-11111111-1111-4111-8111-111111111111",
      "expectedRecordRevision": 2,
      "catalogueSnapshotId": "catalogue-visit-1",
      "operations": [
        {
          "kind": "replace_beat_implementation",
          "beatId": "main",
          "implementation": {
            "entrySituation": "grove-wait",
            "situations": [
              {
                "id": "grove-wait",
                "routes": [
                  {
                    "id": "arrived",
                    "priority": 10,
                    "when": {
                      "tool": "game_inspect_location",
                      "arguments": {
                        "locationRef": "grove-1"
                      },
                      "expect": {
                        "path": ["entries"],
                        "operator": "at_least",
                        "value": 1
                      },
                      "evidence": {
                        "mode": "events",
                        "after": {
                          "kind": "run-start"
                        }
                      }
                    },
                    "next": "grove-end"
                  }
                ]
              },
              {
                "id": "grove-end"
              }
            ],
            "outcomeBindings": []
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-11111111-1111-4111-8111-111111111111",
    "recordRevision": 3,
    "contentRevision": 3,
    "contentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
    "changedIds": ["main", "grove-wait", "grove-end"],
    "assessment": {
      "technicalReady": true,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    }
  }
}
```

**review_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-07",
  "x-cf-turn-request-id": "authoring-turn-7"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 7,
  "method": "tools/call",
  "params": {
    "name": "review_quest_draft",
    "arguments": {
      "draftId": "draft-11111111-1111-4111-8111-111111111111",
      "recordRevision": 3,
      "catalogueSnapshotId": "catalogue-visit-1",
      "includeMermaid": true,
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-11111111-1111-4111-8111-111111111111",
    "recordRevision": 3,
    "contentRevision": 3,
    "contentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
    "catalogueSnapshotId": "catalogue-visit-1",
    "catalogueDigest": "sha256:6de8b233c77942ec4c78808026668777e8e8bfead501029c23d2ac0417c1eac3",
    "assessment": {
      "technicalReady": true,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    },
    "findings": [],
    "mermaid": "flowchart TD\n  main[Enter the grove after activation — implemented]",
    "nextCursor": null
  }
}
```

### Record advisory narrative review without changing content

The author confirms that the visit wording matches event-only behavior. This is an author opinion, not deterministic story certification.

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-08",
  "x-cf-turn-request-id": "authoring-turn-8",
  "x-cf-effect-key": "grove-review-note-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 8,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-11111111-1111-4111-8111-111111111111",
      "expectedRecordRevision": 3,
      "catalogueSnapshotId": "catalogue-visit-1",
      "operations": [
        {
          "kind": "record_narrative_review",
          "review": {
            "reviewedContentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
            "policyVersion": "visit-review-1",
            "summary": "The task asks for a new visit, has one clear destination and no implied reward.",
            "findings": []
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-11111111-1111-4111-8111-111111111111",
    "recordRevision": 4,
    "contentRevision": 3,
    "contentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
    "changedIds": ["narrativeReviews"],
    "assessment": {
      "technicalReady": true,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "current",
        "reviewedContentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
        "policyVersion": "visit-review-1"
      }
    }
  }
}
```

Only recordRevision advances; the content digest/revision remains unchanged, so this review does not stale itself.

### Publish atomically, without activation

**publish_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-09",
  "x-cf-turn-request-id": "authoring-turn-9",
  "x-cf-effect-key": "grove-publish-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 9,
  "method": "tools/call",
  "params": {
    "name": "publish_quest_draft",
    "arguments": {
      "draftId": "draft-11111111-1111-4111-8111-111111111111",
      "expectedRecordRevision": 4,
      "expectedContentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
      "catalogueSnapshotId": "catalogue-visit-1"
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-11111111-1111-4111-8111-111111111111",
    "publicationId": "publication-33333333-3333-4333-8333-333333333333",
    "definitionId": "definition-22222222-2222-4222-8222-222222222222",
    "definitionDigest": "sha256:43ef0a81ae46e86840afbcc80c086652a377daaab9ef7dd2c4d96f94bca59c26",
    "sourceRecordRevision": 4,
    "sourceContentRevision": 3,
    "sourceContentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
    "recordRevision": 5
  }
}
```

One transaction stores the immutable definition row, source snapshot/reference and command receipt. There is no runtime run ID and no game effect. If the receipt response is lost, retry the exact headers/arguments or use outcome lookup; never create a second key to recover.

### Resume after process restart

The service reopens its durable store and reconciles prepared commands. The host explicitly binds the new session to the same stable author namespace with current grants. A fresh tools/list gives new catalogue context for new edits/review/publication. Reading saved records and recovering terminal receipts does not require the original catalogue to remain live.

**list_quest_drafts**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-10",
  "x-cf-turn-request-id": "authoring-turn-10"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 10,
  "method": "tools/call",
  "params": {
    "name": "list_quest_drafts",
    "arguments": {
      "filter": {
        "publicationState": "published"
      },
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "items": [
      {
        "draftId": "draft-11111111-1111-4111-8111-111111111111",
        "title": "Visit the Old Grove",
        "recordRevision": 5,
        "contentRevision": 3,
        "contentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
        "publicationState": "published"
      }
    ],
    "listSnapshotId": "list-visit-after-restart",
    "nextCursor": null
  }
}
```

**read_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-11",
  "x-cf-turn-request-id": "authoring-turn-11"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 11,
  "method": "tools/call",
  "params": {
    "name": "read_quest_draft",
    "arguments": {
      "draftId": "draft-11111111-1111-4111-8111-111111111111",
      "recordRevision": 5,
      "section": "publications",
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-11111111-1111-4111-8111-111111111111",
    "recordRevision": 5,
    "contentRevision": 3,
    "contentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
    "items": [
      {
        "publicationId": "publication-33333333-3333-4333-8333-333333333333",
        "definitionId": "definition-22222222-2222-4222-8222-222222222222",
        "definitionDigest": "sha256:43ef0a81ae46e86840afbcc80c086652a377daaab9ef7dd2c4d96f94bca59c26",
        "sourceRecordRevision": 4,
        "sourceContentRevision": 3,
        "sourceContentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef"
      }
    ],
    "nextCursor": null
  }
}
```

**get_authoring_command_outcome**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-12",
  "x-cf-turn-request-id": "authoring-turn-12"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 12,
  "method": "tools/call",
  "params": {
    "name": "get_authoring_command_outcome",
    "arguments": {
      "commandKey": "grove-publish-01"
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "state": "terminal",
    "tool": "publish_quest_draft",
    "argumentDigest": "sha256:861925ce359e12511407f3c86b9ae2badc7277811cf40b375ec94ef860fc973e",
    "result": {
      "status": "completed",
      "data": {
        "draftId": "draft-11111111-1111-4111-8111-111111111111",
        "publicationId": "publication-33333333-3333-4333-8333-333333333333",
        "definitionId": "definition-22222222-2222-4222-8222-222222222222",
        "definitionDigest": "sha256:43ef0a81ae46e86840afbcc80c086652a377daaab9ef7dd2c4d96f94bca59c26",
        "sourceRecordRevision": 4,
        "sourceContentRevision": 3,
        "sourceContentDigest": "sha256:7635ed4028a34059e0278bb55dc1243ea2a1d842a8d193df8826b09b08a673ef",
        "recordRevision": 5
      }
    }
  }
}
```

Only now may a separately authorized host import the stored definition through the existing SituationHandle.publish API and explicitly start a player/world run. Both retain their existing journal/replay rules. The actual new entry is supplied by the game. No authoring tool performs that import/start.

## 2. The Missing Shipment — larger contract fixture

This uses the same tools and five edit operations; no shipment handlers must exist for the initial visit delivery. The supplied world premise is hypothetical: a merchant promised winter stock, families took it, and the player already has the three supplies before handover. Acquisition, cargo handling, spawning and rewards are out of scope.

### Supplied catalogue/context

The host issues `catalogue-shipment-1` with the location capability plus the following contracts. The schemas shown establish the exact names/argument/results assumed later. They are not delivered Rocket or Workshop handlers.

```json
{
  "contractVersion": "cfw-authoring-1",
  "catalogueSnapshotId": "catalogue-shipment-1",
  "catalogueDigest": "sha256:b8257bba5a1a994ad0ca72724d0cd46faa2fe72e165b9437c048d955d96daa99",
  "expiresAt": "2026-10-14T00:30:00Z",
  "capabilities": [
    {
      "name": "game_inspect_location",
      "description": "Inspect permitted current presence or post-cursor entry count.",
      "kind": "inspection",
      "inputSchema": {
        "type": "object",
        "properties": {
          "locationRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          }
        },
        "required": ["locationRef"],
        "additionalProperties": false
      },
      "outputSchema": {
        "type": "object",
        "properties": {
          "inside": {
            "type": "boolean"
          },
          "entries": {
            "type": "integer",
            "minimum": 0
          }
        },
        "required": ["inside", "entries"],
        "additionalProperties": false
      },
      "factMeaning": "inside is current participant presence",
      "eventMeaning": "entries counts entry events strictly after the authoritative cursor",
      "evidenceStream": {
        "ref": "location-entries",
        "captureKeys": ["locationRef"]
      },
      "supportedBoundaries": ["run-start", "situation-entry"]
    },
    {
      "name": "game_inspect_interaction",
      "description": "Inspect current allowed interaction for the trusted participant.",
      "kind": "inspection",
      "inputSchema": {
        "type": "object",
        "properties": {
          "npcRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          },
          "locationRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          }
        },
        "required": ["npcRef", "locationRef"],
        "additionalProperties": false
      },
      "outputSchema": {
        "type": "object",
        "properties": {
          "allowed": {
            "type": "boolean"
          }
        },
        "required": ["allowed"],
        "additionalProperties": false
      },
      "factMeaning": "allowed is current actor/NPC/location interaction authority",
      "supportedBoundaries": []
    },
    {
      "name": "game_inspect_inventory",
      "description": "Inspect quantity of permitted inventory item.",
      "kind": "inspection",
      "inputSchema": {
        "type": "object",
        "properties": {
          "inventoryRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          },
          "itemRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          }
        },
        "required": ["inventoryRef", "itemRef"],
        "additionalProperties": false
      },
      "outputSchema": {
        "type": "object",
        "properties": {
          "quantity": {
            "type": "integer",
            "minimum": 0
          }
        },
        "required": ["quantity"],
        "additionalProperties": false
      },
      "factMeaning": "Current quantity; no reservation",
      "supportedBoundaries": []
    },
    {
      "name": "game_transfer_items",
      "description": "Atomically transfer available permitted items; reconcile by original effect.",
      "kind": "action",
      "inputSchema": {
        "type": "object",
        "properties": {
          "fromInventoryRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          },
          "toInventoryRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          },
          "itemRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          },
          "quantity": {
            "type": "integer",
            "minimum": 1
          }
        },
        "required": [
          "fromInventoryRef",
          "toInventoryRef",
          "itemRef",
          "quantity"
        ],
        "additionalProperties": false
      },
      "outputSchema": {
        "type": "object",
        "properties": {
          "transferId": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          },
          "quantity": {
            "type": "integer",
            "minimum": 1
          }
        },
        "required": ["transferId", "quantity"],
        "additionalProperties": false
      }
    },
    {
      "name": "game_set_world_fact",
      "description": "Set an explicitly writable registered typed fact.",
      "kind": "action",
      "inputSchema": {
        "type": "object",
        "properties": {
          "factRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          },
          "value": {
            "type": "string",
            "enum": ["returned", "given-to-families"]
          }
        },
        "required": ["factRef", "value"],
        "additionalProperties": false
      },
      "outputSchema": {
        "type": "object",
        "properties": {
          "value": {
            "type": "string",
            "enum": ["returned", "given-to-families"]
          }
        },
        "required": ["value"],
        "additionalProperties": false
      }
    },
    {
      "name": "game_adjust_relationship",
      "description": "Apply permitted relationship delta under original effect identity.",
      "kind": "action",
      "inputSchema": {
        "type": "object",
        "properties": {
          "relationshipRef": {
            "type": "string",
            "minLength": 1,
            "maxLength": 160
          },
          "delta": {
            "type": "integer",
            "minimum": -1,
            "maximum": 1
          }
        },
        "required": ["relationshipRef", "delta"],
        "additionalProperties": false
      },
      "outputSchema": {
        "type": "object",
        "properties": {
          "trust": {
            "type": "integer"
          }
        },
        "required": ["trust"],
        "additionalProperties": false
      }
    }
  ],
  "references": [
    {
      "id": "shipment-site",
      "category": "location",
      "description": "Witness meeting site."
    },
    {
      "id": "merchant-house",
      "category": "location",
      "description": "Requester interaction location."
    },
    {
      "id": "families-camp",
      "category": "location",
      "description": "Beneficiary interaction location."
    },
    {
      "id": "merchant-1",
      "category": "character",
      "description": "Supplier of the village winter stock."
    },
    {
      "id": "witness-1",
      "category": "character",
      "description": "Knows why the supplies went missing."
    },
    {
      "id": "family-representative",
      "category": "character",
      "description": "Represents families without supplies."
    },
    {
      "id": "player-inventory",
      "category": "inventory",
      "description": "Trusted participant inventory."
    },
    {
      "id": "merchant-inventory",
      "category": "inventory",
      "description": "Permitted merchant transfer destination."
    },
    {
      "id": "families-inventory",
      "category": "inventory",
      "description": "Permitted families transfer destination."
    },
    {
      "id": "shipment-supplies",
      "category": "item",
      "description": "Three supplies already held before handover."
    },
    {
      "id": "shipment-outcome",
      "category": "world_fact",
      "description": "Writable outcome: returned or given-to-families."
    },
    {
      "id": "player-merchant",
      "category": "relationship",
      "description": "Permitted player/merchant trust delta."
    },
    {
      "id": "player-families",
      "category": "relationship",
      "description": "Permitted player/families trust delta."
    }
  ]
}
```

Catalogue evidence is scoped and revalidated; descriptions are supplied premise context, not invented facts. Possession inspection is not a transfer reservation. No examination-of-wagon capability exists here, so that idea remains planning prose rather than executable code.

### Create a branching outline

**create_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-13",
  "x-cf-turn-request-id": "authoring-turn-13",
  "x-cf-effect-key": "shipment-create-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 13,
  "method": "tools/call",
  "params": {
    "name": "create_quest_draft",
    "arguments": {
      "intent": {
        "title": "The Missing Shipment",
        "premise": "Discover why supplies disappeared and decide whom to help.",
        "presentation": "quest",
        "constraints": [
          "Both options have understandable motivations",
          "Player already holds the supplies before handover",
          "No implicit spawning or reward"
        ]
      },
      "plan": {
        "startBeat": "request",
        "beats": [
          {
            "id": "request",
            "title": "Learn about the shipment",
            "intent": "Establish what is missing and why it matters.",
            "outcomes": [
              {
                "id": "investigate",
                "nextBeat": "investigation"
              }
            ]
          },
          {
            "id": "investigation",
            "title": "Find an explanation",
            "intent": "Find an interaction that explains the disappearance.",
            "outcomes": [
              {
                "id": "explanation-found",
                "nextBeat": "decision"
              }
            ]
          },
          {
            "id": "decision",
            "title": "Choose whom to help",
            "intent": "Let the player choose the recipient.",
            "outcomes": [
              {
                "id": "return",
                "nextBeat": "return-supplies"
              },
              {
                "id": "help",
                "nextBeat": "help-takers"
              }
            ]
          },
          {
            "id": "return-supplies",
            "title": "Return the supplies",
            "intent": "Transfer to the merchant.",
            "outcomes": [
              {
                "id": "resolved",
                "nextBeat": "resolution"
              }
            ]
          },
          {
            "id": "help-takers",
            "title": "Help the families",
            "intent": "Transfer to the beneficiaries.",
            "outcomes": [
              {
                "id": "resolved",
                "nextBeat": "resolution"
              }
            ]
          },
          {
            "id": "resolution",
            "title": "Resolve the consequences",
            "intent": "Acknowledge the chosen outcome.",
            "outcomes": []
          }
        ]
      }
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 1,
    "contentRevision": 1,
    "contentDigest": "sha256:c0d91961a0adbf4c353825f1478b0428062a791b37123309e2982f43561b9ee1",
    "startBeat": "request",
    "generatedBeatIds": []
  }
}
```

### Record unresolved requirements

A candidate wagon clue is unsupported. The agent records a reference question rather than inventing an examination action. Two additional requirements keep transfer capabilities and permitted references explicit.

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-14",
  "x-cf-turn-request-id": "authoring-turn-14",
  "x-cf-effect-key": "shipment-requirements-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 14,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "expectedRecordRevision": 1,
      "catalogueSnapshotId": "catalogue-shipment-1",
      "operations": [
        {
          "kind": "set_requirement",
          "requirementId": "clue-source",
          "requirement": {
            "id": "clue-source",
            "beatId": "investigation",
            "kind": "world_reference",
            "question": "Which supplied witness or interaction can explain the disappearance?",
            "resolution": null
          }
        },
        {
          "kind": "set_requirement",
          "requirementId": "handover-contract",
          "requirement": {
            "id": "handover-contract",
            "beatId": "decision",
            "kind": "capability",
            "question": "Which supplied inspections/actions implement the handover and consequences?",
            "resolution": null
          }
        },
        {
          "kind": "set_requirement",
          "requirementId": "handover-references",
          "requirement": {
            "id": "handover-references",
            "beatId": "decision",
            "kind": "world_reference",
            "question": "Which supplied item, inventories and consequence refs are permitted?",
            "resolution": null
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 2,
    "contentRevision": 2,
    "contentDigest": "sha256:d19bed744c64381c77a3ce829e5796964d27de0f96f11fa9b8d215fe02701b4e",
    "changedIds": ["clue-source", "handover-contract", "handover-references"],
    "assessment": {
      "technicalReady": false,
      "planCoverage": "incomplete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    }
  }
}
```

### Revise the outline and implement the witness

The supplied catalogue identifies witness-1, not a wagon examination. Replace the small outline, preserving beat IDs, and develop the investigation. Resolve the reference requirement against this host-issued catalogue ID, not a body assertion of trusted provenance.

The arrival condition intentionally uses run-start: an entry after activation but before choosing Investigate may count. If a fresh investigation visit is intended, use `{kind:"situation-entry",situationRef:"shipment-arrival"}` instead. The condition's own situation entry dominates its evaluation.

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-15",
  "x-cf-turn-request-id": "authoring-turn-15",
  "x-cf-effect-key": "shipment-witness-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 15,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "expectedRecordRevision": 2,
      "catalogueSnapshotId": "catalogue-shipment-1",
      "operations": [
        {
          "kind": "replace_plan",
          "plan": {
            "startBeat": "request",
            "beats": [
              {
                "id": "request",
                "title": "Learn about the shipment",
                "intent": "Establish what is missing and why it matters.",
                "outcomes": [
                  {
                    "id": "investigate",
                    "nextBeat": "investigation"
                  }
                ]
              },
              {
                "id": "investigation",
                "title": "Find an explanation",
                "intent": "Meet the supplied witness and hear why the supplies were taken.",
                "outcomes": [
                  {
                    "id": "explanation-found",
                    "nextBeat": "decision"
                  }
                ]
              },
              {
                "id": "decision",
                "title": "Choose whom to help",
                "intent": "Let the player choose the recipient.",
                "outcomes": [
                  {
                    "id": "return",
                    "nextBeat": "return-supplies"
                  },
                  {
                    "id": "help",
                    "nextBeat": "help-takers"
                  }
                ]
              },
              {
                "id": "return-supplies",
                "title": "Return the supplies",
                "intent": "Transfer to the merchant.",
                "outcomes": [
                  {
                    "id": "resolved",
                    "nextBeat": "resolution"
                  }
                ]
              },
              {
                "id": "help-takers",
                "title": "Help the families",
                "intent": "Transfer to the beneficiaries.",
                "outcomes": [
                  {
                    "id": "resolved",
                    "nextBeat": "resolution"
                  }
                ]
              },
              {
                "id": "resolution",
                "title": "Resolve the consequences",
                "intent": "Acknowledge the chosen outcome.",
                "outcomes": []
              }
            ]
          }
        },
        {
          "kind": "replace_beat_implementation",
          "beatId": "investigation",
          "implementation": {
            "entrySituation": "shipment-arrival",
            "situations": [
              {
                "id": "shipment-arrival",
                "routes": [
                  {
                    "id": "arrived",
                    "priority": 10,
                    "when": {
                      "tool": "game_inspect_location",
                      "arguments": {
                        "locationRef": "shipment-site"
                      },
                      "expect": {
                        "path": ["entries"],
                        "operator": "at_least",
                        "value": 1
                      },
                      "evidence": {
                        "mode": "events",
                        "after": {
                          "kind": "run-start"
                        }
                      }
                    },
                    "next": "witness-talk"
                  }
                ]
              },
              {
                "id": "witness-talk",
                "dialogue": {
                  "text": "The supplies were taken to families who have nothing left. The merchant wants them returned.",
                  "requires": {
                    "tool": "game_inspect_interaction",
                    "arguments": {
                      "npcRef": "witness-1",
                      "locationRef": "shipment-site"
                    },
                    "expect": {
                      "path": ["allowed"],
                      "operator": "equals",
                      "value": true
                    },
                    "evidence": {
                      "mode": "fact"
                    }
                  }
                },
                "choices": [
                  {
                    "id": "consider-options",
                    "label": "Consider what to do",
                    "next": "shipment-decision"
                  }
                ]
              }
            ],
            "outcomeBindings": [
              {
                "outcomeId": "explanation-found",
                "transitions": [
                  {
                    "situationId": "witness-talk",
                    "kind": "choice",
                    "transitionId": "consider-options"
                  }
                ]
              }
            ]
          }
        },
        {
          "kind": "set_requirement",
          "requirementId": "clue-source",
          "requirement": {
            "id": "clue-source",
            "beatId": "investigation",
            "kind": "world_reference",
            "question": "Which supplied witness or interaction can explain the disappearance?",
            "resolution": {
              "kind": "catalogue",
              "referenceIds": ["witness-1", "shipment-site"]
            }
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 3,
    "contentRevision": 3,
    "contentDigest": "sha256:8c5f7b56f5b3d50f3000d2af4b75a84c1c3fab271291640cdfdaf5009e118ba8",
    "changedIds": [
      "investigation",
      "shipment-arrival",
      "witness-talk",
      "clue-source"
    ],
    "assessment": {
      "technicalReady": false,
      "planCoverage": "incomplete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    }
  }
}
```

**review_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-16",
  "x-cf-turn-request-id": "authoring-turn-16"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 16,
  "method": "tools/call",
  "params": {
    "name": "review_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "recordRevision": 3,
      "catalogueSnapshotId": "catalogue-shipment-1",
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 3,
    "contentRevision": 3,
    "contentDigest": "sha256:8c5f7b56f5b3d50f3000d2af4b75a84c1c3fab271291640cdfdaf5009e118ba8",
    "catalogueSnapshotId": "catalogue-shipment-1",
    "catalogueDigest": "sha256:b8257bba5a1a994ad0ca72724d0cd46faa2fe72e165b9437c048d955d96daa99",
    "assessment": {
      "technicalReady": false,
      "planCoverage": "incomplete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    },
    "findings": [
      {
        "code": "beat_unimplemented",
        "severity": "blocking",
        "beatId": "request",
        "path": "/implementations/request",
        "message": "The planned start beat has no implementation."
      },
      {
        "code": "missing_destination",
        "severity": "blocking",
        "beatId": "investigation",
        "situationId": "witness-talk",
        "path": "/implementations/investigation/situations/1/choices/0/next",
        "message": "shipment-decision is not implemented.",
        "expected": "The decision beat entry.",
        "supplied": "shipment-decision"
      },
      {
        "code": "requirement_unresolved",
        "severity": "blocking",
        "beatId": "decision",
        "path": "/requirements/1/resolution",
        "message": "Handover capability requirement remains unresolved."
      }
    ],
    "nextCursor": "opaque-shipment-review-page-2"
  }
}
```

More findings exist; nextCursor refers to the same revision/catalogue/filter assessment. There is no claim that the three shown are exhaustive. This is a natural authoring-session stopping point.

### Resume and read only needed sections

A second session receives explicit host rebind approval for the same namespace, then obtains a fresh `catalogue-shipment-2` from tools/list with the same capability/reference content digest and a fresh expiry. Reads below use saved record revision 3. They do not assume CAI session identity alone grants access.

**list_quest_drafts**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-17",
  "x-cf-turn-request-id": "authoring-turn-17"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 17,
  "method": "tools/call",
  "params": {
    "name": "list_quest_drafts",
    "arguments": {
      "filter": {
        "publicationState": "unpublished"
      },
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "items": [
      {
        "draftId": "draft-44444444-4444-4444-8444-444444444444",
        "title": "The Missing Shipment",
        "recordRevision": 3,
        "contentRevision": 3,
        "contentDigest": "sha256:8c5f7b56f5b3d50f3000d2af4b75a84c1c3fab271291640cdfdaf5009e118ba8",
        "publicationState": "unpublished"
      }
    ],
    "listSnapshotId": "list-shipment-session-2",
    "nextCursor": null
  }
}
```

**read_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-18",
  "x-cf-turn-request-id": "authoring-turn-18"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 18,
  "method": "tools/call",
  "params": {
    "name": "read_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "recordRevision": 3,
      "section": "overview",
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 3,
    "contentRevision": 3,
    "contentDigest": "sha256:8c5f7b56f5b3d50f3000d2af4b75a84c1c3fab271291640cdfdaf5009e118ba8",
    "intent": {
      "title": "The Missing Shipment",
      "premise": "Discover why supplies disappeared and decide whom to help.",
      "presentation": "quest",
      "constraints": [
        "Both options have understandable motivations",
        "Player already holds the supplies before handover",
        "No implicit spawning or reward"
      ]
    },
    "startBeat": "request",
    "implementationSummary": {
      "implementedBeats": ["investigation"],
      "unimplementedBeats": [
        "request",
        "decision",
        "return-supplies",
        "help-takers",
        "resolution"
      ]
    },
    "nextCursor": null
  }
}
```

**read_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-19",
  "x-cf-turn-request-id": "authoring-turn-19"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 19,
  "method": "tools/call",
  "params": {
    "name": "read_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "recordRevision": 3,
      "section": "beat",
      "beatId": "return-supplies",
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 3,
    "contentRevision": 3,
    "contentDigest": "sha256:8c5f7b56f5b3d50f3000d2af4b75a84c1c3fab271291640cdfdaf5009e118ba8",
    "beat": {
      "id": "return-supplies",
      "title": "Return the supplies",
      "intent": "Transfer to the merchant.",
      "outcomes": [
        {
          "id": "resolved",
          "nextBeat": "resolution"
        }
      ]
    },
    "implementation": null,
    "nextCursor": null
  }
}
```

The agent can similarly read requirements/plan pages at revision 3. If that snapshot expired, it must deliberately restart reads at a known current revision instead of mixing snapshots.

### Resolve handover requirements and develop request/choice

The agent uses the freshly issued permitted catalogue, not a self-authored sourceKind field.

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-20",
  "x-cf-turn-request-id": "authoring-turn-20",
  "x-cf-effect-key": "shipment-request-choice-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 20,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "expectedRecordRevision": 3,
      "catalogueSnapshotId": "catalogue-shipment-2",
      "operations": [
        {
          "kind": "set_requirement",
          "requirementId": "handover-contract",
          "requirement": {
            "id": "handover-contract",
            "beatId": "decision",
            "kind": "capability",
            "question": "Which supplied inspections/actions implement the handover and consequences?",
            "resolution": {
              "kind": "catalogue",
              "capabilityNames": [
                "game_inspect_inventory",
                "game_transfer_items",
                "game_set_world_fact",
                "game_adjust_relationship"
              ]
            }
          }
        },
        {
          "kind": "set_requirement",
          "requirementId": "handover-references",
          "requirement": {
            "id": "handover-references",
            "beatId": "decision",
            "kind": "world_reference",
            "question": "Which supplied item, inventories and consequence refs are permitted?",
            "resolution": {
              "kind": "catalogue",
              "referenceIds": [
                "player-inventory",
                "merchant-inventory",
                "families-inventory",
                "shipment-supplies",
                "shipment-outcome",
                "player-merchant",
                "player-families"
              ]
            }
          }
        },
        {
          "kind": "replace_beat_implementation",
          "beatId": "request",
          "implementation": {
            "entrySituation": "shipment-request",
            "situations": [
              {
                "id": "shipment-request",
                "dialogue": {
                  "text": "My supplies disappeared. Please find out what happened.",
                  "requires": {
                    "tool": "game_inspect_interaction",
                    "arguments": {
                      "npcRef": "merchant-1",
                      "locationRef": "merchant-house"
                    },
                    "expect": {
                      "path": ["allowed"],
                      "operator": "equals",
                      "value": true
                    },
                    "evidence": {
                      "mode": "fact"
                    }
                  }
                },
                "choices": [
                  {
                    "id": "investigate",
                    "label": "Investigate the shipment",
                    "next": "shipment-arrival"
                  }
                ]
              }
            ],
            "outcomeBindings": [
              {
                "outcomeId": "investigate",
                "transitions": [
                  {
                    "situationId": "shipment-request",
                    "kind": "choice",
                    "transitionId": "investigate"
                  }
                ]
              }
            ]
          }
        },
        {
          "kind": "replace_beat_implementation",
          "beatId": "decision",
          "implementation": {
            "entrySituation": "shipment-decision",
            "situations": [
              {
                "id": "shipment-decision",
                "dialogue": {
                  "text": "Return the supplies to the merchant, or bring them to the families?",
                  "requires": {
                    "tool": "game_inspect_interaction",
                    "arguments": {
                      "npcRef": "witness-1",
                      "locationRef": "shipment-site"
                    },
                    "expect": {
                      "path": ["allowed"],
                      "operator": "equals",
                      "value": true
                    },
                    "evidence": {
                      "mode": "fact"
                    }
                  }
                },
                "choices": [
                  {
                    "id": "return",
                    "label": "Return them to the merchant",
                    "next": "merchant-handover"
                  },
                  {
                    "id": "help",
                    "label": "Bring them to the families",
                    "next": "families-handover"
                  }
                ]
              }
            ],
            "outcomeBindings": [
              {
                "outcomeId": "return",
                "transitions": [
                  {
                    "situationId": "shipment-decision",
                    "kind": "choice",
                    "transitionId": "return"
                  }
                ]
              },
              {
                "outcomeId": "help",
                "transitions": [
                  {
                    "situationId": "shipment-decision",
                    "kind": "choice",
                    "transitionId": "help"
                  }
                ]
              }
            ]
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 4,
    "contentRevision": 4,
    "contentDigest": "sha256:9689b2b6f3c4ffcc9b4418b6e07ef642b38799d9ae203cc112f77cb54da5f90c",
    "changedIds": [
      "handover-contract",
      "handover-references",
      "request",
      "decision"
    ],
    "assessment": {
      "technicalReady": false,
      "planCoverage": "incomplete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    }
  }
}
```

### Implement both handovers and their ending

Actual recipient interaction gates each handover's dialogue and commit-time choice. Possession gates the Give choice; the transfer handler still validates authority/quantity/proximity at admission. Merely selecting a narrative branch cannot remotely grant items.

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-21",
  "x-cf-turn-request-id": "authoring-turn-21",
  "x-cf-effect-key": "shipment-handovers-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 21,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "expectedRecordRevision": 4,
      "catalogueSnapshotId": "catalogue-shipment-2",
      "operations": [
        {
          "kind": "replace_beat_implementation",
          "beatId": "return-supplies",
          "implementation": {
            "entrySituation": "merchant-handover",
            "situations": [
              {
                "id": "merchant-handover",
                "dialogue": {
                  "text": "Hand over the supplies?",
                  "requires": {
                    "tool": "game_inspect_interaction",
                    "arguments": {
                      "npcRef": "merchant-1",
                      "locationRef": "merchant-house"
                    },
                    "expect": {
                      "path": ["allowed"],
                      "operator": "equals",
                      "value": true
                    },
                    "evidence": {
                      "mode": "fact"
                    }
                  }
                },
                "choices": [
                  {
                    "id": "give",
                    "label": "Give the supplies",
                    "when": {
                      "tool": "game_inspect_inventory",
                      "arguments": {
                        "inventoryRef": "player-inventory",
                        "itemRef": "shipment-supplies"
                      },
                      "expect": {
                        "path": ["quantity"],
                        "operator": "at_least",
                        "value": 3
                      },
                      "evidence": {
                        "mode": "fact"
                      }
                    },
                    "next": "merchant-effects"
                  }
                ]
              },
              {
                "id": "merchant-effects",
                "onEnter": [
                  {
                    "id": "transfer",
                    "tool": "game_transfer_items",
                    "arguments": {
                      "fromInventoryRef": "player-inventory",
                      "toInventoryRef": "merchant-inventory",
                      "itemRef": "shipment-supplies",
                      "quantity": 3
                    }
                  },
                  {
                    "id": "record-outcome",
                    "tool": "game_set_world_fact",
                    "arguments": {
                      "factRef": "shipment-outcome",
                      "value": "returned"
                    }
                  },
                  {
                    "id": "relationship",
                    "tool": "game_adjust_relationship",
                    "arguments": {
                      "relationshipRef": "player-merchant",
                      "delta": 1
                    }
                  }
                ],
                "choices": [
                  {
                    "id": "resolved",
                    "label": "Continue",
                    "next": "shipment-resolution"
                  }
                ]
              }
            ],
            "outcomeBindings": [
              {
                "outcomeId": "resolved",
                "transitions": [
                  {
                    "situationId": "merchant-effects",
                    "kind": "choice",
                    "transitionId": "resolved"
                  }
                ]
              }
            ]
          }
        },
        {
          "kind": "replace_beat_implementation",
          "beatId": "help-takers",
          "implementation": {
            "entrySituation": "families-handover",
            "situations": [
              {
                "id": "families-handover",
                "dialogue": {
                  "text": "Hand over the supplies?",
                  "requires": {
                    "tool": "game_inspect_interaction",
                    "arguments": {
                      "npcRef": "family-representative",
                      "locationRef": "families-camp"
                    },
                    "expect": {
                      "path": ["allowed"],
                      "operator": "equals",
                      "value": true
                    },
                    "evidence": {
                      "mode": "fact"
                    }
                  }
                },
                "choices": [
                  {
                    "id": "give",
                    "label": "Give the supplies",
                    "when": {
                      "tool": "game_inspect_inventory",
                      "arguments": {
                        "inventoryRef": "player-inventory",
                        "itemRef": "shipment-supplies"
                      },
                      "expect": {
                        "path": ["quantity"],
                        "operator": "at_least",
                        "value": 3
                      },
                      "evidence": {
                        "mode": "fact"
                      }
                    },
                    "next": "families-effects"
                  }
                ]
              },
              {
                "id": "families-effects",
                "onEnter": [
                  {
                    "id": "transfer",
                    "tool": "game_transfer_items",
                    "arguments": {
                      "fromInventoryRef": "player-inventory",
                      "toInventoryRef": "families-inventory",
                      "itemRef": "shipment-supplies",
                      "quantity": 3
                    }
                  },
                  {
                    "id": "record-outcome",
                    "tool": "game_set_world_fact",
                    "arguments": {
                      "factRef": "shipment-outcome",
                      "value": "given-to-families"
                    }
                  },
                  {
                    "id": "relationship",
                    "tool": "game_adjust_relationship",
                    "arguments": {
                      "relationshipRef": "player-families",
                      "delta": 1
                    }
                  }
                ],
                "choices": [
                  {
                    "id": "resolved",
                    "label": "Continue",
                    "next": "shipment-resolution"
                  }
                ]
              }
            ],
            "outcomeBindings": [
              {
                "outcomeId": "resolved",
                "transitions": [
                  {
                    "situationId": "families-effects",
                    "kind": "choice",
                    "transitionId": "resolved"
                  }
                ]
              }
            ]
          }
        },
        {
          "kind": "replace_beat_implementation",
          "beatId": "resolution",
          "implementation": {
            "entrySituation": "shipment-resolution",
            "situations": [
              {
                "id": "shipment-resolution"
              }
            ],
            "outcomeBindings": []
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 5,
    "contentRevision": 5,
    "contentDigest": "sha256:905c01ea53d7e5c18387dc0875da0bf748d902b5c70cdbb1a16c99a5074df7d6",
    "changedIds": ["return-supplies", "help-takers", "resolution"],
    "assessment": {
      "technicalReady": true,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    }
  }
}
```

Nine situations, six actions across the alternative branches, and a structurally terminal ending. The Continue choice is exposed only after all entry actions acknowledge completion. It explicitly leaves the effect situation; no invented unconditional route operator is used.

The empty ending is technically valid and does not imply narrative satisfaction. Host presentation and any later closing dialogue must be designed deliberately, without mandatory NPCs or rewards.

**review_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-22",
  "x-cf-turn-request-id": "authoring-turn-22"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 22,
  "method": "tools/call",
  "params": {
    "name": "review_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "recordRevision": 5,
      "catalogueSnapshotId": "catalogue-shipment-2",
      "includeMermaid": true,
      "limit": 8
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 5,
    "contentRevision": 5,
    "contentDigest": "sha256:905c01ea53d7e5c18387dc0875da0bf748d902b5c70cdbb1a16c99a5074df7d6",
    "catalogueSnapshotId": "catalogue-shipment-2",
    "catalogueDigest": "sha256:b8257bba5a1a994ad0ca72724d0cd46faa2fe72e165b9437c048d955d96daa99",
    "assessment": {
      "technicalReady": true,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "not_reviewed"
      }
    },
    "findings": [],
    "mermaid": "flowchart TD\n  request --> investigation\n  investigation --> decision\n  decision --> returnSupplies[Merchant handover]\n  decision --> helpFamilies[Families handover]\n  returnSupplies --> resolution\n  helpFamilies --> resolution",
    "nextCursor": null
  }
}
```

### Narrative feedback, a content edit, and review staleness

The author records an advisory review of content revision 5. The tool stores the judgment; it does not generate one itself.

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-23",
  "x-cf-turn-request-id": "authoring-turn-23",
  "x-cf-effect-key": "shipment-review-note-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 23,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "expectedRecordRevision": 5,
      "catalogueSnapshotId": "catalogue-shipment-2",
      "operations": [
        {
          "kind": "record_narrative_review",
          "review": {
            "reviewedContentDigest": "sha256:905c01ea53d7e5c18387dc0875da0bf748d902b5c70cdbb1a16c99a5074df7d6",
            "policyVersion": "shipment-review-1",
            "summary": "Both branches execute coherently, but requester motivation should be clearer. The empty ending remains a later presentation decision.",
            "findings": [
              {
                "beatId": "request",
                "situationId": "shipment-request",
                "path": "/implementations/request/situations/0/dialogue/text",
                "message": "Explain the village winter-stock need from the supplied premise."
              }
            ]
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 6,
    "contentRevision": 5,
    "contentDigest": "sha256:905c01ea53d7e5c18387dc0875da0bf748d902b5c70cdbb1a16c99a5074df7d6",
    "changedIds": ["narrativeReviews"],
    "assessment": {
      "technicalReady": true,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "current",
        "reviewedContentDigest": "sha256:905c01ea53d7e5c18387dc0875da0bf748d902b5c70cdbb1a16c99a5074df7d6",
        "policyVersion": "shipment-review-1"
      }
    }
  }
}
```

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-24",
  "x-cf-turn-request-id": "authoring-turn-24",
  "x-cf-effect-key": "shipment-motivation-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 24,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "expectedRecordRevision": 6,
      "catalogueSnapshotId": "catalogue-shipment-2",
      "operations": [
        {
          "kind": "replace_beat_implementation",
          "beatId": "request",
          "implementation": {
            "entrySituation": "shipment-request",
            "situations": [
              {
                "id": "shipment-request",
                "dialogue": {
                  "text": "Those supplies were promised to the village for winter. Please find out what happened before you decide what to do.",
                  "requires": {
                    "tool": "game_inspect_interaction",
                    "arguments": {
                      "npcRef": "merchant-1",
                      "locationRef": "merchant-house"
                    },
                    "expect": {
                      "path": ["allowed"],
                      "operator": "equals",
                      "value": true
                    },
                    "evidence": {
                      "mode": "fact"
                    }
                  }
                },
                "choices": [
                  {
                    "id": "investigate",
                    "label": "Investigate the shipment",
                    "next": "shipment-arrival"
                  }
                ]
              }
            ],
            "outcomeBindings": [
              {
                "outcomeId": "investigate",
                "transitions": [
                  {
                    "situationId": "shipment-request",
                    "kind": "choice",
                    "transitionId": "investigate"
                  }
                ]
              }
            ]
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 7,
    "contentRevision": 6,
    "contentDigest": "sha256:7722896903235db0abcee374a2c616b473a59fa0f33f3ee3b81974cef58d88b2",
    "changedIds": ["request", "shipment-request"],
    "assessment": {
      "technicalReady": true,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "stale",
        "reviewedContentDigest": "sha256:905c01ea53d7e5c18387dc0875da0bf748d902b5c70cdbb1a16c99a5074df7d6",
        "policyVersion": "shipment-review-1"
      }
    }
  }
}
```

Record revision advances to 7; content revision advances only to 6. The previous review is stale because content changed. It is not mechanically marked resolved or allowed to suppress technical blockers. The winter premise was explicitly supplied; if unknown, it should have remained a requirement instead of invented canon.

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-25",
  "x-cf-turn-request-id": "authoring-turn-25",
  "x-cf-effect-key": "shipment-review-current-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 25,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "expectedRecordRevision": 7,
      "catalogueSnapshotId": "catalogue-shipment-2",
      "operations": [
        {
          "kind": "record_narrative_review",
          "review": {
            "reviewedContentDigest": "sha256:7722896903235db0abcee374a2c616b473a59fa0f33f3ee3b81974cef58d88b2",
            "policyVersion": "shipment-review-1",
            "summary": "Requester and families motivations are understandable under supplied context; terminal presentation is intentionally minimal in this contract fixture.",
            "findings": []
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "recordRevision": 8,
    "contentRevision": 6,
    "contentDigest": "sha256:7722896903235db0abcee374a2c616b473a59fa0f33f3ee3b81974cef58d88b2",
    "changedIds": ["narrativeReviews"],
    "assessment": {
      "technicalReady": true,
      "planCoverage": "complete",
      "narrativeReview": {
        "status": "current",
        "reviewedContentDigest": "sha256:7722896903235db0abcee374a2c616b473a59fa0f33f3ee3b81974cef58d88b2",
        "policyVersion": "shipment-review-1"
      }
    }
  }
}
```

### Publish the exact content

Publication recalculates technical/plan/requirement readiness against current catalogue-shipment-2. Advisory narrative comments are reported but do not grant runtime authority.

**publish_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-26",
  "x-cf-turn-request-id": "authoring-turn-26",
  "x-cf-effect-key": "shipment-publish-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 26,
  "method": "tools/call",
  "params": {
    "name": "publish_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "expectedRecordRevision": 8,
      "expectedContentDigest": "sha256:7722896903235db0abcee374a2c616b473a59fa0f33f3ee3b81974cef58d88b2",
      "catalogueSnapshotId": "catalogue-shipment-2"
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "draftId": "draft-44444444-4444-4444-8444-444444444444",
    "publicationId": "publication-66666666-6666-4666-8666-666666666666",
    "definitionId": "definition-55555555-5555-4555-8555-555555555555",
    "definitionDigest": "sha256:75d6598797e4699ae8d8feff66c8157d54fcfee05baeedec69215bf1efcab7b3",
    "sourceRecordRevision": 8,
    "sourceContentRevision": 6,
    "sourceContentDigest": "sha256:7722896903235db0abcee374a2c616b473a59fa0f33f3ee3b81974cef58d88b2",
    "recordRevision": 9
  }
}
```

No live SituationSystem registration, run, item transfer, relationship mutation or game activation occurs during authoring publication. The larger fixture assumes capabilities; a real service rejects if the game has not supplied them.

## 3. Failure, conflict, and permission calls

### Lost edit reply

If shipment-handovers-01 committed revision 5 but its response was lost, recover it using the original key. Exact receipt replay returns revision 5 even if a later edit has advanced to 8. It does not rerun the fragment edit or inspect inventory. Changed arguments under that key return effect_key_conflict.

### Concurrent edit

This new edit expected revision 3 after another session committed revision 4:

**edit_quest_draft**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-27",
  "x-cf-turn-request-id": "authoring-turn-27",
  "x-cf-effect-key": "shipment-stale-edit-01"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 27,
  "method": "tools/call",
  "params": {
    "name": "edit_quest_draft",
    "arguments": {
      "draftId": "draft-44444444-4444-4444-8444-444444444444",
      "expectedRecordRevision": 3,
      "catalogueSnapshotId": "catalogue-shipment-2",
      "operations": [
        {
          "kind": "set_intent",
          "intent": {
            "title": "The Missing Shipment",
            "premise": "Discover why supplies disappeared and decide whom to help.",
            "presentation": "quest",
            "constraints": [
              "Both options have understandable motivations",
              "Player already holds the supplies before handover",
              "No implicit spawning or reward"
            ]
          }
        }
      ]
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "rejected",
  "code": "revision_conflict",
  "message": "The draft changed; read the current snapshot before reconciling.",
  "issues": [
    {
      "path": "/expectedRecordRevision",
      "code": "revision_conflict",
      "message": "Expected 3, current 4."
    }
  ],
  "details": {
    "expectedRecordRevision": 3,
    "currentRecordRevision": 4,
    "changedIds": [
      "handover-contract",
      "handover-references",
      "request",
      "decision"
    ],
    "summaryComplete": true
  }
}
```

Read revision 4 and deliberately reconcile. The rejected command is terminal; a corrected edit takes a new key. If the change interval is no longer retained, details.summaryComplete is false and a fresh read is necessary.

### Pending and not-admitted outcomes

A mutation durably prepared before its transaction can return a running result. Its opaque operation ID is not a replacement command key.

```json
{
  "status": "running",
  "operationId": "command-77777777-7777-4777-8777-777777777777"
}
```

**get_authoring_command_outcome**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-28",
  "x-cf-turn-request-id": "authoring-turn-28"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 28,
  "method": "tools/call",
  "params": {
    "name": "get_authoring_command_outcome",
    "arguments": {
      "commandKey": "example-pending-command"
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "state": "pending",
    "tool": "edit_quest_draft",
    "argumentDigest": "sha256:7777777777777777777777777777777777777777777777777777777777777777",
    "operationId": "command-77777777-7777-4777-8777-777777777777"
  }
}
```

These standalone pending examples refer to a separate hypothetical command. They do not change either completed transcript. A healthy primary lookup of an unrecorded command, serialized with admission/recovery, can return:

**get_authoring_command_outcome**

Trusted HTTP headers (credentials and session binding omitted):

```json
{
  "x-cf-call-id": "delivery-29",
  "x-cf-turn-request-id": "authoring-turn-29"
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 29,
  "method": "tools/call",
  "params": {
    "name": "get_authoring_command_outcome",
    "arguments": {
      "commandKey": "example-never-admitted-command"
    }
  }
}
```

Response `result.structuredContent`:

```json
{
  "status": "completed",
  "data": {
    "state": "not_admitted"
  }
}
```

An unreachable database returns storage_unavailable, not not_admitted. A revoked or unapproved author session receives permission_denied before receipt access; no draft/publication contents are leaked. Queue admission and authority changes are serialized so late queued work cannot commit under a revoked lease.

### Publication transaction crash cuts

Crash after definition-row insertion but before the source-reference/receipt writes: transaction rollback leaves none of those terminal effects; the prepared original command remains to reconcile. Crash after the whole transaction commits but before reply: outcome lookup returns the committed original publication. Restart never creates a second definition under a new identity. There is no separate external live-registry commit in this first slice.

### Partial game consequences after later activation

If a runtime handover transfer completes but its following world-fact action blocks, retain the original transfer receipt and pending consequence identity. Continue and the opposite branch remain unavailable. A real durable game adapter must reconcile the completed transfer after restart before resuming later actions. Do not repeat delivery, silently roll back items or permit switching branches. This is a future world-adapter test, separate from authoring-store durability and not proven by volatile Rocket demos.

### Limits, removal and old reads

Expired catalogue IDs reject new edits/publications; new tools/list context plus a new intended command is required. Old record snapshots and expired cursors reject explicitly rather than returning current data. Removed identities become tombstones and cannot be reused in the draft. Retained unresolved receipts and publication source snapshots are not silently evicted; capacity exhaustion produces backpressure.

## 4. First delivery acceptance

After human implementation approval: real MCP tools/list → default beat creation → lost-create recovery → incomplete edit/read → corrected fragment → review → atomic immutable publication → process restart and approved author rebinding → saved draft/publication/outcome reads. Then separately import/start through the existing AI-free host and finish on game-owned location evidence.

Include exact-key/digest conflict, stale-edit conflict, revocation/rebinding, expired evidence/snapshot/cursor, quota/tombstone behavior and transaction crash cuts. The shipment remains a richer fixture; it does not make unimplemented inventory handlers prerequisites for the visit milestone. No implementation is authorized by these transcripts.
