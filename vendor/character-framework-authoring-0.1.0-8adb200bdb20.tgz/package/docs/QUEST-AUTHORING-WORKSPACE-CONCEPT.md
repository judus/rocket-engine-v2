# Quest authoring workspace: small operations and a shared Mermaid view

Status: concept for discussion and review, developed with Julien on14 October2026. A bounded local builder demonstration is now implemented: see [working tool contract and walkthrough](QUEST-BUILDER-TOOLS-WALKTHROUGH.md). Broader workspace/CAI deployment remains proposed. The current raw-graph authoring tools and passed transport/publication/gameplay proofs remain valid comparison evidence. This document requests thoughts and review; it does not start a new implementation or live provider batch.

## Why experiment with this?

**The goal is to make quest authoring easier for the LLM. The central question is: is it actually easier?**

Today, `replace_beat_implementation` asks the model to supply a complete runtime situation graph. The model must coordinate IDs, references, nesting, routes, choices, conditions, event boundaries and consequences. CFW validates and stores that graph, but the model still acts as a JSON graph programmer. The exact eleven-call tutorial proves that the tools can reconstruct a supplied graph; it does not prove that an LLM can comfortably design it.

The alternative is a persistent authoring workspace. The model makes smaller creative and logical decisions through tools; CFW constructs the executable graph. The workspace returns progress, stable IDs, readable logic, findings and a Mermaid projection of the saved quest. The model can inspect its whole design, critique branches and revise locally.

This might reduce bookkeeping and make branching easier to reason about. It might instead increase tool calls, latency, context use and opportunities to lose track of revisions. A polished interface is not evidence of lower model effort. We should measure whether it helps before committing to a larger authoring system.

## The shared view

Julien's observation is useful: a human normally interprets a rendered diagram, while an LLM can interpret the Mermaid source. Both can inspect the same underlying graph.

The model does not need browser automation merely to read Mermaid. A tool can return Mermaid text; a web page can render that same text. The earlier browser-workshop idea was an interface for the LLM, not primarily a user-facing editor. Browser automation remains an optional experiment, rather than a prerequisite for this concept.

The useful information is stage purpose, connections, choice text, conditions and consequences. A diagram containing only boxes and IDs is insufficient. Mermaid must be generated from the exact saved draft at the reported revision, never guessed by another model or maintained separately. CFW should escape labels and use deterministic diagram node identifiers.

The primary inspection should preserve real routes and timing. For example, “new pickup OR collected fact” hides two distinct routes. In this world, `collected` stays true after delivery: it does not mean the item is still carried. An optional overview may collapse details if marked as such; the exact graph and stage details must expose them.

## Responsibilities and representations

| Owner            | Responsibility                                                                                                                                                   |
| ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| LLM / CAI        | Ground the quest in supplied information; choose narrative purpose, stages, branches, temporal meaning and permitted consequences; inspect, critique and repair. |
| CFW              | Own authoring operations, IDs/revisions, validation, deterministic graph compilation, Mermaid/readable inspection and immutable publication.                     |
| Game / Rocket    | Supply world facts, roles, interaction rules, capability contracts and authoritative effects/evidence; execute the published quest through ordinary handlers.    |
| Application host | Compose providers, provision grants and binding identities, own endpoint/storage/lifecycle and exact publication-to-consumer handoff.                            |

The model still needs to understand gameplay causes and tool argument contracts. “Hide runtime JSON” does not mean “the model understands no structure.” It means the model should not construct or inspect the raw executable graph as its normal authoring task.

There must be one authoritative saved design. Two plausible implementations are: apply small operations directly to the existing saved graph and project authoring views from it; or store an authoritative authoring model and compile the runtime graph as a derived artifact. In the latter case, raw graph edits cannot independently mutate the same builder draft. Which approach is simplest is a review question, not a settled architecture.

Keep existing raw-graph tools as a versioned comparison interface for existing consumers. A builder-facing grant set should expose authoring logic and Mermaid, without exposing whole-graph replacement or raw beat/publication-definition reads to the model. Host-side artifact retrieval remains available for execution and evidence. Existing validator/publication/receipt semantics should be reused; this concept does not itself require a runtime schema change.

## Small operations, clear responsibilities

Proposed names below illustrate responsibilities; they are not a delivered API.

| Operation                                            | Purpose                                                                |
| ---------------------------------------------------- | ---------------------------------------------------------------------- |
| `create_quest_draft`                                 | Save title, premise and player goal; no implicit first stage.          |
| `add_stage` / `update_stage` / `remove_stage`        | Author a stage's purpose and presentation. Return stable assigned IDs. |
| `set_start_stage`                                    | Explicitly choose where execution begins.                              |
| `create_fact_condition`                              | Define a check of something true now.                                  |
| `create_event_condition`                             | Define events after an explicit quest/stage boundary.                  |
| `update_condition`                                   | Repair a condition without rewriting the whole graph.                  |
| `add_transition`                                     | Connect two stages using an existing condition ID.                     |
| `add_choice`                                         | Offer a player decision and destination, with optional condition ID.   |
| `order_transitions`                                  | Explicitly order automatic routes that may overlap.                    |
| `set_stage_dialogue` / `set_interaction_requirement` | Author prose and gate the interaction, including its choices.          |
| `add_entry_consequence`                              | Attach an explicitly permitted game action to stage entry.             |
| `declare_ending`                                     | Record that a stage is intentionally terminal.                         |
| `inspect_quest_draft` / `review_quest_draft`         | Return saved authoring logic/Mermaid and actionable findings.          |
| `publish_quest_draft`                                | Compile, validate and store an immutable executable definition.        |

The smallest prototype need not implement every editing convenience immediately. It must support creating the comparison quest, recovering a draft and making the local repairs needed by the experiment.

Splitting condition construction from routing was a keeper in Julien's discussion. A large `add_transition` call should not also build the entire condition. A condition operation returns an ID and readable meaning; the route then references that ID. Conditions may be reused where their timing/scope makes that meaningful.

A common `draft` argument can carry `{id, revision}`. Grouping fields does not magically remove complexity; the improvement comes from narrow operations with clear purposes. Game arguments remain typed by the supplied capability catalogue, not arbitrary prose. Avoid a universal `deliver_item` shortcut that silently invents a game action or guesses whether historical delivery counts.

For example:

```text
create_event_condition(
  draft: { id: "d1", revision: 4 },
  check: "game_location",
  arguments: { locationRef: "courtyard" },
  at_least: { field: "count", value: 1 },
  since: "quest_start"
)
```

Response:

```json
{
  "status": "completed",
  "draftId": "d1",
  "revision": 5,
  "created": { "conditionId": "c1" },
  "description": "At least one new courtyard entry since quest start."
}
```

Then:

```text
add_transition(
  draft: { id: "d1", revision: 5 },
  from: "s1",
  to: "s2",
  conditionId: "c1"
)
```

The model specifies logical meaning; CFW supplies runtime nesting and serialization. CFW checks the capability/output type, argument references, timing boundary and connection before committing the operation. Incomplete drafts remain saveable, while unsafe or invalid individual edits return local errors.

## Responses that preserve progress

Each successful mutation should return the draft ID, current revision, assigned/changed IDs and a concise readable change. A small progress summary can identify the start stage, counts and unresolved work. Avoid returning the entire graph after every mutation; the model should inspect at checkpoints or when needed.

Example after adding a stage:

```json
{
  "status": "completed",
  "draftId": "d1",
  "revision": 2,
  "created": { "stageId": "s1", "title": "Enter the courtyard" },
  "progress": {
    "stageCount": 1,
    "conditionCount": 0,
    "transitionCount": 0,
    "choiceCount": 0,
    "startStageId": null
  },
  "findings": [
    { "code": "start_missing", "message": "Choose a starting stage." }
  ]
}
```

Assigned IDs remain stable when titles change. Draft identity must not be confused with the later published definition ID. Revision conflicts return the current revision and instruct the author to inspect current work; they do not silently apply edits to an outdated design.

Inspection should return the ID/title directory, exact readable conditions, routes/choices and their destinations, ordered entry consequences, explicit endings, findings and Mermaid for one reported revision. After interruption, the agent lists/opens the draft and reconstructs its working context from that saved state.

Connector-owned call/turn/effect identities stay outside model arguments. Exact retries retain their original identity and payload. A saved edit is not publication, a successful review is not narrative quality, and publication is not gameplay activation.

## Authoring workflow: guided, but not a rigid questionnaire

1. Receive the authored game description, permitted capabilities and actual world context. Understand hidden entities, reveal/activation, custody, range and matching destinations. Missing information is not an empty world.
2. Create the quest's purpose. Save an idea before deciding its progression. An optional desired stage count is guidance, not a mandatory initial commitment.
3. Add stages and conditions, connect routes/choices and attach permitted consequences. Explicitly choose a start and declare intended endings.
4. Inspect the Mermaid plus stage details. Compare all paths against the purpose and brief.
5. Critique and revise locally. Check causal prerequisites, branch differentiation, dead ends, timing and irreversible actions.
6. Review structure and brief compliance separately. Publish only the saved, ready revision requested by the task.
7. Correlate the exact successful publication receipt/definition digest to a separate reset consumer. Play every offered branch with AI disconnected, recording failures without rescue code.

CFW may return optional `nextSteps` or `availableActions`, such as “This stage has no continuation or declared ending.” These are factual affordances/suggestions, not a second creative agent. The LLM can revisit earlier decisions and build branches in another order. We should test whether a guided question workflow helps beyond small tools plus inspection; do not add it automatically to the first comparison.

## Watchtower example: inspect, critique, revise

Use the corrected fixed-world comparison baseline, quest SHA256 `32aabc76aaf1c3f0a8cc57bb6a9287ac3f55eb46334c78a3ba6086be8d0c9f9d`. Existing CFW193 and Rocket host/consumer/CAI queued-worker proofs establish plumbing and baseline execution, with model HTTP mocked. They do not establish independent generated quality.

The agent creates a draft about restoring a beacon, then adds courtyard entry, sentry encounter and Watchkeeper stages. A new courtyard event leads to the encounter; entering it activates the sentries. Three new defeats lead to the Watchkeeper stage, whose entry reveals the guide and opens the gate. Approaching the guide leads to a guarded choice stage.

The agent adds Blue and Red choices. Inspection reports incomplete branches. It completes each branch with a collected-fact shortcut, otherwise a revealed-seal/new-pickup stage, matching delivery check and explicit ending with the matching beacon consequence. Collected and matching delivered-to facts are separate; the first remains true after delivery.

The exact logic view could look like this:

```mermaid
flowchart TD
    s1["s1: Enter courtyard"] -->|"New entry since quest start"| s2["s2: Encounter; activate sentries"]
    s2 -->|"3 new defeats since s2 entry"| s3["s3: Watchkeeper; reveal guide, open gate"]
    s3 -->|"Guide near"| s4["s4: Choose; interaction requires guide near"]
    s4 -->|"Blue choice"| s5["s5: Check blue custody"]
    s5 -->|"Collected fact is true"| s7["s7: Matching blue delivery"]
    s5 -->|"Collected fact is false"| s6["s6: Reveal/recover blue seal"]
    s6 -->|"New pickup since s6 entry"| s7
    s7 -->|"Blue delivered to A; existing fact counts"| s8["s8: Declared ending; light A"]
    s4 -->|"Red choice"| s9["s9: Check red custody"]
    s9 -->|"Collected fact is true"| s11["s11: Matching red delivery"]
    s9 -->|"Collected fact is false"| s10["s10: Reveal/recover red seal"]
    s10 -->|"New pickup since s10 entry"| s11
    s11 -->|"Red delivered to B; existing fact counts"| s12["s12: Declared ending; light B"]
```

The readable details also state that ordinary interactions use42-pixel range, guide proximity uses48 pixels, unavailable evidence blocks, and the gate can be walked around. Opening the gate is an authored consequence, not proof that no other route exists.

The LLM can now ask whether the two choices have distinct narrative meaning. Different destinations alone do not guarantee a meaningful story branch. It may revise dialogue/motives within supplied lore; it must not invent executable entities, rewards or mechanics. CFW should expose the design, not manufacture a story-quality verdict.

The earlier delivery softlock is a useful lesson: one-time delivery before an event boundary cannot be repeated. This comparison explicitly counts an existing matching delivery. A different brief requiring new delivery must retain that requirement and have compatible gameplay mechanics. Friendlier tools must expose this policy, not hide or silently weaken it.

## Is it really easier? A bounded comparison

First prove deterministic equivalence: build the same watchtower through small operations, inspect its saved Mermaid and publish it. Compare executable guards/routes/effects with the accepted baseline, allowing deliberately assigned IDs to differ through an explicit mapping. Repeat its existing branch and ordering controls. This establishes builder correctness, not LLM ease.

Then compare model authoring approaches on the same frozen briefs/world/capabilities, model and repair/spending budget:

| Arm | Authoring interface                                     | What it helps isolate                                 |
| --- | ------------------------------------------------------- | ----------------------------------------------------- |
| A   | Existing whole-graph authoring plus its technical guide | Current raw-schema baseline.                          |
| B   | Small builder operations plus readable saved summary    | Whether narrower operations reduce authoring burden.  |
| C   | The same builder plus CFW-generated Mermaid inspection  | Whether the graph view adds value beyond the builder. |

A browser-rendered workspace can be a later arm. It adds browser/vision/navigation costs and should not be bundled into C if we want to understand Mermaid text's contribution. Likewise, adaptive questions are another variable; hold them constant or test them separately.

The previously proposed six candidates are a small signal, not enough to claim general reliability across all these arms. Agree which interfaces and repetitions fit the finite budget before execution; do not change tools midway through a batch or combine scores from different interfaces. Only the authorized CAI runner invokes providers, under agreed model/call-token-cost ceilings. No live batch starts from this document.

Record every initial result, tool error, explicit correction, publication and failed candidate. Useful measures include:

- First-pass structural/reference validity and brief compliance.
- Corrections needed, failed tool arguments, orphan/unconnected stages and incorrect temporal conditions.
- Playable completion for every branch, with reset states and ordinary handlers.
- Provider requests, input/output tokens, tool calls, elapsed time and spending, including inspection/repair overhead.
- Independently reviewed narrative coherence and meaningful choice/consequence differentiation, separate from technical readiness.

Small tools may improve validity while worsening cost. Mermaid may improve branches without reducing calls. Copying the worked example may conceal poor independent authoring; separate reconstruction tasks from novel supported briefs. Count host-assisted repairs distinctly and retain exhausted failures. The criterion is better authoring outcomes for acceptable total effort, not fewer top-level parameters or a prettier diagram.

## Review requested

Please offer thoughts and review, especially on these questions:

1. Does separating conditions from transitions remove useful bookkeeping, or introduce too many IDs and calls?
2. What is the smallest builder surface that can express the fixed baseline without game-specific shortcuts or duplicating the runtime schema in tool arguments?
3. Should the existing graph remain the authoritative draft, or should a builder model compile it? How do we prevent competing mutable truths?
4. What must the Mermaid and readable detail view expose for accurate branch/timing reasoning? Which details would overwhelm it?
5. Is explicit ending declaration appropriate, and how should local incomplete-draft findings differ from publication blockers?
6. Should interaction guards apply to an entire choice stage, individual choices, or both? What simple authoring operations make that clear?
7. Which comparison arms and metrics would actually answer “is it easier for the LLM?” within a small agreed budget?
8. Is a guided question/available-action workflow worth testing, or should we first assess freeform small tools plus inspection?

CFW owns any subsequently agreed authoring/compiler/projection implementation. CAI reviews model-facing usability and retains prompt/tool/repair evidence. Rocket reviews world/capability semantics and playable equivalence. Reviewers should identify concrete missing operations or misleading representations without turning a bounded experiment into a broad editor or policy framework.

Related implemented references: [current prototype](QUEST-AUTHORING-PROTOTYPE.md), [raw-graph tool tutorial](QUEST-AGENT-TOOL-TUTORIAL.md), [worked technical guide](QUEST-AUTHORING-WATCHTOWER-GUIDE.md), [domain MCP provider](CFW-MCP-PROVIDER.md). These describe the comparison foundation, not a delivered builder.

## Discussion update and review findings, 14 October 2026

Julien also explored having the LLM write constrained Mermaid, with CFW compiling it and returning unknown-function diagnostics. That would introduce another authoring language: syntax, typed arguments, condition boundaries and consequence timing still need contracts. The current proposed starting point remains small authoring tools with CFW-generated Mermaid inspection. Mermaid input is a possible later alternative, not part of the first builder or an implemented compiler.

Reviews #479 (Steve) and #480 (Rocket) identify two concrete gaps in the proposed surface:

- **Local repair:** routes, choices and entry consequences need stable record IDs and a bounded replacement/removal path. Adding a corrected record must not leave the mistaken behavior executable. Choose narrow record edits or revision-checked collection setters before implementation; the choice is still open. Removing a referenced stage should reject and list references unless an explicit supported cascade was requested.
- **Shared conditions:** changing a reusable condition affects all references. Inspection must list those routes/choices, and a branch-only repair should copy and rebind. Stage-relative timing must bind to an explicit consuming stage; incompatible reuse is rejected rather than inventing unsupported cross-stage history. Exact mutation parameters and preview behavior remain design work.

Rocket's collected-fact terminology correction is incorporated above and independently checked against `World.ts`: delivery assigns `deliveredTo` without resetting `collected`. The current baseline also repeats the guide proximity predicate in dialogue requirements and both choice guards. A proposed stage-level interaction requirement must compile to all three checks; simplifying the authoring interface must not let either choice bypass proximity.

Both reviewers recommend deciding graph versus builder storage through a concrete baseline/reopen/local-repair round trip. Exact inspection should expose typed arguments/comparisons, fact versus event and its boundary, route priority, choice availability and ordered effects, with unavailable evidence shown as blocked. Short Mermaid labels can reference readable details from the same saved revision.

A proposed deterministic fidelity check would build the twelve-node baseline, reopen it, correct a wrong route and wrong beacon consequence, and verify publication equivalence under an explicit ID mapping. Existing branch and ordering controls remain the execution evidence. No new Rocket adapter work is currently identified. These are review findings and proposed constraints, not new implementation authority or completed builder tests.

The evaluation should keep builder and Mermaid effects distinguishable. Raw graph versus builder/readable inspection measures the tool surface; the same builder with versus without Mermaid measures the diagram contribution. Agree an affordable subset rather than infer a Mermaid benefit from changing both together. No live provider batch has started.

## Quality-first question and current execution bounds

Julien's follow-up (#482) makes the priority explicit: longer waits are acceptable for richer, coherent, interesting quests. The first comparison is the complete authoring experience: one large executable JSON submission versus progressive tools with Mermaid feedback. API completeness comes later. Tool usage and elapsed time can diagnose failures; speed alone must not decide the winner.

Rocket #483 and Steve #484 predict progressive authoring will better support larger branching quests and local revision, provided the model keeps a whole-quest plan and periodically inspects the saved whole. Neither has measured an independent storytelling-quality advantage. Both warn that a long chain of locally sensible edits can lose motivation, setup/payoff and meaningful consequences. Mermaid exposes topology and attached logic, not a reliable verdict on interesting dialogue or earned payoffs. Give both approaches room to plan and revise, and assess novel supported briefs separately from reconstruction. Completion/abandonment across all attempts and story quality must be reported separately.

Their execution-limit findings were independently checked read-only in the current CAI checkout:

- `QuestAuthor.php` declares `MaxSteps(16)` and `MaxTokens(2500)`. The installed SDK's `TextGenerationLoop.php` marks the final model step as exhausted and does not execute its requested tools. This allows at most fifteen tool-executing model responses in that invocation; one response may request multiple tools. It is not a universal limit of sixteen MCP calls. Sequential edits depending on returned revision/IDs generally need further model responses.
- OpenAI `BuildsTextRequests.php` maps the token option to `max_output_tokens`: the configured 2500 output tokens apply per request, not as an established aggregate job budget or model context ceiling. This may constrain a large JSON submission while the step bound constrains progressive operations. A quality comparison needs adequate allowances for both representations.
- `GenerateQuestAuthoringReport.php` invokes one prompt with a 120-second timeout; the SDK forwards it into generation steps. `ProcessQuestAuthoringJob.php` has a separate 1440-second job timeout and 300 queue tries, which are not 300 creative continuation rounds. Actual running worker/model/account constraints still need CAI confirmation.
- Persisted CFW drafts can be reopened, but the inspected CAI path is one prompt and skips completed/failed jobs. Automatic continuation after step exhaustion has not been established. Persistence alone is not a resumable authoring-job contract.

No limits were changed, no providers called, and no builder implemented during this review. The outstanding CAI response should confirm its intended runner and continuation behavior before an authoring experiment is configured.

### CAI confirmation and same-run context clarification

CAI #485 confirms the limits above and adds a 64-distinct-call journal bound per attempt in `PrepareGameToolCall.php`; context preflights use slots too. CFW's current prototype limits a fragment to sixteen situations and 12 KiB. Raising only model steps/output limits therefore does not establish long-arc capacity. These are current proof bounds to assess before a quality study, not inherent MCP restrictions. No settings were changed here.

CAI also predicts that whole-story planning plus progressive construction and critique is the more promising experience, without claiming measured better storytelling. Its current authoring context gathers the game/world/catalogue, brief and guide; a bound character ID does not automatically supply that NPC's profile or continuity. Relevant authored motives/lore should be supplied equally to both comparison arms. Authoring-job completion is also not proof of quest publication: score authoritative publication receipts and actual playable consequences separately.

The follow-up discussion #486–488 corrects “losing context”: successive tool calls in the same run do not inherently erase the earlier conversation. Independent SDK source inspection confirms assistant calls and tool results accumulate into subsequent model requests. Useful progress feedback can improve grounding in the actual saved design. The narrower possible failure is neglecting an earlier narrative intention despite it remaining available, which can also happen during whole-JSON authoring. Literal context overflow or host trimming has not been demonstrated in this experiment.

CFW can expose saved structure, prose and explicit recorded commitments. Deciding that a character's lie has an unsatisfying payoff is ordinarily the author's/reviewer's judgment; generated feedback should not pretend CFW is an omniscient story critic. No extra memory framework is implied by this clarification.

## Implemented authoring extensions

Following Julien's direct request to update the tools/docs, the local builder now closes the five identified expressiveness gaps: nested comparison output paths (legacy single `field` remains compatible), earlier-stage event boundaries with runtime dominance validation, separate shared interaction and individual choice conditions, typed references to acknowledged entry-action results, and optional objective records. See the [current22-tool contract and exact walkthrough](QUEST-BUILDER-TOOLS-WALKTHROUGH.md).

Incomplete drafts can save references before the full graph exists; review/publication blocks unavailable boundaries, bypassed/forward producers and incompatible declared result types using the existing runtime validator. Objectives display progress, without implicitly gating completion. Full201-test gate passes, including8 focused builder cases and an actual CFW runtime proof of result chaining/objective progress/both choice guards. The12-stage Watchtower still compiles equivalently. This extends the local authoring experiment, not the runtime format, game mechanics or deployed CAI/MCP interface.

## Registered domain implementation

Julien explicitly requested implementing/registering the concept and notifying CAI when ready. `QuestBuilderAuthoring`, exported from the existing authoring package entry, now exposes the22 builder operations plus catalogue-only discovery and command recovery through the existing CFW MCP provider. SQLite commits draft state, immutable publication/freeze marker and original mutation receipts together. Exact original command replay survives process restart; raw runtime graph reads are not granted. See [registered domain contract](QUEST-BUILDER-MCP.md) and [compact model guide](QUEST-BUILDER-MODEL-GUIDE.md).

The actual compiled Rocket generic host composes this domain with its world provider:25 tools, full63 builder steps through official SDK, exact baseline/digest/replay, zero game events. This is in-process HTTP transport, not a new deployed TCP endpoint or CAI/model/browser run. Full205 checks pass. Application-side fixture adoption, sufficient CAI runner allowances and provider spending remain separate owner responsibilities.
