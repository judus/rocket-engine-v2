# Local Quest and Dialogue Core

The shared runtime now has an optional narrative service. It implements the four initial contracts in process, with player offer choices, objective monitoring and a coordinated checkpoint envelope. The separate [MCP gateway](MCP-SERVER.md) now exposes it remotely. Optional [ordered stages and player branches](QUEST-FLOWS.md) are implemented. CAI foundation sessions/events are delivered, but live game turns/connector, rewards and general dialogue graphs remain pending.

```sh
npm run check
npm run demo:narrative
npm run demo:web
```

Open [the narrative demo](http://127.0.0.1:8093/demo/narrative.html). Create an offer, accept or decline as the player, confirm fake visits and exercise save/restore. The director's quest has two independent objectives. Demo checkpoints live in memory, not a database.

## Composition and updates

Pass `narrativeGame` to `CharacterRuntime` to install one shared `runtime.narrative`. The runtime advances and disposes it. `narrative.bind(characterHandle)` provides a small bound tool facade, not another quest engine.

```ts
const character = runtime.register({
  id: 'forester',
  name: 'Mara',
  capabilities: ['game_inspect_location'],
});
const narrative = runtime.narrative;
if (!narrative) throw new Error('Narrative game adapter required');
const tools = narrative.bind(character);
const reply = tools.call('inspect_context', { scope: 'local' });
runtime.advance(0.05);
const result = await reply;
```

Calls queue operations and return promises that resolve after host advancement commits them. Awaiting while withholding updates cannot complete a call. Identity comes from the bound registration, not tool arguments. Removed handles are rejected. The MCP gateway now handles HTTP authentication and bound transport sessions; CAI game-session ownership remains pending.

Narrative commands/inspections use a separate lane from reasoning, avoiding the model/tool dependency deadlock. Queued commands are capped at 64 and concurrent inspections at eight. Candidate objectives rotate across accepted quests. Providers and game adapters must return promptly and honor cancellation where possible.

## Definitions offers and choices

Create validates recipient, unique objective IDs, permitted inspection capabilities, arguments and semantic references, then registers a recipient-specific definition. It executes no objective and creates no offer.

Offer records dialogue plus accept/decline references. The host-authenticated player path is `narrative.choose(recipientRef, choiceId, effectKey)`. Acceptance activates monitoring; decline creates no active instance. The host authenticates the player; a supplied string alone is not authorization. Framework choices are distinct from CAI interaction choices.

Outstanding identical offers reuse their reference; changed dialogue conflicts. Resolved offers cannot be re-offered in this first model. Each definition has one declared recipient and at most one offer/instance.

The initial dialogue core is committed offer text, player choices and resulting narrative state. Optional stage dialogue and player quest branches are supported; conditional conversation entry routing and general conversation nodes remain extensions. See [the Zemegagame assessment](ZEMEGAGAME-REFERENCE.md).

## Progress from game facts

`NarrativeGame` supplies capabilities, context, recipient eligibility and reference checks. Conditions can only use trusted inspection capabilities. The framework monitors under the author's current scope and revalidates availability. Replies commit at a later host update.

Equals has no coercion; at_least requires numbers. Missing paths, wrong types, unavailable/running/failed inspection and absent authors become unknown. Satisfied objectives latch; later regression does not undo an accomplishment. Completion requires all objectives. Already true facts can satisfy a new accepted quest. Conditions requiring a new event after acceptance need a later baseline contract.

Inspect only reads committed state; host updates independently monitor active objectives. Prose never establishes a game fact. The core does not grant rewards or mutate inventory.

## Whole quests and small authoring steps

Submit a complete definition or use the local draft helper:

```ts
const draft = new QuestDraft(
  {
    recipientRef: 'player-1',
    title: 'Winter survey',
    summary: 'Explore the valley.',
  },
  [visitLocationTemplate],
);
draft.addStep('visit_location', { id: 'grove', locationRef: 'grove-1' });
draft.addStep('visit_location', { id: 'town', locationRef: 'river-town' });
const reply = tools.call(
  'create_quest',
  draft.toInput(),
  'logical-publication-key',
);
```

Templates are trusted injected functions with descriptions/schemas and their own argument validation. They turn small requests into validated objectives using real game mechanics. CAI could later discover draft/append/validate/publish tools using these templates. Contract 0.3 now adds scoped template discovery and pure caller-carried draft composition; see [incremental authoring](QUEST-AUTHORING.md).

Published definitions are detached and immutable. Editing the draft afterward cannot change an accepted quest. Objectives are independent requirements by default. An optional flow assigns them to ordered or branching stages; see [quest flows](QUEST-FLOWS.md).

## Binding identity and generation

Registration snapshots contain runtime-issued `binding.id` and `binding.generation` UUIDs. An explicit host restore may supply the previous identity; registration always issues a fresh generation. Persist identity alongside the character/session association. Reused character IDs are not durable binding identities. Concurrent registrations cannot share an identity or CAI session.

Narrative records/receipts include association, binding identity, character and CAI binding. Ordinary replacement gets a new identity and cannot consume retired receipts. Explicit restoration of the same identity/session can reconcile original effects. Old handles remain invalid.

The future connector must send the current generation before discovery, replay or execution, and explicit rebind must update trusted CAI metadata. Local handles enforce registration lifetime; the [MCP gateway](MCP-SERVER.md) now enforces it on the wire. See [the MCP handoff](MCP-CONTRACTS.md).

## Replay and checkpoints

Create/offer/player choice require stable logical effect keys. Canonical argument order does not change replay identity. Same scope/tool/key and arguments replay the original receipt; changed arguments conflict. Terminal mutation rejections are retained. Queue/disposal failures happen before execution and are not mutation receipts.

Save captures definitions, offers, progress, counters, receipts and pending feedback in one immutable JSON envelope at a safe boundary with no queued commands. It does not write to disk. The host must atomically persist it with game facts and character identities. This is an in-memory atomic mutation/receipt pair plus a checkpoint contract, not a database implementation.

Restore validates consistency before replacing state and invalidates outstanding observations. Old replies cannot complete restored quests. Noncooperative inspections retain their bounded slot until settlement. Promises/providers/physics resources are excluded. A new runtime must rebind restored characters; missing authors produce unknown progress. Rewinding a game with later CAI memories remains unsupported.

Events have stable IDs and framework_narrative origin. Replay emits no duplicate event. The 512-event queue reports overflow; it is not an acknowledged CAI outbox. A bridge must persist/ack delivery rather than assume draining means CAI received it. Retention caps are 256 quests and 4096 receipts; retirement policy is later work.

Narrative arguments are capped at 64 KiB serialized UTF-8 JSON and 32 object/array levels. Adapter validation remains authoritative over projected provider schemas. Checkpoints are trusted host data with structural consistency checks, not cryptographic tamper protection.

## Verification boundary

Tests exercise semantic tool calls against schema validation, player choices, unknown/numeric facts, canonical replay, binding replacement, invalid checkpoints and late observations. Demos use canned narrative and fake visits. They do not prove CAI, MCP isolation, game physics, production persistence or full branching dialogue behavior.

## Second host adapter

`examples/station-scenario.ts` exercises the same core against a small space-station host. Its `station_inspect_system` capability reads numerical efficiency rather than woodland visits. A mechanic offers an oxygen-loop repair quest; the host confirms a repair and the numeric condition completes it. Cross-game mechanics and inaccessible systems are rejected. This is a second fake adapter proof, not a Rocket/Godot implementation or an extra browser demo.

## Standalone authored dialogue

Contract0.5 extends the same narrative runtime with bounded authored DAG definitions and independently scoped player cursors, without dummy quest objectives. See [dialogue graphs](DIALOGUE-GRAPHS.md). The existing trusted player choose path, shared receipt budget, command queue and checkpoint boundary also apply to graphs; graph/quest/CAI choice identities remain separate. CAI transport is delivered in retained HTTP proofs; the new graph implementation awaits independent review and its own HTTP proof.
