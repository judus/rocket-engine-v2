# Dedicated background authoring jobs

CFW's `CaiHttpBackend` provides the small host-side client for CAI's delivered queued authoring API (CAI handoff372, source96750fa). It is separate from `CaiConversation` dialogue and does not load the Node SQLite authoring service into the browser bundle. Use this backend on the trusted server with a private association credential.

Use a dedicated director/authoring game session with a published binding and a persistent host-issued CFW author namespace. The game decides when to request work and how many completed definitions to keep in reserve. Sharing the session with NPC dialogue causes reservation contention.

## Submit and read

```ts
import { CaiHttpBackend } from 'character-framework/cai';

const backend = new CaiHttpBackend({
  origin: 'http://your-private-cai-server',
  token: privateAssociationToken,
  enableGameDraft: true,
});

// Persist the exact payload and UUID in the host's own checkpoint BEFORE calling.
const input = {
  request_id: '4de76355-254c-425a-9d86-e020223d28c9',
  version: authorSession.version,
  brief:
    'Read the catalogue and saved drafts. Publish one new grove visit, with no dialogue or reward. Do not activate gameplay.',
  authoring_guide: currentModelGuide,
};
const job = await backend.submitAuthoring(authorSession.id, input, signal);
// Persist returned job.id beside the original request. Poll only by that server ID.
const status = await backend.readAuthoringJob(authorSession.id, job.id, signal);

if (status.attemptRequestId !== null) {
  const attempt = await backend.readAttempt(
    authorSession,
    status.attemptRequestId,
    signal,
  );
  // Read exact retained calls as needed; these reads do not rerun the agent.
}
```

The examples' host variables and persistence are supplied by the game. This adapter does not implement a scheduler, durable host checkpoint or automatic polling/retry loop.

`submitAuthoring(sessionId, input, signal)` sends POST to `/api/v1/companion/sessions/{session}/quest-authoring-jobs`. The input is captured before dispatch, closed-field validated, bounded to64KiB, and preserves the caller's strings and UUID. Brief is nonblank and at most8000 Unicode code points; optional guide permits empty text and at most16000. Omission is accepted and CAI normalizes it to empty. New admission201 and exact replay200 use the same decoded result shape.

`readAuthoringJob(sessionId, jobId, signal)` sends one GET to that collection plus `/{job UUID}`. No GET collection-list contract is assumed; the maintained controller/routes currently expose single-job reads. The decoder checks session/job/request correlation, admission version, binding generation, state and scalar fields. Readonly results expose camel-case names:

| Field                                       | Meaning                                                                                       |
| ------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `id`                                        | Server job UUID; persist after admission.                                                     |
| `requestId`                                 | Original caller idempotency UUID, distinct from server job ID.                                |
| `sessionId`, `version`, `bindingGeneration` | Original dedicated-session admission snapshot.                                                |
| `status`                                    | `queued`, `running`, `finished`, or `failed`.                                                 |
| `report`, `failureCode`                     | Nullable agent prose and safe domain failure reason; no quest payload.                        |
| `attemptRequestId`                          | Null before an attempt is allocated; otherwise the server job UUID for private receipt reads. |
| `createdAt`, `startedAt`, `finishedAt`      | Backend timestamps; nullable start/finish values.                                             |

## Recovery and authority

After a lost submission response, retain the original UUID and payload. An explicit exact replay can recover the same job/status. Do not allocate a replacement request because a network acknowledgment is missing. The adapter makes no automatic retries. `CaiHttpError.status` retains HTTP status without echoing the response body or private credential; the current client does not expose domain error codes. A409 must not be guessed to mean busy rather than conflict, stale version or missing binding.

CAI allows one queued/running job or unresolved reserved attempt per session; it owns busy/conflict/authority checks and queue recovery. No automatic cross-generation or uncertain external-call reconciliation is provided. Inspect retained attempt/call receipts before replacing uncertain work. The caller's request UUID is **not** the private receipt selector; use `attemptRequestId` from the job.

`finished` means the dedicated agent completed with known tool outcomes. It does not prove publication, human approval, runtime activation or gameplay completion. The successful non-dialogue attempt is sealed as `interrupted` in CAI's journal because no character turn exists; this can accompany a finished job. CFW's stored draft/publication remains authoritative. The game separately loads the stored definition, imports, starts and advances it.

## Correlate a job with stored publications

When an author namespace contains several drafts, do not select the latest publication or extract an ID from the agent's report. The existing exact tool receipts provide the future host integration path:

1. Read the owned job by its server ID. Use its nonnull `attemptRequestId` with `readAttempt`, following `nextCursor` until all call summaries are read. Preserve the attempt's binding identity and original call IDs.
2. Select the original discovered `publish_quest_draft` calls, not the provider's alias or prose. Read each exact call through `readCall(sessionId, attemptRequestId, callId)`. Only `state:"resolved"` with `outcome_kind:"mcp_result"` supplies a terminal MCP result. A resolved call can still contain a rejected tool outcome.
3. For the current prototype, a successful publication result is in `detail.result.structuredContent`, with `status:"completed"` and `data:{draftId,definitionId,definitionDigest,sourceRevision,commandId,...}`. Check that `draftId` matches the call's exact `arguments.draftId`, and retain the definition/source/command identity alongside the original call and job IDs. Validate that result against this delivered tool contract before use; a generic MCP-envelope decoder alone does not validate publication fields.
4. Read the identified draft's `publications` section in the same host-author namespace. Confirm the immutable definition ID, stored digest and source revision against the publication receipt. The host-only `readPublishedDefinition(definitionId)` loads that exact definition for import; it does not itself return source metadata. `get_authoring_command_outcome({commandId})` can also read the original CFW terminal result while its receipt is retained. The game owns this authoritative store access and any later import/start.

These receipts identify publications successfully returned during that attempt. Repeating publication of an already published draft can return the existing definition, so this evidence does not mean the job created a new publication. Deduplicate repeated receipts by immutable definition identity; retain multiple distinct publications if the attempt actually returned them. A finished job with no successful publication receipt has no evidenced publication for this path. Unknown/in-flight calls, expired/missing evidence or mismatched source identity must stay uncertain; neither report text nor a new submission key resolves them.

This is a documented existing correlation path, not a new scheduler, publication inventory or automatic recovery implementation. It follows `CaiCallDetail.result` from the receipt decoder, the gateway's structured MCP envelope, and the prototype's publication/source fields. Rocket's current static-import proof needs no checkpoint layer or187 repin.

## Evidence

CFW focused HTTP regressions cover lost-ack exact replay, read-only status transitions, server/caller identity separation, captured input correlation, invalid payload/results and private conflict errors. CAI reports actual authenticated HTTP admission, a separately started database queue worker, real TCP MCP/CFW SQLite, receipts/status correlation and separate new-entry completion, with only provider HTTP faked. Maintained request/controller/worker sources and handoff were read-only reviewed by CFW; its PHP suite and queue proof are CAI-owned evidence, not rerun by this client work.

CFW's full187 gate and exact packaged client tests pass. CAI374 independently consumed the exact187 adapter against its preserved actual HTTP job: finished status decoded, original-payload submission replay returned the same job, session/attempt decoding confirmed a non-dialogue interrupted journal with continuation allowed and unchanged version, and all five resolved call-detail envelopes decoded. No provider rerun, new draft, publication or activation occurred. CFW inspected the maintained sanitized handoff and matching assessment flags read-only. The thin client is accepted; a durable host checkpoint/scheduler has not been implemented by this result.

No paid provider call, deployment, peer project write or Rocket repin is required to add this client. Existing accepted185 Rocket package/proof stays pinned until a coherent consumer need warrants an upgrade. Long-arc quality, durable game-world storage and full production recovery remain separate work.
