# Initial MCP Tool Contracts

Contract version 0.3, 13 October 2026. The four domain operations and character-scoped HTTP MCP transport now have local implementations. See [MCP-SERVER.md](MCP-SERVER.md) for executable connection details and fake-client proofs. CAI game integration remains pending. It supplies the four initial tools plus two pure authoring tools, character/session binding, narrative semantics and examples for a forester and an unseen director. Existing Phase 0 runtime types are local scaffolding; they are not these external contracts.

Start here when reviewing the integration. [Tool schemas](contracts/tools.json) contain complete input/output JSON Schemas and discovery descriptions. [Examples](contracts/examples.json) contain sixteen calls/results: one successful and one rejected call for each tool, for each character. The examples are fictional fixtures, not live API results. `npm run contracts:check` validates fixture structure. The full gate now also exercises local semantic execution through the narrative core; it still does not prove external MCP/CAI integration. See [NARRATIVE.md](NARRATIVE.md).

## Ownership and first scope

The framework owns quest definitions, offers, player quest instances, dialogue choices and progression. CAI generates content and remembers interactions in the bound session. The game provides facts and mechanics through its available MCP capabilities. No CAI standalone quest run or inventory mutation is used.

For the first proof, create one complete quest definition with one to eight objectives. Without a flow, all objectives must be satisfied to complete an accepted instance. Optional [quest flows](QUEST-FLOWS.md) allow ordered stages and player-selected branches. Conditions reference permitted game inspection capabilities, never arbitrary executable code. Offering returns accept/decline choices. Rewards, autonomous movement and general dialogue-tree authoring come later. This deliberately small vocabulary is a foundation for a universal runtime, not the final narrative model.

The same four framework tools serve embodied and disembodied characters. The supplied inspection/action capabilities differ by game and character role. MCP is the transport boundary; core simulation still runs under its host update loop.

## Bind every request outside model arguments

Use one combined endpoint per game association, such as a configured `/mcp` path. CAI's trusted connector authenticates with a framework-side service credential. That credential identifies the game association; it is separate from the game's credential used to call CAI. Both secrets remain server-side. Initial provisioning can be development configuration; no new provisioning API is prescribed here.

Proposed application headers on every bound HTTP MCP request:

```http
Authorization: Bearer <framework-association-key>
X-CF-Binding-Key: forester/workforce-17
X-CF-CAI-Session-Id: 81
X-CF-Binding-Generation: <runtime-issued-generation>
```

For `tools/call`, also send:

```http
X-CF-Turn-Request-Id: c9b1c36e-d3f7-49bb-8ad2-1bc85a1a073c
X-CF-Call-Id: call-forester-create-1
X-CF-Effect-Key: forester-story-1-create
```

The effect key is required for `create_quest`, `offer_quest` and any exposed game action. Inspection calls need no effect key. Headers are our proposed application convention, not MCP standard fields. Use normal MCP initialization/version negotiation, transport headers and lifecycle as supported by the agreed SDK. A protocol `Mcp-Session-Id`, where used, is not the CAI conversation session ID.

The framework resolves credential association + binding key + CAI session ID to a current registered character. The association, binding key, CAI session and generation must all match its stored binding before discovery, receipt replay or execution. Do not accept `characterRef`, association IDs or session IDs in tool arguments as a way to switch identity. The connector copies selectors from the authorized CAI session, never from model-generated context. Binding keys are opaque character-instance references; they need not identify a body.

Discovery (`tools/list`) and calls use the same binding. Do not cache character-scoped discovery as one global association catalogue, or change shared mutable headers while requests overlap. Separate immutable request contexts can share one endpoint/transport implementation. Removal or binding replacement invalidates old calls; the adapter needs a registration generation in its stored binding, not merely an ID lookup that can attach old work to a new character.

For missing/invalid credentials or mismatched bindings, reject at the transport boundary before exposing tools or executing anything. Domain rejection results below apply only after a valid binding. Even a model that guesses another quest or entity reference cannot acquire access through the arguments.

Please confirm with CAI whether its intended SDK connector can supply these per-request headers and isolate discovery this way. If it needs metadata or separate bound client handles instead, keep the same identity semantics; header spelling is negotiable.

## Example bindings and game capabilities

| Framework character | Binding key           | CAI character | CAI session | Physical entity | Context                            |
| ------------------- | --------------------- | ------------- | ----------- | --------------- | ---------------------------------- |
| forester            | forester/workforce-17 | 42            | 81          | workforce-17    | Local forester/player interaction  |
| director            | director/main-story   | 43            | 82          | None            | Broader world narrative inspection |

These CAI IDs are illustrative numeric IDs, serialized as strings in HTTP headers/fixtures. The forester may inspect local context and author/offer its own quests. The director may inspect world context and author/offer its own quests without a position. Broader inspection does not imply unrestricted private data, rewards or spawning.

The fictional game exposes `game_inspect_location({ playerRef, locationRef })`, returning confirmed data such as `{ visited: true }`. The forester may reference the Old Grove (`grove-1`); the director may additionally reference River Town (`river-town`). The game determines which references and facts each character can access. The combined endpoint also discovers available game tools with their own schemas; the four framework tools are a fixed initial narrative surface, not the entire catalogue.

The Phase 0 fake tools (`inspect_nearby`, `inspect_world`, `request_work`) are demonstrations, not implementations of these new contracts.

## Tool results and MCP envelope

All four initial tools return only `completed` or `rejected` domain results. `completed` means the stated inspection or framework operation committed. It does not mean the quest is complete, the offer was accepted or a physical action succeeded.

The proposed MCP result carries the domain object as `structuredContent`, plus its identical serialized JSON in one text content block for compatible clients. Set `isError: false` for completed results and `isError: true` for rejected results so CAI can correct its request. These fields follow the [MCP tools specification](https://modelcontextprotocol.io/specification/2025-11-25/server/tools); the domain statuses and schemas are our proposal.

For example, the `create_quest` domain result is:

```json
{
  "status": "completed",
  "data": {
    "questId": "quest-17",
    "authorRef": "forester",
    "revision": 1,
    "status": "registered"
  }
}
```

Wrap that object in MCP's result envelope. A tool's `outputSchema` describes the domain object, not the outer JSON-RPC response. Protocol/transport failures are distinct from these structured tool rejections.

Do not return Phase 0's immediate `Admission.accepted` as a completed tool effect. The MCP adapter queues a host operation and waits for its committed receipt at a safe update boundary. The four operations do not require long-running physical work or MCP task extensions. If a request times out, the effect is unknown until reconciled; timeout does not prove it was rejected. Later movement tools may return accepted/running references and need a separate status/cancellation contract.

## inspect_context

Input: required `scope` (`local` or `world`) and optional `entityRefs` (at most sixteen). Output: bound character/role/entity, scope, observation revision, bounded facts/entities, available game capability descriptors and `truncated`.

The revision identifies this observation, not a global optimistic-lock requirement for every command. The game revalidates relevant facts when actions commit. Results contain no credentials or other characters' CAI session histories.

- Forester success: `{ "scope": "local" }` returns the Old Grove, player and a location-inspection capability.
- Forester rejection: `{ "scope": "world" }` returns `scope_denied`.
- Director success: `{ "scope": "world" }` includes River Town without requiring a body.
- Director rejection: requesting a private/unavailable entity returns `entity_unavailable` without distinguishing nonexistent from inaccessible records.

Full results are in the corresponding `*-inspect-*` fixtures. Future context pagination can extend this contract; initially `truncated` is explicit and an entity-filtered request can narrow the result.

## create_quest

Input: a complete `quest` with a declared `recipientRef`, title, summary and objectives. The first definition targets one known recipient; reusable recipient templates are a later extension. Each objective has a unique local ID, description and condition:

```json
{
  "quest": {
    "recipientRef": "player-1",
    "title": "Survey the Old Grove",
    "summary": "Discover the grove's winter story.",
    "objectives": [
      {
        "id": "visit",
        "description": "Visit the Old Grove.",
        "condition": {
          "tool": "game_inspect_location",
          "arguments": { "playerRef": "player-1", "locationRef": "grove-1" },
          "expect": { "path": ["visited"], "operator": "equals", "value": true }
        }
      }
    ]
  }
}
```

The framework validates the condition tool against the character's installed inspection capabilities and validates its arguments against the discovered game schema. It checks accessible entity references and unique objective IDs. A tool's inspection/action classification is assigned by trusted framework/game registration, not accepted solely from untrusted discovery annotations. This tool cannot execute an action as a condition or accept arbitrary scripts.

`expect.path` addresses the inspection result's domain `data`, using object-property segments. Missing fields, pending facts, failed inspection or invalid types mean unknown, not satisfied. `equals` compares primitive values without coercion. `at_least` requires numeric observed/expected values. These initial conditions describe current state, so an already true fact may satisfy an objective on acceptance. Conditions requiring a new event after acceptance need a later baseline/event contract. Actual objective monitoring occurs for an accepted instance through framework scheduling and authoritative game results, not as a side effect of creating or inspecting the quest.

Success registers a definition and returns stable `questId`, author reference and revision. It creates no offer or player instance. Identical titles may exist; title is not identity. This first contract permits characters to author their own definitions; cross-character ownership transfer remains later work.

Forester/director successful examples differ in locations and story context, not narrative schema. Both rejected examples use an action as an objective condition and receive `invalid_condition` with a JSON-pointer issue path. Structural invalidity returns `invalid_arguments`; semantic failures use specific codes and issue paths. Registration is atomic: a rejected definition leaves no partial quest.

## offer_quest

Input: accessible `questId`, eligible `recipientRef` and offer `dialogue`. First-version eligibility requires the quest be authored by the bound character and the recipient match the definition's declared recipient and be permitted in current context. A different recipient returns `recipient_mismatch`. Forester offers appear in its dialogue; director offers can appear as a narrator/system presentation without a visible NPC.

Success records a framework offer and returns `offerId`, revision, dialogue and accept/decline choice references. It does not make the player accept, activate objectives or grant anything. Speaking an offer without this committed tool result is only dialogue. The player UI presents the committed offer text; CAI may add a reply but must not silently change the committed terms.

Both role examples offer to `player-1`; both rejected examples target an unavailable recipient and receive `recipient_unavailable`. No partial offer is recorded. An existing outstanding offer for the same definition/recipient is reused instead of duplicated. A different proposed text for that outstanding offer returns `offer_conflict`; editing offers is not included yet.

The player selects the returned framework choice through the game's framework integration, not by CAI executing a choice on their behalf. Choice IDs are framework references, not automatically CAI `choice_id`/`choice_turn_id` values; mapping between them requires explicit integration. Acceptance creates one recipient quest instance. Decline marks the offer declined. First-version re-offering after decline/completion is rejected; a new continuation should use a new definition. The four CAI tools do not constitute the player's accept/decline API.

## inspect_quest

Input: accessible `questId` and optional `recipientRef`. Without a recipient, return the registered definition projection: pending objectives, null recipient and no player choices. With a recipient, return that offer/instance's status, authoritative objective progress and available accept/decline choices while offered. An eligible recipient without an offer gets registered/pending state; no offer is created.

Only framework-confirmed progress is reported. `unknown` remains visible when a condition cannot currently be evaluated. Inspection does not award anything, evaluate conditions through action tools or change state. `revision` is the returned projection revision; it need not match a CAI session version.

The successful fixtures for both roles show a completed recipient instance after the player accepted and the game confirmed the visit. Their stated precondition is essential; earlier create/offer examples alone cannot produce completion. Unavailable quests return `quest_unavailable` without exposing whether they exist in another character's context.

## Correlation retries and host commits

X-CF-Call-Id identifies one logical connector invocation and stays constant across HTTP retries; a transport-attempt ID can differ separately. The connector persists that call ID, canonical arguments, binding/generation, parent turn ID and a generated opaque effect key before each logical mutation. It must retain that key across uncertain network retries and reconcile a failed overall turn before attempting the same effect again. Keys are not generated fresh on every HTTP attempt, inferred from dialogue text or replaced by MCP JSON-RPC IDs.

Scope receipts by game association + persistent character binding identity + tool name + effect key. The local core also verifies character/CAI binding, so a replacement cannot consume another identity's receipts. Compare canonical validated arguments: identical replay returns the original result; different arguments return `effect_key_conflict`. Persist receipt and narrative mutation together at the host's safe commit boundary. Keep receipts for the retained quest/offer lifetime and coordinated saves; removal of a live registration does not itself erase committed narrative receipts. No TTL-based replay guarantee is introduced in this first contract.

Store terminal rejection receipts too; a corrected or intentionally new attempt uses a new key. The HTTP gateway treats argument-limit and receipt-capacity failures as JSON-RPC admission errors with `admitted: false`, not terminal domain rejections. They consume no effect key and execute no invocation; corrected input may use the unconsumed key. See [admission details](MCP-SERVER.md#admission-errors-and-terminal-rejections). If the host is unavailable before accepting work, return a transport/service failure instead of inventing a permanent rejection. If the mutation commits and the CAI turn later fails, the quest/offer remains committed. CAI's turn failure is not a rollback command. Exactly-once provider execution is not promised.

On unknown outcomes, retry the identical mutation with its retained key or inspect a known quest reference. Do not regenerate a turn with fresh effect keys until previous tool effects are reconciled. Adopt CAI's reviewed first policy: reconcile prepared calls from its durable journal, preserve original terminal MCP envelopes separately from dialogue commits, and do not automatically rerun a failed externally mutating turn with fresh effect keys. After reconciliation, an explicit continuation can reason from known effects. A turn ID plus changing tool-call ordinal alone is insufficient. The CAI read envelope for incomplete-turn receipts remains to agree.

The local narrative service now keeps mutation receipts with its save envelope; the host must persist that envelope atomically. Phase 0 request IDs and bounded events alone do not satisfy this requirement. The transport and gateway effect receipts are implemented; the CAI turn/tool journal remains absent. A tool adapter must not await the runtime's currently pending reasoning job while sharing its only scheduler slot: external calls made during that reasoning require a separate capability execution lane or reserved capacity. The local narrative service has a separate command/inspection lane and is advanced by the shared runtime. The server uses this service and a separate game-tool lane rather than waiting behind reasoning slots.

## Typed feedback examples

Use CAI's proposed per-session event route, not ordinary player chat. Nothing below exists as a working route yet. Reports do not request another model reply; a later explicit turn can react using the resulting session version.

Framework quest progress/completion:

```json
{
  "event_id": "396a54d6-fc2f-41c3-9ff1-601fa6ccdd17",
  "version": 3,
  "origin": "framework_narrative",
  "type": "quest_completed",
  "summary": "The player completed Mara's Old Grove survey.",
  "references": { "quest_id": "quest-17", "recipient_ref": "player-1" }
}
```

Confirmed world fact:

```json
{
  "event_id": "36d7e3d2-c144-41aa-b23f-3d3a484b1644",
  "version": 4,
  "origin": "game_outcome",
  "type": "location_visited",
  "summary": "The game confirmed that the player visited the Old Grove.",
  "references": { "player_ref": "player-1", "location_ref": "grove-1" }
}
```

Versions are illustrative; obtain the actual current CAI session version and serialize writes per session. Stable event IDs prevent replay from repeating effects. Typical first narrative reports are `quest_offered`, `quest_accepted`, `quest_declined`, `quest_progressed` and `quest_completed`. Send narrative reports to involved character sessions; a director does not automatically receive every NPC's private dialogue or memories. The framework chooses what narrative history it shares with that role.

Player speech uses `player_dialogue` turns. Initial authoring and director reasoning use `framework_request` turns. A game outcome may inform the story without being evaluated as player speech. CAI should echo committed tool references/outcomes in its existing turn envelope where useful, not invent a competing quest-result schema.

## Binding generation handoff

The runtime issues `binding.id` and `binding.generation` in `CharacterHandle.snapshot()`. Registering a fresh character gives a new identity and generation. Explicit host restore can supply the previous identity, but always receives a new generation. Host development configuration maps the opaque binding key to that identity, CAI session and current generation; no public provisioning API exists yet.

An explicit rebind must update CAI's authorized connector metadata and invalidate old discovery/pending calls. Old-generation calls must fail before receipt lookup. Reconciliation after an agreed restoration retains the original persistent identity/effect key under the new authorized generation; an unrelated replacement uses a new identity and cannot consume old receipts. Persist identity separately from the reusable binding-key string. These are bridge requirements; the local handle implements lifetime checks, not HTTP authentication.

## CAI review incorporated

[CAI's response](/home/maduser/workspace/companion-ai/companion-ai-next/docs/character-framework-response.md) accepts the model and confirms header/raw-result support in its installed client. Its SDK may simplify recursive argument schemas, so full framework validation and 64 KiB/32-level argument bounds remain authoritative. Canonical condition tool names must not acquire provider alias prefixes. Persist raw structuredContent/isError results before model-facing text conversion. The framework server now implements its side; CAI connector features remain pending.

## Remaining review questions for CAI

1. Can the connector bind discovery and calls to these per-request selectors, without exposing them to model arguments or cross-contaminating concurrent sessions?
2. Can tool results preserve the `structuredContent` envelope, rejection reasons and committed references in turn history?
3. How will effect keys/receipts be retained across a failed turn and any subsequent model rerun?
4. Does an explicit `framework_request` after side-effect-free session creation fit initial quest authoring for both roles?
5. Can the proposed event route retain typed outcomes separately from player evaluation, with returned versions usable by subsequent turns?

Header details, limits and the first condition vocabulary are reviewable proposals. The four discovered schemas belong to the framework; CAI need only connect, validate tool responses and preserve session/origin/correlation semantics. No message is sent to another chat automatically by creating this handoff.

## Incremental authoring addition

Contract 0.3 adds pure `inspect_quest_templates` and `compose_quest_draft` tools. See [the authoring workflow](QUEST-AUTHORING.md), machine-readable discovery and authoring examples. These require binding/call headers but no effect key, shared draft state or new CAI endpoint. `create_quest` remains the publication mutation. Existing contracts and checkpoints remain compatible.

## Contract0.4 offering access

The catalogue now includes eight narrative tools. inspect_offering_access is read-only; set_offering_access is a scoped mutation with policy CAS revision and explicit same-author/recipient quest exceptions. It applies to future offer commitments, preserving outstanding/accepted work and game eligibility. See OFFERING-ACCESS.md and the updated role examples for checkpoint/source ordering and bounds.

## Contract0.5 authored dialogue

The catalogue now has eleven narrative tools. create_dialogue_graph and start_dialogue_graph are effect-key mutations; inspect_dialogue_graph is explicitly read-only and returns only the committed current node. All have full input/result schemas and forester/director completed/rejected examples. Host-authenticated player selection remains outside model discovery. See [authored graphs](DIALOGUE-GRAPHS.md) for bounds, ownership, checkpoint and retained source semantics.
