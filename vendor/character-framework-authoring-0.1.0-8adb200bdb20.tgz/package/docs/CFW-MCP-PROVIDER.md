# CFW domain provider for an application-owned MCP host

`CfwMcpProvider` is exported from `character-framework/mcp`. It contains CFW character grants, narrative dispatch, capability validation, the host-driven tool lane and scoped effect receipts. It creates no HTTP server, credentials, SDK transport or protocol sessions. Rocket owns its independent host service; applications compose and dispose providers.

The existing `McpGateway` remains a compatible standalone HTTP facade over the same provider implementation. Existing clients retain schemas, envelopes, binding/call/turn/effect headers and receipt scopes. A game-only Rocket host does not need this provider or CFW installed.

```ts
const provider = new CfwMcpProvider({ runtime, id: 'cfw' });
const headers = provider.bind('author', authorHandle, authoring.tools, [
  'cfw',
  'watchtower-world',
]);
// Configure Rocket's host using its own transport/auth options:
// resolveBinding: request => provider.resolveBinding(request)
// Register provider and the separate game-owned world provider.
```

`bind` is trusted application provisioning. Every CFW capability must be explicitly granted to the registered CharacterHandle and have a unique name. Other provider IDs are selected by the application; they do not grant additional CFW capability execution. Catalogue declarations likewise do not grant direct world-inspection calls.

`resolveBinding(request)` checks the established `X-CF-Binding-Key`, `X-CF-CAI-Session-Id` and `X-CF-Binding-Generation` against live CFW state. Call it after the host authenticates transport. It returns a cached opaque binding (`scope`, `providers`, metadata, `isCurrent`) or null. Return/pass that exact object; do not clone it or append provider names after provisioning. The host remains independent of these identities and may use a different resolver for game-only applications.

The provider exposes `id`, `tools(binding)` and `call(name,args,{binding,headers,signal})`, structurally matching Rocket's neutral provider seam. Calls require unchanged `X-CF-Call-Id` and `X-CF-Turn-Request-Id`, plus `X-CF-Effect-Key` for mutations. Its result is the existing MCP content/structuredContent envelope. Exact replay returns the original terminal receipt; changed arguments conflict; unresolved outcomes require reconciliation. Binding is checked again before dispatch and after completion. Aborted/stale responses do not imply that admitted mutations never committed.

Applications call `provider.advance(seconds)` alongside `runtime.advance(seconds)` in their existing update boundary. No new simulation clock or scheduler is introduced. The provider's lane prevents a pending reasoning turn from blocking its own tools. Applications own provider disposal, authoring storage and runtime disposal independently. `provider.dispose()` invalidates bindings and aborts queued tool contexts without disposing the runtime. Host unregister invalidates protocol sessions; it must not silently double-dispose domain state.

`saveReceipts()` requires quiescent effects and lane. Restore to the same association with `restoreReceipts(value)` before reconnecting clients; the generic host must enforce its own session shutdown barrier. Receipt restoration never restores SDK sessions or implies process-crash exactly-once execution. The compatibility gateway retains its existing no-open-connections restore guard.

The worked [watchtower guide](QUEST-AUTHORING-WATCHTOWER-GUIDE.md) and fixed [example](contracts/watchtower-authoring-example.json) use the current authoring contract. Rocket's live world summary is separate from the CFW capability catalogue. Generated publication must be correlated through its exact authoritative receipt/definition digest before the application separately imports/starts it. Guide validation and provider transport do not establish AI quest quality.
