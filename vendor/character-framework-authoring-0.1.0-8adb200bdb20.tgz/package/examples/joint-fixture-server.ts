import { randomBytes } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import { createJointFixture } from './joint-fixture.js';
import { createMcpHttpServer } from './mcp-http.js';

const port = Number(process.env['CF_PROOF_PORT'] ?? 8096);
if (!Number.isSafeInteger(port) || ![8096, 8097].includes(port))
  throw new Error('Unsupported proof port');
const authority = `127.0.0.1:${String(port)}`;
const externalHost = process.env['CF_PROOF_ALLOWED_HOST'];
const listenIp = process.env['CF_PROOF_LISTEN_IP'] ?? '127.0.0.1';
if (listenIp !== '127.0.0.1' && listenIp !== '172.28.0.1')
  throw new Error('Unsupported proof listen IP');
if (listenIp !== '127.0.0.1' && !externalHost)
  throw new Error('Explicit CF_PROOF_ALLOWED_HOST required for Sail routing');
const credential =
  process.env['CF_PROOF_KEY'] ?? randomBytes(32).toString('hex');
const fixture = createJointFixture(credential, [
  authority,
  ...(externalHost ? [externalHost] : []),
]);
const server = createMcpHttpServer(fixture, externalHost ?? authority);
const configPath =
  process.env['CF_PROOF_CONFIG_PATH'] ??
  `/tmp/cfw-joint-${randomBytes(6).toString('hex')}.json`;
await writeFile(
  configPath,
  JSON.stringify({
    url: `http://${externalHost ?? authority}/mcp`,
    controlUrl: `http://${externalHost ?? authority}/fixture`,
    credential,
    bindingKey: 'forester/workforce-17',
  }),
  { flag: 'wx', mode: 0o600 },
);
const timer = setInterval(fixture.advance, 10);
server.listen(port, listenIp, () => {
  console.log(
    `Disposable CFW proof fixture on port${String(port)}. Private config: ${configPath}`,
  );
});
const stop = () => {
  clearInterval(timer);
  server.close();
  void fixture.dispose().catch(() => {
    process.exitCode = 1;
  });
};
process.once('SIGINT', stop);
process.once('SIGTERM', stop);
server.on('error', () => {
  console.error('Joint fixture failed to listen');
  process.exitCode = 1;
  stop();
});
