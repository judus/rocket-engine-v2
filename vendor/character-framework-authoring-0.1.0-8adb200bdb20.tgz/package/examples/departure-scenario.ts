import { CharacterRuntime } from '../src/index.js';
import type {
  Capability,
  CapabilityResult,
  Invocation,
  Json,
  NarrativeGame,
} from '../src/index.js';
import { McpGateway } from '../src/mcp/index.js';
import type { CaiFeedback } from '../src/cai/types.js';
import { immutable } from '../src/json.js';

type Status = 'moving' | 'blocked' | 'arrived' | 'unreachable' | 'cancelled';
export interface Operation {
  readonly id: string;
  readonly mutationId: string;
  readonly target: string;
  readonly generation: string;
  status: Status;
}
/** Volatile fake game adapter for the reviewed admission/outcome seam, not navigation. */
export function createDepartureScenario(
  credential: string,
  options: {
    readonly capabilities?: readonly Capability[];
    readonly narrativeGame?: NarrativeGame;
  } = {},
) {
  const operations = new Map<string, Operation>();
  const sources: CaiFeedback[] = [];
  let active: Operation | undefined;
  let retired = false;
  let starts = 0;
  let handingOff = false;
  const reject = (code: string): CapabilityResult => ({
    status: 'rejected',
    code,
    message: code,
  });
  const target = (input: Json): string | undefined =>
    input !== null &&
    typeof input === 'object' &&
    !Array.isArray(input) &&
    Object.keys(input).length === 1 &&
    typeof input['destination_ref'] === 'string'
      ? input['destination_ref']
      : undefined;
  const action: Capability = {
    name: 'game_submit_departure',
    kind: 'action',
    description:
      'Admit departure to an eligible authored destination. Running is not physical arrival.',
    inputSchema: {
      type: 'object',
      properties: { destination_ref: { type: 'string' } },
      required: ['destination_ref'],
      additionalProperties: false,
    },
    validate: (input) => target(input) !== undefined,
    execute(context: Invocation, input: Json): CapabilityResult {
      if (!context.mutation) return reject('missing_mutation_identity');
      if (retired) return reject('retired_actor');
      if (!context.character.binding) return reject('missing_binding');
      const destination = target(input);
      const previous = operations.get(context.mutation.id);
      if (previous)
        return previous.target === destination
          ? { status: 'running', operationId: previous.id }
          : reject('operation_conflict');
      if (destination !== 'gate') return reject('destination_unavailable');
      if (active) return reject('actor_busy');
      if (sources.length) return reject('feedback_pending');
      if (operations.size >= 128) return reject('operation_capacity');
      const operation: Operation = {
        id: crypto.randomUUID(),
        mutationId: context.mutation.id,
        target: destination,
        generation: context.character.binding.generation,
        status: 'moving',
      };
      operations.set(operation.mutationId, operation);
      active = operation;
      starts++;
      return { status: 'running', operationId: operation.id };
    },
  };
  const capabilities = [action, ...(options.capabilities ?? [])];
  const runtime = new CharacterRuntime({
    gameId: 'departure-proof',
    capabilities,
    ...(options.narrativeGame ? { narrativeGame: options.narrativeGame } : {}),
    reasoning: {
      decide: () => ({ dialogue: 'Canned departure proposal only.' }),
    },
  });
  const character = runtime.register({
    id: 'mara',
    name: 'Mara',
    entityId: 'worker-17',
    cai: { characterId: 'canned-profile', sessionId: 'canned-session' },
    capabilities: capabilities.map((capability) => capability.name),
  });
  const gateway = new McpGateway({
    runtime,
    credential,
    allowedHosts: ['127.0.0.1:8094'],
  });
  const headers = gateway.bind('mara', character, capabilities);
  const settle = (status: Status) => {
    if (!active || retired) return;
    character.snapshot();
    active.status = status;
    if (status === 'moving' || status === 'blocked') return;
    sources.push(
      immutable({
        sourceId: 'departure/' + active.id + '/terminal',
        origin: 'game_outcome',
        type: 'departure_' + status,
        summary:
          status === 'arrived'
            ? 'Fake host confirmed Mara arrived at the gate.'
            : 'Fake host departure ended: ' + status + '.',
        references: {
          operation_id: active.id,
          actor_ref: 'worker-17',
          destination_ref: active.target,
        },
      }),
    );
    active = undefined;
  };
  const retire = () => {
    if (retired) return;
    settle('cancelled');
    retired = true;
    character.unregister();
  };
  return {
    runtime,
    gateway,
    character,
    headers,
    action,
    advance: (seconds = 0) => {
      runtime.advance(seconds);
      gateway.advance(seconds);
    },
    // Host-owned outcome injection, never a model tool or presentation command.
    settle,
    retire,
    snapshot: () =>
      immutable({
        starts,
        retainedOperations: operations.size,
        status: active?.status ?? null,
        sources,
        operations: [...operations.values()],
        reconciliationRequired: retired && sources.length > 0,
      }),
    async handoff(
      persist: (feedback: CaiFeedback) => Promise<void>,
    ): Promise<void> {
      if (retired && sources.length) throw new Error('reconciliation_required');
      const source = sources[0];
      if (!source) return;
      if (handingOff) throw new Error('feedback_handoff_busy');
      handingOff = true;
      try {
        character.snapshot();
        await persist(source);
        character.snapshot();
        if (sources[0]?.sourceId === source.sourceId) sources.shift();
      } finally {
        handingOff = false;
      }
    },
    async dispose(): Promise<void> {
      retire();
      await gateway.dispose();
      runtime.dispose();
    },
  };
}
