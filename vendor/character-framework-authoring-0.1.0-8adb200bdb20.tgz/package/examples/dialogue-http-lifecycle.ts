import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import type {
  CaiHostDriver,
  CharacterHostPort,
  HostChoice,
} from '../src/host/index.js';
import { integer, record, shape, text } from '../src/narrative/validation.js';
type Control = (
  operation: string,
  input?: Record<string, unknown>,
) => Promise<Record<string, unknown>>;
function validView(value: unknown): value is Record<string, unknown> {
  return (
    shape(value, [
      'graphId',
      'instanceId',
      'characterRef',
      'recipientRef',
      'revision',
      'nodeId',
      'text',
      'closed',
      'choices',
    ]) &&
    text(value['graphId']) &&
    text(value['instanceId']) &&
    text(value['characterRef']) &&
    value['recipientRef'] === 'player-1' &&
    integer(value['revision']) &&
    value['revision'] <= 15 &&
    text(value['nodeId'], 80) &&
    text(value['text'], 2000) &&
    typeof value['closed'] === 'boolean' &&
    Array.isArray(value['choices']) &&
    value['choices'].length <= 4 &&
    value['choices'].every(
      (choice: unknown) =>
        shape(choice, ['id', 'label']) &&
        text(choice['id']) &&
        text(choice['label'], 200),
    ) &&
    value['closed'] === (value['choices'].length === 0)
  );
}
/** Volatile trusted projection cache; never interprets model prose as a player choice. */
export function createDialogueHttpHost(control: Control) {
  let view: Record<string, unknown> | null = null,
    choiceCalls = 0;
  return {
    read: () => (view === null ? null : structuredClone(view)),
    choices: (): readonly HostChoice[] =>
      view === null ? [] : (structuredClone(view['choices']) as HostChoice[]),
    choiceCalls: () => choiceCalls,
    async refresh(state?: Record<string, unknown>) {
      const current = state ?? (await control('state'));
      assert.ok(
        Array.isArray(current['dialogueViews']) &&
          current['dialogueViews'].length <= 1,
      );
      const next: unknown = current['dialogueViews'][0];
      if (next === undefined) {
        assert.equal(view, null);
        return;
      }
      assert.ok(validView(next));
      if (view) {
        assert.equal(next['instanceId'], view['instanceId']);
        assert.ok(Number(next['revision']) >= Number(view['revision']));
      }
      view = structuredClone(next);
    },
    async choose(choiceId: string, effectKey: string): Promise<string> {
      assert.ok(view);
      const result = await control('graph-choose', { choiceId, effectKey });
      assert.equal(result['status'], 'completed');
      assert.ok(validView(result['data']));
      assert.equal(result['data']['instanceId'], view['instanceId']);
      assert.equal(result['data']['revision'], Number(view['revision']) + 1);
      view = structuredClone(result['data']);
      choiceCalls++;
      assert.ok(text(view['text'], 2000));
      return view['text'];
    },
  };
}
export async function runDialogueHttpLifecycle(options: {
  control: Control;
  driver: CaiHostDriver;
  port: CharacterHostPort;
  host: ReturnType<typeof createDialogueHttpHost>;
  generation: string;
  stage: (value: string) => void;
}) {
  const { control, driver, port, host, generation, stage } = options;
  const world = async () => {
    const s = await control('state');
    assert.deepEqual(s['quests'], []);
    assert.ok(
      Array.isArray(s['dialogueGraphs']) && s['dialogueGraphs'].length <= 1,
    );
    return s;
  };
  const dialogue = async (phase: string) => {
    stage('dialogue-' + phase);
    await port.dispatch({
      kind: 'dialogue',
      requestId: randomUUID(),
      expectedRevision: port.read().revision,
      message: 'dialogue-proof:' + phase,
    });
  };
  const current = (revision: number, nodeId: string, closed: boolean) => {
    const v = host.read();
    assert.ok(v);
    assert.equal(v['revision'], revision);
    assert.equal(v['nodeId'], nodeId);
    assert.equal(v['closed'], closed);
    return v;
  };
  const transferred: Record<string, unknown>[] = [];
  const transfer = async (
    s: Record<string, unknown>,
    revision: number,
    type: string,
  ) => {
    stage('dialogue-source-transfer-' + String(revision));
    assert.ok(
      Array.isArray(s['dialogueEvents']) && s['dialogueEvents'].length === 1,
    );
    const source: unknown = s['dialogueEvents'][0];
    assert.ok(
      record(source) &&
        text(source['id']) &&
        text(source['ownerKey']) &&
        text(source['graphId']) &&
        text(source['instanceId']) &&
        text(source['characterRef']) &&
        text(source['nodeId'], 80),
    );
    assert.equal(source['bindingGeneration'], generation);
    assert.equal(source['revision'], revision);
    assert.equal(source['type'], type);
    const v = host.read();
    assert.ok(v);
    assert.equal(source['instanceId'], v['instanceId']);
    assert.equal(source['graphId'], v['graphId']);
    assert.equal(source['nodeId'], v['nodeId']);
    assert.equal(source['recipientRef'], 'player-1');
    const checkpoint = JSON.parse(JSON.stringify(source)) as Record<
      string,
      unknown
    >;
    await driver.persistFeedback({
      sourceId: source['id'],
      origin: 'framework_narrative',
      type,
      summary: 'Committed authored dialogue: ' + type,
      references: {
        graph_id: source['graphId'],
        instance_id: source['instanceId'],
        actor_ref: source['characterRef'],
        recipient_ref: 'player-1',
        node_id: source['nodeId'],
        revision: String(revision),
      },
    });
    transferred.push(checkpoint);
    await control('ack-dialogue', { sourceId: source['id'] });
    assert.deepEqual((await world())['dialogueEvents'], []);
  };
  const select = async () => {
    stage('dialogue-player-choice');
    const snapshot = port.read();
    assert.equal(snapshot.choices.length, 1);
    const choice = snapshot.choices[0];
    assert.ok(choice);
    const command = {
      kind: 'choice' as const,
      requestId: randomUUID(),
      expectedRevision: snapshot.revision,
      choiceId: choice.id,
    };
    await port.dispatch(command);
    return command;
  };
  const initial = await world();
  assert.deepEqual(initial['dialogueGraphs'], []);
  assert.deepEqual(initial['dialogueViews'], []);
  assert.deepEqual(initial['dialogueEvents'], []);
  await dialogue('author');
  let s = await world();
  await host.refresh(s);
  await port.publishAuthority();
  current(0, 'greet', false);
  await transfer(s, 0, 'dialogue_started');
  await select();
  s = await world();
  await host.refresh(s);
  current(1, 'explain', false);
  assert.equal(host.choiceCalls(), 1);
  await transfer(s, 1, 'dialogue_selected');
  const before = current(1, 'explain', false);
  await dialogue('inspect');
  s = await world();
  await host.refresh(s);
  await port.publishAuthority();
  assert.deepEqual(host.read(), before);
  assert.deepEqual(s['dialogueEvents'], []);
  const exit = await select();
  s = await world();
  await host.refresh(s);
  current(2, 'exit', true);
  assert.deepEqual(port.read().choices, []);
  await port.dispatch(exit);
  assert.equal(host.choiceCalls(), 2);
  assert.deepEqual((await world())['dialogueEvents'], s['dialogueEvents']);
  await transfer(s, 2, 'dialogue_closed');
  await dialogue('confirm');
  s = await world();
  await host.refresh(s);
  current(2, 'exit', true);
  assert.deepEqual(s['dialogueEvents'], []);
  assert.deepEqual(port.read().choices, []);
  assert.equal(new Set(transferred.map((event) => event['id'])).size, 3);
  assert.equal(host.choiceCalls(), 2);
  return {
    proof: 'actual-CFW-HTTP-authored-dialogue',
    graphs: 1,
    instances: 1,
    closed: true,
    revision: 2,
    hostChoiceCallbacks: 2,
    hostChoiceReplay: true,
    dialogueSources: 3,
    pendingSources: 0,
    quests: 0,
    sourceIds: transferred.map((source) => source['id']),
    confirmedGeneration: true,
    hostDriver: true,
    volatileStorage: true,
    presentedMessages: port.read().messages.length,
  };
}
