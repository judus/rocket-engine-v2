import {
  QuestBuilderWorkspace,
  builderSchemas,
} from './quest-builder-workspace.js';
import assert from 'node:assert/strict';
import { readFile, mkdtemp, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { setImmediate } from 'node:timers/promises';
import { CharacterRuntime } from '../dist/src/index.js';
import { McpGateway } from '../dist/src/mcp/index.js';
import { QuestAuthoringPrototype } from '../dist/src/authoring/index.js';
import { FakeCaiClient } from './fake-cai-client.js';

const example = JSON.parse(
  await readFile(
    new URL(
      '../docs/contracts/watchtower-authoring-example.json',
      import.meta.url,
    ),
    'utf8',
  ),
);
const baselinePath = process.argv[2];
const baseline = baselinePath
  ? JSON.parse(await readFile(baselinePath, 'utf8'))
  : {
      proposalVersion: 'cfw-situations-draft-2',
      start: example.implementation.entrySituation,
      situations: example.implementation.situations,
    };
const dir = await mkdtemp(join(tmpdir(), 'cfw-builder-watchtower-'));
const author = new QuestAuthoringPrototype({
  path: join(dir, 'author.sqlite'),
  authorId: 'watchtower-rebuild',
  authorize: (c) => c.character.id === 'author',
  capabilities: example.capabilities.map((c) => ({
    ...c,
    validate: () => true,
    execute: () => {
      throw new Error('Rebuilding must not execute game actions');
    },
  })),
  references: example.references,
  referenceBindings: Object.fromEntries(
    example.capabilities.map((c) => [c.name, c.referenceBindings]),
  ),
});
const runtime = new CharacterRuntime({
  gameId: 'watchtower-rebuild',
  capabilities: author.tools,
});
const actor = runtime.register({
  id: 'author',
  name: 'Quest author',
  binding: { id: 'rebuild', generation: 'one' },
  cai: { characterId: 'author', sessionId: 'offline-rebuild' },
  capabilities: author.tools.map((t) => t.name),
});
const gateway = new McpGateway({
  runtime,
  credential: 'offline-rebuild-only',
  allowedHosts: ['127.0.0.1:8094'],
});
const headers = gateway.bind('author', actor, author.tools);
const client = new FakeCaiClient(
  new URL('http://127.0.0.1:8094/mcp'),
  headers,
  'offline-rebuild-only',
  (url, init) => gateway.handle(new Request(url, init)),
);
let sequence = 0;
const transcript = [];
async function call(name, args, effectKey) {
  const pending = client.call(name, args, {
    callId: `rebuild-call-${++sequence}`,
    turnId: 'rebuild-turn',
    ...(effectKey ? { effectKey } : {}),
  });
  let done = false;
  pending.then(
    () => {
      done = true;
    },
    () => {
      done = true;
    },
  );
  for (let i = 0; i < 200 && !done; i++) {
    runtime.advance(0);
    gateway.advance(0);
    await setImmediate();
  }
  assert.ok(done, 'Tool call must settle');
  const result = (await pending).structuredContent;
  transcript.push({ tool: name, arguments: args, result });
  return result;
}
const canonical = (v) =>
  Array.isArray(v)
    ? '[' + v.map(canonical).join(',') + ']'
    : v && typeof v === 'object'
      ? '{' +
        Object.keys(v)
          .sort()
          .map((k) => JSON.stringify(k) + ':' + canonical(v[k]))
          .join(',') +
        '}'
      : JSON.stringify(v);
let underlyingId, underlyingRevision, definition;
const host = async (name, fragment) => {
  if (!underlyingId) {
    const r = await call(
      'create_quest_draft',
      { intent: { title: 'Progressively authored watchtower' } },
      'host-create',
    );
    underlyingId = r.data.draftId;
    underlyingRevision = r.data.recordRevision;
  }
  const saved = await call(
    'edit_quest_draft',
    {
      draftId: underlyingId,
      expectedRecordRevision: underlyingRevision,
      operations: [
        {
          kind: 'replace_beat_implementation',
          beatId: 'main',
          implementation: fragment,
        },
      ],
    },
    `host-save-${underlyingRevision}`,
  );
  assert.equal(saved.status, 'completed', JSON.stringify(saved));
  underlyingRevision = saved.data.recordRevision;
  const review = await call('review_quest_draft', {
    draftId: underlyingId,
    recordRevision: underlyingRevision,
  });
  if (name === 'review_quest_draft')
    return {
      status: review.status,
      technicalReady: review.data.technicalReady,
      findings: review.data.technicalFindings ?? review.data.findings ?? [],
    };
  const args = {
    draftId: underlyingId,
    expectedRecordRevision: underlyingRevision,
  };
  const r = await call(
    'publish_quest_draft',
    args,
    `host-publish-${underlyingRevision}`,
  );
  assert.equal(r.status, 'completed');
  assert.deepEqual(
    await call(
      'publish_quest_draft',
      args,
      `host-publish-${underlyingRevision}`,
    ),
    r,
  );
  const read = await call('read_quest_draft', {
    section: 'publications',
    draftId: underlyingId,
  });
  definition = read.data.publication.definition;
  assert.equal(
    createHash('sha256').update(canonical(definition)).digest('hex'),
    r.data.definitionDigest,
  );
  return {
    status: 'completed',
    publication: {
      definitionId: r.data.definitionId,
      digest: r.data.definitionDigest,
    },
  };
};
const options = {
  path: join(dir, 'workspace.json'),
  capabilities: example.capabilities,
  host,
};
let workspace = new QuestBuilderWorkspace(options);
const builderCalls = [];
let context;
async function invoke(tool, parameters, expect = 'completed') {
  const args = [
    'create_quest_draft',
    'list_quest_drafts',
    'inspect_quest_draft',
  ].includes(tool)
    ? parameters
    : { draft: structuredClone(context), ...parameters };
  const result = await workspace.call(tool, args);
  builderCalls.push({ tool, arguments: args, result });
  assert.equal(result.status, expect, JSON.stringify(result));
  if (result.draftId && result.revision)
    context = { id: result.draftId, revision: result.revision };
  return result;
}
try {
  await client.connect();
  const catalogue = await call('read_quest_draft', { section: 'catalogue' });
  assert.equal(catalogue.status, 'completed');
  await invoke('create_quest_draft', {
    title: 'Recover the watchtower beacon',
    premise:
      'Choose a seal, recover it if not already collected, and complete matching delivery.',
  });
  const stageMap = {},
    recordMap = {},
    conditionMap = {};
  for (const s of baseline.situations) {
    const r = await invoke('add_stage', {
      title: s.id,
      purpose: `Watchtower ${s.id} progression`,
      ...(s.dialogue ? { dialogue: s.dialogue.text } : {}),
    });
    stageMap[s.id] = r.created.stageId;
  }
  await invoke('set_start_stage', { stageId: stageMap[baseline.start] });
  await invoke('review_quest_draft', {});
  await invoke('publish_quest_draft', {}, 'rejected');
  async function condition(c) {
    const k = canonical(c);
    if (conditionMap[k]) return conditionMap[k];
    const args = {
      capability: c.tool,
      arguments: c.arguments,
      comparison: {
        field: c.expect.path[0],
        operator: c.expect.operator,
        value: c.expect.value,
      },
    };
    const events = c.evidence.mode === 'events';
    if (events)
      args.since =
        c.evidence.after.kind === 'run-start'
          ? 'quest_start'
          : { stageId: stageMap[c.evidence.after.situationRef] };
    const r = await invoke(
      events ? 'create_event_condition' : 'create_fact_condition',
      args,
    );
    conditionMap[k] = r.created.conditionId;
    return conditionMap[k];
  }
  for (const s of baseline.situations) {
    const from = stageMap[s.id];
    if (s.dialogue?.requires)
      await invoke('set_interaction_requirement', {
        stageId: from,
        conditionId: await condition(s.dialogue.requires),
      });
    for (const route of s.routes ?? []) {
      const r = await invoke('add_transition', {
        from,
        to: stageMap[route.next],
        conditionId: await condition(route.when),
        priority: route.priority,
      });
      recordMap[s.id + ':' + route.id] = r.created.recordId;
    }
    for (const choice of s.choices ?? []) {
      const r = await invoke('add_choice', {
        from,
        to: stageMap[choice.next],
        label: choice.label,
        ...(choice.when ? { conditionId: await condition(choice.when) } : {}),
      });
      recordMap[s.id + ':' + choice.id] = r.created.recordId;
    }
    for (const a of s.onEnter ?? []) {
      const r = await invoke('add_entry_consequence', {
        stageId: from,
        capability: a.tool,
        arguments: a.arguments,
      });
      recordMap[s.id + ':' + a.id] = r.created.recordId;
    }
    if (!s.routes?.length && !s.choices?.length)
      await invoke('declare_ending', { stageId: from, ending: true });
  }
  const before = (await invoke('inspect_quest_draft', { draftId: context.id }))
    .data;
  workspace = new QuestBuilderWorkspace(options);
  assert.deepEqual(
    (await invoke('inspect_quest_draft', { draftId: context.id })).data,
    before,
  );
  // A valid but mistaken destination/action can be replaced without retaining it.
  const route = before.records.find(
    (r) => r.id === recordMap['blue-delivery:matching-delivery'],
  );
  const { id: routeId, kind: routeKind, ...routeValue } = route;
  await invoke('edit_record', {
    recordId: routeId,
    change: {
      operation: 'replace',
      kind: routeKind,
      value: { ...routeValue, to: stageMap['red-complete'] },
    },
  });
  await invoke('inspect_quest_draft', { draftId: context.id });
  await invoke('edit_record', {
    recordId: routeId,
    change: { operation: 'replace', kind: routeKind, value: routeValue },
  });
  const action = before.records.find(
    (r) => r.id === recordMap['blue-complete:light-matching-beacon'],
  );
  const { id: actionId, kind: actionKind, ...actionValue } = action;
  await invoke('edit_record', {
    recordId: actionId,
    change: {
      operation: 'replace',
      kind: actionKind,
      value: { ...actionValue, arguments: { entityRef: 'beacon-b' } },
    },
  });
  await invoke('inspect_quest_draft', { draftId: context.id });
  await invoke('edit_record', {
    recordId: actionId,
    change: { operation: 'replace', kind: actionKind, value: actionValue },
  });
  const rejectedRevision = context.revision;
  await invoke(
    'remove_stage',
    { stageId: stageMap['blue-complete'] },
    'rejected',
  );
  assert.equal(context.revision, rejectedRevision);
  const near = before.conditions.find(
    (c) => c.capability === 'game_entity' && c.arguments.entityRef === 'guide',
  );
  const { id: conditionId, usedBy, ...replacement } = near;
  assert.equal(usedBy.length, 4);
  await invoke(
    'update_condition',
    { conditionId, replacement, affectedRecordIds: [] },
    'rejected',
  );
  assert.equal(context.revision, rejectedRevision);
  const review = await invoke('review_quest_draft', {});
  assert.equal(review.technicalReady, true);
  const published = await invoke('publish_quest_draft', {});
  const expected = structuredClone(baseline);
  expected.start = stageMap[expected.start];
  for (const s of expected.situations) {
    const original = s.id;
    s.id = stageMap[s.id];
    for (const r of [...(s.routes ?? []), ...(s.choices ?? [])]) {
      r.id = recordMap[original + ':' + r.id];
      r.next = stageMap[r.next];
      if (r.when?.evidence.after?.situationRef)
        r.when.evidence.after.situationRef =
          stageMap[r.when.evidence.after.situationRef];
    }
    for (const a of s.onEnter ?? []) a.id = recordMap[original + ':' + a.id];
  }
  assert.deepEqual(definition.situations, expected.situations);
  assert.equal(definition.start, expected.start);
  const view = (await invoke('inspect_quest_draft', { draftId: context.id }))
    .data;
  assert.equal(view.findings.length, 0);
  await writeFile(
    join(dir, 'builder-calls.json'),
    JSON.stringify(builderCalls, null, 2) + '\n',
  );
  await writeFile(
    join(dir, 'host-mcp-calls.json'),
    JSON.stringify(transcript, null, 2) + '\n',
  );
  await writeFile(
    join(dir, 'published-definition.json'),
    JSON.stringify(definition, null, 2) + '\n',
  );
  await writeFile(
    join(dir, 'inspection.json'),
    JSON.stringify(view, null, 2) + '\n',
  );
  await writeFile(
    join(dir, 'id-mapping.json'),
    JSON.stringify({ stageMap, recordMap }, null, 2) + '\n',
  );
  await writeFile(
    join(dir, 'tool-schemas.json'),
    JSON.stringify(builderSchemas, null, 2) + '\n',
  );
  await writeFile(join(dir, 'quest.mmd'), view.mermaid + '\n');
  console.log(
    JSON.stringify({
      builderCalls: builderCalls.length,
      hostMcpCalls: transcript.length,
      stages: 12,
      reopened: true,
      wrongRouteAndEffectReplaced: true,
      referencedStageDeletionRejected: true,
      sharedConditionEditRejected: true,
      baselineEquivalent: true,
      publication: published.publication,
      artifacts: dir,
    }),
  );
} finally {
  await client.close();
  await gateway.dispose();
  runtime.dispose();
  author.close();
}
