import type { CharacterHandle } from '../src/Runtime.js';
import { record } from '../src/narrative/validation.js';
import { createNarrativeScenario } from './narrative-scenario.js';
import { McpGateway } from '../src/mcp/index.js';
import { integer, shape, text } from '../src/narrative/validation.js';

/** Disposable one-NPC world; controls are private host operations, never model tools. */
export function createJointFixture(
  credential: string,
  allowedHosts: readonly string[],
) {
  const world = createNarrativeScenario();
  world.forester.unregister();
  world.director.unregister();
  const gateway = new McpGateway({
    runtime: world.runtime,
    credential,
    allowedHosts,
  });
  let bound: {
    sessionId: string;
    characterId: string;
    headers: Readonly<Record<string, string>>;
  } | null = null;
  let actor: CharacterHandle | null = null;
  let dropCreate = false;
  let droppedCreates = 0;
  const advance = () => {
    world.advance(0.01);
    gateway.advance(0.01);
  };
  const state = () => {
    const saved = world.narrative.save();
    const currentActor = actor;
    return {
      bound: bound !== null,
      quests: saved.quests.map((quest) => ({
        questId: quest.id,
        title: quest.definition.title,
        offerId: quest.offer?.id ?? null,
        status: quest.offer?.status ?? 'registered',
        progress: quest.progress,
      })),
      events: saved.events,
      offeringPolicies: saved.offeringPolicies ?? [],
      offeringEvents: world.narrative.offeringEvents(),
      dialogueGraphs: (saved.dialogue?.graphs ?? []).map((graph) => ({
        graphId: graph.id,
        characterRef: graph.characterRef,
        recipientRef: graph.definition.recipientRef,
        nodeCount: graph.definition.nodes.length,
      })),
      dialogueViews: currentActor
        ? (saved.dialogue?.instances ?? []).flatMap((instance) => {
            const result = world.narrative.dialogueView(
              currentActor,
              instance.id,
            );
            return result.status === 'completed' && record(result.data)
              ? [result.data]
              : [];
          })
        : [],
      dialogueEvents: world.narrative.dialogueEvents(),
      dialogueDefinition: {
        recipientRef: 'player-1',
        title: 'A greeting',
        start: 'greet',
        nodes: [
          {
            id: 'greet',
            text: 'Hello.',
            choices: [{ id: 'ask', label: 'Tell me more.', next: 'explain' }],
          },
          {
            id: 'explain',
            text: 'The grove is peaceful.',
            choices: [{ id: 'leave', label: 'Goodbye.', next: 'exit' }],
          },
          { id: 'exit', text: 'Safe travels.', choices: [] },
        ],
      },
      droppedCreates,
      definition: world.draft('Survey the Old Grove', 'grove-1').toInput(),
    };
  };
  const handle = async (request: Request): Promise<Response> => {
    const url = new URL(request.url);
    if (url.pathname === '/mcp') {
      let isCreate = false;
      if (dropCreate && request.method === 'POST') {
        const input: unknown = await request.clone().json();
        isCreate =
          shape(input, ['jsonrpc', 'id', 'method', 'params']) &&
          input['method'] === 'tools/call' &&
          shape(input['params'], ['name', 'arguments']) &&
          input['params']['name'] === 'create_quest';
      }
      const response = await gateway.handle(request);
      if (isCreate && response.ok) {
        const before = droppedCreates;
        const result: unknown = await response.clone().json();
        if (
          shape(result, ['jsonrpc', 'id', 'result']) &&
          shape(
            result['result'],
            ['content', 'structuredContent', 'isError'],
            ['content', 'structuredContent'],
          ) &&
          shape(result['result']['structuredContent'], ['status', 'data']) &&
          result['result']['structuredContent']['status'] === 'completed'
        ) {
          dropCreate = false;
          droppedCreates = before + 1;
          // The real gateway committed; discard its reply so CAI must reconcile the same effect.
          return Response.json(
            { error: 'fixture_committed_reply_lost' },
            { status: 503 },
          );
        }
      }
      return response;
    }
    if (request.headers.get('authorization') !== `Bearer ${credential}`)
      return Response.json({ error: 'denied' }, { status: 403 });
    if (!allowedHosts.includes(url.host))
      return Response.json({ error: 'host_denied' }, { status: 403 });
    if (url.pathname === '/fixture/state' && request.method === 'GET')
      return Response.json(state());
    if (request.method !== 'POST')
      return Response.json({ error: 'method_denied' }, { status: 405 });
    if (Number(request.headers.get('content-length') ?? 0) > 4096)
      return Response.json({ error: 'input_limit' }, { status: 413 });
    const encoded = await request.text();
    if (Buffer.byteLength(encoded) > 4096)
      return Response.json({ error: 'input_limit' }, { status: 413 });
    const input: unknown = JSON.parse(encoded);
    if (url.pathname === '/fixture/bind') {
      if (
        !shape(input, ['sessionId', 'characterId']) ||
        !integer(input['sessionId']) ||
        input['sessionId'] < 1 ||
        !integer(input['characterId']) ||
        input['characterId'] < 1
      )
        return Response.json({ error: 'invalid_binding' }, { status: 422 });
      const sessionId = String(input['sessionId']),
        characterId = String(input['characterId']);
      if (
        bound &&
        (bound.sessionId !== sessionId || bound.characterId !== characterId)
      )
        return Response.json({ error: 'binding_conflict' }, { status: 409 });
      if (!bound) {
        const forester = world.runtime.register({
          id: 'forester',
          name: 'Mara the forester',
          entityId: 'workforce-17',
          cai: { sessionId, characterId },
          capabilities: ['game_inspect_location'],
        });
        actor = forester;
        bound = {
          sessionId,
          characterId,
          headers: gateway.bind(
            'forester/workforce-17',
            forester,
            world.capabilities.filter(
              (cap) => cap.name === 'game_inspect_location',
            ),
          ),
        };
      }
      return Response.json({
        sessionId,
        characterId,
        headers: bound.headers,
        definition: state().definition,
      });
    }
    if (!bound)
      return Response.json({ error: 'binding_required' }, { status: 409 });
    if (url.pathname === '/fixture/drop-create' && shape(input, [])) {
      dropCreate = true;
      return Response.json({ armed: true });
    }
    if (url.pathname === '/fixture/accept') {
      if (
        !shape(input, ['effectKey', 'questId'], ['effectKey']) ||
        !text(input['effectKey']) ||
        (input['questId'] !== undefined && !text(input['questId']))
      )
        return Response.json({ error: 'invalid_choice' }, { status: 422 });
      const quests = state().quests;
      const quest =
        input['questId'] !== undefined
          ? quests.find((item) => item.questId === input['questId'])
          : quests.length === 1
            ? quests[0]
            : undefined;
      if (!quest?.offerId)
        return Response.json({ error: 'one_offer_required' }, { status: 409 });
      return Response.json(
        await world.narrative.choose(
          'player-1',
          `${quest.offerId}/accept`,
          input['effectKey'],
        ),
      );
    }
    if (
      url.pathname === '/fixture/complete' &&
      shape(input, ['questId'], []) &&
      (input['questId'] === undefined || text(input['questId']))
    ) {
      const quests = state().quests;
      const quest =
        input['questId'] !== undefined
          ? quests.find((item) => item.questId === input['questId'])
          : quests.length === 1
            ? quests[0]
            : undefined;
      if (!quest || !['active', 'completed'].includes(quest.status))
        return Response.json(
          { error: 'one_active_quest_required' },
          { status: 409 },
        );
      world.visit('grove-1');
      return Response.json({ visited: true }); // Authoritative fact; runtime computes completion on advance.
    }
    if (
      url.pathname === '/fixture/ack-offering' &&
      shape(input, ['sourceId']) &&
      text(input['sourceId'])
    ) {
      world.narrative.acknowledgeOfferingEvent(input['sourceId']);
      return Response.json({ acknowledged: true });
    }
    if (
      url.pathname === '/fixture/graph-choose' &&
      shape(input, ['choiceId', 'effectKey']) &&
      text(input['choiceId']) &&
      text(input['effectKey'])
    ) {
      return Response.json(
        await world.narrative.choose(
          'player-1',
          input['choiceId'],
          input['effectKey'],
        ),
      );
    }
    if (
      url.pathname === '/fixture/ack-dialogue' &&
      shape(input, ['sourceId']) &&
      text(input['sourceId'])
    ) {
      world.narrative.acknowledgeDialogueEvent(input['sourceId']);
      return Response.json({ acknowledged: true });
    }
    return Response.json({ error: 'unknown_control' }, { status: 404 });
  };
  return {
    handle,
    advance,
    state,
    async dispose() {
      await gateway.dispose();
      world.dispose();
    },
  };
}
