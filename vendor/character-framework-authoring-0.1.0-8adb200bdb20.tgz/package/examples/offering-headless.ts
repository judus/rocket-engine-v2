import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { createNarrativeScenario } from './narrative-scenario.js';
import type { Json, NarrativeResult, ToolName } from '../src/index.js';
import { record } from '../src/narrative/validation.js';
const world = createNarrativeScenario();
async function commit(
  promise: Promise<NarrativeResult>,
): Promise<NarrativeResult> {
  world.advance(0);
  return promise;
}
async function call(
  tool: ToolName,
  input: unknown,
  effect?: string,
): Promise<{ [key: string]: Json }> {
  const result = await commit(
    world.foresterNarrative.call(tool, input, effect),
  );
  if (result.status !== 'completed' || !record(result.data))
    throw new Error('Expected committed narrative result');
  return result.data;
}
try {
  const ordinary = (
    await call(
      'create_quest',
      world.draft('Ordinary survey', 'grove-1').toInput(),
      'ordinary',
    )
  )['questId'];
  const redemption = (
    await call(
      'create_quest',
      world.draft('Make amends', 'grove-1').toInput(),
      'redemption',
    )
  )['questId'];
  if (typeof ordinary !== 'string' || typeof redemption !== 'string')
    throw new Error('Quest identities required');
  await call(
    'set_offering_access',
    {
      recipientRef: 'player-1',
      expectedRevision: 0,
      mode: 'restricted',
      allowedQuestIds: [redemption],
    },
    'refusal',
  );
  const refused = await commit(
    world.foresterNarrative.call(
      'offer_quest',
      {
        questId: ordinary,
        recipientRef: 'player-1',
        dialogue: 'Ordinary work?',
      },
      'refused',
    ),
  );
  assert.equal(refused.status, 'rejected');
  const offered = await call(
    'offer_quest',
    {
      questId: redemption,
      recipientRef: 'player-1',
      dialogue: 'Visit the grove to make amends.',
    },
    'redemption-offer',
  );
  const choices = offered['choices'];
  if (
    !Array.isArray(choices) ||
    !record(choices[0]) ||
    typeof choices[0]['id'] !== 'string'
  )
    throw new Error('Recipient choice required');
  await commit(
    world.narrative.choose('player-1', choices[0]['id'], 'accept-redemption'),
  );
  world.visit('grove-1');
  for (let i = 0; i < 4; i++) {
    world.advance(0);
    await setImmediate();
  }
  assert.equal(
    (
      await call('inspect_quest', {
        questId: redemption,
        recipientRef: 'player-1',
      })
    )['status'],
    'completed',
  );
  assert.equal(
    (await call('inspect_offering_access', { recipientRef: 'player-1' }))[
      'mode'
    ],
    'restricted',
  );
  await call(
    'set_offering_access',
    {
      recipientRef: 'player-1',
      expectedRevision: 1,
      mode: 'open',
      allowedQuestIds: [],
    },
    'restoration',
  );
  await call(
    'offer_quest',
    { questId: ordinary, recipientRef: 'player-1', dialogue: 'Ordinary work?' },
    'fresh-ordinary-offer',
  );
  // Source evidence remains in the checkpoint until transferred after turn settlement.
  world.narrative.restore(
    JSON.parse(JSON.stringify(world.narrative.save())) as unknown,
  );
  const sources = world.narrative.offeringEvents();
  assert.equal(sources.length, 2);
  const hostFeedbackCheckpoint = sources.map((source) => ({
    sourceId: source.id,
    ownerKey: source.ownerKey,
    bindingGeneration: source.bindingGeneration,
    origin: 'framework_narrative',
    type: 'offering_access_changed',
    summary: 'Committed offering policy: ' + source.mode,
    references: {
      policy_id: source.policyId,
      actor_ref: source.characterRef,
      recipient_ref: source.recipientRef,
      revision: String(source.revision),
    },
  }));
  assert.equal(hostFeedbackCheckpoint.length, 2);
  for (const source of sources)
    world.narrative.acknowledgeOfferingEvent(source.id);
  console.log(
    JSON.stringify({
      offline: true,
      refusal: true,
      explicitRedemption: true,
      completion: true,
      explicitRestoration: true,
      policyRevision: 2,
      retainedFeedbackSources: hostFeedbackCheckpoint.length,
      livePersonality: false,
      durableStorage: false,
    }),
  );
} finally {
  world.dispose();
}
