import assert from 'node:assert/strict';
import { DialogueDraft } from '../src/index.js';
import { createNarrativeScenario } from './narrative-scenario.js';
import type { NarrativeResult } from '../src/index.js';
import { record } from '../src/narrative/validation.js';
const world = createNarrativeScenario();
async function commit(promise: Promise<NarrativeResult>) {
  world.advance(0);
  const result = await promise;
  if (result.status !== 'completed' || !record(result.data))
    throw new Error('Expected completed dialogue commit');
  return result.data;
}
try {
  const draft = new DialogueDraft({
    recipientRef: 'player-1',
    title: 'A greeting',
    start: 'greet',
  })
    .addNode({
      id: 'greet',
      text: 'Hello.',
      choices: [
        { id: 'ask', label: 'Tell me about the grove.', next: 'explain' },
      ],
    })
    .addNode({
      id: 'explain',
      text: 'The grove is quiet today.',
      choices: [{ id: 'leave', label: 'Goodbye.', next: 'exit' }],
    })
    .addNode({ id: 'exit', text: 'Safe travels.', choices: [] });
  const graph = await commit(
    world.foresterNarrative.call(
      'create_dialogue_graph',
      draft.toInput(),
      'author',
    ),
  );
  const start = await commit(
    world.foresterNarrative.call(
      'start_dialogue_graph',
      { graphId: graph['graphId'] },
      'start',
    ),
  );
  function choice(data: Record<string, unknown>) {
    if (
      !Array.isArray(data['choices']) ||
      !record(data['choices'][0]) ||
      typeof data['choices'][0]['id'] !== 'string'
    )
      throw new Error('Committed player choice required');
    return data['choices'][0]['id'];
  }
  const next = await commit(
    world.narrative.choose('player-1', choice(start), 'ask'),
  );
  const closed = await commit(
    world.narrative.choose('player-1', choice(next), 'leave'),
  );
  assert.equal(closed['closed'], true);
  world.narrative.restore(
    JSON.parse(JSON.stringify(world.narrative.save())) as unknown,
  );
  assert.deepEqual(
    await commit(world.narrative.choose('player-1', choice(start), 'ask')),
    next,
  );
  const stored = JSON.parse(
    JSON.stringify(world.narrative.dialogueEvents()),
  ) as unknown[];
  for (const source of world.narrative.dialogueEvents())
    world.narrative.acknowledgeDialogueEvent(source.id);
  console.log(
    JSON.stringify({
      offline: true,
      authoredNodes: 3,
      closed: true,
      choiceReplay: true,
      jsonRestored: true,
      feedbackSources: stored.length,
      pendingSources: world.narrative.dialogueEvents().length,
      quests: world.narrative.save().quests.length,
      volatileStorage: true,
    }),
  );
} finally {
  world.dispose();
}
