import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import {
  createAuthoringPrototypeFixture,
  visitFragment,
} from './authoring-prototype-fixture.js';

const path =
  process.argv[2] ??
  join(await mkdtemp(join(tmpdir(), 'cfw-authoring-')), 'drafts.sqlite');
let f = await createAuthoringPrototypeFixture(path);
try {
  const tools = await f.client.client.listTools();
  assert.equal(tools.tools.length, 7);
  const catalogue = await f.call('read_quest_draft', { section: 'catalogue' });
  assert.equal(catalogue.status, 'completed');
  assert.equal(catalogue.data.capabilities[0].name, 'rocket_inspect_grove');
  const created = await f.call(
    'create_quest_draft',
    {
      intent: {
        title: 'Visit the Old Grove',
        presentation: 'task',
        premise: 'Explore the destination.',
      },
    },
    'prototype-create',
  );
  assert.equal(created.status, 'completed');
  const id = created.data.draftId;
  const incomplete = structuredClone(visitFragment);
  incomplete.situations.pop();
  const edited = await f.call(
    'edit_quest_draft',
    {
      draftId: id,
      expectedRecordRevision: 1,
      operations: [
        {
          kind: 'replace_beat_implementation',
          beatId: 'main',
          implementation: incomplete,
        },
      ],
    },
    'prototype-incomplete',
  );
  assert.equal(edited.data.assessment.technicalReady, false);
  const read = await f.call('read_quest_draft', {
    section: 'beat',
    draftId: id,
    recordRevision: 2,
  });
  assert.equal(read.data.implementation.situations.length, 1);
  const corrected = await f.call(
    'edit_quest_draft',
    {
      draftId: id,
      expectedRecordRevision: 2,
      operations: [
        {
          kind: 'replace_beat_implementation',
          beatId: 'main',
          implementation: visitFragment,
        },
      ],
    },
    'prototype-correct',
  );
  assert.equal(corrected.data.assessment.technicalReady, true);
  const reviewed = await f.call('review_quest_draft', {
    draftId: id,
    recordRevision: 3,
  });
  assert.equal(reviewed.data.technicalReady, true);
  const published = await f.call(
    'publish_quest_draft',
    { draftId: id, expectedRecordRevision: 3 },
    'prototype-publish',
  );
  assert.equal(published.status, 'completed');
  assert.equal(f.game.system.stats.runs, 0);
  await f.close();
  f = await createAuthoringPrototypeFixture(path);
  const saved = await f.call('read_quest_draft', {
    section: 'publications',
    draftId: id,
  });
  assert.equal(
    saved.data.publication.definition.id,
    published.data.definitionId,
  );
  const outcome = await f.call('get_authoring_command_outcome', {
    commandId: published.data.commandId,
  });
  assert.deepEqual(outcome.data.result, published);
  const definition = f.authoring.readPublishedDefinition(
    published.data.definitionId,
  );
  await f.pump(f.game.handle.publish(definition, 'prototype-import'));
  const run = await f.pump(
    f.game.handle.start(
      definition.id,
      { kind: 'player', ref: 'player' },
      'prototype-start',
    ),
  );
  for (let i = 0; i < 10; i++)
    await f.pump(Promise.resolve(f.game.runtime.advance(0)));
  assert.notEqual(f.game.handle.read(run.runId).status, 'closed');
  f.game.enter();
  for (
    let i = 0;
    i < 100 && f.game.handle.read(run.runId).status !== 'closed';
    i++
  )
    await f.pump(new Promise((resolve) => setImmediate(resolve)));
  const closed = f.game.handle.read(run.runId).status === 'closed';
  assert.ok(closed);
  console.log(
    JSON.stringify({
      proof: 'persistent-authoring-mcp-visit',
      tools: 7,
      catalogueVisible: true,
      incompleteSaved: true,
      corrected: true,
      publishedWithoutActivation: true,
      reopened: true,
      receiptRecovered: true,
      visitClosed: closed,
      aiCalls: 0,
      world: 'volatile fake location evidence',
      database: path,
    }),
  );
} finally {
  await f.close();
}

const resumed = spawnSync(
  process.execPath,
  [
    fileURLToPath(new URL('./authoring-prototype-resume.js', import.meta.url)),
    path,
  ],
  { encoding: 'utf8' },
);
if (resumed.error) throw resumed.error;
if (resumed.status !== 0) throw new Error(resumed.stderr + resumed.stdout);
console.log(resumed.stdout.trim());
