import assert from 'node:assert/strict';
import { readFile, writeFile, mkdtemp } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { setImmediate } from 'node:timers/promises';
import { createQuestBuilderMcpFixture } from './quest-builder-mcp-fixture.js';
import { CharacterRuntime } from '../dist/src/index.js';
import { QuestBuilderAuthoring } from '../dist/src/authoring/index.js';
import { CfwMcpProvider } from '../dist/src/mcp/index.js';
import { FakeCaiClient } from './fake-cai-client.js';

const reference = process.argv[2];
if (!reference)
  throw new Error(
    'Usage: node examples/quest-builder-mcp-proof.js <local-proof-directory> [rocket-root]',
  );
const rocketRoot = process.argv[3];
const example = JSON.parse(
  await readFile(
    new URL(
      '../docs/contracts/watchtower-authoring-example.json',
      import.meta.url,
    ),
    'utf8',
  ),
);
const recorded = JSON.parse(
  await readFile(join(reference, 'builder-calls.json'), 'utf8'),
);
const expected = JSON.parse(
  await readFile(join(reference, 'published-definition.json'), 'utf8'),
);
const dir = await mkdtemp(join(tmpdir(), 'cfw-builder-registered-'));
const path = join(dir, 'author.sqlite');
async function combined() {
  const { McpService } = await import(
    pathToFileURL(join(rocketRoot, 'dist/src/mcp/McpService.js')).href
  );
  const { worldProvider } = await import(
    pathToFileURL(
      join(rocketRoot, 'dist/examples/quest-authoring/WorldProvider.js'),
    ).href
  );
  const { EncounterWorld } = await import(
    pathToFileURL(
      join(rocketRoot, 'dist/examples/character-encounter/World.js'),
    ).href
  );
  const world = new EncounterWorld(
    JSON.parse(
      await readFile(
        join(rocketRoot, 'examples/character-encounter/world.json'),
        'utf8',
      ),
    ),
  );
  const wp = worldProvider(
    world,
    JSON.parse(
      await readFile(
        join(rocketRoot, 'examples/quest-authoring/game-description.json'),
        'utf8',
      ),
    ),
  );
  const author = new QuestBuilderAuthoring({
    path,
    authorId: 'combined-builder',
    authorize: (c) => c.character.id === 'author',
    capabilities: example.capabilities.map((c) => ({
      ...c,
      validate: () => true,
      execute: () => {
        throw new Error('No gameplay during authoring');
      },
    })),
    references: example.references,
    referenceBindings: Object.fromEntries(
      example.capabilities.map((c) => [c.name, c.referenceBindings]),
    ),
  });
  const runtime = new CharacterRuntime({
    gameId: 'combined-builder',
    capabilities: author.tools,
  });
  const actor = runtime.register({
    id: 'author',
    name: 'Author',
    binding: { id: 'combined-builder', generation: 'fresh' },
    cai: { characterId: 'author', sessionId: 'offline-session' },
    capabilities: author.tools.map((t) => t.name),
  });
  const provider = new CfwMcpProvider({ runtime });
  const headers = provider.bind('author', actor, author.tools, [
    'cfw',
    'watchtower-world',
  ]);
  const host = new McpService().configure({
    credential: 'offline-builder-only',
    allowedHosts: ['127.0.0.1:8094'],
    resolveBinding: (r) => provider.resolveBinding(r),
  });
  host.register(provider);
  host.register(wp);
  const client = new FakeCaiClient(
    new URL('http://127.0.0.1:8094/mcp'),
    headers,
    'offline-builder-only',
    (url, init) => host.handle(new Request(url, init)),
  );
  await client.connect();
  let sequence = 0;
  const transcript = [];
  async function call(name, args, effectKey) {
    const pending = client.call(name, args, {
      callId: `call-${++sequence}`,
      turnId: 'builder-proof',
      ...(effectKey ? { effectKey } : {}),
    });
    let done = false;
    pending.then(
      () => {
        done = true;
      },
      () => {
        done = true;
      },
    );
    for (let i = 0; i < 1000 && !done; i++) {
      runtime.advance(0);
      provider.advance(0);
      await setImmediate();
    }
    assert.ok(done, 'call settled');
    const response = await pending;
    transcript.push({ tool: name, arguments: args, response });
    return response.structuredContent;
  }
  return {
    author,
    client,
    call,
    transcript,
    world,
    close: async () => {
      await client.close();
      host.dispose();
      await host.close();
      provider.dispose();
      runtime.dispose();
      await author.close();
      world.dispose();
    },
  };
}
const f = rocketRoot
  ? await combined()
  : await createQuestBuilderMcpFixture(path, example);
const canonical = (v) =>
  Array.isArray(v)
    ? '[' + v.map(canonical).join(',') + ']'
    : v && typeof v === 'object'
      ? '{' +
        Object.keys(v)
          .sort()
          .map((k) => JSON.stringify(k) + ':' + canonical(v[k]))
          .join(',') +
        '}'
      : JSON.stringify(v);
try {
  const { tools } = await f.client.client.listTools();
  assert.equal(tools.length, rocketRoot ? 25 : 24);
  await writeFile(
    join(dir, 'tools.json'),
    JSON.stringify(tools, null, 2) + '\n',
  );
  if (rocketRoot)
    assert.equal((await f.call('game_world_summary', {})).status, 'completed');
  assert.equal(
    (await f.call('read_quest_draft', { section: 'catalogue' })).status,
    'completed',
  );
  let draftId, publication;
  for (let i = 0; i < recorded.length; i++) {
    const c = recorded[i],
      args = structuredClone(c.arguments);
    if (args.draft) args.draft.id = draftId;
    if (args.draftId) args.draftId = draftId;
    const action =
      tools.find((t) => t.name === c.tool).annotations.readOnlyHint === false;
    const result = await f.call(
      c.tool,
      args,
      action ? `builder-${i}` : undefined,
    );
    assert.equal(result.status, c.result.status, JSON.stringify(result));
    if (c.tool === 'create_quest_draft') {
      draftId = result.data.draftId;
      assert.deepEqual(await f.call(c.tool, args, `builder-${i}`), result);
    }
    if (c.tool === 'publish_quest_draft' && result.status === 'completed') {
      publication = result.data.publication;
      assert.deepEqual(await f.call(c.tool, args, `builder-${i}`), result);
    }
  }
  const definition = f.author.readPublishedDefinition(publication.definitionId);
  assert.deepEqual(definition.situations, expected.situations);
  assert.equal(definition.start, expected.start);
  assert.equal(
    createHash('sha256').update(canonical(definition)).digest('hex'),
    publication.digest,
  );
  const listed = await f.call('list_quest_drafts', {});
  const commandId = listed.data.recentCommands.at(-1).commandId;
  assert.equal(
    (await f.call('get_authoring_command_outcome', { commandId })).status,
    'completed',
  );
  assert.equal(
    (await f.call('read_quest_draft', { section: 'publications', draftId }))
      .status,
    'rejected',
  );
  if (f.world) assert.equal(f.world.events.length, 0);
  await writeFile(
    join(dir, 'tool-calls.json'),
    JSON.stringify(f.transcript, null, 2) + '\n',
  );
  await writeFile(
    join(dir, 'published-definition.json'),
    JSON.stringify(definition, null, 2) + '\n',
  );
  const result = {
    registeredTools: tools.length,
    builderSteps: recorded.length,
    calls: f.transcript.length,
    combinedRocketHost: !!rocketRoot,
    baselineEquivalent: true,
    exactReplay: true,
    catalogueOnly: true,
    worldEvents: f.world?.events.length ?? 0,
    publication,
    artifacts: dir,
  };
  await writeFile(
    join(dir, 'result.json'),
    JSON.stringify(result, null, 2) + '\n',
  );
  console.log(JSON.stringify(result));
} finally {
  await f.close();
}
