import { Ajv2020 } from 'ajv/dist/2020.js';
import { CharacterRuntime } from '../src/index.js';
import type {
  CapabilityResult,
  Json,
  SituationCapability,
  SituationGame,
  SituationInvocation,
  SituationSave,
} from '../src/index.js';
import { record } from '../src/narrative/validation.js';

/** Volatile deterministic game adapter, not Rocket combat or durable world storage. */
export function createSituationScenario() {
  const ajv = new Ajv2020({ strict: true });
  let sequence = 0,
    inside = false,
    trust = 1,
    interaction = true,
    encounterSequence = 0,
    rewards = 0,
    reveals = 0,
    flags = 0,
    retirements = 0;
  let checkpoint: SituationSave | undefined;
  let storageFailure: ((save: SituationSave) => boolean) | undefined;
  let loseActionReply = false,
    unknownObservations = false;
  const entries: number[] = [],
    pickups: number[] = [];
  const deaths: {
    sequence: number;
    encounterId: string;
    entity: string;
    incarnation: string;
    location: string;
    eventId: string;
  }[] = [];
  const manifests = new Map<
    string,
    {
      runId: string;
      location: string;
      roster: readonly { entity: string; incarnation: string }[];
    }
  >();
  const effects = new Map<string, CapabilityResult>();
  const cursors = new Map<string, Json>();
  const capabilities: SituationCapability[] = [];
  const schema = (properties: Record<string, Json>) => ({
    type: 'object',
    properties,
    required: Object.keys(properties),
    additionalProperties: false,
  });
  const string: Json = { type: 'string', minLength: 1, maxLength: 160 };
  const capability = (
    name: string,
    kind: 'action' | 'inspection',
    inputs: Record<string, Json>,
    outputs: Record<string, Json>,
    execute: SituationCapability['execute'],
    evidenceStream?: SituationCapability['evidenceStream'],
  ) => {
    const inputSchema = schema(inputs);
    const validate = ajv.compile(inputSchema);
    capabilities.push({
      name,
      kind,
      description: 'Fake game contract: ' + name,
      inputSchema,
      outputSchema: schema(outputs),
      validate: (input) => validate(input),
      execute,
      ...(evidenceStream ? { evidenceStream } : {}),
    });
  };
  const complete = (data: Json): CapabilityResult => ({
    status: 'completed',
    data,
  });
  const action = (
    context: SituationInvocation,
    commit: () => CapabilityResult,
  ) => {
    const id = context.narrative.effectId;
    if (!id) throw new Error('Trusted narrative effect required');
    const previous = effects.get(id);
    if (previous) return previous;
    const result = commit();
    effects.set(id, result);
    if (loseActionReply) {
      loseActionReply = false;
      throw new Error('Action reply lost');
    }
    return result;
  };
  const stringInput = (value: unknown): string => {
    if (typeof value !== 'string') throw new Error('String required');
    return value;
  };
  const input = (value: Json) => {
    if (!record(value)) throw new Error('Object required');
    return value;
  };
  capability(
    'game_inspect_location',
    'inspection',
    { locationRef: string },
    { inside: { type: 'boolean' }, entries: { type: 'integer', minimum: 0 } },
    (context) =>
      complete({
        inside,
        entries: entries.filter(
          (x) => x > Number(context.narrative?.evidence?.cursor ?? -1),
        ).length,
      }),
    { ref: 'location-entries', captureKeys: ['locationRef'] },
  );
  capability(
    'game_inspect_relationship',
    'inspection',
    { npcRef: string },
    { trust: { type: 'number' } },
    () => complete({ trust }),
  );
  capability(
    'game_inspect_interaction',
    'inspection',
    { npcRef: string, locationRef: string },
    { allowed: { type: 'boolean' } },
    (_, args) =>
      complete({
        allowed:
          interaction &&
          inside &&
          input(args)['npcRef'] === 'giuseppe' &&
          input(args)['locationRef'] === 'grove',
      }),
  );
  capability(
    'game_inspect_collection',
    'inspection',
    { existingItemRef: string },
    { collected: { type: 'boolean' }, count: { type: 'integer', minimum: 0 } },
    (context) =>
      complete({
        collected: pickups.length > 0,
        count: pickups.filter(
          (x) => x > Number(context.narrative?.evidence?.cursor ?? -1),
        ).length,
      }),
    { ref: 'item-pickups', captureKeys: ['existingItemRef'] },
  );
  capability(
    'game_inspect_encounter',
    'inspection',
    { encounterId: string, locationRef: string },
    { cleared: { type: 'boolean' } },
    (context, args) => {
      const value = input(args),
        manifest = manifests.get(stringInput(value['encounterId']));
      const eligible = deaths.filter(
        (d) =>
          d.encounterId === value['encounterId'] &&
          d.location === value['locationRef'] &&
          d.sequence > Number(context.narrative?.evidence?.cursor ?? -1),
      );
      return complete({
        cleared:
          !!manifest &&
          manifest.runId === context.narrative?.runId &&
          manifest.location === value['locationRef'] &&
          manifest.roster.length > 0 &&
          manifest.roster.every((m) =>
            eligible.some(
              (d) => d.entity === m.entity && d.incarnation === m.incarnation,
            ),
          ),
      });
    },
    { ref: 'combat-deaths', captureKeys: ['locationRef'] },
  );
  capability(
    'game_ensure_encounter',
    'action',
    { locationRef: string, presetRef: string },
    { encounterId: string },
    (context, args) =>
      action(context as SituationInvocation, () => {
        const id = 'encounter-' + String(++encounterSequence);
        manifests.set(id, {
          runId: context.narrative?.runId ?? '',
          location: stringInput(input(args)['locationRef']),
          roster: [
            { entity: 'guard-1', incarnation: id + '-1' },
            { entity: 'guard-2', incarnation: id + '-2' },
          ],
        });
        return complete({ encounterId: id });
      }),
  );
  capability(
    'game_reveal_npc',
    'action',
    { npcRef: string, locationRef: string },
    { revealed: { const: true } },
    (context) =>
      action(context as SituationInvocation, () => {
        reveals++;
        return complete({ revealed: true });
      }),
  );
  capability(
    'game_grant_reward',
    'action',
    { rewardRef: string },
    { receiptId: string },
    (context) =>
      action(context as SituationInvocation, () => {
        rewards++;
        return complete({ receiptId: 'reward-' + String(rewards) });
      }),
  );
  capability(
    'game_set_world_flag',
    'action',
    { flagRef: string, value: { type: 'boolean' } },
    { value: { type: 'boolean' } },
    (context, args) =>
      action(context as SituationInvocation, () => {
        flags++;
        return complete({ value: input(args)['value'] ?? false });
      }),
  );
  const game: SituationGame = {
    capabilities: () => capabilities,
    scopeAvailable: (_, scope) =>
      scope.kind === 'world' || scope.ref === 'player-1',
    capture: (context) => {
      const id = context.narrative.effectId;
      if (!id) throw new Error('Capture identity required');
      if (!cursors.has(id)) cursors.set(id, sequence);
      return cursors.get(id) ?? null;
    },
    observe: async (context, observations) => {
      const revision = String(sequence);
      const results = await Promise.all(
        observations.map(async (observation) =>
          unknownObservations
            ? { status: 'running' as const, operationId: 'history-unavailable' }
            : observation.capability.execute(
                {
                  ...context,
                  narrative: {
                    ...context.narrative,
                    ...(observation.evidence
                      ? { evidence: observation.evidence }
                      : {}),
                  },
                },
                observation.arguments,
              ),
        ),
      );
      if (revision !== String(sequence))
        throw new Error('Observation revision changed');
      return { revision, results };
    },
    observationCurrent: (_, revision) => revision === String(sequence),
    reconcile: (context) =>
      effects.get(context.narrative.effectId ?? '') ?? {
        status: 'not_admitted',
      },
    persist: (save) => {
      if (storageFailure?.(save)) throw new Error('Checkpoint storage failed');
      checkpoint = structuredClone(save);
    },
    retire: (context) => {
      if (!effects.has('retire/' + context.narrative.runId)) {
        effects.set('retire/' + context.narrative.runId, complete({}));
        retirements++;
        for (const [id, m] of manifests)
          if (m.runId === context.narrative.runId) manifests.delete(id);
      }
    },
  };
  const runtime = new CharacterRuntime({
    gameId: 'situation-proof',
    capabilities,
    situationGame: game,
  });
  const actor = runtime.register({
    id: 'director',
    name: 'Bodyless director',
    capabilities: capabilities.map((c) => c.name),
  });
  const system = runtime.situations;
  if (!system) throw new Error('Situation service required');
  const handle = system.bind(actor);
  return {
    runtime,
    system,
    handle,
    actor,
    game,
    capabilities,
    enter: () => {
      inside = true;
      entries.push(++sequence);
    },
    leave: () => {
      inside = false;
      sequence++;
    },
    interaction: (allowed: boolean) => {
      interaction = allowed;
      sequence++;
    },
    trust: (value: number) => {
      trust = value;
      sequence++;
    },
    pickup: () => {
      pickups.push(++sequence);
    },
    death: (
      encounterId: string,
      entity = 'guard-1',
      location = 'grove',
      incarnation = encounterId + (entity === 'guard-1' ? '-1' : '-2'),
      eventId = crypto.randomUUID(),
    ) => {
      if (!deaths.some((d) => d.eventId === eventId))
        deaths.push({
          sequence: ++sequence,
          encounterId,
          entity,
          incarnation,
          location,
          eventId,
        });
    },
    unknown: (value: boolean) => {
      unknownObservations = value;
    },
    failStorage: (predicate?: (save: SituationSave) => boolean) => {
      storageFailure = predicate;
    },
    loseReply: () => {
      loseActionReply = true;
    },
    checkpoint: () => checkpoint && structuredClone(checkpoint),
    stats: () => ({
      encounters: encounterSequence,
      rewards,
      reveals,
      flags,
      retirements,
      captureCount: cursors.size,
    }),
    dispose: () => {
      runtime.dispose();
    },
  };
}
