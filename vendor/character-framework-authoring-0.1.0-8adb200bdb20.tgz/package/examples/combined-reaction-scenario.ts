import { createDepartureScenario } from './departure-scenario.js';
import type { Capability, Json, QuestDefinition } from '../src/index.js';

/** One fake game/NPC binding exposes physical admission and framework narrative tools. */
export function createCombinedReactionScenario(credential: string) {
  let redeemed = false;
  const inputMatches = (input: Json) =>
    input !== null &&
    typeof input === 'object' &&
    !Array.isArray(input) &&
    Object.keys(input).length === 1 &&
    input['playerRef'] === 'player-1';
  const inspection: Capability = {
    name: 'game_inspect_redemption',
    kind: 'inspection',
    description: 'Read the fake game committed player redemption fact.',
    inputSchema: {
      type: 'object',
      properties: { playerRef: { const: 'player-1' } },
      required: ['playerRef'],
      additionalProperties: false,
    },
    validate: inputMatches,
    execute: () => ({ status: 'completed', data: { redeemed } }),
  };
  const scenario = createDepartureScenario(credential, {
    capabilities: [inspection],
    narrativeGame: {
      capabilities: () => [inspection],
      recipientAvailable: (_, ref) => ref === 'player-1',
      referencesAvailable: (_, condition) =>
        condition.tool === inspection.name && inputMatches(condition.arguments),
      inspectContext: () => ({
        status: 'completed',
        data: { actorRef: 'mara', recipientRef: 'player-1' },
      }),
    },
  });
  const narrative = scenario.runtime.narrative;
  if (!narrative) throw new Error('Shared narrative service required');
  return {
    ...scenario,
    narrative,
    redeem: () => {
      redeemed = true;
    },
    quest: (title: string): { quest: QuestDefinition } => ({
      quest: {
        recipientRef: 'player-1',
        title,
        summary: 'A scripted reaction contract, not personality evaluation.',
        objectives: [
          {
            id: 'redemption',
            description: 'Complete the game-owned redemption action.',
            condition: {
              tool: inspection.name,
              arguments: { playerRef: 'player-1' },
              expect: { path: ['redeemed'], operator: 'equals', value: true },
            },
          },
        ],
      },
    }),
  };
}
