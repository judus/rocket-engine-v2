// Compatibility entry for local examples; the maintained engine is packaged.
export {
  QuestBuilderWorkspace,
  builderSchemas,
} from '../dist/src/authoring/QuestBuilderWorkspace.js';
