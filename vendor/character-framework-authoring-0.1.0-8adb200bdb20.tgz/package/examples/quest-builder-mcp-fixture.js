import { CharacterRuntime } from '../dist/src/index.js';
import { QuestBuilderAuthoring } from '../dist/src/authoring/index.js';
import { McpGateway } from '../dist/src/mcp/index.js';
import { FakeCaiClient } from './fake-cai-client.js';
import { setImmediate } from 'node:timers/promises';

/** Offline SDK fixture; production hosts register these same domain tools. */
export async function createQuestBuilderMcpFixture(path, example) {
  let authorized = true;
  const author = new QuestBuilderAuthoring({
    path,
    authorId: 'builder-author',
    authorize: (c) => authorized && c.character.id === 'author',
    capabilities: example.capabilities.map((c) => ({
      ...c,
      validate: () => true,
      execute: () => {
        throw new Error('Authoring must not execute game capabilities');
      },
    })),
    references: example.references,
    referenceBindings: Object.fromEntries(
      example.capabilities.map((c) => [c.name, c.referenceBindings]),
    ),
  });
  const runtime = new CharacterRuntime({
    gameId: 'builder-mcp',
    capabilities: author.tools,
  });
  const actor = runtime.register({
    id: 'author',
    name: 'Quest author',
    binding: { id: 'builder-author-binding', generation: 'fresh' },
    cai: { characterId: 'author', sessionId: 'offline-builder-session' },
    capabilities: author.tools.map((c) => c.name),
  });
  const gateway = new McpGateway({
    runtime,
    credential: 'offline-builder-only',
    allowedHosts: ['127.0.0.1:8094'],
  });
  const headers = gateway.bind('builder', actor, author.tools);
  const client = new FakeCaiClient(
    new URL('http://127.0.0.1:8094/mcp'),
    headers,
    'offline-builder-only',
    (url, init) => gateway.handle(new Request(url, init)),
  );
  await client.connect();
  let sequence = 0;
  const transcript = [];
  async function call(name, args, effectKey) {
    const pending = client.call(name, args, {
      callId: `call-${++sequence}`,
      turnId: 'builder-turn',
      ...(effectKey ? { effectKey } : {}),
    });
    let done = false;
    pending.then(
      () => {
        done = true;
      },
      () => {
        done = true;
      },
    );
    for (let i = 0; i < 1000 && !done; i++) {
      runtime.advance(0);
      gateway.advance(0);
      await setImmediate();
    }
    if (!done) throw new Error('Builder call did not settle');
    const response = await pending;
    transcript.push({ tool: name, arguments: args, response });
    return response.structuredContent;
  }
  return {
    author,
    runtime,
    gateway,
    client,
    headers,
    transcript,
    call,
    revoke: () => {
      authorized = false;
    },
    close: async () => {
      await client.close();
      await gateway.dispose();
      runtime.dispose();
      await author.close();
    },
  };
}
