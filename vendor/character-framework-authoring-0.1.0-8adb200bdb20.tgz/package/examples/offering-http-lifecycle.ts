import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { setTimeout } from 'node:timers/promises';
import type { CaiHostDriver, CharacterHostPort } from '../src/host/index.js';
import { record, text, integer } from '../src/narrative/validation.js';

type Control = (
  operation: string,
  input?: Record<string, unknown>,
) => Promise<Record<string, unknown>>;
/** Actual HTTP proof choreography; CAI owns the isolated provider-only fake. */
export async function runOfferingHttpLifecycle(options: {
  control: Control;
  driver: CaiHostDriver;
  port: CharacterHostPort;
  generation: string;
  stage: (value: string) => void;
}) {
  const { control, driver, port, generation, stage } = options;
  const dialogue = async (phase: string) => {
    stage('offering-' + phase);
    await port.dispatch({
      kind: 'dialogue',
      requestId: randomUUID(),
      expectedRevision: port.read().revision,
      message: 'offering-proof:' + phase,
    });
  };
  const quests = (state: Record<string, unknown>) => {
    assert.ok(Array.isArray(state['quests']) && state['quests'].length === 2);
    const values = state['quests'];
    assert.ok(
      values.every((q) => record(q) && text(q['questId']) && text(q['title'])),
    );
    return values as Record<string, unknown>[];
  };
  const policy = (
    state: Record<string, unknown>,
    revision: number,
    mode: string,
  ) => {
    assert.ok(
      Array.isArray(state['offeringPolicies']) &&
        state['offeringPolicies'].length === 1,
    );
    const value: unknown = state['offeringPolicies'][0];
    assert.ok(record(value));
    assert.equal(value['recipientRef'], 'player-1');
    assert.equal(value['revision'], revision);
    assert.equal(value['mode'], mode);
    assert.ok(Array.isArray(value['allowedQuestIds']));
    return value;
  };
  // Volatile JSON checkpoint; persistFeedback must finish before source acknowledgment.
  const transferred: Record<string, unknown>[] = [];
  const transfer = async (
    state: Record<string, unknown>,
    revision: number,
    mode: string,
  ) => {
    stage('offering-source-transfer-' + String(revision));
    assert.ok(
      Array.isArray(state['offeringEvents']) &&
        state['offeringEvents'].length === 1,
    );
    const raw: unknown = state['offeringEvents'][0];
    assert.ok(
      record(raw) &&
        text(raw['id']) &&
        text(raw['policyId']) &&
        text(raw['ownerKey']) &&
        text(raw['characterRef']),
    );
    assert.equal(raw['bindingGeneration'], generation);
    assert.equal(raw['recipientRef'], 'player-1');
    assert.equal(raw['revision'], revision);
    assert.equal(raw['mode'], mode);
    const source = JSON.parse(JSON.stringify(raw)) as Record<string, unknown>;
    await driver.persistFeedback({
      sourceId: raw['id'],
      origin: 'framework_narrative',
      type: 'offering_access_changed',
      summary: 'Committed offering policy: ' + mode,
      references: {
        policy_id: raw['policyId'],
        actor_ref: raw['characterRef'],
        recipient_ref: 'player-1',
        revision: String(revision),
      },
    });
    transferred.push(source);
    await control('ack-offering', { sourceId: raw['id'] });
    assert.deepEqual((await control('state'))['offeringEvents'], []);
  };
  await dialogue('author');
  let state = await control('state');
  const authored = quests(state);
  assert.ok(authored.every((q) => q['status'] === 'registered'));
  assert.equal(new Set(authored.map((q) => q['questId'])).size, 2);
  assert.equal(new Set(authored.map((q) => q['title'])).size, 2);
  assert.deepEqual(state['offeringPolicies'], []);
  assert.deepEqual(state['offeringEvents'], []);
  await dialogue('restrict');
  state = await control('state');
  const restricted = policy(state, 1, 'restricted');
  assert.ok(
    Array.isArray(restricted['allowedQuestIds']) &&
      restricted['allowedQuestIds'].length === 1 &&
      text(restricted['allowedQuestIds'][0]),
  );
  const redemptionId = restricted['allowedQuestIds'][0];
  const current = quests(state);
  assert.deepEqual(
    new Set(current.map((q) => q['questId'])),
    new Set(authored.map((q) => q['questId'])),
  );
  const redemption = current.find((q) => q['questId'] === redemptionId);
  const ordinary = current.find((q) => q['questId'] !== redemptionId);
  assert.ok(redemption && ordinary && text(ordinary['questId']));
  const ordinaryId = ordinary['questId'];
  assert.equal(redemption['status'], 'offered');
  assert.equal(ordinary['status'], 'registered');
  await transfer(state, 1, 'restricted');
  stage('offering-host-completion');
  await control('accept', { questId: redemptionId, effectKey: randomUUID() });
  await control('complete', { questId: redemptionId });
  let completion: Record<string, unknown> | undefined;
  for (let i = 0; i < 50; i++) {
    state = await control('state');
    if (Array.isArray(state['events']))
      completion = state['events'].find(
        (event: unknown): event is Record<string, unknown> =>
          record(event) &&
          event['type'] === 'quest_completed' &&
          event['questId'] === redemptionId,
      );
    if (completion) break;
    await setTimeout(20);
  }
  assert.ok(completion && text(completion['id']));
  assert.equal(
    quests(state).find((q) => q['questId'] === redemptionId)?.['status'],
    'completed',
  );
  policy(state, 1, 'restricted');
  await driver.persistFeedback({
    sourceId: completion['id'],
    origin: 'game_outcome',
    type: 'quest_completed',
    summary: 'The game confirms the redemption survey is completed.',
    references: { quest_id: redemptionId },
  });
  await dialogue('restore');
  state = await control('state');
  assert.deepEqual(policy(state, 2, 'open')['allowedQuestIds'], []);
  assert.equal(
    quests(state).find((q) => q['questId'] === redemptionId)?.['status'],
    'completed',
  );
  assert.equal(
    quests(state).find((q) => q['questId'] === ordinaryId)?.['status'],
    'offered',
  );
  await transfer(state, 2, 'open');
  await dialogue('confirm');
  state = await control('state');
  assert.deepEqual(policy(state, 2, 'open')['allowedQuestIds'], []);
  assert.equal(
    quests(state).find((q) => q['questId'] === redemptionId)?.['status'],
    'completed',
  );
  assert.equal(
    quests(state).find((q) => q['questId'] === ordinaryId)?.['status'],
    'offered',
  );
  assert.deepEqual(state['offeringEvents'], []);
  assert.equal(new Set(transferred.map((source) => source['id'])).size, 2);
  assert.ok(integer(port.read().revision));
  return {
    proof: 'actual-CFW-HTTP-offering-policy',
    quests: 2,
    redemptionCompleted: true,
    ordinaryOffered: true,
    policyRevision: 2,
    policySources: 2,
    pendingOfferingSources: 0,
    confirmedGeneration: true,
    hostDriver: true,
    volatileStorage: true,
    policySourceIds: transferred.map((source) => source['id']),
    completionSourceId: completion['id'],
    presentedMessages: port.read().messages.length,
  };
}
