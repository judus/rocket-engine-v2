import assert from 'node:assert/strict';
import { readFile, mkdtemp, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { setImmediate } from 'node:timers/promises';
import { CharacterRuntime } from '../dist/src/index.js';
import { McpGateway } from '../dist/src/mcp/index.js';
import { QuestAuthoringPrototype } from '../dist/src/authoring/index.js';
import { FakeCaiClient } from './fake-cai-client.js';

const example = JSON.parse(
  await readFile(
    new URL(
      '../docs/contracts/watchtower-authoring-example.json',
      import.meta.url,
    ),
    'utf8',
  ),
);
const baselinePath = process.argv[2];
const baseline = baselinePath
  ? JSON.parse(await readFile(baselinePath, 'utf8'))
  : {
      proposalVersion: 'cfw-situations-draft-2',
      start: example.implementation.entrySituation,
      situations: example.implementation.situations,
    };
const dir = await mkdtemp(join(tmpdir(), 'cfw-watchtower-rebuild-'));
const author = new QuestAuthoringPrototype({
  path: join(dir, 'author.sqlite'),
  authorId: 'watchtower-rebuild',
  authorize: (c) => c.character.id === 'author',
  capabilities: example.capabilities.map((c) => ({
    ...c,
    validate: () => true,
    execute: () => {
      throw new Error('Rebuilding must not execute game actions');
    },
  })),
  references: example.references,
  referenceBindings: Object.fromEntries(
    example.capabilities.map((c) => [c.name, c.referenceBindings]),
  ),
});
const runtime = new CharacterRuntime({
  gameId: 'watchtower-rebuild',
  capabilities: author.tools,
});
const actor = runtime.register({
  id: 'author',
  name: 'Quest author',
  binding: { id: 'rebuild', generation: 'one' },
  cai: { characterId: 'author', sessionId: 'offline-rebuild' },
  capabilities: author.tools.map((t) => t.name),
});
const gateway = new McpGateway({
  runtime,
  credential: 'offline-rebuild-only',
  allowedHosts: ['127.0.0.1:8094'],
});
const headers = gateway.bind('author', actor, author.tools);
const client = new FakeCaiClient(
  new URL('http://127.0.0.1:8094/mcp'),
  headers,
  'offline-rebuild-only',
  (url, init) => gateway.handle(new Request(url, init)),
);
let sequence = 0;
const transcript = [];
async function call(name, args, effectKey) {
  const pending = client.call(name, args, {
    callId: `rebuild-call-${++sequence}`,
    turnId: 'rebuild-turn',
    ...(effectKey ? { effectKey } : {}),
  });
  let done = false;
  pending.then(
    () => {
      done = true;
    },
    () => {
      done = true;
    },
  );
  for (let i = 0; i < 200 && !done; i++) {
    runtime.advance(0);
    gateway.advance(0);
    await setImmediate();
  }
  assert.ok(done, 'Tool call must settle');
  const result = (await pending).structuredContent;
  transcript.push({ tool: name, arguments: args, result });
  return result;
}
const canonical = (v) =>
  Array.isArray(v)
    ? '[' + v.map(canonical).join(',') + ']'
    : v && typeof v === 'object'
      ? '{' +
        Object.keys(v)
          .sort()
          .map((k) => JSON.stringify(k) + ':' + canonical(v[k]))
          .join(',') +
        '}'
      : JSON.stringify(v);
try {
  await client.connect();
  const catalogue = await call('read_quest_draft', { section: 'catalogue' });
  assert.equal(catalogue.status, 'completed');
  const created = await call(
    'create_quest_draft',
    {
      intent: {
        title: 'Rebuilt watchtower recovery',
        premise: 'Choose a seal and complete its matching delivery.',
      },
    },
    'create',
  );
  const draftId = created.data.draftId;
  let revision = created.data.recordRevision;
  // Rebuild in two saved stages; unfinished destinations must prevent publication.
  const initial = {
    ...structuredClone(example.implementation),
    situations: structuredClone(example.implementation.situations.slice(0, 3)),
  };
  const first = await call(
    'edit_quest_draft',
    {
      draftId,
      expectedRecordRevision: revision,
      operations: [
        {
          kind: 'replace_beat_implementation',
          beatId: 'main',
          implementation: initial,
        },
      ],
    },
    'initial-stages',
  );
  assert.equal(first.status, 'completed');
  revision = first.data.recordRevision;
  const incomplete = await call('review_quest_draft', {
    draftId,
    recordRevision: revision,
  });
  assert.equal(incomplete.data.technicalReady, false);
  const blocked = await call(
    'publish_quest_draft',
    { draftId, expectedRecordRevision: revision },
    'blocked-publication',
  );
  assert.equal(blocked.status, 'rejected');
  const complete = await call(
    'edit_quest_draft',
    {
      draftId,
      expectedRecordRevision: revision,
      operations: [
        {
          kind: 'replace_beat_implementation',
          beatId: 'main',
          implementation: example.implementation,
        },
      ],
    },
    'complete-branches',
  );
  assert.equal(complete.status, 'completed');
  revision = complete.data.recordRevision;
  const review = await call('review_quest_draft', {
    draftId,
    recordRevision: revision,
  });
  assert.equal(review.data.technicalReady, true);
  const beat = await call('read_quest_draft', {
    section: 'beat',
    draftId,
    recordRevision: revision,
  });
  assert.deepEqual(beat.data.implementation, example.implementation);
  const args = { draftId, expectedRecordRevision: revision };
  const published = await call('publish_quest_draft', args, 'publish');
  assert.equal(published.status, 'completed');
  assert.deepEqual(
    await call('publish_quest_draft', args, 'publish'),
    published,
  );
  // Retrieve the actual stored definition through a read tool, not a host side-door.
  const stored = await call('read_quest_draft', {
    section: 'publications',
    draftId,
  });
  const definition = stored.data.publication.definition;
  assert.equal(definition.id, published.data.definitionId);
  assert.equal(definition.start, baseline.start);
  assert.equal(definition.proposalVersion, baseline.proposalVersion);
  assert.deepEqual(definition.situations, baseline.situations);
  assert.equal(
    createHash('sha256').update(canonical(definition)).digest('hex'),
    published.data.definitionDigest,
  );
  await writeFile(
    join(dir, 'published-definition.json'),
    JSON.stringify(definition, null, 2) + '\n',
  );
  await writeFile(
    join(dir, 'tool-calls.json'),
    JSON.stringify(transcript, null, 2) + '\n',
  );
  console.log(
    JSON.stringify({
      toolOnlyRebuild: true,
      incompletePublicationBlocked: true,
      situations: definition.situations.length,
      baselineGraphExact: true,
      onlyDefinitionIdChanges: true,
      exactPublicationReplay: true,
      draftId,
      definitionId: definition.id,
      artifacts: dir,
    }),
  );
} finally {
  await client.close();
  await gateway.dispose();
  runtime.dispose();
  author.close();
}
