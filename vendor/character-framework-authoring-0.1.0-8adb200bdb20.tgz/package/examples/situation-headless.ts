import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import definitions from '../docs/contracts/situation-examples.json' with { type: 'json' };
import type { SituationDefinition, SituationView } from '../src/index.js';
import { createSituationScenario } from './situation-scenario.js';
const world = createSituationScenario();
async function tick() {
  world.runtime.advance(0);
  await setImmediate();
}
async function settle<T>(promise: Promise<T>): Promise<T> {
  const state = { done: false };
  void promise
    .finally(() => {
      state.done = true;
    })
    .catch(() => undefined);
  for (let i = 0; i < 200 && !state.done; i++) await tick();
  assert.ok(state.done);
  return promise;
}
async function until(
  runId: string,
  condition: (view: SituationView) => boolean,
) {
  for (let i = 0; i < 200; i++) {
    const view = world.handle.read(runId);
    if (condition(view)) return view;
    await tick();
  }
  throw new Error('Host proof did not settle');
}
try {
  const definition = definitions[1] as unknown as SituationDefinition;
  await settle(world.handle.publish(definition, 'publish-patrol'));
  const started = await settle(
    world.handle.start(
      definition.id,
      { kind: 'player', ref: 'player-1' },
      'arm-patrol',
    ),
  );
  world.enter();
  await until(started.runId, () => world.stats().encounters === 1);
  world.death('unrelated-encounter');
  world.death('encounter-1', 'guard-1', 'cemetery');
  for (let i = 0; i < 8; i++) await tick();
  assert.equal(world.handle.read(started.runId).situationId, 'fight');
  world.death('encounter-1', 'guard-1');
  world.death('encounter-1', 'guard-2');
  const view = await until(started.runId, (v) => v.choices.length === 2);
  assert.equal(world.stats().reveals, 1);
  const claim = view.choices.find((c) => c.label === 'Collect reward');
  if (!claim) throw new Error('Claim missing');
  await settle(
    world.handle.choose(started.runId, claim.id, view.revision, 'claim-reward'),
  );
  await until(started.runId, (v) => v.status === 'closed');
  await settle(
    world.handle.choose(started.runId, claim.id, view.revision, 'claim-reward'),
  );
  assert.equal(world.stats().rewards, 1);
  console.log(
    JSON.stringify({
      proof: 'authored-situation-flow',
      offline: true,
      aiConfigured: false,
      definition: definition.id,
      closed: true,
      ...world.stats(),
      storage: 'volatile fake game journal',
      rocketWorldProof: false,
    }),
  );
} finally {
  world.dispose();
}
