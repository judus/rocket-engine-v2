import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { createAuthoringPrototypeFixture } from './authoring-prototype-fixture.js';

const path = process.argv[2];
if (!path) throw new Error('Pass the saved authoring SQLite file.');
const f = await createAuthoringPrototypeFixture(path);
try {
  const listed = await f.call('list_quest_drafts', {});
  const draft = listed.data.items.find((d) => d.published);
  assert.ok(
    draft,
    'A published visit draft must survive the previous process.',
  );
  const saved = await f.call('read_quest_draft', {
    section: 'publications',
    draftId: draft.draftId,
  });
  const command = listed.data.recentCommands.findLast(
    (r) => r.tool === 'publish_quest_draft',
  );
  assert.ok(command);
  const outcome = await f.call('get_authoring_command_outcome', {
    commandId: command.commandId,
  });
  assert.equal(
    outcome.data.result.data.definitionId,
    saved.data.publication.definition.id,
  );
  const definition = f.authoring.readPublishedDefinition(
    saved.data.publication.definition.id,
  );
  await f.pump(f.game.handle.publish(definition, 'reopened-import'));
  f.game.enter(); // Prior entry before activation must not complete the new-visit task.
  const run = await f.pump(
    f.game.handle.start(
      definition.id,
      { kind: 'player', ref: 'player' },
      'reopened-start',
    ),
  );
  for (let i = 0; i < 10; i++) await f.pump(setImmediate());
  assert.notEqual(f.game.handle.read(run.runId).status, 'closed');
  f.game.leave();
  f.game.enter();
  for (
    let i = 0;
    i < 100 && f.game.handle.read(run.runId).status !== 'closed';
    i++
  )
    await f.pump(setImmediate());
  assert.equal(f.game.handle.read(run.runId).status, 'closed');
  console.log(
    JSON.stringify({
      freshProcess: true,
      savedDraftRecovered: true,
      commandRecoveredFromList: true,
      publicationImported: true,
      priorEntryExcluded: true,
      newEntryClosed: true,
      aiCalls: 0,
    }),
  );
} finally {
  await f.close();
}
