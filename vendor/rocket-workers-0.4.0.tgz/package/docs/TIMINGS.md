# Bounded host timings (0.4.0 candidate)

Every pool has `stats.timings`, a deeply frozen lifetime snapshot with exactly nineteen duration aggregates. There are no histories, histograms, per-task dynamic buckets, reset method, extra timer, clock service or scheduler. Restart/disposal retains numeric lifetime evidence; disposal clears extractor callbacks and job/attempt timestamp references. These fields do not measure process heap or thread reclamation.

```ts
import { createWorkerPool } from "rocket-workers";
import type { TimingTasks } from "./timing-tasks.js";
import { timingValidators } from "./timing-tasks.js";
const pool = createWorkerPool<TimingTasks>({
  workerUrl: new URL("./timing-tasks.worker.js", import.meta.url),
  tasks: timingValidators,
  maxQueued: 1,
  diagnostics: { computeMs: { work: (output) => output.computeMs } },
});
await pool.ready;
const result = await pool.run("work", 0);
console.log(pool.stats.timings.physical.active.result.durationMs);
pool.dispose();
```

`PoolDiagnostics<T>.computeMs` is an optional PARTIAL task-key map of synchronous output-to-number functions. Ordinary own enumerable string data records only; unknown/nonfunction/accessor/symbol/hidden keys reject `configuration` before Worker construction. Callbacks are snapshotted. Omitted tasks have no reported compute sample; host measurements always operate.

Queue wait runs from successful record/reservation commit AFTER initial admission callbacks to native post attempt AFTER dispatch revalidation. It excludes initial admission callback time, includes dispatch revalidation and waiting, and can be nonzero for immediate work. Matching result/task-error response duration runs from post attempt to matched handler arrival BEFORE output validators/extractor. It excludes queue/callback time but includes clone/worker work/main event-loop delivery; it is not isolated transfer latency.

Physical buckets have active/cancelled populations and result, task-error, output-error, transport-error, protocol-error, deadline and disposed outcomes. Result/task-error duration is observed dispatch-to-response. The other five durations are CENSORED dispatch-to-terminate-return elapsed, including validation/termination overhead where relevant. Never merge them into result/compute means. A post/clone failure is a transport-error attempt even if nothing reached the worker. Active.result is domain-validated; cancelled.result skips output validation/extraction. Running abort does not end physical timing or release resource charge until actual matching response/termination. Stale/duplicate callbacks do not finish a replacement.

Committed-but-unposted records count once as aborted, validationRejected (including ID exhaustion), stranded or disposed. They create no physical or queue-wait duration sample. Refusal/pre-admission abort is excluded and remains in original pool rejection/cancel counters. Startup ready/failed/disposed measures each actual start attempt, including restart, separately from first usable pool.ready. Failed/disposed startup durations are censored; a later job failure does not recategorize ready startup.

An extractor runs only after valid noncancelled matching output/current guards. Finite nonnegative number -> task-reported sample. Throw, negative/NaN/infinity/nonnumber/Promise/async -> invalidExtractors counter, while validated domain success is preserved. Wrong native Promise returns are consumed without awaiting or accepting asynchronous diagnostics. Abort/dispose/failure inside validators/extractors wins over return/throw and preserves original settlement; no double physical outcome, subsequent compute/invalid update or callback. Nested submissions still see the current job's reserved physical charge. Callbacks must be pure; output mutation or unbounded recursive user code is unsupported.

Reported compute sums across ALL opted-in tasks. It does not describe a particular task unless you select a homogeneous workload. Worker compute uses its own elapsed clock; absolute host/worker timestamps are not subtracted. `roundtrip - compute` is not transfer cost. The example measures a bounded worker computation separately from its artificial delay.

Each `DurationStats` exposes samples, totalMs, minMs/maxMs/meanMs, frozen and dropped. No samples: count/total0 and min/max/mean null. Valid zero: numeric0, distinct from no samples. Count/total prospective overflow freezes the complete retained prefix BEFORE changing count/total/min/max. Mean is total/retained samples, never event count or dropped count. Further samples increment dropped only. Finite values above representable safe magnitude freeze/drop rather than create infinity. Floating measurements have normal clock resolution/rounding.

`TimingCounter {value,saturated}` clamps at MAX_SAFE_INTEGER and marks saturation on further increment, then represents a lower bound. Dropped/event counts are never means' denominators. performance.now throw/nonfinite increments invalidClockReads; missing clock or negative/nonfinite subtraction omits durations (invalidClockDurations for subtraction). Domain success/failure stays unchanged, with no fabricated zero or Date.now fallback.

Run npm start and open [the finite timing demo](http://127.0.0.1:8126/timing.html). Its button prevents overlapping runs. Native acceptance serves installed public ESM from exact selected archives; snapshots include labels, outcomes and cleanup evidence. Assertions concern endpoints/ordering and finite values, not exact scheduling or speedup. See BROWSER-ACCEPTANCE.md and Q3-REPORT.md for artifact commands/identities. Resource reservations still end at caller handoff; Rocket owns later scene publication and timing.
