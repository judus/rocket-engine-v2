# Declared-cost reservations (0.3.0 candidate)

Enable `PoolOptions<T>.admission` to constrain admitted logical work in one caller-defined unit. This is a declared reservation ledger, not measured heap memory. Count-only behavior remains when admission is omitted or undefined. No runtime dependencies or worker protocol changes.

```ts
import { createWorkerPool } from "rocket-workers";
import { resourceValidators, resourceCost } from "./resource-tasks.js";
import type { ResourceTasks } from "./resource-tasks.js";
const pool = createWorkerPool<ResourceTasks>({
  workerUrl: new URL("./resource-tasks.worker.js", import.meta.url),
  tasks: resourceValidators,
  size: 1,
  maxQueued: 2,
  admission: { maxCost: 4096, costs: { bytes: resourceCost } },
});
await pool.ready;
```

`AdmissionPolicy<T>` requires a positive safe integer maxCost and one synchronous numeric callback for EVERY registered task. Policy records accept own enumerable string data fields only, with Object/null prototype, no hidden/symbol/accessor/extra fields. Invalid configuration throws `WorkerPoolError` code `configuration` before creating a Worker. Configuration is snapshotted; mutating its callbacks/maximum afterward has no effect. Hostile Proxies are outside the supported configuration model.

Each admitted task reserves one positive safe integer cost. Thrown callbacks, zero/negative/fractional/NaN/infinite/unsafe values and Promise/async returns reject with `cost`. A valid declared cost larger than available budget rejects immediately with `resource-full`, before native posting or input detachment. There is no additional waiting queue or per-run override. Existing count errors remain `busy`/`full`; unregistered task is `unknown-task`.

The pool revalidates borrowed input/transfers and recomputes cost at EVERY dispatch, even immediate dispatch. A valid different dispatch value rejects with `cost-changed`; invalid/thrown dispatch values reject with `cost`. No growth/shrink/repricing. Caller input must remain immutable while queued/unposted; equal cost does not prove immutable content. Transfer arrays are snapshotted, not payloads.

After input/cost/output callbacks the host guards lifecycle, abort and current job/attempt before invoking another callback or posting/settling. Nested successful admission remains owned; outer capacity is rechecked to prevent oversubscription. Invalidation wins over callback false/throw. Cost callbacks should nevertheless be pure; unbounded recursive user callbacks are not made finite by the pool.

`pool.stats.admission` is a frozen exact snapshot: enabled, maxCost (null when disabled), reservedCost, queuedCost, occupiedCost and cancelledOccupiedCost. Disabled counters are zero. Enabled invariant: reservedCost = queuedCost + occupiedCost <= maxCost. A dispatching record is included in occupiedCost during pre-post revalidation. Cancelled occupied cost is a subset, never added twice.

Queued abort or pre-post refusal releases once without native detachment. Running logical abort rejects promptly but retains occupied reservation until matching physical result/error, failure/deadline or disposal. Native post failure, bad current message, rejected output and deadline terminate the worker before physical charge release. Duplicate/stale callbacks release nothing; restart has no task cost/replay. Disposal returns all ledger fields to zero. Matching validated result releases before Promise handoff and FIFO drain; caller retention after handoff is outside the budget.

The task-owned sample validates two small views of backing ArrayBuffers, each backing store at most 1024 bytes, and reserves the FULL distinct backing stores once within the job plus 1024 output units. Two aliased eight-byte views of one 1024-byte store cost2048, not their 16 visible bytes. Independent jobs reserve independently even when the same attached store is reused. Transferring it in one job can invalidate another queued job's borrowed input. Output validation enforces the sample's 1024-byte ceiling. The policy is a logical allowance, not an allocator limit.

Run `npm start`, open [the resource demo](http://127.0.0.1:8126/resource.html) and click **Run finite resource proof**. The separate packed-native acceptance uses installed public exports; see BROWSER-ACCEPTANCE.md for exact candidate/baseline commands. Deterministic tests cover exact ledger transitions, reentrancy, faults and termination ordering.

Worker/module baseline memory, temporary computation/clone allocations, malicious oversized output sent before validation, caller-retained buffers/results, browser overhead, RSS and garbage collection are outside this contract. Rocket owns its scene/demand/edit/publication and must bound combined pending plus completed-but-unpublished outputs itself. The standalone package copies no terrain algorithm and defines no terrain memory constant.
