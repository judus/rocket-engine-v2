# API and usage (0.4.0 candidate)

## Environments and build

The host runs in a browser Window with native module Worker support. The worker helper runs in a dedicated worker with `postMessage`, `close` and event listeners. Core emitted modules contain no Node/DOM-rendering/Rocket imports. Node is used only for development tools and tests; importing the package in Node is safe, but creating a native browser pool there is unsupported. Shared/service workers, arbitrary remote executors and main-thread fallback are not supported.

Serve emitted ESM and worker entries over HTTP from the same origin, or HTTPS for deployment. Correct JavaScript MIME types and your host's Worker CSP/origin policy are required. A file:// URL is not a supported demo setup. This project emits `dist/src` and `dist/examples`; `index.html` loads `dist/examples/main.js`, whose relative worker URL resolves to `dist/examples/tasks.worker.js`. Consumers compile/bundle their own worker entry and preserve the emitted URL relationship. A browser cannot resolve a bare npm import without a bundler/import map. A bundler may use `new URL('./task.worker.ts', import.meta.url)` as supported by that bundler; raw tsc output uses `.js`.

## Shared task declaration

Declare task names, input and output types. Runtime validators are mandatory, synchronous and must return exactly true; returning a Promise does not accept the value. They should be pure and enforce payload bounds, dimensions and domain identity. TypeScript declarations do not establish runtime validity.

```ts
interface Tasks {
  invert: { input: Uint8Array; output: Uint8Array };
}
const bytes = (value: unknown): value is Uint8Array =>
  value instanceof Uint8Array &&
  value.byteLength >= 1 &&
  value.byteLength <= 65536;
```

Example bounds: 1–65536 input/output bytes for inversion; 0–1000 ms for the deliberately slow diagnostic task. Callers must specify comparable finite bounds for their own tasks. Count bounds do not bound arbitrary worker allocations or caller-retained results.

## Worker entry

```ts
import { serveTasks } from "rocket-workers/worker";

const disposeWorker = serveTasks<Tasks>({
  invert: {
    input: bytes,
    handle(input) {
      const output = new Uint8Array(input.length);
      for (let i = 0; i < input.length; i++) output[i] = 255 - input[i]!;
      return { value: output, transfer: [output.buffer] };
    },
  },
});
```

`serveTasks` registers handlers, installs the protocol listener and returns idempotent cleanup that removes its listeners and closes the worker. Call it once per worker. It accepts synchronous or Promise-returning handlers and runs at most one handler at a time. Unknown tasks, input validation failure/throw and handler exceptions return a bounded task error. The host validates outputs independently.

## Host

```ts
import { createWorkerPool, WorkerPoolError } from "rocket-workers";

const pool = createWorkerPool<Tasks>({
  workerUrl: new URL("./task.worker.js", import.meta.url),
  tasks: { invert: { input: bytes, output: bytes } },
  size: 1,
  maxQueued: 0,
  startupTimeoutMs: 5000,
  jobTimeoutMs: 10000,
});

try {
  await pool.ready;
  const data = new Uint8Array([0, 12, 255]);
  const pending = pool.run("invert", data, { transfer: [data.buffer] });
  // data.buffer is now detached after successful dispatch.
  try {
    await pool.run("invert", new Uint8Array([1]));
  } catch (error) {
    if (!(error instanceof WorkerPoolError) || error.code !== "busy")
      throw error;
  }
  const inverted = await pending;
  console.log(inverted); // caller-owned [255, 243, 0]
} finally {
  pool.dispose();
}
```

`ready: Promise<void>` resolves only after a validated handshake. If all startup slots fail or time out, or disposal occurs before first readiness, it rejects. It has an internal rejection observer to prevent an unobserved startup rejection; consumers should still await it to handle failures. `run` before readiness rejects with `not-ready` immediately. Before first readiness, submissions are not retained. With defaults (size=1/maxQueued=0), a busy slot rejects immediately with `busy`. Configured pools dispatch on idle slots and admit FIFO waiting records up to maxQueued; a full positive queue rejects with `full`.

Invalid configuration throws synchronously, before worker creation: size must be an integer 1–16 and maxQueued an integer 0–256; defaults 1 and 0 preserve single-worker use. Deadlines are integers from 1 to 2147483647 ms, defaulting to 5000 and 10000. Unknown option keys reject; AbortSignal and explicit failed-slot restart are supported. Unknown settings (such as priorities) cannot be silently ignored from JavaScript. `run` validation/admission failures always reject its Promise.

`stats` returns an immutable snapshot with state, liveWorkers, occupied, queued, cancelledOccupied, cancelled, completed, failedJobs, rejected, discardedMessages and a bounded immutable slots array with index/generation/state/cancelled/error. liveWorkers includes starting workers. Counters saturate at MAX_SAFE_INTEGER. Pool retains only current/queued job metadata and a completed-ID watermark per slot/generation, never result history. Completed data belongs to the caller.

## Buffer ownership

Transfer is opt-in and restricted to unique attached ArrayBuffers reachable from the input/result. Typed array views transfer through their `.buffer`. Empty attached ArrayBuffers are valid; detached buffers are detected by constructing a view, which throws even for detached zero-length buffers. SharedArrayBuffers, duplicate entries and nonbuffers reject.

Reachability supports plain records/arrays, ArrayBuffers and ArrayBuffer views, with cycles. Only enumerable own string-keyed properties are traversed, matching ordinary structured cloning. Buffers referenced only by hidden/non-enumerable or symbol properties reject before detachment; hidden accessors are omitted. Enumerable accessors and class/Map/Set graphs with transfers reject. Inspection is bounded to 4096 objects and 8192 own properties; inputs requiring broader graph support are outside this version. With no transfer list, native structured clone handles the payload; task validators must enforce allowed data and size.

Not-ready/busy/invalid-input/invalid-transfer rejection occurs before detachment. Successful dispatch transfers ownership synchronously; later task failure, timeout or disposal does not return the input buffer. Never mutate borrowed input while queued or during validation/dispatch. Admission snapshots transfer-list entries, so mutating the original list container cannot remove a scheduled transfer. Input/transfer validation runs again at actual dispatch; detached or altered queued payloads reject without posting. Results transferred by a handler belong to the receiver; their worker-side buffer is detached. No fallback copy or hidden execution occurs. Queued cancellation never dispatches or detaches buffers; running cancellation cannot recover buffers already transferred. Native postMessage failure is fatal to the slot; no guarantee of buffer recovery is promised after attempting dispatch.

## Failure and cleanup

| Failure                                                                                                                       | Effect                                                                               |
| ----------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| Not ready, busy, unknown task, input validator false/throw, invalid transfer, unsupported run option                          | Reject submission; healthy worker unchanged; no dispatch                             |
| Worker unknown task, worker input validator false/throw, handler throw/rejection, invalid result transfer                     | Reject job with task error; later jobs may run                                       |
| Host output validator false/throw                                                                                             | Reject job and terminate affected slot (invalid remote output)                       |
| Worker construction/init error, native clone/postMessage failure, worker error/messageerror                                   | Terminate slot; reject affected readiness/current job                                |
| Invalid handshake, protocol/version/session mismatch, impossible job ID/concurrent handler, worker output postMessage failure | Terminate slot; reject owned promises                                                |
| Startup/job deadline                                                                                                          | Terminate slot before reporting zero occupancy; reject readiness/job                 |
| Job ID exhaustion                                                                                                             | Fail explicitly and terminate; IDs never wrap or repeat                              |
| dispose                                                                                                                       | Terminate, remove listeners/timers, reject pending readiness/job; future run rejects |

`WorkerPoolError.code` distinguishes `configuration`, `not-ready`, `busy`, `unknown-task`, `input`, `transfer`, `task`, `output`, `transport`, `protocol`, `startup-timeout`, `job-timeout`, `id-exhausted`, `failed`, `disposed`, and `state` (a validator changed pool state). Construction configuration/deadline errors can also be RangeError. M2 adds full and restart error codes; cancellations use DOMException with name AbortError rather than WorkerPoolError. Error text from worker task exceptions is capped at 1024 characters; do not use it to transfer secrets.

restartWorker(index) returns a new Promise for a failed slot's handshake. Only failed slots can restart; invalid index, live/starting slot or disposed pool rejects. It increments generation and never replays a failed job. No automatic retry or restart. Protocol messages use version, a random pool session, a session namespace per slot, increasing worker generations and increasing positive safe-integer job IDs within each generation. Well-formed duplicate completed responses are discarded, never accepted for a newer job. Mismatched or malformed current messages fail the worker. A provably older generation in the same session can be discarded, and callbacks from terminated attempts are ignored before inspecting the replacement.

Disposal is synchronous and idempotent: termination, zero owned live workers/jobs, listener/timer removal, clearing validators/current-job references and rejecting promises. Late callbacks cannot resurrect the pool. Browser `terminate()` stops execution without giving worker tasks a cleanup opportunity. Handler code must not rely on a final callback to save domain state. Browser internal reclamation/GC and caller-retained outputs are not total memory guarantees. Pure runtime validators are trusted callbacks, not a security boundary against malicious in-process code.

Worker timeouts use host wall-clock timers; browser throttling can delay delivery. There is no own engine clock or rendering loop. M2 does not claim measured speedup or solve Rocket stream admission under rapid camera cancellation; those integration/measurement gates remain separate.

References: [Worker termination](https://developer.mozilla.org/en-US/docs/Web/API/Worker/terminate), [Transferable ownership](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Transferable_objects).

## Readiness, bounded admission and cancellation

```ts
const pool = createWorkerPool<Tasks>({
  workerUrl: new URL("./task.worker.js", import.meta.url),
  tasks: { invert: { input: bytes, output: bytes } },
  size: 2,
  maxQueued: 4,
});
await pool.ready; // first usable slot, not every initial worker
const controller = new AbortController();
const result = pool.run("invert", new Uint8Array([10]), {
  signal: controller.signal,
});
controller.abort();
try {
  await result;
} catch (error) {
  if (!(error instanceof DOMException) || error.name !== "AbortError")
    throw error;
}
console.log(pool.stats.cancelledOccupied); // may remain nonzero until actual work finishes
```

`ready` is the original startup Promise and is never replaced by a restart. It resolves when the first slot completes a validated handshake, rejects if every initial slot fails, or rejects on disposal before first readiness. Other initial slots can still be starting/failed; inspect slots stats for degraded capacity. Before first handshake, run rejects not-ready. After first readiness, if no idle slot exists, the bounded queue can wait for occupied or starting workers. If no live/starting worker can drain, queued jobs reject promptly with failed, and new admissions reject. A failed initial ready can recover only via explicit restart: await restartWorker(index), then submit; the original ready remains rejected.

Every slot has at most one physically dispatched job. At most size workers (including starting workers), size occupied slots and maxQueued borrowed queued payloads exist. FIFO is dispatch order, not completion order. There is no priority policy, retry queue, secondary submission queue or result cache. Reentrant validators cannot exceed these admission limits; validators should remain pure.

Abort before admission rejects once with AbortError without a record or transfer. Queued abort removes its record/listener and rejects once while buffers remain attached. Dispatched abort immediately rejects its Promise and removes its signal subscription but preserves the job's identity, deadline and physical slot. A synchronous handler cannot process interrupt messages; ordinary cancellation sends none and never automatically terminates/restarts a worker. Its eventual response is validated for protocol correlation, discarded without semantic output validation, and frees only that slot. cancelledOccupied tracks this remaining physical work. A malformed/mismatched cancelled response still fails its worker. A running deadline starts only at actual dispatch, including continued occupancy after cancellation.

Task errors leave their worker healthy. Fatal transport/protocol/output failure or deadline terminates only the affected slot and settles its current job; healthy slots continue draining FIFO. Failed-slot restart creates a new worker/generation and a fresh handshake Promise, which rejects if that startup fails or the pool disposes. ready is not replaced; no failed job is replayed. Queued work may wait during an explicit restart only if admission was already enabled by a prior handshake. Slot failures are bounded error strings, not histories. IDs/generations fail explicitly on exhaustion rather than wrapping; fresh generation uses its own ID namespace.

Dispose settles every queued/running/initial/restart Promise, removes AbortSignal subscriptions and deadlines/listeners, terminates all owned workers and ignores late callbacks. Count diagnostics reach zero immediately after owned termination; browser GC remains outside the memory contract. Completed/cancelled counters count logical outcomes once; cancelled work that later times out does not increment failedJobs again. rejected counts admission rejection, and discardedMessages counts well-formed duplicates/stale generations/cancelled responses. Cancelled results are never returned to callers.

## M2 demo and proof

Run npm start and open [pool.html](http://127.0.0.1:8126/pool.html). Manual controls fill/overflow a one-worker/two-queue pool, cancel running or queued jobs, throw a healthy task error, trigger a native worker error or a running deadline, restart a failed slot and dispose/recreate. Refresh diagnostics reads current stats without a persistent polling/render clock. Fill uses a finite one-second synchronous worker task; cancel promptly or use the automated proof for repeatable occupancy evidence.

Run pool browser proof exercises multiple actual workers, FIFO saturation, cancellation, queued buffer transfer timing, native worker failure, distinct restart readiness, deadlines/all-worker queue draining and final disposal. The original single-worker/transfer proof at index.html preserves all accepted M1 cases including hidden-only buffer rejection. Proof-only readiness sampling is finite and does not add a clock to the package. No terrain task or Rocket adapter is included.

## Optional declared-cost admission

PoolOptions.admission accepts AdmissionPolicy<T>; PoolStats.admission exposes frozen AdmissionStats. See [complete resource contract and byte example](RESOURCE-ADMISSION.md). It adds cost/resource-full/cost-changed errors without altering existing busy/full/unknown-task codes or the worker protocol. Declared reservations end at validated output handoff and are not heap measurement.

## Fixed timing diagnostics

PoolStats.timings and optional PoolOptions.diagnostics.computeMs add fixed lifetime summaries and guarded task-reported compute. See [complete timing contract](TIMINGS.md). Queue wait excludes initial admission callbacks and includes dispatch revalidation. Censored termination populations are distinct from validated response durations; no transfer-cost or speedup claim.
