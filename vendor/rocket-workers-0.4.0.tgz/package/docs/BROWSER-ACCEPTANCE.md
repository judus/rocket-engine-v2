# Automated native browser acceptance (Q1)

This development-only gate installs the accepted M2 archive into an owned temporary consumer and serves its installed public ESM exports. It never runs workspace src in Chromium. No runtime API, package version or accepted archive changes.

```sh
npm ci
npm run browser:install
npm run check
npm run smoke
npm run test:browser
```

Node/npm, a supported Chromium host and free loopback port 8128 are prerequisites. Playwright is pinned to 1.64.0; browser:install downloads its matching Chromium to node_modules/.cache/rocket-workers-browsers (or the explicit PLAYWRIGHT_BROWSERS_PATH). It does not install OS packages. Missing prerequisites fail; no skip, fake transport or execution fallback. Installation on this Linux Mint 22 host selected Playwright's Ubuntu 24.04 build; the native gate ran Chromium 156.0.8078.4. Other platforms are unverified.

The default input is artifacts/rocket-workers-0.2.0-m2.tgz, SHA-256 2ea111be07feed5c90ea0c1c2becac9fa52e1a66514ae1efa4dfca5488000599. The gate checks archive and accepted src hashes before setup, installs the archive offline with scripts disabled, resolves rocket-workers and rocket-workers/worker from that consumer, compiles fixtures against its public declarations, and serves JavaScript with explicit relative module Worker URLs. Fixture host-entry declarations in the workspace exist only for strict development type checking; temporary consumer declarations are freshly generated from the installed package. Existing default/pool scenario bodies are copied with only their entry imports rewritten.

Six serial tests, one runner, zero retries: 18 default proof checks, 15 pool proof checks, 3 adversarial correlation checks, 2 blocked-worker/restart checks, 1 captured callback check and 10 lifecycle cycles. Each test owns a fresh browser context. The adversarial LIVE native worker sends duplicate and old-generation headers; the deliberately captured HOST callback test is explicitly instrumented. Neither claims natural traffic from an already terminated worker.

Worker instrumentation subclasses and forwards to the real native Worker; it counts constructor/termination, event registrations and owned AbortSignal subscriptions without changing message delivery. All cases assert zero live handles/listeners/subscriptions and no duplicate termination. Ten cycles also assert zero occupied/queued/cancelled jobs, including pre-ready disposal and cancellation while physically running. These are pool-owned accounting checks, not RSS, garbage collection or browser thread reclamation evidence. Deterministic unit tests retain exact race/timer coverage.

Timeouts: server startup 20 seconds, each case 15 seconds, global test suite 90 seconds, outer runner 150 seconds, server graceful teardown 5 seconds. Existing services are never reused or killed. The server removes its temporary consumer on SIGTERM/exit; the outer runner verifies removal and fails if emergency cleanup is needed. Forced external SIGKILL of the runner cannot guarantee cleanup. Run from the project root.

Machine-readable results and attached native evidence are overwritten in artifacts/Q1-browser-results; six tests bound traces/screenshots to failures, case details to 100 and instrumentation records to 256. Negative runs use separate Q1-negative-hash/module directories. HTTP failures and page errors are checked; only default-proof's deliberate missing.worker.js 404 and pool-proof's exact deliberate crash error are allowed. There is no blanket error suppression.

```sh
npm run test:browser -- --negative-hash
npm run test:browser -- --negative-module
```

Both MUST exit nonzero: the first rejects setup before installation, the second serves an intentionally missing public host module and cannot reach readiness. They never alter the accepted archive. An occupied 8128 also fails immediately. Successful positive results must be read separately from intentional negative evidence.

The existing smoke gate repacks the current development checkout into its own temporary consumer. Its archive digest differs as tooling/docs evolve; it does not replace or repin the accepted M2 archive. Q1's browser gate uses the exact accepted archive. Future candidate artifacts and Firefox/WebKit need separate agreement.

## Explicit Q2 candidate and retained baseline

The explicit browser:install prerequisite only downloads the pinned browser and does not execute the pool, so it can run on either checkout. On the intentional Q2 source checkout, default Q1 execution identity verification refuses changes. Keep its original manifest/archive/evidence immutable. Build/pack the candidate and select ALL three explicit arguments; a supplied source manifest identifies the checkout separately from the installed archive. The candidate fixture verifies every installed dist/src file against just-built emitted files, then resolves its public exports and reports runtime digest/version. Never infer candidate provenance from a supplied source manifest alone.

```sh
npm run build
npm pack --pack-destination artifacts
sha256sum artifacts/rocket-workers-0.3.0.tgz
npm run test:browser -- --artifact artifacts/rocket-workers-0.3.0.tgz --sha256 <candidate-sha256> --runtime-manifest artifacts/Q2-runtime.sha256
npm run test:browser -- --artifact artifacts/rocket-workers-0.2.0-m2.tgz --sha256 2ea111be07feed5c90ea0c1c2becac9fa52e1a66514ae1efa4dfca5488000599 --runtime-manifest artifacts/Q2-runtime.sha256
```

Use the exact final candidate SHA recorded in Q2-REPORT.md. Q2-runtime.sha256 records intentionally changed src after build review; it never replaces Q1-runtime.sha256. Partial/unknown options, missing archive, hash mismatch, runtime mismatch and installed candidate/build mismatch fail. Candidate0.3.0 runs all six legacy suites plus three resource suites; the retained0.2.0 baseline runs six suites only. Explicit resource mode cannot silently skip missing candidate prerequisites. Baseline results overwrite artifacts/Q2-baseline, candidate artifacts/Q2-candidate; negative modes append -negative-hash/module. Q1 evidence is preserved. No repin or Rocket consumer upgrade.

## Q3 execution selection

The same explicit artifact/SHA/current-runtime-manifest bundle now supports candidate0.4.0, retained accepted0.3.0 and original0.2.0. Select artifacts/Q3-runtime.sha256 for the intentional Q3 checkout. Candidate0.4.0 verifies installed dist/src against just-built emitted files and runs the nine inherited suites plus three timing suites. The retained0.3.0 digest f31b0af4b3d5ebd094de08f203092c088afd9baa1004ccad9bbbb8b6c4fe175f runs nine suites; original0.2.0 runs six. Neither baseline is expected to match the intentionally changed0.4.0 emission. Their exact archive SHA is the provenance anchor and is reported separately from checkout identity.

```sh
npm run test:browser -- --artifact artifacts/rocket-workers-0.4.0.tgz --sha256 <Q3-candidate-sha-from-report> --runtime-manifest artifacts/Q3-runtime.sha256
npm run test:browser -- --artifact artifacts/rocket-workers-0.3.0.tgz --sha256 f31b0af4b3d5ebd094de08f203092c088afd9baa1004ccad9bbbb8b6c4fe175f --runtime-manifest artifacts/Q3-runtime.sha256
npm run test:browser -- --artifact artifacts/rocket-workers-0.2.0-m2.tgz --sha256 2ea111be07feed5c90ea0c1c2becac9fa52e1a66514ae1efa4dfca5488000599 --runtime-manifest artifacts/Q3-runtime.sha256
```

Output directories are artifacts/Q3-candidate, Q3-accepted-q2 and Q3-baseline, with separate negative suffixes. No Q1/Q2 evidence overwrite, baseline repin, dependency addition, missing-candidate skip or execution fallback. Clock metrics use task-controlled ordering/finite values in native tests; exact boundaries and prefix arithmetic are deterministic tests, not timing speed benchmarks. Module-negative stops on its first readiness failure; remaining cases are intentionally not run.
