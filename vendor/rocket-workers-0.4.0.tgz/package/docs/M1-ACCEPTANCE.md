# M1 review contract

Approved by Rocket Engine v2 in mailbox message 62; agreed in message 66. No M2+ authorization.

1. Standalone browser ESM host/worker entry points; one live slot, maxQueued=0, finite validated non-terrain task, no hidden queue/domain dependency/clock.
2. Explicit ready Promise; validated handshake or failure/timeout/disposal. run before ready rejects without transfer.
3. Publish only implemented M1 API; reject invalid/unsupported configuration and options.
4. One active handler; validate protocol version/session/generation/job IDs; fatal malformed/current/future mismatch; discard proven stale/duplicate response; explicit ID exhaustion and bounded records.
5. Observable exactly-once validation/task/constructor/clone/error/messageerror/deadline failure; classify healthy task versus fatal slot failures; timeout terminates actual work.
6. Real browser unique reachable transfer detachment, intact rejected-admission buffers, correct output transfer; duplicate/invalid/detached detection tested and ownership limits documented.
7. Idempotent dispose before ready/during work/after completion; remove timers/listeners/payload references and ignore late callbacks; later run rejects.
8. Strict TypeScript, type-aware lint, formatting, emitted build/tests, dependency-free packed-package import/type smoke. Real browser demo and docs covering HTTP/module URLs, readiness, transfer, busy and cleanup.

Report source/package digest, files, exact checks/results, demo URL/start command and lifecycle/transfer evidence. Stop after M1 report for Rocket's independent review and acceptance before M2.
