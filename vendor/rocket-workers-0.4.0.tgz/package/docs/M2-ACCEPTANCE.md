# M2 review contract

Rocket accepted M1 correction1 and approved M2 in message 83. Agreement/refinements in message 87. No M3+ authorization.

1. Finite integer size 1–16/maxQueued 0–256, defaults 1/0; bounded worker slots, dispatched jobs and FIFO records. Same implementation preserves M1 safeguards; no priority/retry/history/secondary queue.
2. Initial ready resolves at first usable handshake or rejects if all initial slots fail. Pre-first-ready admission rejects; degraded slots visible. Failed-slot restart returns a fresh handshake Promise without replacing initial ready.
3. Early/queued abort rejects once, removes subscriptions/records and preserves attached buffers. Running abort rejects once, retains physical slot/identity/deadline and never silently terminates/restarts work.
4. Admission before transfer; explicit borrowed input and snapshotted transfer-list lifetime. Revalidate at dispatch, job deadline begins there. Cancelled responses cannot fulfill newer jobs or retain outputs.
5. Slot-specific failure terminates worker and settles affected work, healthy slots drain FIFO. No usable/starting slot drains queue/rejects admission. Explicit failed-only restart increments generation without replay; stale callbacks/messages cannot affect replacement.
6. Dispose settles initial/restart/queued/running promises, subscriptions/deadlines/listeners/workers. Stats distinguish queued/occupied/cancelledOccupied and bounded counters/slot metadata.
7. Deterministic failure/race tests cover ordering, cancellation storms, result/abort races, timeout/restart, partial/all failure, stale/duplicate IDs, queue saturation, validator reentrancy, transferred/queued buffer lifetime and all M1 hidden-transfer regressions.
8. Real browser pool controls/proof for saturation, queued/running synchronous cancellation, task error, native worker error/deadline, restart and final disposal. API/usage/ownership docs, strict TS/lint/format/build/tests, packed public runtime/type checks, artifact/source identity and report required.

Report M2 and stop for Rocket independent acceptance. Rocket owns eventual terrain worker/ChunkLoader/demo under a later M3 gate; M4 measurements are separate.
