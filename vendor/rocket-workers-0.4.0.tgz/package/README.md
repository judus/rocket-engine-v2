# Rocket-Workers

Standalone TypeScript execution in native browser module workers. Candidate 0.4.0 adds [bounded timing diagnostics](docs/TIMINGS.md), retaining accepted 0.3.0 declared-cost reservations; [resource contract and demo](docs/RESOURCE-ADMISSION.md). M2 supports 1–16 workers, a finite FIFO queue, AbortSignal and explicit failed-slot restart. Defaults retain one worker with no waiting queue. Rocket, rendering, world state and terrain algorithms are not dependencies.

```sh
npm ci
npm run check
npm run smoke
npm start
```

Open [the local demo](http://127.0.0.1:8126/) and click **Run browser acceptance proof**. This uses real module workers, transfers, deliberate errors, timeouts and disposal. The missing-worker 404 is an intentional startup-failure check. The finite slow task blocks its worker for at most one second; it does not block the main thread. The demo worker can be disposed separately. There is no performance benchmark in M1.

Open [the pool demo](http://127.0.0.1:8126/pool.html) for saturation, queued/running cancellation, failure/restart and final disposal controls plus the multi-worker proof.

The package has no runtime dependencies. Build/check dependencies are pinned in package-lock.json. Only `rocket-workers` and `rocket-workers/worker` are public entry points. [API and usage](docs/API.md), [M1 acceptance](docs/M1-ACCEPTANCE.md), and [roadmap](PLAN.md) describe the contract and review gates.

M1 correction1 and M2 are accepted. Q1 automates native acceptance of the pinned M2 archive without changing its runtime. See [browser gate prerequisites, commands and limits](docs/BROWSER-ACCEPTANCE.md). Further quality milestones require separate Rocket approval.
