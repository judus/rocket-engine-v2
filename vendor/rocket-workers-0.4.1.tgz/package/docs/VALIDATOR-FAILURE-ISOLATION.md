# Validator failure isolation — 0.4.1

WORKERS-001 fixes an extra unhandled rejection when an invalid JavaScript validator returns a rejected native Promise. Host input, host output and worker input now retain the return value and attach a guarded native Promise rejection handler before requiring exactly `true`. The handler bypasses an overridden `.catch`. Nothing awaits a validator: even a Promise resolving to true is invalid.

Use synchronous validators with the existing type predicate signature. Host input still rejects with `input`; host output still rejects with `output` and fails the affected worker; worker input still emits the bounded task error and skips its handler. Reentrant cancellation/disposal continues to take precedence under the existing lifecycle guards. Promise rejection consumption does not add a new task, queue, retry, timeout or protocol field.

Controlled subprocess tests cover rejected, async-rejecting, overridden-catch and resolved native Promises across all three paths. They also verify output abort/disposal and worker-input disposal, then wait through event-loop turns and require zero unhandled rejections. These tests exercise callback failure isolation; they do not certify all browsers or arbitrary thenables/modified Promise constructors.

The existing standalone demos and timing/resource APIs are unchanged. Run `npm run check`, `npm run smoke` and the explicit artifact native gate described in the correction report. Accepted 0.4.0 archives and evidence remain historical baselines; Rocket owns its consumer upgrade.
