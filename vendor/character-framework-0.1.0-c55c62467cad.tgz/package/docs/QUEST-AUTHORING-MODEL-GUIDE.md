# Model guide: one new visit

For `cfw-authoring-prototype-1`. This is a syntax reference for the bounded visit proof, alongside the live capability catalogue. A valid graph can still fail the requested task: technical review checks executable structure, not whether the author's prose is true.

## Brief and contracts

Fictional fixture context: Old Grove is a quiet woodland beside a village. A surveyor wants the player to visit it anew. These supplied facts are narrative input, not additional executable capabilities.

Required behavior: complete automatically on a **new entry into grove after activation**. A previous visit or already being inside does not count. No dialogue, player choice, reward, NPC, or extra action is required. If evidence is unavailable, do not claim completion.

First call `read_quest_draft` with `{"section":"catalogue"}`. Confirm the permitted inspection `rocket_inspect_grove`, argument `locationRef:"grove"`, numeric output `entries`, and event evidence contract. Do not substitute a current `inside` or historical `visited` fact for the requested new event.

## Canonical edit

Use IDs and current revisions returned by the tools. Replace the placeholders below; do not send them literally. This graph is the fixture's tested `visitFragment` in `examples/authoring-prototype-fixture.js`.

```json
{
  "draftId": "RETURNED_DRAFT_ID",
  "expectedRecordRevision": 1,
  "operations": [
    {
      "kind": "replace_beat_implementation",
      "beatId": "main",
      "implementation": {
        "entrySituation": "watch",
        "situations": [
          {
            "id": "watch",
            "routes": [
              {
                "id": "entered",
                "priority": 10,
                "when": {
                  "tool": "rocket_inspect_grove",
                  "arguments": { "locationRef": "grove" },
                  "expect": {
                    "path": ["entries"],
                    "operator": "at_least",
                    "value": 1
                  },
                  "evidence": {
                    "mode": "events",
                    "after": { "kind": "run-start" }
                  }
                },
                "next": "end"
              }
            ]
          },
          { "id": "end" }
        ],
        "outcomeBindings": []
      }
    }
  ]
}
```

The condition belongs in `routes[].when`. It uses `tool`, `arguments`, `expect`, and `evidence`; `expect.path` is an array. `run-start` establishes the event boundary when the host starts the runtime. The terminal situation has no waiting dialogue or choice. This condition tests at least one captured subsequent entry, not the lifetime entry count.

## Planning, correction, resume, publication

1. Create with `create_quest_draft({"intent":{"title":"Visit Old Grove","premise":"Make a new visit to the grove."}})`. The prototype supplies beat `main`.
2. Save the implementation with `edit_quest_draft` using the returned revision. An incomplete supported fragment can be saved; missing destinations remain review findings and block publication.
3. Call `review_quest_draft({"draftId":"RETURNED_DRAFT_ID","recordRevision":CURRENT_REVISION})`. Correct the indicated fields by replacing the beat; **do not remove the new-entry requirement to make validation pass**. Use the revision returned by each edit and review again.
4. To resume without conversation history, call `list_quest_drafts({})`, then `read_quest_draft({"section":"overview","draftId":"SAVED_DRAFT_ID"})` and `read_quest_draft({"section":"beat","draftId":"SAVED_DRAFT_ID"})`. Read actual saved graph and current revision before editing.
5. Before publishing, compare the saved graph with the brief: grove reference, event mode, run-start boundary, entry count predicate, reachable terminal, no player choice/dialogue/reward. Advisory narrative review is an opinion, not proof of this comparison or game completion.
6. Call `publish_quest_draft({"draftId":"RETURNED_DRAFT_ID","expectedRecordRevision":CURRENT_REVISION})` only after technical readiness and brief conformance. Publication stores an immutable definition and creates no game run. Published prototype drafts are read-only.

The host separately imports and starts the stored definition. The actual acceptance check must exclude a prior entry, then show that a new outside-to-inside crossing closes the run without another AI call. A successful publication alone does not prove this behavior.

Transport mutation identities are connector-owned. Keep the original key and arguments for exact retries; do not put guessed mutation keys into tool arguments. Broader arcs, prepared-command crash recovery, cross-binding recovery, paging and production workers remain outside this first proof.
