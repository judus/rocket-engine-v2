# Synchronized sprite layers

`createLayerSet` and `sampleLayers` compose body, clothing and equipment around one existing `AnimationPlayer`. Core remains DOM-free. A layer set contains metadata only: no images, timers, listeners or gameplay state.

```ts
import {
  AnimationPlayer,
  createLayerSet,
  sampleLayers,
} from "sprite-animation";
import { drawSprite } from "sprite-animation/canvas2d";

// bodyAtlas and shirtAtlas contain the same named frames as timelineAtlas.
const look = createLayerSet({
  timeline: timelineAtlas,
  layers: [
    { id: "body", atlas: bodyAtlas },
    { id: "shirt", atlas: shirtAtlas },
    {
      id: "weapon",
      atlas: weaponAtlas,
      frames: { walk: ["low", "high"] },
    },
  ],
  order: {
    walk: [
      ["weapon", "body", "shirt"],
      ["body", "shirt", "weapon"],
    ],
  },
});
const player = new AnimationPlayer(timelineAtlas);
player.play("walk");
const completion = player.advance(dtSeconds); // exactly one update owner
const composed = sampleLayers(look, player.snapshot);
for (const layer of composed?.layers ?? []) {
  drawSprite(ctx, images[layer.id], layer.frame); // images owned by the host
}
```

The example assumes a two-step `walk` clip and host-defined atlases, image map, context and elapsed time. The [runnable fixture](../examples/layers/fixture.ts) supplies concrete metadata.

## Metadata rules

`createLayerSet(input: LayerSetInput): LayerSet` requires a validated timeline atlas and a nonempty dense layer array. Each `{id, atlas, frames?}` has a unique nonblank ID and an atlas created by `createAtlas`. It copies/freeze-protects mappings and compiles draw steps once. The returned metadata is reusable across independent players.

With no `frames` entry for a timeline clip, each layer uses that step's timeline frame **name**. Thus same-layout sheet variants can reuse exactly the same atlas. A different layout may use different frame rectangles, dimensions and pivots. Its `frames[clip]` must contain exactly one frame name or `null` per timeline step. Null explicitly hides a layer; unknown names and missing entries throw. A layer's own atlas clip durations do not participate in playback. A layer atlas still follows the existing `createAtlas` contract, which requires at least one clip.

`order[clip]`, when present, has one dense array per timeline step. Every inner array must be a complete permutation of the declared IDs, back to front. Hidden layers remain listed but produce no draw item. Without an order mapping, declaration order applies. Unknown clip keys, sparse arrays (including inherited array holes), duplicates and wrong lengths throw during preparation.

Frames align at their pivot origins. The host applies character transforms and flips once through the existing Canvas adapter. There are no implicit offsets or automatic collision geometry. Different directions can be ordinary clips such as `walk_up`, selected by the game; weapon/equipment rules produce data outside the package.

## Sampling and changing appearance

`sampleLayers(set, snapshot: FrameSnapshot | null): LayerSnapshot | null` returns `{timeline, layers: readonly {id, frame}[]}` or null for an idle/disposed player's null snapshot. Output and nested metadata are frozen. Each layer frame has its own source/pivot/bounds/atlas dimensions, with the master's clip, step index, seconds phase, generation, rate, mode and status. `frameIndex` identifies the **timeline step**, not a layer atlas clip step. Each frame can be passed directly to `drawSprite` or `getSpriteBounds`.

Sampling checks that the master snapshot's current clip/step, canonical geometry, dimensions and playback fields agree with the set's timeline. Equivalent structural snapshots are accepted; this is a compatibility check of the current step, not provenance authentication or a promise that every other clip of another atlas is identical. Use the same timeline atlas for all interchangeable looks.

Prepare alternate layer sets first, then select one when sampling the unchanged master. This preserves phase, pause state, rate, generation and completion eligibility, including after a once clip completes. Same-layout recolors can instead replace the host's image for an ID without replacing the set. Never create or advance one player per layer. Draw and sample can run for several views without consuming time. Only the master `advance` returns completion; there are no per-layer events.

Dispose the master player at the host lifecycle boundary. Layer sets have no dispose method because they own no runtime resources. The host releases images and its clock/listener scope separately. The adapter borrows images and does not close them.

## Try it

- `npm run demo:layers:headless` prints variable-duration steps, ordering, completion and disposal.
- `npm run demo:layers`, then open `http://127.0.0.1:8098/examples/layers/` for two views, shirt swaps, weapon visibility and per-step draw order, loop/once/pause/rate, mirror and destroy/recreate.
- The demo's **Run checks** button runs deterministic native Canvas pixel/state/cleanup checks over ten cycles.
- `npm run proof:layers:prepare`, serve this directory on port 8098, then open `http://127.0.0.1:8098/artifacts/layers-proof/` and click **Run packed checks** to exercise the exact archive ESM. A successful result is `status: PASS`, 230 assertions and 30 released Canvas source backings across ten cycles. A thrown check displays FAIL and does not claim success.

Art is generated locally in code. The demo owns one RAF, an abortable control scope and three canvas sources per lifetime. Destroy cancels RAF, aborts controls, disposes the player and clears owned source backings. Recreate first destroys the old lifetime; a separate page scope owns the destroy/recreate/check buttons and ends at pagehide.

This slice does not import a ManaSeed pack, implement reverse playback, add blending/skeletons or change Rocket consumers. Existing single-sprite APIs remain available.
