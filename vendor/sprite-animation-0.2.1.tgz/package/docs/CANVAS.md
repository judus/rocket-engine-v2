# Optional Canvas2D adapter — M2

Import core from `sprite-animation`; import `drawSprite`, `getSpriteBounds` and `SpriteImage`/`DrawOptions` from `sprite-animation/canvas2d`. Only the Canvas subpath needs DOM declarations. Core exports remain DOM-free, including when the package is installed independently.

```ts
import { AnimationPlayer } from "sprite-animation";
import { drawSprite, getSpriteBounds } from "sprite-animation/canvas2d";
// atlas and ready image are explicitly supplied by this consumer.
const player = new AnimationPlayer(atlas);
player.play("walk");
player.advance(dtSeconds); // exactly one host update owner
const frame = player.snapshot;
if (frame) {
  ctx.save();
  try {
    ctx.translate(100, 120); // caller supplies transforms, camera and scale
    drawSprite(ctx, image, frame, { flipX: true });
    const bounds = getSpriteBounds(frame, { flipX: true });
    ctx.strokeRect(bounds.x, bounds.y, bounds.width, bounds.height);
  } finally {
    ctx.restore();
  }
}
player.dispose(); // never closes the consumer's image
```

Supported ready sources in this slice are same-realm HTMLCanvasElement, HTMLImageElement and ImageBitmap. Canvas/bitmap width and height are intrinsic pixels. HTMLImageElement uses complete plus positive naturalWidth/naturalHeight, never display/CSS width or height. Loading/broken images, closed bitmaps, zero-size canvases, mismatched declared atlas dimensions and unsupported source objects throw. No OffscreenCanvas, video, SVGImageElement or cross-realm support is promised. Browser decode and CORS remain the consumer's responsibility. The adapter never fetches, decodes or caches.

`drawSprite(ctx, image, frame, options={})` validates safe pixel rectangles within declared dimensions, finite/nondegenerate pivots and matching visual bounds, boolean flips and actual source dimensions before saving context. It accepts the frame snapshot returned by the core. Invalid/null geometry or options throws. Snapshot status/phase is not interpreted as timing input; paused/completed frames draw normally. The source is borrowed and must remain alive through drawing; the caller must not release it prematurely.

Destination rectangle is exactly `(-pivot.x, -pivot.y, source.width, source.height)` in local coordinates. Existing caller transforms/styles/clip compose naturally. flipX/flipY mirrors around local origin by scaling -1 on that axis, so bounds become `(pivot.x-width, pivot.y-height)` on flipped axes. `getSpriteBounds` returns the matching frozen local visual rectangle without touching a context/image/player. Off-center/outside pivots are supported subject to the core's nondegenerate numeric bounds validation. These rectangles never update physics geometry.

Context save/restore is protected by finally after a successful save, including drawImage failure. Smoothing, globalAlpha, composition and clipping stay caller-owned and are not changed by the adapter. Draw does not clear/resize the canvas, advance animation, schedule work or release images. Canvas errors propagate after restoration.

## Standalone demo and cleanup

`npm run demo:canvas`, then open `http://127.0.0.1:8095/examples/canvas/`. The original 96×32 atlas is drawn in code into a caller-owned canvas. A and B share this image with independent players; A appears in both canvases. Both players advance once from one host requestAnimationFrame; three draws normally occur per tick. Flip control changes may cause extra paints without consuming time.

A's controls: clip, loop/once, play/restart, pause/resume, reset (new paused generation), rate including zero and both flips. B independently plays blink at rate 0.6. Cyan crosses mark pivots and gold rectangles show visual bounds. Playback counters expose phase/generation/completion and update/draw counts.

Destroy cancels the one pending frame, aborts nine host UI listeners, disposes both players once and displays disposed/null snapshots plus final counters. Recreate first destroys any prior host, then creates fresh players/artwork and one clock/listener scope. Two persistent lifecycle button listeners remain until pagehide, where the page controller removes them and its pagehide handler. The image is a canvas with no close/dispose API; releasing the destroyed host closure permits collection. Native ImageBitmap ownership is consumer-managed, never assumed by adapter/player.

Tests use simulated source/context objects for exact rectangles, validation and restore paths; real browser inspection is required separately. This demo establishes the standalone Canvas slice, not Rocket transforms/picking/leases or population capacity.

Native browser source verification is runnable at `http://127.0.0.1:8095/examples/canvas/verify.html` after the same build/server command. It checks actual canvas/image/bitmap sources, intrinsic dimensions, closed/unready/mismatch rejection, real context restoration after an injected drawing failure, clipping preservation and cleanup. It uses an original locally drawn PNG data URL, owns and closes its bitmap, and needs no external asset.

## Preparation-time readiness (0.2.1 candidate)

`validateSpriteImage(atlas: Atlas, image: SpriteImage): void` is exported only from `sprite-animation/canvas2d`. It accepts an atlas produced by createAtlas and synchronously checks the same intrinsic/readiness rules used by drawing, without creating a player or touching a context. Invalid/forged atlas and unsupported sources throw TypeError; unready/failed/closed/zero-size sources or mismatched dimensions throw RangeError. Validation does not acquire, retain, mutate or release anything, on success or failure.

```ts
import { validateSpriteImage } from "sprite-animation/canvas2d";
validateSpriteImage(atlas, readyBorrowedImage); // before installing a presentation
```

The image's consumer owns decoding/acquisition and lifetime. An acquiring host must release its own image lease when preparation fails or is cancelled, including validation failure; this function has no lease authority. Validation describes this instant, not permanent readiness. Reloading an HTMLImageElement, resizing a canvas or closing a bitmap afterward can invalidate the association. Public drawSprite retains its checks on every draw, so validation is never an unchecked rendering token.

## Packed native browser acceptance

Run `npm run proof:browser` from this project. It builds/packs, verifies installed public entry points, extracts the exact local archive and emits a deterministic self-running page at `http://127.0.0.1:8097/artifacts/browser-proof/`. Its import map resolves the two public package specifiers to extracted archive ESM, not workspace source. Package version/filename/SHA256 are included in ARTIFACT.json and in the result. `npm run proof:prepare` prepares the fixture without starting a server. Python's server binds loopback only and exits nonzero if the port is occupied; it does not reuse or kill another server. Port 8097 is separate from the existing demo server.

Assertions run automatically when loaded in a native browser. Each image/bitmap decode has a 3-second deadline, with a 20-second whole-page watchdog covering module load/errors/unhandled rejection. Results appear as JSON text in `#result`: `{schema:1, completed:true, status:'passed'|'failed', artifact, assertions, failures, resources}`. A load/watchdog failure may omit assertion/resource fields because the suite never initialized; always require schema=1, completed=true, status=passed, no failures and matching expected artifact digest. Missing/incomplete/malformed results are failures, not success. The script also emits PASS lines. Fixture resource counters are explicit ownership counts, not measurements of browser GC or GPU memory.

Use `?fail=1` for a reproducible failure after normal resource cleanup. It must produce completed=true/status=failed with an Injected proof failure entry. The same assertions exercise actual decoded local PNG, all supported sources/error cases, two independent players and two presentations, read-only rendering, completion/snapshot/bounds contracts, real context state/clip preservation, ten finite creation/cleanup cycles, closing one presentation without releasing the shared bitmap and final owner closure after disposing players. Late bitmap completion after a decode deadline is explicitly closed.

Execution through the documented browser tool is runner-assisted native-browser verification. These are automated assertions, not unattended CI or cross-browser coverage. Actual Rocket node/view/scene/lease lifetimes, transformed picking, callback hooks and index refresh belong to Rocket's separate acceptance suite.
