# Character Framework

A framework that gives characters a brain and owns reusable quest and dialogue systems for any game. Characters include embodied NPCs and unseen story/lore directors. Personality, memories, relationships and motives influence dialogue, quests and behavior, while the game retains its rules and Rocket owns navigation and movement.

The first connection binds a framework character instance to a CAI character and one persistent game-owned session for chat, session-scoped memories and quests. Behavioral reasoning, local execution and autonomous decisions develop from that connection. Games expose inspection/actions through MCP; physical entities are optional. Scripted characters can still operate without CAI.

Status, 13 October 2026: shared runtime, scoped MCP, CAI host integration and bounded quest/dialogue services are delivered with retained joint proofs. The new authored situation-flow API implements neutral conditional routes, entry actions and per-condition evidence with no AI dependency. See [Situation flow API](docs/SITUATION-FLOWS.md) for the typed game adapter, recovery contract and limits. Rocket physical integration and production world durability are separate owned gates.

```sh
npm ci
npm run check
npm run demo
npm run demo:narrative
npm run demo:flow
npm run demo:draft
npm run demo:situations
npm run demo:mcp
npm run demo:web
```

The interactive demo runs at [127.0.0.1:8093](http://127.0.0.1:8093/), with fake game/reasoning adapters. It exercises a forester and a bodyless director in one runtime.

- [CAI adapter and simple chat demo](docs/CAI-ADAPTER.md): persistent conversations, typed feedback, exact retries and pending live API seams.
- [Trusted binding publication and recovery](docs/BINDING-LIFECYCLE.md): delivered foundation metadata API, host journal and pending live integration.
- [Concept](docs/CONCEPT.md): purpose, persistent session model, character behavior and ownership.
- [Roadmap](docs/ROADMAP.md): staged integration and behavior development.
- [Narrative core and demos](docs/NARRATIVE.md): executable quests, player choices, progress, draft templates and replay/checkpoints.
- [Incremental quest authoring](docs/QUEST-AUTHORING.md): build/validate one task or stage at a time through pure scoped tools, then publish.
- [Ordered quests and player branches](docs/QUEST-FLOWS.md): optional stage flows, dialogue, incremental local drafting and a small headless example.
- [Zemegagame reuse assessment](docs/ZEMEGAGAME-REFERENCE.md): reusable ideas and easier CAI authoring.
- [MCP server and CAI connection handoff](docs/MCP-SERVER.md): simple demos, host integration, bound headers, retries and limitations.
- [MCP tool contract proposal](docs/MCP-CONTRACTS.md): bound calls, four tool schemas and forester/director examples for CAI review.
- [Foundation API and demos](docs/FOUNDATION.md): lifecycle, capability dispatch, scheduling, tooling and current limits.
- [CompanionAI discussion](docs/COMPANIONAI-REQUESTS.md): what we imagine and what CAI can provide or extend; not an implementation assignment.

Only this workspace is writable for this task. Rocket Engine v2, the original Rocket demo, CompanionAI Next and Zemegagame remain read-only references.

Native browser consumption and package proof: [Browser package contract](docs/BROWSER-PACKAGE.md).
