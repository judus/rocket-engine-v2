import { immutable, isJson } from '../json.js';
import { canonical, record, shape, text } from '../narrative/validation.js';
import type { CharacterHandle } from '../Runtime.js';
import type { CharacterDefinition, Json } from '../types.js';
import {
  conditions,
  conditionKey,
  field,
  references,
  validateOutput,
  validateSituationDefinition,
} from './validation.js';
import type {
  Situation,
  SituationCursor,
  SituationDefinition,
  SituationGame,
  SituationInvocation,
  SituationObservation,
  SituationRun,
  SituationSave,
  SituationScope,
  SituationView,
} from './types.js';

type Owner = () => CharacterDefinition;
type Command = {
  owner: Owner;
  key: string;
  input: Json;
  apply: (
    save: SituationSave,
    character: CharacterDefinition,
  ) => Promise<Json> | Json;
  resolve: (value: Json) => void;
  reject: (error: unknown) => void;
};
interface Projection {
  revision: number;
  observationRevision: string;
  values: Map<string, boolean | null>;
}
/** Shared bounded host-driven interpreter. No CAI, world mechanics or private timer. */
export class SituationSystem {
  readonly #associationId: string;
  readonly #game: SituationGame;
  #state: SituationSave;
  readonly #owners = new Map<string, Owner>();
  readonly #projections = new Map<string, Projection>();
  #commands: Command[] = [];
  #activeCommand: Command | undefined;
  #restoreNeedsPersist = false;
  #busy = false;
  #ready: (() => void) | undefined;
  #disposed = false;
  #epoch = 0;
  #scan = 0;
  #observationGuards: (() => boolean)[] = [];
  #time = 0;
  #lastJournal: SituationSave | undefined;
  #paused = false;
  readonly #controller = new AbortController();
  constructor(options: { associationId: string; game: SituationGame }) {
    if (!text(options.associationId))
      throw new TypeError('Association required');
    this.#associationId = options.associationId;
    this.#game = options.game;
    this.#state = {
      schemaVersion: 1,
      associationId: options.associationId,
      definitions: [],
      runs: [],
      receipts: [],
    };
  }
  bind(handle: CharacterHandle): SituationHandle {
    this.#assertLive();
    const owner = () => handle.snapshot();
    const key = this.#ownerKey(owner());
    this.#owners.set(key, owner);
    return new SituationHandle(
      (definition, effect) =>
        this.#command(
          owner,
          effect,
          { kind: 'publish', definition: definition as unknown as Json },
          (save, character) => {
            const issues = validateSituationDefinition(
              definition,
              this.#capabilities(character),
            );
            if (issues.length) throw new Error(issues.join('; '));
            if (
              save.definitions.length >= 256 ||
              save.definitions.some(
                (d) => d.ownerKey === key && d.definition.id === definition.id,
              )
            )
              throw new Error('Definition capacity or duplicate identity');
            this.#replaceDefinitions(save, [
              ...save.definitions,
              { ownerKey: key, definition: immutable(definition) },
            ]);
            return { definitionId: definition.id };
          },
        ),
      (id, scope, effect) =>
        this.#command(
          owner,
          effect,
          { kind: 'start', definitionId: id, scope: scope as unknown as Json },
          (save, character) => {
            this.#scope(character, scope);
            const definition = this.#definition(save, key, id);
            if (
              save.runs.length >= 256 ||
              save.runs.some(
                (r) =>
                  r.ownerKey === key &&
                  r.definitionId === id &&
                  canonical(r.scope) === canonical(scope),
              )
            )
              throw new Error('Run already armed or capacity exceeded');
            const run: SituationRun = {
              id: crypto.randomUUID(),
              definitionId: id,
              ownerKey: key,
              generation: character.binding?.generation ?? '',
              originGeneration: character.binding?.generation ?? '',
              scope: immutable(scope),
              revision: 0,
              path: [definition.start],
              entries: [{ situationId: definition.start, actions: [] }],
              cursors: [],
              status: 'entering',
            };
            this.#replaceRuns(save, [...save.runs, run]);
            return this.#view(run, definition) as unknown as Json;
          },
        ),
      (runId) => {
        const character = owner();
        const run = this.#run(this.#state, key, runId, character);
        return this.#view(
          run,
          this.#definition(this.#state, key, run.definitionId),
        );
      },
      (runId, choiceId, revision, effect) =>
        this.#command(
          owner,
          effect,
          { kind: 'choose', runId, choiceId, revision },
          async (save, character) => {
            const run = this.#run(save, key, runId, character);
            const definition = this.#definition(save, key, run.definitionId);
            const node = this.#node(run, definition);
            if (run.status !== 'waiting' || run.revision !== revision)
              throw new Error('Stale or blocked choice');
            const index = (node.choices ?? []).findIndex(
              (_, i) => this.#choiceId(run, i) === choiceId,
            );
            const choice = node.choices?.[index];
            if (!choice) throw new Error('Choice unavailable');
            const observation = await this.#observe(run, definition, character);
            if (this.#automatic(node, observation.values) !== null)
              throw new Error('Automatic route must settle before choice');
            if (
              (node.dialogue?.requires &&
                observation.values.get(conditionKey(node.dialogue.requires)) !==
                  true) ||
              (choice.when &&
                observation.values.get(conditionKey(choice.when)) !== true)
            )
              throw new Error('Interaction or choice condition unavailable');
            this.#enter(run, choice.next);
            return { runId, revision: run.revision, situationId: choice.next };
          },
        ),
      (runId, effect) =>
        this.#command(
          owner,
          effect,
          { kind: 'retire', runId },
          (save, character) => {
            const run = this.#run(save, key, runId, character);
            run.status = 'retiring';
            run.retirementRequested = true;
            run.revision++;
            return { runId, status: run.status };
          },
        ),
    );
  }
  get stats() {
    return Object.freeze({
      definitions: this.#state.definitions.length,
      runs: this.#state.runs.length,
      receipts: this.#state.receipts.length,
      pendingCommands: this.#commands.length,
      busy: this.#busy,
      disposed: this.#disposed,
      paused: this.#paused,
    });
  }
  advance(seconds = 0): void {
    this.#assertLive();
    if (!Number.isFinite(seconds) || seconds < 0)
      throw new TypeError('Nonnegative time required');
    this.#time += seconds;
    if (this.#ready) {
      const ready = this.#ready;
      this.#ready = undefined;
      ready();
    }
    if (this.#busy || this.#paused) return;
    const command = this.#commands.shift();
    if (command) {
      this.#launch(command);
      return;
    }
    for (let n = 0; n < this.#state.runs.length; n++) {
      const run = this.#state.runs[this.#scan++ % this.#state.runs.length];
      if (!run || run.status === 'closed' || run.status === 'retired') continue;
      const owner = this.#owners.get(run.ownerKey);
      if (!owner) continue;
      let character: CharacterDefinition;
      try {
        character = owner();
        this.#run(this.#state, run.ownerKey, run.id, character);
      } catch {
        continue;
      }
      this.#launchStep(run.id, owner);
      break;
    }
  }
  setPaused(paused: boolean): void {
    this.#assertLive();
    this.#paused = paused;
  }
  save(): SituationSave {
    this.#assertLive();
    return immutable(this.#lastJournal ?? this.#state);
  }
  restore(value: unknown): void {
    this.#assertLive();
    if (this.#busy || this.#commands.length)
      throw new Error('Restore requires quiescent interpreter');
    this.#validateSave(value);
    this.#state = structuredClone(value);
    for (const run of this.#state.runs) {
      const owner = this.#owners.get(run.ownerKey);
      if (owner) run.generation = owner().binding?.generation ?? '';
    }
    this.#restoreNeedsPersist = true;
    this.#lastJournal = undefined;
    this.#projections.clear();
    this.#epoch++;
  }
  dispose(): void {
    if (this.#disposed) return;
    this.#disposed = true;
    this.#controller.abort();
    this.#activeCommand?.reject(new Error('Disposed'));
    this.#activeCommand = undefined;
    this.#epoch++;
    this.#ready = undefined;
    for (const command of this.#commands.splice(0))
      command.reject(new Error('Disposed'));
    this.#owners.clear();
    this.#projections.clear();
  }
  #command(
    owner: Owner,
    effect: string,
    input: Json,
    apply: Command['apply'],
  ): Promise<Json> {
    this.#assertLive();
    owner();
    if (!text(effect) || !isJson(input) || this.#commands.length >= 64)
      return Promise.reject(new Error('Invalid command or command capacity'));
    return new Promise((resolve, reject) =>
      this.#commands.push({
        owner,
        key: effect,
        input: immutable(input),
        apply,
        resolve,
        reject,
      }),
    );
  }
  #launch(command: Command): void {
    this.#activeCommand = command;
    this.#busy = true;
    this.#observationGuards = [];
    const epoch = this.#epoch;
    void (async () => {
      const character = command.owner();
      const ownerKey = this.#ownerKey(character);
      const key = canonical([ownerKey, command.key]);
      const digest = canonical(command.input);
      const previous = this.#state.receipts.find((r) => r.key === key);
      if (previous) {
        if (previous.digest !== digest) throw new Error('Effect key conflict');
        return { state: this.#state, result: previous.result };
      }
      if (this.#state.receipts.length >= 4096)
        throw new Error('Receipt capacity exceeded');
      const state = structuredClone(this.#state);
      const result = await command.apply(state, character);
      command.owner();
      Object.assign(state, {
        receipts: [
          ...state.receipts,
          { key, digest, result: immutable(result) },
        ],
      });
      for (const run of state.runs) {
        const prior = this.#state.runs.find((r) => r.id === run.id);
        if (!prior || prior.path.length !== run.path.length)
          await this.#prepareBoundary(
            state,
            run,
            this.#definition(state, run.ownerKey, run.definitionId),
            character,
          );
      }
      await this.#persist(state);
      command.owner();
      return { state, result };
    })().then(
      ({ state, result }) => {
        if (this.#disposed || epoch !== this.#epoch) {
          command.reject(new Error('Disposed'));
          return;
        }
        this.#ready = () => {
          this.#busy = false;
          this.#activeCommand = undefined;
          this.#state = state;
          command.resolve(immutable(result));
        };
      },
      (error: unknown) => {
        if (this.#disposed || epoch !== this.#epoch) {
          command.reject(error);
          return;
        }
        this.#ready = () => {
          this.#busy = false;
          if (this.#lastJournal)
            this.#state = structuredClone(this.#lastJournal);
          command.reject(error);
        };
      },
    );
  }
  #launchStep(runId: string, owner: Owner): void {
    this.#busy = true;
    this.#observationGuards = [];
    const epoch = this.#epoch;
    const state = structuredClone(this.#state);
    const character = owner();
    const key = this.#ownerKey(character);
    const run = this.#run(state, key, runId, character);
    void this.#step(
      run,
      this.#definition(state, key, run.definitionId),
      character,
      state,
    )
      .then(async (projection) => {
        owner();
        await this.#persist(state);
        owner();
        if (this.#disposed || epoch !== this.#epoch) return;
        this.#ready = () => {
          this.#busy = false;
          this.#state = state;
          if (projection) this.#projections.set(runId, projection);
        };
      })
      .catch((error: unknown) => {
        if (this.#disposed || epoch !== this.#epoch) return;
        this.#ready = () => {
          this.#busy = false;
          if (this.#lastJournal)
            this.#state = structuredClone(this.#lastJournal);
          const current = this.#state.runs.find((r) => r.id === runId);
          if (current) {
            current.status = 'blocked';
            current.error =
              error instanceof Error ? error.message : 'Host failure';
            this.#projections.delete(runId);
          }
        };
      });
  }
  async #step(
    run: SituationRun,
    definition: SituationDefinition,
    character: CharacterDefinition,
    state: SituationSave,
  ): Promise<Projection | undefined> {
    if (this.#restoreNeedsPersist) {
      await this.#persist(state);
      this.#restoreNeedsPersist = false;
    }
    const context = this.#context(run, character);
    const node = this.#node(run, definition);
    if (run.retirementRequested) {
      await this.#game.retire(context);
      run.status = 'retired';
      run.revision++;
      delete run.error;
      return undefined;
    }
    const pendingCursor = run.cursors.find((c) => !Object.hasOwn(c, 'cursor'));
    if (pendingCursor) {
      const cursor = await this.#game.capture(
        this.#context(run, character, pendingCursor.effectId),
        pendingCursor.streamRef,
        pendingCursor.arguments,
      );
      if (!isJson(cursor)) throw new Error('Invalid evidence cursor');
      pendingCursor.cursor = immutable(cursor);
      run.revision++;
      return undefined;
    }
    const needed = this.#captureRequirements(run, definition, character);
    if (needed.length) {
      await this.#prepareBoundary(state, run, definition, character);
      return undefined;
    }
    const entry = run.entries[run.entries.length - 1];
    if (!entry) throw new Error('Missing entry');
    const actions = node.onEnter ?? [];
    const incomplete = entry.actions.find((a) => a.state !== 'completed');
    if (incomplete) {
      const action = actions.find((a) => a.id === incomplete.id);
      if (!action) throw new Error('Unknown entry action');
      const capability = this.#capability(character, action.tool, 'action');
      const invocation = this.#context(run, character, incomplete.effectId);
      if (!capability.validate(incomplete.arguments))
        throw new Error('Resolved action input rejected');
      const priorOutcome = JSON.stringify({
        action: incomplete,
        status: run.status,
        error: run.error,
      });
      let result = await this.#game.reconcile(
        invocation,
        capability,
        incomplete.arguments,
        incomplete.operationId,
      );
      if (result.status === 'unknown') {
        run.status = 'blocked';
        run.error = 'Action outcome unknown';
        return undefined;
      }
      this.#ensureCurrent(run);
      if (result.status === 'not_admitted')
        result = await capability.execute(
          invocation,
          immutable(incomplete.arguments),
        );
      if (result.status === 'completed') {
        if (!validateOutput(capability, result.data))
          throw new Error('Action output schema mismatch');
        incomplete.state = 'completed';
        incomplete.result = immutable(result.data);
        delete incomplete.operationId;
        delete incomplete.code;
        run.status = 'entering';
        delete run.error;
      } else if (result.status === 'running' && text(result.operationId)) {
        incomplete.state = 'running';
        incomplete.operationId = result.operationId;
        run.status = 'entering';
      } else if (result.status === 'rejected') {
        incomplete.state = 'rejected';
        incomplete.code = result.code;
        run.status = 'blocked';
        run.error = result.code;
      } else throw new Error('Invalid action reconciliation');
      if (
        priorOutcome !==
        JSON.stringify({
          action: incomplete,
          status: run.status,
          error: run.error,
        })
      )
        run.revision++;
      return undefined;
    }
    const nextAction = actions[entry.actions.length];
    if (nextAction) {
      const capability = this.#capability(character, nextAction.tool, 'action');
      const arguments_ = this.#resolve(run, nextAction.arguments);
      if (!capability.validate(arguments_))
        throw new Error('Resolved action input rejected');
      entry.actions.push({
        id: nextAction.id,
        effectId:
          run.id + '/' + String(run.path.length - 1) + '/' + nextAction.id,
        arguments: arguments_,
        state: 'prepared',
      });
      run.status = 'entering';
      run.revision++;
      return undefined;
    }
    if (!(node.routes?.length || node.choices?.length)) {
      const projection =
        node.dialogue?.requires || node.objectives?.length
          ? await this.#observe(run, definition, character)
          : undefined;
      run.status = 'closed';
      delete run.error;
      run.revision++;
      return projection ? { ...projection, revision: run.revision } : undefined;
    }
    const projection = await this.#observe(run, definition, character);
    const next = this.#automatic(node, projection.values);
    run.status = 'waiting';
    delete run.error;
    if (typeof next === 'string') {
      this.#enter(run, next);
      await this.#prepareBoundary(state, run, definition, character);
      return undefined;
    }
    if (next === undefined) {
      run.status = 'blocked';
      run.error = 'Higher-priority route evidence unknown';
    }
    return { ...projection, revision: run.revision };
  }
  #captureRequirements(
    run: SituationRun,
    definition: SituationDefinition,
    character: CharacterDefinition,
  ): SituationCursor[] {
    const result: SituationCursor[] = [];
    const current = run.path[run.path.length - 1];
    if (!current) throw new Error('Missing current situation');
    for (const { condition } of conditions(definition)) {
      if (condition.evidence.mode !== 'events') continue;
      const boundary =
        condition.evidence.after.kind === 'run-start'
          ? 'run-start'
          : 'entry:' + condition.evidence.after.situationRef;
      if (boundary !== 'run-start' && boundary !== 'entry:' + current) continue;
      const metadata = this.#capability(
        character,
        condition.tool,
        'inspection',
      ).evidenceStream;
      if (!metadata) throw new Error('Missing event stream');
      const arguments_: Record<string, Json> = {};
      for (const key of metadata.captureKeys) {
        const value = condition.arguments[key];
        if (value === undefined) throw new Error('Missing capture key');
        arguments_[key] = this.#resolveValue(run, value);
      }
      const key = canonical([boundary, metadata.ref, arguments_]);
      if (
        run.cursors.some((c) => c.key === key) ||
        result.some((c) => c.key === key)
      )
        continue;
      result.push({
        key,
        boundary,
        streamRef: metadata.ref,
        arguments: arguments_,
        effectId:
          run.id + '/capture/' + String(run.cursors.length + result.length),
      });
    }
    return result;
  }
  async #observe(
    run: SituationRun,
    definition: SituationDefinition,
    character: CharacterDefinition,
  ): Promise<Projection> {
    const node = this.#node(run, definition);
    const selected = conditions({ ...definition, situations: [node] }).map(
      (c) => c.condition,
    );
    const unique = [
      ...new Map(selected.map((c) => [conditionKey(c), c])).values(),
    ];
    const observations: SituationObservation[] = [];
    for (const condition of unique) {
      const capability = this.#capability(
        character,
        condition.tool,
        'inspection',
      );
      const arguments_ = this.#resolve(run, condition.arguments);
      if (!capability.validate(arguments_))
        throw new Error('Resolved inspection input rejected');
      if (condition.evidence.mode === 'fact')
        observations.push({ capability, arguments: arguments_ });
      else {
        const metadata = capability.evidenceStream;
        if (!metadata) throw new Error('Missing event stream');
        const capture: Record<string, Json> = {};
        for (const key of metadata.captureKeys) {
          const value = arguments_[key];
          if (value === undefined) throw new Error('Missing capture scope');
          capture[key] = value;
        }
        const boundary =
          condition.evidence.after.kind === 'run-start'
            ? 'run-start'
            : 'entry:' + condition.evidence.after.situationRef;
        const cursor = run.cursors.find(
          (c) => c.key === canonical([boundary, metadata.ref, capture]),
        );
        if (!cursor || !Object.hasOwn(cursor, 'cursor'))
          throw new Error('Evidence boundary unavailable');
        observations.push({
          capability,
          arguments: arguments_,
          evidence: {
            streamRef: metadata.ref,
            cursor: cursor.cursor ?? null,
            arguments: capture,
          },
        });
      }
    }
    const observationContext = this.#context(run, character);
    const batch = await this.#game.observe(
      observationContext,
      Object.freeze(
        observations.map((observation) => Object.freeze(observation)),
      ),
    );
    if (!text(batch.revision) || batch.results.length !== unique.length)
      throw new Error('Incoherent observation batch');
    this.#observationGuards.push(() =>
      this.#game.observationCurrent(observationContext, batch.revision),
    );
    const values = new Map<string, boolean | null>();
    unique.forEach((condition, i) => {
      const result = batch.results[i];
      const capability = observations[i]?.capability;
      const data =
        result?.status === 'completed' &&
        capability &&
        validateOutput(capability, result.data)
          ? field(result.data, condition.expect.path)
          : undefined;
      const expected = condition.expect;
      let matched: boolean | null = null;
      if (
        expected.operator === 'at_least' &&
        typeof data === 'number' &&
        typeof expected.value === 'number'
      )
        matched = data >= expected.value;
      else if (
        expected.operator === 'equals' &&
        typeof data === typeof expected.value &&
        (data === null || ['string', 'boolean', 'number'].includes(typeof data))
      )
        matched = data === expected.value;
      values.set(conditionKey(condition), matched);
    });
    return {
      revision: run.revision,
      observationRevision: batch.revision,
      values,
    };
  }
  #automatic(
    node: Situation,
    values: Map<string, boolean | null>,
  ): string | null | undefined {
    for (const route of node.routes ?? []) {
      const value = values.get(conditionKey(route.when));
      if (value === null || value === undefined) return undefined;
      if (value) return route.next;
    }
    return null;
  }
  #view(run: SituationRun, definition: SituationDefinition): SituationView {
    const node = this.#node(run, definition),
      projection = this.#projections.get(run.id);
    const values =
      projection?.revision === run.revision ? projection.values : undefined;
    const permitted =
      !node.dialogue?.requires ||
      values?.get(conditionKey(node.dialogue.requires)) === true;
    return immutable({
      runId: run.id,
      definitionId: run.definitionId,
      revision: run.revision,
      situationId: node.id,
      status: run.status,
      ...(run.error ? { error: run.error } : {}),
      dialogue:
        permitted && (run.status === 'waiting' || run.status === 'closed')
          ? (node.dialogue?.text ?? null)
          : null,
      choices:
        run.status === 'waiting' &&
        permitted &&
        values &&
        this.#automatic(node, values) === null
          ? (node.choices ?? []).flatMap((c, i) =>
              !c.when || values.get(conditionKey(c.when)) === true
                ? [{ id: this.#choiceId(run, i), label: c.label }]
                : [],
            )
          : [],
      objectives: (node.objectives ?? []).map((o) => ({
        id: o.id,
        satisfied: values?.get(conditionKey(o.condition)) ?? null,
      })),
      observationRevision: projection?.observationRevision ?? null,
    });
  }
  #enter(run: SituationRun, destination: string) {
    run.path.push(destination);
    run.entries.push({ situationId: destination, actions: [] });
    run.status = 'entering';
    run.revision++;
    delete run.error;
    this.#projections.delete(run.id);
  }
  #choiceId(run: SituationRun, index: number) {
    return 'sit/' + run.id + '/' + String(run.revision) + '/' + String(index);
  }
  #resolve(
    run: SituationRun,
    input: Readonly<Record<string, unknown>>,
  ): Record<string, Json> {
    return Object.fromEntries(
      Object.entries(input).map(([key, value]) => [
        key,
        this.#resolveValue(run, value),
      ]),
    );
  }
  #resolveValue(run: SituationRun, value: unknown): Json {
    if (record(value) && record(value['$result'])) {
      const r = references(value)[0];
      const entry = run.entries.find((e) => e.situationId === r?.situationRef);
      const action = entry?.actions.find(
        (a) => a.id === r?.actionId && a.state === 'completed',
      );
      const result = r ? field(action?.result, r.path) : undefined;
      if (!isJson(result))
        throw new Error('Acknowledged result field unavailable');
      return immutable(result);
    }
    if (Array.isArray(value))
      return value.map((v: unknown) => this.#resolveValue(run, v));
    if (record(value)) return this.#resolve(run, value);
    if (!isJson(value)) throw new Error('Invalid argument JSON');
    return value;
  }
  async #persist(state: SituationSave): Promise<void> {
    if (
      !isJson(state) ||
      new TextEncoder().encode(JSON.stringify(state)).length > 64 * 1024 * 1024
    )
      throw new Error('Journal JSON/byte limit');
    if (!this.#observationGuards.every((check) => check()))
      throw new Error('Observation revision stale');
    if (
      this.#lastJournal &&
      canonical(state) === canonical(this.#lastJournal as unknown as Json)
    )
      return;
    await this.#game.persist(immutable(state));
    if (!this.#observationGuards.every((check) => check())) {
      await this.#game.persist(immutable(this.#state));
      this.#lastJournal = structuredClone(this.#state);
      throw new Error('Observation revision stale');
    }
    this.#lastJournal = structuredClone(state);
  }
  #ensureCurrent(run: SituationRun): void {
    this.#assertLive();
    const owner = this.#owners.get(run.ownerKey);
    if (!owner) throw new Error('Owner unavailable');
    this.#run(this.#state, run.ownerKey, run.id, owner());
  }
  async #prepareBoundary(
    state: SituationSave,
    run: SituationRun,
    definition: SituationDefinition,
    character: CharacterDefinition,
  ): Promise<void> {
    const needed = this.#captureRequirements(run, definition, character);
    if (run.cursors.length + needed.length > 256)
      throw new Error('Evidence cursor capacity exceeded');
    run.cursors.push(...needed);
    if (needed.length) await this.#persist(state);
    for (const cursor of run.cursors.filter(
      (c) => !Object.hasOwn(c, 'cursor'),
    )) {
      const captured = await this.#game.capture(
        this.#context(run, character, cursor.effectId),
        cursor.streamRef,
        immutable(cursor.arguments),
      );
      if (!isJson(captured)) throw new Error('Invalid evidence cursor');
      cursor.cursor = immutable(captured);
      run.revision++;
      await this.#persist(state);
    }
  }
  #context(
    run: SituationRun,
    character: CharacterDefinition,
    effectId?: string,
  ): SituationInvocation {
    const action = run.entries
      .flatMap((e) => e.actions)
      .find((a) => a.effectId === effectId);
    const capture = run.cursors.find((c) => c.effectId === effectId);
    const argumentDigest = action
      ? canonical(action.arguments)
      : capture
        ? canonical(capture.arguments)
        : undefined;
    return Object.freeze({
      gameId: this.#associationId,
      character,
      requestId: effectId ?? run.id,
      time: this.#time,
      signal: this.#controller.signal,
      narrative: immutable({
        runId: run.id,
        scope: run.scope,
        entryId: String(run.path.length - 1),
        originGeneration: run.originGeneration,
        ...(effectId ? { effectId } : {}),
        ...(argumentDigest ? { argumentDigest } : {}),
      }),
    });
  }
  #scope(
    character: CharacterDefinition,
    scope: unknown,
  ): asserts scope is SituationScope {
    if (
      !record(scope) ||
      (scope['kind'] !== 'world' && scope['kind'] !== 'player') ||
      (scope['kind'] === 'player' &&
        (!shape(scope, ['kind', 'ref']) || !text(scope['ref']))) ||
      (scope['kind'] === 'world' && !shape(scope, ['kind'])) ||
      !this.#game.scopeAvailable(character, scope as SituationScope)
    )
      throw new Error('Narrative scope unavailable');
  }
  #ownerKey(character: CharacterDefinition): string {
    if (!character.binding) throw new Error('Registered owner required');
    return canonical([this.#associationId, character.binding.id, character.id]);
  }
  #capabilities(character: CharacterDefinition) {
    return this.#game
      .capabilities(character)
      .filter((c) => character.capabilities.includes(c.name));
  }
  #capability(
    character: CharacterDefinition,
    name: string,
    kind: 'action' | 'inspection',
  ) {
    const c = this.#capabilities(character).find(
      (c) => c.name === name && c.kind === kind,
    );
    if (!c) throw new Error('Capability unavailable');
    return c;
  }
  #definition(save: SituationSave, key: string, id: string) {
    const d = save.definitions.find(
      (d) => d.ownerKey === key && d.definition.id === id,
    );
    if (!d) throw new Error('Definition unavailable');
    return d.definition;
  }
  #run(
    save: SituationSave,
    key: string,
    id: string,
    character: CharacterDefinition,
  ) {
    const run = save.runs.find((r) => r.ownerKey === key && r.id === id);
    if (!run || run.generation !== character.binding?.generation)
      throw new Error('Run authority stale or unavailable');
    this.#scope(character, run.scope);
    return run;
  }
  #node(run: SituationRun, definition: SituationDefinition) {
    const node = definition.situations.find(
      (n) => n.id === run.path[run.path.length - 1],
    );
    if (!node) throw new Error('Situation unavailable');
    return node;
  }
  #replaceDefinitions(
    save: SituationSave,
    definitions: SituationSave['definitions'],
  ) {
    Object.assign(save, { definitions });
  }
  #replaceRuns(save: SituationSave, runs: SituationSave['runs']) {
    Object.assign(save, { runs });
  }
  #assertLive() {
    if (this.#disposed) throw new Error('Situation interpreter disposed');
  }
  #validateSave(value: unknown): asserts value is SituationSave {
    if (
      !isJson(value) ||
      !shape(value, [
        'schemaVersion',
        'associationId',
        'definitions',
        'runs',
        'receipts',
      ]) ||
      value['schemaVersion'] !== 1 ||
      value['associationId'] !== this.#associationId ||
      !Array.isArray(value['definitions']) ||
      !Array.isArray(value['runs']) ||
      !Array.isArray(value['receipts']) ||
      value['definitions'].length > 256 ||
      value['runs'].length > 256 ||
      value['receipts'].length > 4096
    )
      throw new Error('Invalid situation checkpoint');
    if (
      new TextEncoder().encode(JSON.stringify(value)).length >
      64 * 1024 * 1024
    )
      throw new Error('Checkpoint byte limit');
    const save = value as unknown as SituationSave;
    const ids = new Set<string>();
    for (const item of save.definitions) {
      if (!text(item.ownerKey)) throw new Error('Invalid definition owner');
      const owner = this.#owners.get(item.ownerKey);
      if (
        !owner ||
        validateSituationDefinition(
          item.definition,
          this.#capabilities(owner()),
        ).length ||
        ids.has(item.ownerKey + '/' + item.definition.id)
      )
        throw new Error('Invalid restored definition');
      ids.add(item.ownerKey + '/' + item.definition.id);
    }
    ids.clear();
    for (const run of save.runs) {
      if (
        !text(run.id) ||
        !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u.test(
          run.id,
        ) ||
        ids.has(run.id) ||
        !Number.isSafeInteger(run.revision) ||
        run.revision < 0 ||
        !Array.isArray(run.path) ||
        run.path.length < 1 ||
        run.path.length > 16 ||
        !Array.isArray(run.entries) ||
        run.entries.length !== run.path.length ||
        !Array.isArray(run.cursors) ||
        run.cursors.length > 256 ||
        ![
          'entering',
          'waiting',
          'blocked',
          'closed',
          'retiring',
          'retired',
        ].includes(run.status)
      )
        throw new Error('Invalid restored run');
      ids.add(run.id);
      const owner = this.#owners.get(run.ownerKey);
      if (!owner) throw new Error('Restore requires live owner');
      const character = owner();
      this.#scope(character, run.scope);
      if (
        !text(run.originGeneration) ||
        !text(run.generation) ||
        (run.generation !== character.binding?.generation &&
          !this.#game.authorizeRestore?.(
            character,
            run.generation,
            run.scope,
            run.id,
          ))
      )
        throw new Error(
          'Restored registration requires explicit host reconciliation',
        );
      const definition = this.#definition(save, run.ownerKey, run.definitionId);
      if (
        run.path[0] !== definition.start ||
        new Set(run.path).size !== run.path.length
      )
        throw new Error('Invalid restored path');
      run.path.forEach((id, index) => {
        const node = definition.situations.find((n) => n.id === id);
        const entry = run.entries[index];
        if (
          !node ||
          entry?.situationId !== id ||
          !Array.isArray(entry.actions) ||
          entry.actions.length > (node.onEnter?.length ?? 0)
        )
          throw new Error('Invalid restored entry');
        if (index > 0) {
          const parent = definition.situations.find(
            (n) => n.id === run.path[index - 1],
          );
          if (
            ![...(parent?.choices ?? []), ...(parent?.routes ?? [])].some(
              (r) => r.next === id,
            )
          )
            throw new Error('Impossible restored path');
        }
        entry.actions.forEach((a, i) => {
          const authored = node.onEnter?.[i];
          if (
            !authored ||
            a.id !== authored.id ||
            a.effectId !== run.id + '/' + String(index) + '/' + a.id ||
            !['prepared', 'running', 'completed', 'rejected'].includes(
              a.state,
            ) ||
            (i + 1 < entry.actions.length && a.state !== 'completed') ||
            canonical(a.arguments) !==
              canonical(this.#resolve(run, authored.arguments))
          )
            throw new Error('Invalid restored action');
          const c = this.#capability(owner(), authored.tool, 'action');
          if (
            !c.validate(a.arguments) ||
            (a.state === 'completed' && !validateOutput(c, a.result)) ||
            (a.state === 'running' && !text(a.operationId))
          )
            throw new Error('Invalid restored action outcome');
        });
        if (
          index + 1 < run.path.length &&
          (entry.actions.length !== (node.onEnter?.length ?? 0) ||
            entry.actions.some((a) => a.state !== 'completed'))
        )
          throw new Error('Unacknowledged prior entry');
      });
      if (new Set(run.cursors.map((c) => c.key)).size !== run.cursors.length)
        throw new Error('Duplicate cursors');
      run.cursors.forEach((c, i) => {
        if (
          c.effectId !== run.id + '/capture/' + String(i) ||
          c.key !== canonical([c.boundary, c.streamRef, c.arguments]) ||
          !text(c.streamRef) ||
          (c.boundary !== 'run-start' &&
            !run.path.some((id) => c.boundary === 'entry:' + id))
        )
          throw new Error('Invalid restored cursor');
      });
      const node = this.#node(run, definition);
      if (
        run.status === 'closed' &&
        (node.routes?.length ||
          node.choices?.length ||
          run.entries.at(-1)?.actions.some((a) => a.state !== 'completed') ||
          run.entries.at(-1)?.actions.length !== (node.onEnter?.length ?? 0))
      )
        throw new Error('Premature closed run');
    }
    const keys = new Set<string>();
    for (const receipt of save.receipts) {
      if (
        !text(receipt.key, 2000) ||
        keys.has(receipt.key) ||
        !text(receipt.digest, 65536) ||
        !isJson(receipt.result)
      )
        throw new Error('Invalid restored receipt');
      keys.add(receipt.key);
    }
  }
}
export class SituationHandle {
  readonly #publish: (
    definition: SituationDefinition,
    effectKey: string,
  ) => Promise<Json>;
  readonly #start: (
    definitionId: string,
    scope: SituationScope,
    effectKey: string,
  ) => Promise<Json>;
  readonly #choose: (
    runId: string,
    choiceId: string,
    expectedRevision: number,
    effectKey: string,
  ) => Promise<Json>;
  readonly #retire: (runId: string, effectKey: string) => Promise<Json>;
  constructor(
    publish: (
      definition: SituationDefinition,
      effectKey: string,
    ) => Promise<Json>,
    start: (
      definitionId: string,
      scope: SituationScope,
      effectKey: string,
    ) => Promise<Json>,
    readonly read: (runId: string) => SituationView,
    choose: (
      runId: string,
      choiceId: string,
      expectedRevision: number,
      effectKey: string,
    ) => Promise<Json>,
    retire: (runId: string, effectKey: string) => Promise<Json>,
  ) {
    this.#publish = publish;
    this.#start = start;
    this.#choose = choose;
    this.#retire = retire;
  }
  async publish(
    definition: SituationDefinition,
    effectKey: string,
  ): Promise<{ readonly definitionId: string }> {
    return (await this.#publish(definition, effectKey)) as unknown as {
      readonly definitionId: string;
    };
  }
  async start(
    definitionId: string,
    scope: SituationScope,
    effectKey: string,
  ): Promise<SituationView> {
    return (await this.#start(
      definitionId,
      scope,
      effectKey,
    )) as unknown as SituationView;
  }
  async choose(
    runId: string,
    choiceId: string,
    expectedRevision: number,
    effectKey: string,
  ): Promise<{
    readonly runId: string;
    readonly revision: number;
    readonly situationId: string;
  }> {
    return (await this.#choose(
      runId,
      choiceId,
      expectedRevision,
      effectKey,
    )) as unknown as {
      readonly runId: string;
      readonly revision: number;
      readonly situationId: string;
    };
  }
  async retire(
    runId: string,
    effectKey: string,
  ): Promise<{ readonly runId: string; readonly status: 'retiring' }> {
    return (await this.#retire(runId, effectKey)) as unknown as {
      readonly runId: string;
      readonly status: 'retiring';
    };
  }
}
